"""액션 스케줄러 — 함수 제어 핸들러 믹스인."""

from __future__ import annotations

import logging

from engine.scheduler.models import MAX_FUNCTION_DEPTH, FunctionFrame, SchedulerError
from shared.models import FunctionCallAction, ReturnAction

logger = logging.getLogger(__name__)


class FunctionHandlersMixin:
    """FUNCTION_DEF, FUNCTION_CALL, RETURN 핸들러."""

    def _handle_function_def(self) -> None:
        """실행 흐름에서 함수 본문을 건너뛴다."""
        end_idx = self._function_end_map.get(self._program_counter)
        if end_idx is None:
            raise SchedulerError(
                f"액션 #{self._program_counter}: FunctionDef에 대응하는 FunctionEnd가 없음"
            )
        self._program_counter = end_idx + 1

    def _handle_function_call(self, action: FunctionCallAction) -> None:
        """함수를 호출한다."""
        if len(self._function_call_stack) >= MAX_FUNCTION_DEPTH:
            raise SchedulerError(f"함수 호출 깊이 제한 초과: 최대 {MAX_FUNCTION_DEPTH}단계")

        if action.target not in self._function_map:
            raise SchedulerError(
                f"액션 #{self._program_counter}: 함수 '{action.target}'을 찾을 수 없음"
            )

        func_idx = self._function_map[action.target]
        func_def = self._actions[func_idx]

        if len(action.args) != len(func_def.params):
            raise SchedulerError(
                f"함수 '{action.target}' 매개변수 {len(func_def.params)}개, "
                f"인자 {len(action.args)}개"
            )

        evaluated_args = [self._variables.evaluate(a) if a else "" for a in action.args]
        self._function_call_stack.append(
            FunctionFrame(return_address=self._program_counter + 1, return_var=action.return_var)
        )

        self._variables.push_scope()
        for param_name, arg_val in zip(func_def.params, evaluated_args, strict=False):
            self._variables.set(param_name, arg_val)

        self._program_counter = func_idx + 1
        logger.info("함수 호출: %s (depth=%d)", action.target, len(self._function_call_stack))

    def _handle_return(self, action: ReturnAction) -> None:
        """함수에서 반환한다."""
        if not self._function_call_stack:
            raise SchedulerError(f"액션 #{self._program_counter}: RETURN은 함수 안에서만 사용 가능")

        return_value = self._variables.evaluate(action.expression) if action.expression else ""
        self._variables.pop_scope()

        frame = self._function_call_stack.pop()
        if frame.return_var:
            self._variables.set_global(frame.return_var, return_value)

        self._program_counter = frame.return_address
        logger.info(
            "함수 반환: value=%s -> %s (depth=%d)",
            return_value,
            frame.return_var or "(없음)",
            len(self._function_call_stack),
        )

    def _handle_function_end(self) -> None:
        """RETURN 없이 함수 끝에 도달하면 빈 문자열로 암시적 반환한다."""
        if not self._function_call_stack:
            self._program_counter += 1
            return

        self._variables.pop_scope()
        frame = self._function_call_stack.pop()
        if frame.return_var:
            self._variables.set_global(frame.return_var, "")
        self._program_counter = frame.return_address
        logger.info(
            "함수 암시적 반환 (FUNCTION_END): -> %s (depth=%d)",
            frame.return_var or "(없음)",
            len(self._function_call_stack),
        )
