"""액션 스케줄러 — OCR 핸들러 믹스인."""

from __future__ import annotations

import logging

from shared.models import (
    OCRReadAction,
    OCRWaitAction,
)

logger = logging.getLogger(__name__)


class OCRHandlersMixin:
    """OCR 읽기·대기 액션 핸들러 믹스인."""

    def _handle_ocr_read(self, action: OCRReadAction) -> None:
        """화면 영역에서 OCR로 텍스트를 인식하여 변수에 저장한다."""
        if self._screen is None:
            logger.warning("ScreenAnalyzer 없음. OCRRead를 건너뜁니다.")
            self._safe_set_var(action.store_var, "")
            self._program_counter += 1
            return

        region_x, region_y, region_width, region_height = self._resolve_region_fields(
            region_x=action.region_x,
            region_y=action.region_y,
            region_width=action.region_width,
            region_height=action.region_height,
            region_x_expression=action.region_x_expression,
            region_y_expression=action.region_y_expression,
            region_xy_expression=action.region_xy_expression,
            region_end_x_expression=action.region_end_x_expression,
            region_end_y_expression=action.region_end_y_expression,
            region_end_xy_expression=action.region_end_xy_expression,
            action_index=self._program_counter,
            field_prefix="OCRRead(region)",
        )
        text = self._screen.ocr_read_text(
            region_x,
            region_y,
            region_width,
            region_height,
            action.lang,
            action.psm,
            action.whitelist,
            action.grayscale,
            action.invert,
            action.threshold,
        )

        result = text.strip() if action.strip_whitespace else text
        self._safe_set_var(action.store_var, result)
        logger.info(
            "OCRRead 완료: region=(%d,%d,%d,%d) → var=%s='%s'",
            region_x,
            region_y,
            region_width,
            region_height,
            action.store_var,
            result[:50],
        )
        self._program_counter += 1

    def _handle_ocr_wait(self, action: OCRWaitAction) -> None:
        """특정 텍스트가 화면에 나타날 때까지 OCR로 감시한다."""
        if self._screen is None:
            logger.warning("ScreenAnalyzer 없음. OCRWait 실패로 else 분기합니다.")
            self._jump_to_else_or_end("OCRWait")
            return

        region_x, region_y, region_width, region_height = self._resolve_region_fields(
            region_x=action.region_x,
            region_y=action.region_y,
            region_width=action.region_width,
            region_height=action.region_height,
            region_x_expression=action.region_x_expression,
            region_y_expression=action.region_y_expression,
            region_xy_expression=action.region_xy_expression,
            region_end_x_expression=action.region_end_x_expression,
            region_end_y_expression=action.region_end_y_expression,
            region_end_xy_expression=action.region_end_xy_expression,
            action_index=self._program_counter,
            field_prefix="OCRWait(region)",
        )
        result = self._screen.ocr_wait_for_text(
            region_x,
            region_y,
            region_width,
            region_height,
            action.pattern,
            action.use_regex,
            action.lang,
            action.psm,
            action.whitelist,
            action.grayscale,
            action.invert,
            action.threshold,
            action.timeout_ms,
            action.poll_interval_ms,
            stop_event=self._stop_event,
            link_lost_event=self._link_lost_event,
        )

        self._raise_if_link_lost()
        if result is not None:
            store_text = result.strip() if action.strip_whitespace else result
            self._safe_set_var(action.store_var, store_text)
            logger.info(
                "OCRWait 성공: pattern='%s' → '%s' timeout=%dms",
                action.pattern,
                store_text[:50],
                action.timeout_ms,
            )
            self._program_counter += 1
        else:
            logger.warning(
                "OCRWait 타임아웃: pattern='%s' timeout=%dms",
                action.pattern,
                action.timeout_ms,
            )
            self._jump_to_else_or_end("OCRWait")
