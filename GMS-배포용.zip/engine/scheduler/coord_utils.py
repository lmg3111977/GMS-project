"""액션 스케줄러 — 좌표 해석·마우스 동작 유틸리티 믹스인."""

from __future__ import annotations

import logging
import re

from engine.scheduler.models import SchedulerError
from shared.models import (
    MouseButton,
    MouseClickAction,
    MouseDragAction,
    MouseMoveAction,
)

logger = logging.getLogger(__name__)


class CoordUtilsMixin:
    """좌표 해석, 마우스 이동/클릭, 변수 저장 유틸리티 믹스인."""

    def _resolve_mouse_move_action(self, action: MouseMoveAction) -> MouseMoveAction:
        """MouseMove 좌표식을 실제 정수 좌표로 해석한 액션을 반환한다.

        우선순위:
        1) xy_expression ("x,y" 또는 "(x,y)")
        2) x_expression / y_expression (각각)
        3) 기존 x / y 숫자
        """
        x_val = action.x
        y_val = action.y

        xy_raw = (action.xy_expression or "").strip()
        if xy_raw:
            xy_eval = str(self._variables.evaluate(xy_raw)).strip()
            x_parsed, y_parsed = self._parse_xy_pair(xy_eval)
            if x_parsed is not None and y_parsed is not None:
                x_val, y_val = x_parsed, y_parsed
            else:
                logger.warning(
                    "MouseMove xy_expression 해석 실패: %r (액션 #%d). 기본 x/y를 사용합니다.",
                    xy_raw,
                    self._program_counter,
                )

        x_expr_raw = (action.x_expression or "").strip()
        if x_expr_raw:
            x_eval = self._variables.evaluate(x_expr_raw)
            x_val = self._coerce_eval_to_int(
                x_eval,
                field_name="x_expression",
                action_index=self._program_counter,
            )

        y_expr_raw = (action.y_expression or "").strip()
        if y_expr_raw:
            y_eval = self._variables.evaluate(y_expr_raw)
            y_val = self._coerce_eval_to_int(
                y_eval,
                field_name="y_expression",
                action_index=self._program_counter,
            )

        if not action.is_relative:
            x_val = max(0, min(7680, x_val))
            y_val = max(0, min(4320, y_val))

        return action.model_copy(
            update={
                "x": x_val,
                "y": y_val,
            }
        )

    def _resolve_mouse_drag_action(self, action: MouseDragAction) -> MouseDragAction:
        """MouseDrag 좌표식을 실제 정수 좌표로 해석한 액션을 반환한다."""
        sx, sy = self._resolve_xy_fields(
            x=action.start_x,
            y=action.start_y,
            x_expression=action.start_x_expression,
            y_expression=action.start_y_expression,
            xy_expression=action.start_xy_expression,
            x_min=0,
            x_max=7680,
            y_min=0,
            y_max=4320,
            action_index=self._program_counter,
            field_prefix="MouseDrag(start)",
        )
        ex, ey = self._resolve_xy_fields(
            x=action.end_x,
            y=action.end_y,
            x_expression=action.end_x_expression,
            y_expression=action.end_y_expression,
            xy_expression=action.end_xy_expression,
            x_min=0,
            x_max=7680,
            y_min=0,
            y_max=4320,
            action_index=self._program_counter,
            field_prefix="MouseDrag(end)",
        )
        return action.model_copy(
            update={
                "start_x": sx,
                "start_y": sy,
                "end_x": ex,
                "end_y": ey,
            }
        )

    def _resolve_xy_fields(
        self,
        *,
        x: int,
        y: int,
        x_expression: str | None,
        y_expression: str | None,
        xy_expression: str | None,
        x_min: int,
        x_max: int,
        y_min: int,
        y_max: int,
        action_index: int,
        field_prefix: str,
    ) -> tuple[int, int]:
        """x/y 및 좌표식을 우선순위에 따라 해석한다."""
        rx = x
        ry = y
        xy_raw = (xy_expression or "").strip()
        if xy_raw:
            xy_eval = str(self._variables.evaluate(xy_raw)).strip()
            px, py = self._parse_xy_pair(xy_eval)
            if px is None or py is None:
                raise SchedulerError(
                    f"액션 #{action_index}: {field_prefix}.xy_expression 형식이 잘못되었습니다: {xy_eval!r}"
                )
            rx, ry = px, py

        x_raw = (x_expression or "").strip()
        if x_raw:
            rx = self._coerce_eval_to_int(
                self._variables.evaluate(x_raw),
                field_name=f"{field_prefix}.x_expression",
                action_index=action_index,
            )
        y_raw = (y_expression or "").strip()
        if y_raw:
            ry = self._coerce_eval_to_int(
                self._variables.evaluate(y_raw),
                field_name=f"{field_prefix}.y_expression",
                action_index=action_index,
            )
        rx = max(x_min, min(x_max, rx))
        ry = max(y_min, min(y_max, ry))
        return rx, ry

    def _resolve_region_fields(
        self,
        *,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        region_x_expression: str | None,
        region_y_expression: str | None,
        region_xy_expression: str | None,
        region_end_x_expression: str | None,
        region_end_y_expression: str | None,
        region_end_xy_expression: str | None,
        action_index: int,
        field_prefix: str,
    ) -> tuple[int, int, int, int]:
        """영역 시작/끝 좌표식을 해석하여 (x, y, width, height)를 반환한다."""
        rx, ry = self._resolve_xy_fields(
            x=region_x,
            y=region_y,
            x_expression=region_x_expression,
            y_expression=region_y_expression,
            xy_expression=region_xy_expression,
            x_min=0,
            x_max=7680,
            y_min=0,
            y_max=4320,
            action_index=action_index,
            field_prefix=f"{field_prefix}(start)",
        )
        rw = max(1, region_width)
        rh = max(1, region_height)
        base_end_x = rx + rw
        base_end_y = ry + rh
        ex, ey = self._resolve_xy_fields(
            x=base_end_x,
            y=base_end_y,
            x_expression=region_end_x_expression,
            y_expression=region_end_y_expression,
            xy_expression=region_end_xy_expression,
            x_min=0,
            x_max=7680,
            y_min=0,
            y_max=4320,
            action_index=action_index,
            field_prefix=f"{field_prefix}(end)",
        )
        return rx, ry, max(1, ex - rx), max(1, ey - ry)

    @staticmethod
    def _parse_xy_pair(value: str) -> tuple[int | None, int | None]:
        """'x,y' 또는 '(x,y)' 문자열을 정수 좌표쌍으로 파싱한다."""
        raw = value.strip()
        if raw.startswith("(") and raw.endswith(")"):
            raw = raw[1:-1].strip()
        parts = [p.strip() for p in raw.split(",")]
        if len(parts) != 2:
            return None, None
        try:
            x_val = int(float(parts[0]))
            y_val = int(float(parts[1]))
        except (TypeError, ValueError):
            return None, None
        return x_val, y_val

    @staticmethod
    def _coerce_eval_to_int(
        evaluated: str,
        *,
        field_name: str,
        action_index: int,
    ) -> int:
        """수식 평가 문자열을 정수로 변환한다."""
        text = str(evaluated).strip()
        if not re.fullmatch(r"[+-]?\d+(?:\.\d+)?", text):
            raise SchedulerError(
                f"액션 #{action_index}: {field_name} 결과가 숫자가 아닙니다: {evaluated!r}"
            )
        return int(float(text))

    def _perform_move(self, x: int, y: int, duration_ms: int = 0) -> None:
        """지정 좌표로 마우스를 이동한다 (클릭 없음)."""
        if self._serial is None:
            logger.info("[dry-run] 이동: (%d, %d) %dms", x, y, duration_ms)
            return

        from engine.serial_cmd import SerialConnectionError

        move_action = MouseMoveAction(x=x, y=y, is_relative=False, duration_ms=duration_ms)
        try:
            self._serial.send_action(move_action)
        except SerialConnectionError as exc:
            raise SchedulerError(f"Arduino 연결 끊김 (ImageSearch 이동): {exc}") from exc
        except Exception as exc:
            logger.error("마우스 이동 실패: (%d, %d) — %s", x, y, exc)

    def _perform_click(self, x: int, y: int, button: str = "LEFT") -> None:
        """지정 좌표로 마우스를 이동한 후 클릭한다."""
        if self._serial is None:
            logger.info("[dry-run] 클릭: (%d, %d) %s", x, y, button)
            return

        from engine.serial_cmd import SerialConnectionError

        move_action = MouseMoveAction(x=x, y=y, is_relative=False, duration_ms=0)
        click_action = MouseClickAction(button=MouseButton(button), count=1)

        try:
            self._serial.send_action(move_action)
            self._serial.send_action(click_action)
        except SerialConnectionError as exc:
            raise SchedulerError(f"Arduino 연결 끊김 (ImageSearch 클릭): {exc}") from exc
        except Exception as exc:
            logger.error("자동 클릭 실패: (%d, %d) — %s", x, y, exc)

    def _safe_set_var(self, name: str, value: str) -> None:
        """변수를 안전하게 설정한다 (에러 시 로그만 남김)."""
        if not name:
            return
        try:
            self._variables.set(name, value)
        except Exception as exc:
            logger.error("변수 저장 실패: %s = %s — %s", name, value, exc)

    def _safe_set_vars_batch(self, updates: dict[str, str]) -> None:
        """여러 변수를 한 번에 안전하게 설정한다."""
        if not updates:
            return
        try:
            self._variables.set_many(updates)
        except Exception as exc:
            logger.error("변수 일괄 저장 실패: %s", exc)
