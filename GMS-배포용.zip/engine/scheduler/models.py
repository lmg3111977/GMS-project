"""액션 스케줄러 — 데이터 구조 및 상수."""

from __future__ import annotations

from dataclasses import dataclass, field

from shared.models import Action

MAX_LOOP_NESTING: int = 10
MAX_SUB_MACRO_DEPTH: int = 5
MAX_FUNCTION_DEPTH: int = 10


@dataclass
class LoopFrame:
    """루프 스택 프레임.

    Args:
        start_index: LoopStart 액션의 인덱스
        remaining: 남은 반복 횟수. -1이면 무한.
    """

    start_index: int
    remaining: int


@dataclass
class SubMacroFrame:
    """서브매크로 호출 스택 프레임.

    서브매크로 실행이 끝나면 caller의 상태로 복원한다.

    Args:
        actions: 호출자의 액션 리스트
        label_map: 호출자의 Label 맵
        loop_end_map: 호출자의 LoopStart→LoopEnd 맵
        program_counter: 복귀할 프로그램 카운터 (호출 다음 액션)
        loop_stack: 호출자의 루프 스택
        macro_path: 진입한 서브매크로 파일 경로 (로그·디버깅용)
        nested_paths_snapshot: 호출 직전의 중첩 매크로 경로 집합 (복귀 시 복원)
    """

    actions: list[Action]
    label_map: dict[str, int]
    loop_end_map: dict[int, int]
    if_else_map: dict[int, int]
    if_end_map: dict[int, int]
    else_end_map: dict[int, int]
    program_counter: int
    loop_stack: list[LoopFrame]
    macro_path: str = ""
    nested_paths_snapshot: frozenset[str] = field(default_factory=frozenset)


@dataclass
class FunctionFrame:
    """함수 호출 스택 프레임."""

    return_address: int
    return_var: str


class SchedulerError(Exception):
    """스케줄러 실행 에러."""
