"""액션 스케줄러 — 서브매크로 호출 믹스인."""

from __future__ import annotations

import logging
from pathlib import Path

from engine.scheduler.models import MAX_SUB_MACRO_DEPTH, SchedulerError, SubMacroFrame
from shared.action_flatten import BranchFlattenError, flatten_actions_for_execution
from shared.models import SubMacroCallAction

logger = logging.getLogger(__name__)


class SubMacroMixin:
    """서브매크로 호출·복귀 믹스인."""

    def _handle_sub_macro_call(self, action: SubMacroCallAction) -> None:
        """서브매크로를 로드하고 실행 컨텍스트를 전환한다.

        현재 실행 상태를 call_stack에 push하고,
        서브매크로의 액션 리스트로 전환한다.
        순환 참조(A→B→A)를 호출 스택에서 탐지하여 명확한 에러를 낸다.
        사전 로딩된 캐시를 우선 사용하여 런타임 파일 I/O를 제거한다.
        """
        if len(self._call_stack) >= MAX_SUB_MACRO_DEPTH:
            raise SchedulerError(f"서브매크로 호출 깊이 제한 초과: 최대 {MAX_SUB_MACRO_DEPTH}단계")

        if not action.macro_path:
            logger.warning("SubMacroCall: macro_path가 비어 있음, 건너뜁니다.")
            self._program_counter += 1
            return

        resolved = str(Path(action.macro_path).resolve())
        if resolved in self._nested_macro_paths:
            chain = " → ".join((*sorted(self._nested_macro_paths), resolved))
            raise SchedulerError(f"서브매크로 순환 참조 감지: {chain}")

        sub_macro = self._sub_macro_cache.get(resolved)
        if sub_macro is None:
            from shared.schema import load_macro

            try:
                sub_macro = load_macro(action.macro_path)
            except Exception as exc:
                raise SchedulerError(
                    f"서브매크로 로드 실패: '{action.macro_path}' — {exc}"
                ) from exc

        if not sub_macro.actions:
            logger.warning(
                "SubMacroCall: '%s' 액션이 비어 있음, 건너뜁니다.",
                action.macro_path,
            )
            self._program_counter += 1
            return

        paths_before = frozenset(self._nested_macro_paths)
        self._call_stack.append(
            SubMacroFrame(
                actions=self._actions,
                label_map=self._label_map,
                loop_end_map=self._loop_end_map,
                if_else_map=self._if_else_map,
                if_end_map=self._if_end_map,
                else_end_map=self._else_end_map,
                program_counter=self._program_counter + 1,
                loop_stack=list(self._loop_stack),
                macro_path=resolved,
                nested_paths_snapshot=paths_before,
            )
        )
        self._nested_macro_paths.add(resolved)

        try:
            sub_flat = flatten_actions_for_execution(list(sub_macro.actions))
        except BranchFlattenError as exc:
            raise SchedulerError(
                f"서브매크로 분기 펼치기 실패: '{action.macro_path}' — {exc}"
            ) from exc

        self._actions = sub_flat
        self._loop_stack = []
        self._build_label_loop_maps(sub_flat)

        self._program_counter = 0
        logger.info(
            "SubMacroCall 진입: '%s' (%d개 액션, depth=%d)",
            action.macro_path,
            len(self._actions),
            len(self._call_stack),
        )

    def _return_from_sub_macro(self) -> None:
        """서브매크로 실행이 끝나서 호출자로 복귀한다."""
        if not self._call_stack:
            return

        frame = self._call_stack.pop()
        self._nested_macro_paths = set(frame.nested_paths_snapshot)
        self._actions = frame.actions
        self._label_map = frame.label_map
        self._loop_end_map = frame.loop_end_map
        self._if_else_map = frame.if_else_map
        self._if_end_map = frame.if_end_map
        self._else_end_map = frame.else_end_map
        self._program_counter = frame.program_counter
        self._loop_stack = frame.loop_stack

        logger.info(
            "SubMacroCall 복귀: PC=%d (remaining depth=%d)",
            self._program_counter,
            len(self._call_stack),
        )
