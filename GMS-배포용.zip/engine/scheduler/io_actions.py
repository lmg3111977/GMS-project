"""액션 스케줄러 — I/O 액션 실행 믹스인."""

from __future__ import annotations

import logging

from engine.scheduler.models import SchedulerError
from shared.models import Action, MouseDragAction, MouseMoveAction

logger = logging.getLogger(__name__)


class IOActionsMixin:
    """마우스/키보드 I/O 액션 전송 믹스인."""

    def _execute_io_action(self, action: Action) -> None:
        """마우스/키보드 I/O 액션을 시리얼로 전송한다.

        SerialConnectionError 발생 시 SchedulerError로 변환하여
        runner.run_blocking()까지 전파한다. 이를 통해 매크로가 자동 정지된다.
        """
        if self._serial is None:
            logger.info("[dry-run] 액션 #%d: %s", self._program_counter, action.type)
            return

        from engine.serial_cmd import SerialConnectionError

        action_to_send = action
        if isinstance(action, MouseMoveAction):
            action_to_send = self._resolve_mouse_move_action(action)
        elif isinstance(action, MouseDragAction):
            action_to_send = self._resolve_mouse_drag_action(action)

        try:
            success = self._serial.send_action(action_to_send)
            if not success:
                logger.warning(
                    "액션 #%d 전송 실패: %s",
                    self._program_counter,
                    action_to_send.type,
                )
        except SerialConnectionError as exc:
            raise SchedulerError(
                f"Arduino 연결 끊김 (액션 #{self._program_counter}: {action.type}): {exc}"
            ) from exc
        except Exception as exc:
            raise SchedulerError(
                f"액션 #{self._program_counter} 실행 에러 ({action.type}): {exc}"
            ) from exc
