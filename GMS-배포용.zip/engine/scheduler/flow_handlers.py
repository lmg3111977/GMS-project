"""액션 스케줄러 — 흐름 제어 핸들러 믹스인."""

from __future__ import annotations

import logging
import time

from engine.scheduler.models import MAX_LOOP_NESTING, LoopFrame, SchedulerError
from shared.humanizer import sync_human_delay, sync_random_delay
from shared.models import (
    DelayAction,
    ElseAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    LoopStartAction,
    PixelWaitAction,
    VariableSetAction,
)

logger = logging.getLogger(__name__)


class FlowHandlersMixin:
    """흐름 제어 액션 핸들러 믹스인.

    Goto, Label, Loop, If-Pixel, PixelWait, Delay, IfVariable, Else 등
    흐름 제어 액션의 실행 로직을 담당한다.
    """

    def _jump_to_else_or_end(self, action_name: str) -> None:
        """현재 분기 액션 기준으로 else 또는 endif 다음으로 이동한다."""
        else_idx = self._if_else_map.get(self._program_counter)
        if else_idx is not None:
            self._program_counter = else_idx + 1
            return
        end_idx = self._if_end_map.get(self._program_counter)
        if end_idx is None:
            raise SchedulerError(
                f"액션 #{self._program_counter}: {action_name}에 대응하는 Else/EndIf를 찾지 못함"
            )
        self._program_counter = end_idx + 1

    def _handle_goto(self, action: GotoAction) -> None:
        """Label로 점프한다."""
        if action.target not in self._label_map:
            raise SchedulerError(
                f"액션 #{self._program_counter}: "
                f"Goto target '{action.target}'에 해당하는 Label이 없음"
            )
        self._program_counter = self._label_map[action.target]

    def _jump_to_label(self, label_name: str) -> None:
        """Label 이름으로 점프한다.

        빈 문자열이면 다음 액션으로 진행한다.
        """
        if not label_name:
            self._program_counter += 1
            return

        if label_name not in self._label_map:
            raise SchedulerError(f"Label '{label_name}'을 찾을 수 없음")
        self._program_counter = self._label_map[label_name]

    def _resolve_loop_repeat_count(self, action: LoopStartAction) -> int:
        """LoopStart의 실제 반복 횟수를 정한다. count_expression이 있으면 런타임 평가."""
        start_raw = action.range_start_expression
        end_raw = action.range_end_expression
        if start_raw is not None and start_raw.strip() and end_raw is not None and end_raw.strip():
            start_eval = self._variables.evaluate(start_raw.strip())
            end_eval = self._variables.evaluate(end_raw.strip())
            try:
                start_n = int(float(str(start_eval).strip()))
                end_n = int(float(str(end_eval).strip()))
            except (TypeError, ValueError) as exc:
                raise SchedulerError(
                    f"액션 #{self._program_counter}: LoopStart 범위 식(start/end) "
                    f"평가 결과가 정수가 아닙니다: start={start_eval!r}, end={end_eval!r}"
                ) from exc
            base = end_n - start_n
            if action.range_end_inclusive:
                base += 1
            return max(0, base)

        raw = action.count_expression
        if raw is not None and raw.strip():
            evaluated = self._variables.evaluate(raw.strip())
            try:
                n = int(float(str(evaluated).strip()))
            except (TypeError, ValueError) as exc:
                raise SchedulerError(
                    f"액션 #{self._program_counter}: LoopStart count_expression "
                    f"평가 결과가 정수가 아닙니다: {evaluated!r}"
                ) from exc
            if n < -1:
                raise SchedulerError(
                    f"액션 #{self._program_counter}: LoopStart 반복 횟수는 "
                    f"-1(무한) 이상이어야 합니다 (현재 {n})"
                )
            return n
        return action.count

    def _handle_loop_start(self, action: LoopStartAction) -> None:
        """루프 스택에 프레임을 push한다."""
        if len(self._loop_stack) >= MAX_LOOP_NESTING:
            raise SchedulerError(f"루프 중첩 제한 초과: 최대 {MAX_LOOP_NESTING}단계")

        if self._loop_stack and self._loop_stack[-1].start_index == self._program_counter:
            self._program_counter += 1
            return

        remaining = self._resolve_loop_repeat_count(action)
        self._loop_stack.append(
            LoopFrame(
                start_index=self._program_counter,
                remaining=remaining,
            )
        )
        self._program_counter += 1

    def _handle_loop_end(self) -> None:
        """루프 카운터를 확인하고 반복 또는 종료한다."""
        if not self._loop_stack:
            raise SchedulerError(
                f"액션 #{self._program_counter}: " f"LoopEnd에 대응하는 LoopStart가 없음"
            )

        frame = self._loop_stack[-1]

        if frame.remaining == -1:
            self._program_counter = frame.start_index + 1

        elif frame.remaining > 1:
            frame.remaining -= 1
            self._program_counter = frame.start_index + 1

        else:
            self._loop_stack.pop()
            self._program_counter += 1

    def _exit_innermost_loop(self) -> None:
        """가장 안쪽 루프를 빠져나와 해당 LoopEnd 바로 다음 액션으로 이동한다.

        Break 액션에서 공통 사용한다.
        """
        if not self._loop_stack:
            raise SchedulerError(
                f"액션 #{self._program_counter}: Break는 루프 안에서만 사용할 수 있습니다"
            )

        frame = self._loop_stack.pop()
        if frame.start_index not in self._loop_end_map:
            raise SchedulerError(
                f"액션 #{self._program_counter}: Break 대상 루프의 LoopEnd를 찾을 수 없음"
            )

        end_idx = self._loop_end_map[frame.start_index]
        self._program_counter = end_idx + 1

    def _handle_break(self) -> None:
        """현재 가장 안쪽 루프를 즉시 빠져나간다.

        LoopStart~LoopEnd 사이 어디에서든 Break를 만나면
        해당 LoopEnd 바로 다음 액션으로 점프한다.
        """
        self._exit_innermost_loop()

    def _handle_delay(self, action: DelayAction) -> None:
        """딜레이를 실행한다."""
        if action.random_min is not None and action.random_max is not None:
            sync_random_delay(
                action.random_min,
                action.random_max,
                stop_event=self._stop_event,
                link_lost_event=self._link_lost_event,
            )
        else:
            sync_human_delay(
                action.ms,
                randomize=False,
                stop_event=self._stop_event,
                link_lost_event=self._link_lost_event,
            )

        self._raise_if_link_lost()
        self._program_counter += 1

    def _handle_if_pixel(self, action: IfPixelAction) -> None:
        """화면 픽셀 색상을 확인하고 조건 분기한다."""
        if self._screen is None:
            logger.warning("ScreenAnalyzer 없음. IfPixel을 else 분기로 처리합니다.")
            self._jump_to_else_or_end("IfPixel")
            return

        px, py = self._resolve_xy_fields(
            x=action.x,
            y=action.y,
            x_expression=action.x_expression,
            y_expression=action.y_expression,
            xy_expression=action.xy_expression,
            x_min=0,
            x_max=7680,
            y_min=0,
            y_max=4320,
            action_index=self._program_counter,
            field_prefix="IfPixel",
        )
        matched, distance, similarity = self._screen.get_pixel_match_metrics(
            px,
            py,
            action.color,
            action.tolerance,
        )
        condition_met = (not matched) if action.detect_change else matched
        logger.info(
            "IfPixel 판정: (%d,%d) mode=%s color=%s distance=%.2f, 유사성=%.4f / 기준 허용오차=%d -> %s",
            px,
            py,
            "변화감지" if action.detect_change else "일치",
            action.color,
            distance,
            similarity,
            action.tolerance,
            "성공" if condition_met else "실패",
        )
        self._emit_visual_debug_pixel(
            "if_pixel",
            action.color,
            px,
            py,
            capture_screen=condition_met,
        )

        if condition_met:
            self._program_counter += 1
            return
        self._jump_to_else_or_end("IfPixel")

    def _handle_pixel_wait(self, action: PixelWaitAction) -> None:
        """픽셀 색상이 나타날 때까지 대기한다."""
        if self._screen is None:
            logger.warning("ScreenAnalyzer 없음. PixelWait 실패로 else 분기합니다.")
            self._jump_to_else_or_end("PixelWait")
            return

        px, py = self._resolve_xy_fields(
            x=action.x,
            y=action.y,
            x_expression=action.x_expression,
            y_expression=action.y_expression,
            xy_expression=action.xy_expression,
            x_min=0,
            x_max=7680,
            y_min=0,
            y_max=4320,
            action_index=self._program_counter,
            field_prefix="PixelWait",
        )
        if action.detect_change:
            found = False
            start_time = time.monotonic()
            timeout_sec = action.timeout_ms / 1000.0
            stop_event = self._stop_event
            link_lost_event = self._link_lost_event
            reference_color = action.color
            if action.change_reference == "runtime":
                reference_color = self._screen.get_pixel_color(px, py)
            while time.monotonic() - start_time < timeout_sec:
                if stop_event is not None and stop_event.is_set():
                    break
                if link_lost_event is not None and link_lost_event.is_set():
                    break
                matched_now = self._screen.check_pixel_color(
                    px, py, reference_color, action.tolerance
                )
                if not matched_now:
                    found = True
                    break
                sync_human_delay(
                    50,
                    randomize=False,
                    stop_event=stop_event,
                    link_lost_event=link_lost_event,
                )
        else:
            found = self._screen.wait_for_pixel(
                px,
                py,
                action.color,
                action.tolerance,
                action.timeout_ms,
                stop_event=self._stop_event,
                link_lost_event=self._link_lost_event,
            )
        _, distance, similarity = self._screen.get_pixel_match_metrics(
            px,
            py,
            action.color,
            action.tolerance,
        )

        self._raise_if_link_lost()
        self._emit_visual_debug_pixel(
            "pixel_wait",
            action.color,
            px,
            py,
            capture_screen=found,
        )
        logger.info(
            "PixelWait 판정: (%d,%d) mode=%s ref=%s color=%s distance=%.2f, 유사성=%.4f / 기준 허용오차=%d timeout=%dms -> %s",
            px,
            py,
            "변화감지" if action.detect_change else "일치대기",
            action.change_reference,
            action.color,
            distance,
            similarity,
            action.tolerance,
            action.timeout_ms,
            "성공" if found else "타임아웃",
        )
        if found:
            self._program_counter += 1
            return
        self._jump_to_else_or_end("PixelWait")

    def _handle_variable_set(self, action: VariableSetAction) -> None:
        """변수를 설정한다."""
        value = self._variables.evaluate(action.expression) if action.expression else action.value

        self._variables.set(action.var_name, value)
        self._program_counter += 1

    def _handle_if_variable(self, action: IfVariableAction) -> None:
        """변수 값을 비교하여 조건 분기한다."""
        var_val = self._variables.get(action.var_name, "")
        compare_val = self._variables.evaluate(action.compare_value)

        matched = False
        try:
            num_var = float(var_val)
            num_cmp = float(compare_val)
            if action.operator == "==":
                matched = num_var == num_cmp
            elif action.operator == "!=":
                matched = num_var != num_cmp
            elif action.operator == ">":
                matched = num_var > num_cmp
            elif action.operator == "<":
                matched = num_var < num_cmp
            elif action.operator == ">=":
                matched = num_var >= num_cmp
            elif action.operator == "<=":
                matched = num_var <= num_cmp
        except ValueError:
            if action.operator == "==":
                matched = var_val == compare_val
            elif action.operator == "!=":
                matched = var_val != compare_val
            else:
                matched = var_val == compare_val

        logger.debug(
            "IfVariable: %s(%s) %s %s → %s",
            action.var_name,
            var_val,
            action.operator,
            compare_val,
            matched,
        )

        if matched:
            self._program_counter += 1
            return
        self._jump_to_else_or_end("IfVariable")

    def _handle_else(self, action: ElseAction) -> None:
        _ = action
        end_idx = self._else_end_map.get(self._program_counter)
        if end_idx is None:
            raise SchedulerError(
                f"액션 #{self._program_counter}: Else에 대응하는 EndIf를 찾지 못함"
            )
        self._program_counter = end_idx + 1
