"""액션 스케줄러 — 이미지 매칭 핸들러 믹스인."""

from __future__ import annotations

import logging

from shared.humanizer import sync_human_delay
from shared.models import (
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
)

logger = logging.getLogger(__name__)


class ImageHandlersMixin:
    """이미지 검색·대기·클릭 액션 핸들러 믹스인."""

    def _handle_image_search(self, action: ImageSearchAction) -> None:
        """이미지 템플릿 매칭을 수행한다.

        재시도, 그레이스케일, 자동 클릭, 결과 변수 저장 등 고급 옵션을 지원한다.
        """
        if self._screen is None:
            logger.warning("ScreenAnalyzer 없음. ImageSearch 실패로 else 분기합니다.")
            if action.store_found_var.strip():
                self._safe_set_var(action.store_found_var.strip(), "0")
            self._jump_to_else_or_end("ImageSearch")
            return

        region_x, region_y, region_width, region_height = self._resolve_region_fields(
            region_x=action.region_x,
            region_y=action.region_y,
            region_width=action.region_width,
            region_height=action.region_height,
            region_x_expression=action.region_x_expression,
            region_y_expression=action.region_y_expression,
            region_xy_expression=action.region_xy_expression,
            region_end_x_expression=action.region_end_x_expression,
            region_end_y_expression=action.region_end_y_expression,
            region_end_xy_expression=action.region_end_xy_expression,
            action_index=self._program_counter,
            field_prefix="ImageSearch(region)",
        )
        click_ox, click_oy = self._resolve_xy_fields(
            x=action.click_offset_x,
            y=action.click_offset_y,
            x_expression=action.click_offset_x_expression,
            y_expression=action.click_offset_y_expression,
            xy_expression=action.click_offset_xy_expression,
            x_min=-500,
            x_max=500,
            y_min=-500,
            y_max=500,
            action_index=self._program_counter,
            field_prefix="ImageSearch(offset)",
        )
        result = None
        found_attempt: int | None = None
        best_similarity = 0.0
        for attempt in range(action.max_retry):
            result, similarity = self._screen.search_image_with_similarity(
                action.template_path,
                region_x,
                region_y,
                region_width,
                region_height,
                action.confidence,
                action.grayscale,
            )
            best_similarity = max(best_similarity, similarity)
            if result is not None:
                found_attempt = attempt + 1
                break
            if attempt < action.max_retry - 1:
                sync_human_delay(
                    action.retry_interval_ms,
                    randomize=False,
                    stop_event=self._stop_event,
                    link_lost_event=self._link_lost_event,
                )
                self._raise_if_link_lost()

        if result is not None:
            x, y, conf = result
            self._emit_visual_debug_image(
                "image_search",
                action.template_path,
                region_x,
                region_y,
                region_width,
                region_height,
                (x, y),
            )
            logger.info(
                "ImageSearch 성공: %s @(%d,%d) 유사성=%.4f / 기준=%.4f (attempt %d/%d)",
                action.template_path,
                x,
                y,
                conf,
                action.confidence,
                found_attempt or 1,
                action.max_retry,
            )
            updates: dict[str, str] = {}
            cxy = action.store_xy_combined_var.strip()
            if cxy:
                updates[cxy] = f"{x},{y}"
            if action.store_x_var.strip():
                updates[action.store_x_var.strip()] = str(x)
            if action.store_y_var.strip():
                updates[action.store_y_var.strip()] = str(y)
            if action.store_found_var.strip():
                updates[action.store_found_var.strip()] = "1"
            if action.store_confidence_var.strip():
                updates[action.store_confidence_var.strip()] = f"{conf:.4f}"
            self._safe_set_vars_batch(updates)

            tx = x + click_ox
            ty = y + click_oy
            want_move = action.move_on_found
            want_click = action.click_on_found
            if want_move or want_click:
                if self._serial is None:
                    if want_move:
                        logger.warning(
                            "ImageSearch 마우스 이동 요청했지만 시리얼 없음(dry-run) " "→ (%d,%d)",
                            tx,
                            ty,
                        )
                    if want_click:
                        logger.warning("ImageSearch 자동 클릭 요청했지만 시리얼 없음(dry-run)")
                elif want_move and want_click and action.move_duration_ms > 0:
                    logger.info(
                        "ImageSearch 이동(%dms) 후 클릭: (%d,%d) button=%s",
                        action.move_duration_ms,
                        tx,
                        ty,
                        action.click_button.value,
                    )
                    self._perform_move(tx, ty, action.move_duration_ms)
                    self._perform_click(tx, ty, action.click_button.value)
                elif want_click:
                    logger.info(
                        "ImageSearch 자동 클릭: (%d,%d) button=%s",
                        tx,
                        ty,
                        action.click_button.value,
                    )
                    self._perform_click(tx, ty, action.click_button.value)
                elif want_move:
                    logger.info(
                        "ImageSearch 커서 이동: (%d,%d) duration=%dms",
                        tx,
                        ty,
                        action.move_duration_ms,
                    )
                    self._perform_move(tx, ty, action.move_duration_ms)

            self._program_counter += 1
            return

        self._emit_visual_debug_image(
            "image_search",
            action.template_path,
            region_x,
            region_y,
            region_width,
            region_height,
            None,
        )
        logger.warning(
            "ImageSearch 실패: %s (attempts=%d, 최대 유사성=%.4f / 기준=%.4f)",
            action.template_path,
            action.max_retry,
            best_similarity,
            action.confidence,
        )
        if action.store_found_var.strip():
            self._safe_set_var(action.store_found_var.strip(), "0")
        self._jump_to_else_or_end("ImageSearch")

    def _handle_image_wait(self, action: ImageWaitAction) -> None:
        """이미지가 나타날 때까지 대기한다."""
        if self._screen is None:
            logger.warning("ScreenAnalyzer 없음. ImageWait 실패로 else 분기합니다.")
            self._jump_to_else_or_end("ImageWait")
            return

        region_x, region_y, region_width, region_height = self._resolve_region_fields(
            region_x=action.region_x,
            region_y=action.region_y,
            region_width=action.region_width,
            region_height=action.region_height,
            region_x_expression=action.region_x_expression,
            region_y_expression=action.region_y_expression,
            region_xy_expression=action.region_xy_expression,
            region_end_x_expression=action.region_end_x_expression,
            region_end_y_expression=action.region_end_y_expression,
            region_end_xy_expression=action.region_end_xy_expression,
            action_index=self._program_counter,
            field_prefix="ImageWait(region)",
        )
        result, best_similarity = self._screen.wait_for_image_with_similarity(
            action.template_path,
            region_x,
            region_y,
            region_width,
            region_height,
            action.confidence,
            action.grayscale,
            action.timeout_ms,
            stop_event=self._stop_event,
            link_lost_event=self._link_lost_event,
        )

        self._raise_if_link_lost()
        if result is not None:
            x, y, _conf = result
            self._emit_visual_debug_image(
                "image_wait",
                action.template_path,
                region_x,
                region_y,
                region_width,
                region_height,
                (x, y),
            )
            logger.info(
                "ImageWait 성공: %s @(%d,%d) 유사성=%.4f / 기준=%.4f timeout=%dms",
                action.template_path,
                x,
                y,
                _conf,
                action.confidence,
                action.timeout_ms,
            )
            self._safe_set_var(action.store_x_var, str(x))
            self._safe_set_var(action.store_y_var, str(y))
            self._program_counter += 1
        else:
            self._emit_visual_debug_image(
                "image_wait",
                action.template_path,
                region_x,
                region_y,
                region_width,
                region_height,
                None,
            )
            logger.warning(
                "ImageWait 실패(타임아웃): %s timeout=%dms, 최대 유사성=%.4f / 기준=%.4f",
                action.template_path,
                action.timeout_ms,
                best_similarity,
                action.confidence,
            )
            self._jump_to_else_or_end("ImageWait")

    def _handle_image_click(self, action: ImageClickAction) -> None:
        """이미지를 찾아서 클릭한다."""
        if self._screen is None:
            logger.warning("ScreenAnalyzer 없음. ImageClick 실패로 else 분기합니다.")
            self._jump_to_else_or_end("ImageClick")
            return

        region_x, region_y, region_width, region_height = self._resolve_region_fields(
            region_x=action.region_x,
            region_y=action.region_y,
            region_width=action.region_width,
            region_height=action.region_height,
            region_x_expression=action.region_x_expression,
            region_y_expression=action.region_y_expression,
            region_xy_expression=action.region_xy_expression,
            region_end_x_expression=action.region_end_x_expression,
            region_end_y_expression=action.region_end_y_expression,
            region_end_xy_expression=action.region_end_xy_expression,
            action_index=self._program_counter,
            field_prefix="ImageClick(region)",
        )
        click_ox, click_oy = self._resolve_xy_fields(
            x=action.click_offset_x,
            y=action.click_offset_y,
            x_expression=action.click_offset_x_expression,
            y_expression=action.click_offset_y_expression,
            xy_expression=action.click_offset_xy_expression,
            x_min=-500,
            x_max=500,
            y_min=-500,
            y_max=500,
            action_index=self._program_counter,
            field_prefix="ImageClick(offset)",
        )
        result = None
        found_attempt: int | None = None
        best_similarity = 0.0
        for attempt in range(action.max_retry):
            result, similarity = self._screen.search_image_with_similarity(
                action.template_path,
                region_x,
                region_y,
                region_width,
                region_height,
                action.confidence,
                action.grayscale,
            )
            best_similarity = max(best_similarity, similarity)
            if result is not None:
                found_attempt = attempt + 1
                break
            if attempt < action.max_retry - 1:
                sync_human_delay(
                    action.retry_interval_ms,
                    randomize=False,
                    stop_event=self._stop_event,
                    link_lost_event=self._link_lost_event,
                )
                self._raise_if_link_lost()

        if result is not None:
            x, y, _conf = result
            self._emit_visual_debug_image(
                "image_click",
                action.template_path,
                region_x,
                region_y,
                region_width,
                region_height,
                (x, y),
            )
            logger.info(
                "ImageClick 성공: %s @(%d,%d) 유사성=%.4f / 기준=%.4f (attempt %d/%d)",
                action.template_path,
                x,
                y,
                _conf,
                action.confidence,
                found_attempt or 1,
                action.max_retry,
            )
            click_x = x + click_ox
            click_y = y + click_oy
            self._perform_click(click_x, click_y, action.click_button.value)
            self._program_counter += 1
            return

        self._emit_visual_debug_image(
            "image_click",
            action.template_path,
            region_x,
            region_y,
            region_width,
            region_height,
            None,
        )
        logger.warning(
            "ImageClick 실패: %s (attempts=%d, 최대 유사성=%.4f / 기준=%.4f)",
            action.template_path,
            action.max_retry,
            best_similarity,
            action.confidence,
        )
        self._jump_to_else_or_end("ImageClick")
