"""에디터 실행 중 이미지/픽셀 액션 디버그용 30×30 PNG 썸네일 생성."""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np

from engine.screen import ScreenAnalyzer, _parse_color

logger = logging.getLogger(__name__)

THUMB_SIZE = 30
_template_thumb_cache: dict[str, bytes] = {}
_MAX_THUMB_CACHE = 30


def bgr_to_png_bytes(bgr: np.ndarray, size: int = THUMB_SIZE) -> bytes | None:
    """BGR 배열을 size×size로 맞춘 뒤 PNG 바이트로 인코딩한다."""
    try:
        import cv2
    except ImportError:
        return None
    try:
        if bgr.size == 0:
            return None
        if bgr.shape[0] != size or bgr.shape[1] != size:
            bgr = cv2.resize(bgr, (size, size), interpolation=cv2.INTER_AREA)
        ok, buf = cv2.imencode(".png", bgr)
        if not ok:
            return None
        return bytes(buf)
    except Exception as exc:
        logger.debug("bgr_to_png_bytes 실패: %s", exc)
        return None


def template_png_thumb(template_path: str, size: int = THUMB_SIZE) -> bytes | None:
    """템플릿 파일을 로드해 size×size PNG로 만든다 (한글 경로 대응 imdecode)."""
    cache_key = f"{template_path}:{size}"
    cached = _template_thumb_cache.get(cache_key)
    if cached is not None:
        return cached

    path = Path(template_path)
    if not path.is_file():
        return None
    try:
        import cv2
    except ImportError:
        return None
    try:
        raw = path.read_bytes()
        arr = np.frombuffer(raw, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            return None
        small = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
        result = bgr_to_png_bytes(small, size)
        if result is not None:
            _template_thumb_cache[cache_key] = result
            if len(_template_thumb_cache) > _MAX_THUMB_CACHE:
                oldest = next(iter(_template_thumb_cache))
                del _template_thumb_cache[oldest]
        return result
    except Exception as exc:
        logger.debug("template_png_thumb 실패: %s", exc)
        return None


def expected_color_png_thumb(color_hex: str, size: int = THUMB_SIZE) -> bytes | None:
    """#RRGGBB 기대색을 단색 size×size PNG로 만든다."""
    try:
        normalized = color_hex if color_hex.startswith("#") else f"#{color_hex}"
        r, g, b = _parse_color(normalized)
        bgr = np.full((size, size, 3), (b, g, r), dtype=np.uint8)
        return bgr_to_png_bytes(bgr, size)
    except Exception as exc:
        logger.debug("expected_color_png_thumb 실패: %s", exc)
        return None


def screen_center_png_thumb(
    screen: ScreenAnalyzer,
    cx: int,
    cy: int,
    size: int = THUMB_SIZE,
) -> bytes | None:
    """화면 (cx, cy) 주변을 캡처해 PNG 바이트로 반환한다."""
    bgr = screen.capture_square_thumbnail_bgr(cx, cy, size)
    if bgr is None:
        return None
    return bgr_to_png_bytes(bgr, size)
