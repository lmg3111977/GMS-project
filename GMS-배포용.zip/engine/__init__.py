"""GameMacroStudio 실행 엔진 패키지.

매크로 JSON을 로드하여 순차 실행하고,
Arduino Leonardo와 시리얼 통신하여 HID 명령을 전송한다.
shared/ 패키지만 import 가능 (editor/ 직접 import 금지).
"""
