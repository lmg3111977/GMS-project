"""런타임 변수 저장소.

매크로 실행 중 사용되는 변수(카운터, 좌표, 색상값 등)를 관리한다.
VariableSetAction으로 값을 설정하고,
다른 액션의 expression에서 변수를 참조할 수 있다.
"""

from __future__ import annotations

import ast
import logging
import operator
import re

logger = logging.getLogger(__name__)

MAX_VARIABLES: int = 100
MAX_VAR_NAME_LENGTH: int = 30
VAR_NAME_PATTERN: re.Pattern[str] = re.compile(r"^[a-zA-Z0-9_]+$")
VAR_REF_PATTERN: re.Pattern[str] = re.compile(r"\{(\w+)\}")


class VariableError(Exception):
    """변수 관련 에러."""


class VariableStore:
    """런타임 변수 저장소.

    문자열 키-값 쌍으로 변수를 관리한다.
    간단한 수식 평가({var_name} 치환 + 사칙연산)을 지원한다.
    """

    def __init__(self) -> None:
        self._variables: dict[str, str] = {}
        self._scope_stack: list[dict[str, str]] = []
        self._dirty: bool = False

    def push_scope(self) -> None:
        """로컬 스코프를 생성한다."""
        self._scope_stack.append({})
        self._dirty = True

    def pop_scope(self) -> None:
        """현재 로컬 스코프를 폐기한다."""
        if self._scope_stack:
            self._scope_stack.pop()
            self._dirty = True

    def set(self, name: str, value: str) -> None:
        """변수를 설정한다.

        Args:
            name: 변수 이름 (영숫자+_, 최대 30자)
            value: 값 (문자열)

        Raises:
            VariableError: 이름이 잘못되거나 변수 수 초과 시
        """
        self._validate_name(name)

        if self._scope_stack:
            self._scope_stack[-1][name] = value
            self._dirty = True
            logger.debug("로컬 변수 설정: %s = %s", name, value)
            return

        self.set_global(name, value)
        logger.debug("변수 설정: %s = %s", name, value)

    def set_global(self, name: str, value: str) -> None:
        """스코프와 무관하게 글로벌 변수에 설정한다."""
        self._validate_name(name)
        if name not in self._variables and len(self._variables) >= MAX_VARIABLES:
            raise VariableError(
                f"변수 수 제한 초과: 최대 {MAX_VARIABLES}개 " f"(현재 {len(self._variables)}개)"
            )
        self._variables[name] = value
        self._dirty = True

    def set_many(self, updates: dict[str, str]) -> None:
        """여러 변수를 한 번에 설정한다 (검증·저장을 묶어 처리).

        이미지 검색 등 한 액션에서 여러 결과 변수를 쓸 때
        반복 호출 오버헤드를 줄인다.
        """
        if not updates:
            return
        filtered = {k.strip(): v for k, v in updates.items() if k and k.strip()}
        if not filtered:
            return
        for name in filtered:
            self._validate_name(name)
        if self._scope_stack:
            for name, value in filtered.items():
                self.set(name, value)
            return

        new_keys = [k for k in filtered if k not in self._variables]
        if len(self._variables) + len(new_keys) > MAX_VARIABLES:
            raise VariableError(
                f"변수 수 제한 초과: 최대 {MAX_VARIABLES}개 "
                f"(현재 {len(self._variables)}개, 추가 시도 {len(new_keys)}개)"
            )
        for name, value in filtered.items():
            self.set(name, value)

    def get(self, name: str, default: str = "") -> str:
        """변수 값을 조회한다.

        Args:
            name: 변수 이름
            default: 변수가 없을 때 반환할 기본값

        Returns:
            변수 값 또는 기본값
        """
        for scope in reversed(self._scope_stack):
            if name in scope:
                return scope[name]
        return self._variables.get(name, default)

    def has(self, name: str) -> bool:
        """변수 존재 여부를 확인한다."""
        for scope in reversed(self._scope_stack):
            if name in scope:
                return True
        return name in self._variables

    def delete(self, name: str) -> None:
        """변수를 삭제한다."""
        if name in self._variables:
            self._variables.pop(name, None)
            self._dirty = True

    def increment(self, name: str, amount: int = 1) -> None:
        """숫자 변수를 증가시킨다.

        변수가 없으면 0에서 시작한다.

        Args:
            name: 변수 이름
            amount: 증가량 (음수도 가능)

        Raises:
            VariableError: 변수가 숫자가 아닐 때
        """
        current_str = self.get(name, "0")
        try:
            current_val = int(current_str)
        except ValueError as err:
            raise VariableError(f"변수 '{name}'의 값 '{current_str}'은 숫자가 아닙니다") from err

        new_val = current_val + amount
        self.set(name, str(new_val))

    def evaluate(self, expression: str) -> str:
        """수식을 평가한다.

        {var_name} 형태의 변수 참조를 치환한 후,
        숫자 계산식(+, -, *, /, %, //, **, 괄호)이면 계산한다.

        Args:
            expression: 수식 문자열 (예: "{counter} + 1", "{x} * 2")

        Returns:
            평가 결과 문자열

        Examples:
            store.set("counter", "5")
            store.evaluate("{counter} + 10")  → "15"
            store.evaluate("{counter}")       → "5"
            store.evaluate("hello")           → "hello"
        """

        # 1단계: 변수 치환
        def replace_var(match: re.Match[str]) -> str:
            var_name = match.group(1)
            return self.get(var_name, "0")

        substituted = VAR_REF_PATTERN.sub(replace_var, expression)

        # 2단계: AST 기반 안전한 숫자식 평가
        try:
            if re.match(r"^[\d\s\+\-\*\/%\(\)\.]+$", substituted.strip()):
                result = _safe_math_eval(substituted.strip())
                if isinstance(result, float) and result == int(result):
                    return str(int(result))
                return str(result)
        except Exception:
            pass

        return substituted

    def reset(self) -> None:
        """모든 변수를 초기화한다."""
        count = len(self._variables)
        self._variables.clear()
        self._scope_stack.clear()
        self._dirty = True
        logger.debug("변수 저장소 초기화 (삭제: %d개)", count)

    def get_all(self) -> dict[str, str]:
        """전체 변수 목록을 반환한다 (복사본).

        Returns:
            변수 이름→값 딕셔너리 (원본과 독립)
        """
        return dict(self._variables)

    def get_all_if_changed(self) -> dict[str, str] | None:
        """변경이 있었으면 전체 변수 복사본을 반환하고, 없으면 None."""
        if not self._dirty:
            return None
        self._dirty = False
        return dict(self._variables)

    @property
    def count(self) -> int:
        """현재 저장된 변수 수."""
        return len(self._variables)

    # -------------------------------------------------------------------
    # 내부 메서드
    # -------------------------------------------------------------------

    @staticmethod
    def _validate_name(name: str) -> None:
        """변수 이름의 유효성을 검증한다.

        Raises:
            VariableError: 이름이 유효하지 않을 때
        """
        if not name:
            raise VariableError("변수 이름이 비어있습니다")

        if len(name) > MAX_VAR_NAME_LENGTH:
            raise VariableError(
                f"변수 이름이 너무 깁니다: {len(name)}자 (최대 {MAX_VAR_NAME_LENGTH}자)"
            )

        if not VAR_NAME_PATTERN.match(name):
            raise VariableError(f"잘못된 변수 이름: '{name}' (영숫자와 _만 허용)")


# ---------------------------------------------------------------------------
# AST 기반 안전한 사칙연산 평가
# ---------------------------------------------------------------------------

_SAFE_OPS: dict[type, object] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def _safe_math_eval(expr: str) -> int | float:
    """AST를 파싱하여 숫자 연산만 허용하는 안전한 수식 평가.

    eval()과 달리 함수 호출, 속성 접근, import 등이 불가능하다.

    Args:
        expr: 숫자와 + - * / % // ** 연산자, 괄호만 포함된 수식 문자열

    Returns:
        계산 결과

    Raises:
        ValueError: 허용되지 않는 노드가 포함된 경우
    """
    tree = ast.parse(expr, mode="eval")
    return _eval_node(tree.body)


def _eval_node(node: ast.expr) -> int | float:
    """AST 노드를 재귀적으로 평가한다."""
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value

    if isinstance(node, ast.BinOp):
        op_func = _SAFE_OPS.get(type(node.op))
        if op_func is None:
            raise ValueError(f"허용되지 않는 연산자: {type(node.op).__name__}")
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        return op_func(left, right)

    if isinstance(node, ast.UnaryOp):
        op_func = _SAFE_OPS.get(type(node.op))
        if op_func is None:
            raise ValueError(f"허용되지 않는 단항 연산자: {type(node.op).__name__}")
        return op_func(_eval_node(node.operand))

    raise ValueError(f"허용되지 않는 수식 요소: {type(node).__name__}")
