"""Arduino 시리얼 통신 관리자.

Arduino Leonardo와 USB CDC 시리얼 연결을 관리하고,
shared/protocol.py의 패킷을 전송/수신한다.

연결 → 핸드셰이크 → 명령 전송/ACK 수신 → 재연결 로직을 캡슐화한다.
"""

from __future__ import annotations

import logging
import sys
import threading
import time
from contextlib import suppress
from typing import Any

if sys.platform.startswith("win"):
    import ctypes
    from ctypes import wintypes

import serial
import serial.tools.list_ports

from shared.models import Action, MouseDragAction, MouseMoveAction
from shared.mouse_utils import generate_bezier_path, path_to_relative_steps
from shared.protocol import (
    PACKET_STX,
    InvalidPacketError,
    SerialCommand,
    action_to_commands,
    build_emergency_stop,
    build_handshake,
    decode_packet,
    encode_mouse_move,
)

logger = logging.getLogger(__name__)

# Arduino Leonardo USB VID:PID
ARDUINO_VID: int = 0x2341
ARDUINO_PID_NORMAL: int = 0x8036
ARDUINO_PID_BOOTLOADER: int = 0x8037

DEFAULT_BAUD_RATE: int = 115200
DEFAULT_READ_TIMEOUT: float = 0.1  # 100ms
DEFAULT_CONNECT_TIMEOUT: float = 3.0  # 3초
MAX_RETRIES: int = 3
ACK_TIMEOUT: float = 0.1  # 100ms
MOUSE_CLICK_ACK_BASE_TIMEOUT: float = 0.1
MOUSE_CLICK_ACK_PER_GAP_TIMEOUT: float = 0.05
MOUSE_CLICK_ACK_MARGIN_TIMEOUT: float = 0.05


# ---------------------------------------------------------------------------
# 커스텀 예외
# ---------------------------------------------------------------------------


class SerialConnectionError(Exception):
    """시리얼 연결 실패 에러."""


# ---------------------------------------------------------------------------
# 포트 탐지 유틸리티
# ---------------------------------------------------------------------------


def list_available_ports() -> list[dict[str, Any]]:
    """사용 가능한 시리얼 포트 목록을 반환한다.

    Returns:
        포트 정보 딕셔너리의 리스트.
        각 항목: {"device": str, "description": str, "vid": int|None, "pid": int|None}
    """
    ports: list[dict[str, Any]] = []
    for port_info in serial.tools.list_ports.comports():
        ports.append(
            {
                "device": port_info.device,
                "description": port_info.description,
                "vid": port_info.vid,
                "pid": port_info.pid,
            }
        )
    return ports


def detect_arduino_port() -> str | None:
    """Arduino Leonardo를 VID:PID로 자동 탐지한다.

    Returns:
        감지된 포트 이름 (예: "COM3") 또는 None
    """
    for port_info in serial.tools.list_ports.comports():
        if port_info.vid == ARDUINO_VID and port_info.pid in (
            ARDUINO_PID_NORMAL,
            ARDUINO_PID_BOOTLOADER,
        ):
            logger.info(
                "Arduino Leonardo 감지: %s (%s)",
                port_info.device,
                port_info.description,
            )
            return port_info.device
    return None


# ---------------------------------------------------------------------------
# SerialCommander
# ---------------------------------------------------------------------------


class SerialCommander:
    """Arduino 시리얼 통신 관리자.

    연결, 핸드셰이크, 명령 전송, ACK 대기, 재연결을 관리한다.
    """

    def __init__(
        self,
        port: str | None = None,
        baud_rate: int = DEFAULT_BAUD_RATE,
    ) -> None:
        """초기화.

        Args:
            port: 시리얼 포트. None이면 자동 탐지.
            baud_rate: 보드레이트 (기본 115200)
        """
        self._port_name: str | None = port
        self._baud_rate: int = baud_rate
        self._serial: serial.Serial | None = None
        self._current_mouse_pos: tuple[int, int] = (0, 0)
        # 핸드셰이크 성공 이후 True — 의도치 않은 끊김만 러너에 알리기 위함
        self._session_active: bool = False
        self._suppress_link_lost: bool = False
        self._link_lost_event: threading.Event | None = None

    @property
    def port_name(self) -> str | None:
        """현재 연결된 포트 이름."""
        return self._port_name

    @property
    def current_mouse_pos(self) -> tuple[int, int]:
        """PC가 추적하는 현재 마우스 위치."""
        return self._current_mouse_pos

    @current_mouse_pos.setter
    def current_mouse_pos(self, pos: tuple[int, int]) -> None:
        """마우스 추적 좌표를 설정한다."""
        self._current_mouse_pos = pos

    def set_link_lost_event(self, event: threading.Event | None) -> None:
        """Arduino 세션이 비정상 종료될 때 set될 스레드 이벤트를 등록한다."""
        self._link_lost_event = event

    def _raise_if_link_lost_flag(self) -> None:
        """다른 스레드가 이미 포트를 닫은 뒤 플래그만 켜진 경우 즉시 중단."""
        ev = self._link_lost_event
        if ev is not None and ev.is_set():
            raise SerialConnectionError("Arduino 연결 끊김")

    def is_connected(self) -> bool:
        """시리얼 연결 상태를 확인한다.

        단순 is_open 플래그 외에 실제 포트 접근을 시도하여
        USB 분리 등 물리적 끊김도 감지한다.
        """
        if self._serial is None or not self._serial.is_open:
            return False
        try:
            _ = self._serial.in_waiting
            return True
        except (serial.SerialException, OSError):
            self._close_port()
            return False

    def sync_mouse_position_from_os(self) -> None:
        """OS의 실제 마우스 위치를 읽어 내부 좌표를 동기화한다.

        절대 좌표 MouseMove 액션이 화면 좌측 상단(0,0) 기준으로
        동작하도록 현재 커서 위치를 기준점으로 사용한다.
        """
        try:
            if sys.platform.startswith("win"):
                point = wintypes.POINT()
                if ctypes.windll.user32.GetCursorPos(ctypes.byref(point)):
                    self._current_mouse_pos = (int(point.x), int(point.y))
                    logger.debug("OS 마우스 위치 동기화: %s", self._current_mouse_pos)
            else:
                logger.debug("OS 마우스 위치 동기화는 Windows에서만 지원됩니다.")
        except Exception as exc:
            logger.warning("OS 마우스 위치 동기화 실패: %s", exc)

    def connect(self, port: str | None = None) -> None:
        """Arduino에 시리얼 연결하고 핸드셰이크를 수행한다.

        Args:
            port: 연결할 포트. None이면 자동 탐지 또는 초기 설정값 사용.

        Raises:
            SerialConnectionError: 연결 또는 핸드셰이크 실패 시
        """
        self._suppress_link_lost = True
        try:
            if self.is_connected():
                logger.warning("이미 연결됨. 기존 연결을 닫습니다.")
                self._close_port()
        finally:
            self._suppress_link_lost = False

        target_port = port or self._port_name or detect_arduino_port()
        if target_port is None:
            raise SerialConnectionError(
                "Arduino Leonardo를 찾을 수 없습니다. "
                "USB 연결을 확인하거나 포트를 직접 지정하세요."
            )

        self._port_name = target_port

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                logger.info(
                    "시리얼 연결 시도 (%d/%d): %s",
                    attempt,
                    MAX_RETRIES,
                    target_port,
                )
                self._serial = serial.Serial(
                    port=target_port,
                    baudrate=self._baud_rate,
                    timeout=DEFAULT_READ_TIMEOUT,
                )

                # Leonardo 연결 안정화 대기
                time.sleep(0.5)
                self._serial.reset_input_buffer()

                # 핸드셰이크
                if self._perform_handshake():
                    self._session_active = True
                    logger.info("Arduino 연결 성공: %s", target_port)
                    return
                else:
                    logger.warning("핸드셰이크 실패 (시도 %d/%d)", attempt, MAX_RETRIES)
                    self._close_port()

            except serial.SerialException as exc:
                logger.warning(
                    "시리얼 연결 실패 (시도 %d/%d): %s",
                    attempt,
                    MAX_RETRIES,
                    exc,
                )
                self._close_port()

            if attempt < MAX_RETRIES:
                time.sleep(1.0)

        raise SerialConnectionError(f"{MAX_RETRIES}회 시도 후 Arduino 연결 실패: {target_port}")

    def disconnect(self) -> None:
        """EMERGENCY_STOP 전송 후 시리얼 연결을 닫는다."""
        self._suppress_link_lost = True
        try:
            if self.is_connected():
                try:
                    self.emergency_stop(routine_shutdown=True)
                except Exception as exc:
                    logger.warning("연결 해제 중 비상정지 전송 실패: %s", exc)
                self._close_port()
                logger.info("Arduino 연결 해제 완료")
        finally:
            self._suppress_link_lost = False

    def send_command(self, packet: bytes) -> bool:
        """시리얼 패킷을 전송하고 ACK를 대기한다.

        Args:
            packet: 전송할 완전한 패킷 바이트열

        Returns:
            ACK 성공 여부

        Raises:
            SerialConnectionError: 전송 실패 또는 재시도 초과 시
        """
        if not self.is_connected():
            raise SerialConnectionError("Arduino에 연결되어 있지 않습니다")

        ack_timeout = self._resolve_ack_timeout(packet)

        for attempt in range(1, MAX_RETRIES + 1):
            self._raise_if_link_lost_flag()
            try:
                self._serial.write(packet)  # type: ignore[union-attr]
                self._serial.flush()  # type: ignore[union-attr]

                logger.debug("패킷 전송: %s", packet.hex())

                ack_status = self._wait_for_ack(timeout=ack_timeout)
                if ack_status == 0x00:
                    return True
                elif ack_status == 0x01:
                    logger.warning("체크섬 오류 ACK (시도 %d/%d)", attempt, MAX_RETRIES)
                elif ack_status == 0x02:
                    logger.error("알 수 없는 CMD ACK")
                    return False
                elif ack_status == 0x03:
                    logger.warning("실행 실패 ACK (킬 스위치?)")
                    return False
                elif ack_status is None:
                    logger.warning("ACK 타임아웃 (시도 %d/%d)", attempt, MAX_RETRIES)
                    # 끊김 시 재시도 3번 기다리지 않고 바로 일시정지 분기로 넘김
                    if not self.is_connected():
                        raise SerialConnectionError("Arduino 연결 끊김 (ACK 타임아웃)")

            except serial.SerialException as exc:
                logger.error("시리얼 전송 에러: %s", exc)
                self._close_port()
                raise SerialConnectionError(f"시리얼 전송 실패: {exc}") from exc

        raise SerialConnectionError(f"{MAX_RETRIES}회 재시도 후 ACK 수신 실패")

    def send_action(self, action: Action) -> bool:
        """Action 모델을 시리얼 명령으로 변환하여 전송한다.

        MouseMoveAction에 duration_ms > 0이 설정된 경우,
        베지어 커브 경로를 생성하여 스텝별로 딜레이를 넣어 전송한다.

        Args:
            action: 전송할 Action 인스턴스

        Returns:
            모든 패킷 전송 성공 여부
        """
        # 절대 좌표 마우스 이동 전에 OS 커서 위치를 재동기화하여
        # 누적된 추적 오차를 제거한다.
        if (isinstance(action, MouseMoveAction) and not action.is_relative) or isinstance(
            action, MouseDragAction
        ):
            self.sync_mouse_position_from_os()

        # 베지어 커브 이동: duration_ms > 0이고 절대 좌표인 경우
        if (
            isinstance(action, MouseMoveAction)
            and not action.is_relative
            and action.duration_ms > 0
        ):
            success = self._send_bezier_move(action)
            if success:
                self._current_mouse_pos = (action.x, action.y)
            return success

        # 베지어 커브 드래그: duration_ms > 0인 MouseDrag
        if isinstance(action, MouseDragAction) and action.duration_ms > 0:
            success = self._send_bezier_drag(action)
            if success:
                self._current_mouse_pos = (action.end_x, action.end_y)
            return success

        packets = action_to_commands(action, self._current_mouse_pos)
        if not packets:
            return True  # 흐름 제어 액션은 패킷 없음

        for packet in packets:
            self._raise_if_link_lost_flag()
            if not self.send_command(packet):
                return False

        self._update_mouse_position(action)

        # 절대 좌표 이동 후 실제 커서 위치를 확인하고
        # 오차가 있으면 보정 이동을 수행한다.
        if isinstance(action, MouseMoveAction) and not action.is_relative:
            self._correct_absolute_position(action.x, action.y)

        return True

    def emergency_stop(self, *, routine_shutdown: bool = False) -> None:
        """비상 정지 패킷을 전송한다.

        모든 눌린 키와 마우스 버튼을 즉시 해제한다.
        ACK 실패해도 예외를 발생시키지 않는다 (비상 상황이므로).

        Args:
            routine_shutdown: True이면 앱 종료·포트 닫기 직전의 안전 해제로 간주하고
                로그 레벨을 낮춘다 (매크로를 돌리지 않았어도 disconnect 시 항상 호출됨).
        """
        if not self.is_connected():
            return

        try:
            packet = build_emergency_stop()
            self._serial.write(packet)  # type: ignore[union-attr]
            self._serial.flush()  # type: ignore[union-attr]
            if routine_shutdown:
                logger.info("연결 해제: EMERGENCY_STOP 전송 (HID 안전 해제)")
            else:
                logger.critical("EMERGENCY_STOP 전송 완료")
        except serial.SerialException as exc:
            logger.error("EMERGENCY_STOP 전송 실패: %s", exc)

    # -------------------------------------------------------------------
    # 내부 메서드
    # -------------------------------------------------------------------

    def _perform_handshake(self) -> bool:
        """핸드셰이크 패킷을 전송하고 ACK를 확인한다."""
        try:
            packet = build_handshake()
            self._serial.write(packet)  # type: ignore[union-attr]
            self._serial.flush()  # type: ignore[union-attr]

            ack_status = self._wait_for_ack()
            return ack_status == 0x00
        except Exception as exc:
            logger.debug("핸드셰이크 에러: %s", exc)
            return False

    def _wait_for_ack(self, timeout: float = ACK_TIMEOUT) -> int | None:
        """ACK 패킷을 대기하고 status를 반환한다.

        Returns:
            ACK status (0x00=성공 등) 또는 타임아웃 시 None

        Raises:
            serial.SerialException: USB 분리 등 시리얼 통신 실패 시
        """
        ser = self._serial
        if ser is None:
            return None

        start_time = time.monotonic()
        buffer = bytearray()
        try:
            saved_timeout = ser.timeout
            ser.timeout = 0.01  # 10ms OS-level 블로킹 대기
        except (AttributeError, OSError):
            return None

        try:
            while time.monotonic() - start_time < timeout:
                try:
                    available = ser.in_waiting
                except serial.SerialException:
                    raise  # USB 분리 → 상위 send_command에서 처리
                except OSError as err:
                    raise serial.SerialException("시리얼 포트 접근 실패 (USB 분리?)") from err

                try:
                    chunk = ser.read(max(available, 1))
                except serial.SerialException:
                    raise
                except OSError as err:
                    raise serial.SerialException("시리얼 읽기 실패 (USB 분리?)") from err

                if chunk:
                    buffer.extend(chunk)

                    stx_idx = buffer.find(bytes([PACKET_STX]))
                    if stx_idx >= 0 and len(buffer) >= stx_idx + 6:
                        candidate = bytes(buffer[stx_idx : stx_idx + 6])
                        try:
                            cmd, payload = decode_packet(candidate)
                            if cmd == SerialCommand.ACK and len(payload) >= 1:
                                return payload[0]
                        except InvalidPacketError:
                            buffer = buffer[stx_idx + 1 :]
        except (AttributeError, OSError):
            return None
        finally:
            with suppress(AttributeError, OSError):
                ser.timeout = saved_timeout

        return None

    def _resolve_ack_timeout(self, packet: bytes) -> float:
        """패킷 타입에 맞는 ACK 타임아웃을 계산한다."""
        if len(packet) < 6:
            return ACK_TIMEOUT

        cmd = packet[1]
        if cmd != int(SerialCommand.MOUSE_CLICK):
            return ACK_TIMEOUT

        length = packet[2]
        if length < 2 or len(packet) < 7:
            return ACK_TIMEOUT

        count = packet[4]
        if count <= 1:
            return MOUSE_CLICK_ACK_BASE_TIMEOUT

        # Arduino 펌웨어의 click 간 delay(50ms) * (count-1) 반영.
        return (
            MOUSE_CLICK_ACK_BASE_TIMEOUT
            + (count - 1) * MOUSE_CLICK_ACK_PER_GAP_TIMEOUT
            + MOUSE_CLICK_ACK_MARGIN_TIMEOUT
        )

    def _close_port(self) -> None:
        """시리얼 포트를 안전하게 닫는다."""
        had_session = self._session_active
        self._session_active = False
        if self._serial is not None:
            try:
                if self._serial.is_open:
                    self._serial.close()
            except Exception:
                pass
            self._serial = None
        if had_session and self._link_lost_event is not None and not self._suppress_link_lost:
            self._link_lost_event.set()

    def _correct_absolute_position(
        self,
        target_x: int,
        target_y: int,
        max_attempts: int = 3,
        tolerance: int = 2,
    ) -> None:
        """절대 이동 후 커서가 목표에 도달했는지 확인하고 보정한다.

        OS 마우스 가속 등으로 인해 HID 상대 이동이 정확하지 않을 수 있으므로,
        실제 커서 위치를 읽어 오차가 허용 범위를 초과하면 보정 이동을 반복한다.
        """
        for _ in range(max_attempts):
            self.sync_mouse_position_from_os()
            actual_x, actual_y = self._current_mouse_pos

            err_x = target_x - actual_x
            err_y = target_y - actual_y

            if abs(err_x) <= tolerance and abs(err_y) <= tolerance:
                break

            logger.debug(
                "마우스 보정 이동: 목표(%d,%d), 실제(%d,%d), 오차(%d,%d)",
                target_x,
                target_y,
                actual_x,
                actual_y,
                err_x,
                err_y,
            )

            err_x = max(-128, min(127, err_x))
            err_y = max(-128, min(127, err_y))
            packet = encode_mouse_move(err_x, err_y)
            if not self.send_command(packet):
                break

        self._current_mouse_pos = (target_x, target_y)

    def _send_bezier_move(self, action: MouseMoveAction) -> bool:
        """베지어 커브 경로를 따라 마우스를 자연스럽게 이동한다.

        ACK 대기 없이 연속 전송하고, 실제 경과 시간을 측정하여
        설정한 duration_ms에 맞게 보정한다.
        """
        import math

        from shared.protocol import _split_move_proportional

        start_x, start_y = self._current_mouse_pos
        end_x, end_y = action.x, action.y

        distance = math.sqrt((end_x - start_x) ** 2 + (end_y - start_y) ** 2)
        if distance < 3:
            return True

        duration_ms = action.duration_ms

        # 100ms 이하면 베지어 없이 즉시 이동 (기존 ACK 방식)
        if duration_ms <= 100:
            dx = end_x - start_x
            dy = end_y - start_y
            for sub_dx, sub_dy in _split_move_proportional(dx, dy):
                self._raise_if_link_lost_flag()
                packet = encode_mouse_move(sub_dx, sub_dy)
                if not self.send_command(packet):
                    return False
            return True

        # 스텝 수: 10ms 간격 기준, 최소 10개 ~ 최대 200개
        num_points = max(10, min(round(duration_ms / 10), 200))

        path = generate_bezier_path(
            start_x,
            start_y,
            end_x,
            end_y,
            num_points=num_points,
        )
        if len(path) < 2:
            return True

        steps = path_to_relative_steps(path)
        if not steps:
            return True

        # 전체 패킷 미리 생성
        all_packets: list[bytes] = []
        for step_dx, step_dy in steps:
            if step_dx == 0 and step_dy == 0:
                continue
            for sub_dx, sub_dy in _split_move_proportional(step_dx, step_dy):
                all_packets.append(encode_mouse_move(sub_dx, sub_dy))

        if not all_packets or not self.is_connected():
            return False

        # 실제 시간을 측정하면서 전송
        target_duration = duration_ms / 1000.0
        start_time = time.monotonic()

        try:
            for i, packet in enumerate(all_packets):
                if i % 3 == 0:
                    self._raise_if_link_lost_flag()
                self._serial.write(packet)

                # 현재까지 걸린 시간 대비 목표 시간 비율로 딜레이 보정
                elapsed = time.monotonic() - start_time
                expected = target_duration * (i + 1) / len(all_packets)
                remaining_sleep = expected - elapsed

                if remaining_sleep > 0.0005:
                    time.sleep(remaining_sleep)

            self._serial.flush()
        except serial.SerialException as exc:
            logger.error("베지어 이동 중 연결 끊김: %s", exc)
            self._close_port()
            raise SerialConnectionError(f"베지어 이동 중 연결 끊김: {exc}") from exc
        except Exception as exc:
            logger.error("베지어 이동 전송 실패: %s", exc)
            return False

        # 쌓인 ACK 응답 제거
        try:
            if self._serial.in_waiting > 0:
                self._serial.read(self._serial.in_waiting)
        except Exception:
            pass

        return True

    def _send_bezier_drag(self, action: MouseDragAction) -> bool:
        """베지어 커브로 드래그를 자연스럽게 수행한다."""
        import math

        from shared.protocol import (
            _split_move_proportional,
            encode_mouse_down,
            encode_mouse_up,
            get_mouse_button_code,
        )

        # 1) 시작점으로 이동
        start_x, start_y = action.start_x, action.start_y
        end_x, end_y = action.end_x, action.end_y

        move_to_start = MouseMoveAction(
            x=start_x,
            y=start_y,
            is_relative=False,
            duration_ms=min(200, action.duration_ms // 2),
        )
        if not self.send_action(move_to_start):
            return False

        # 2) 마우스 다운
        button_code = get_mouse_button_code("LEFT")
        if not self.send_command(encode_mouse_down(button_code)):
            return False

        # 3) 끝점까지 베지어 이동
        distance = math.sqrt((end_x - start_x) ** 2 + (end_y - start_y) ** 2)
        if distance < 3:
            if not self.send_command(encode_mouse_up(button_code)):
                with suppress(Exception):
                    self.send_command(encode_mouse_up(button_code))
                with suppress(Exception):
                    self.emergency_stop()
                logger.error(
                    "짧은 드래그: mouse_up 전송 실패 → emergency_stop 시도",
                )
                return False
            return True

        num_points = max(15, min(50, round(distance / 30)))
        path = generate_bezier_path(start_x, start_y, end_x, end_y, num_points=num_points)
        steps = path_to_relative_steps(path)

        delay_per_step = action.duration_ms / max(len(steps), 1) / 1000.0

        for step_dx, step_dy in steps:
            if step_dx == 0 and step_dy == 0:
                continue
            for sub_dx, sub_dy in _split_move_proportional(step_dx, step_dy):
                packet = encode_mouse_move(sub_dx, sub_dy)
                if not self.send_command(packet):
                    with suppress(Exception):
                        self.send_command(encode_mouse_up(button_code))
                    return False
            if delay_per_step > 0.001:
                time.sleep(delay_per_step)

        # 4) 마우스 업 (실패 시 재시도 후 비상 해제 — 버튼 잠김 방지)
        if not self.send_command(encode_mouse_up(button_code)):
            with suppress(Exception):
                self.send_command(encode_mouse_up(button_code))
            with suppress(Exception):
                self.emergency_stop()
            logger.error("베지어 드래그 종료: mouse_up 전송 실패 → emergency_stop 시도")
            return False

        return True

    def _update_mouse_position(self, action: Action) -> None:
        """마우스 이동 액션 후 추적 위치를 업데이트한다."""
        if isinstance(action, MouseMoveAction):
            if action.is_relative:
                cx, cy = self._current_mouse_pos
                self._current_mouse_pos = (cx + action.x, cy + action.y)
            else:
                self._current_mouse_pos = (action.x, action.y)
        elif isinstance(action, MouseDragAction):
            self._current_mouse_pos = (action.end_x, action.end_y)
