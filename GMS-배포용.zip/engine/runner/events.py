import logging
import time

logger = logging.getLogger(__name__)


class EventEmitterMixin:
    def _dispatch_visual_debug(
        self,
        kind: str,
        ref_png: bytes | None,
        screen_png: bytes | None,
        show_found_thumb: bool,
    ) -> None:
        for callback in list(self.on_visual_debug):
            try:
                callback(kind, ref_png, screen_png, show_found_thumb)
            except Exception as exc:
                logger.debug("on_visual_debug 콜백 에러: %s", exc)

    def _emit_action_executed(self, index: int) -> None:
        for callback in list(self.on_action_executed):
            try:
                callback(index)
            except Exception as exc:
                logger.debug("on_action_executed 콜백 에러: %s", exc)

    def _emit_error(self, message: str) -> None:
        for callback in list(self.on_error):
            try:
                callback(message)
            except Exception as exc:
                logger.debug("on_error 콜백 에러: %s", exc)

    def _emit_variables_changed(self, variables: dict[str, str]) -> None:
        if not self.on_variables_changed:
            return
        snapshot = dict(variables)
        for callback in self.on_variables_changed:
            try:
                callback(snapshot)
            except Exception as exc:
                logger.debug("on_variables_changed 콜백 에러: %s", exc)

    def _emit_log(self, level: str, message: str) -> None:
        log_func = getattr(logger, level.lower(), logger.info)
        log_func(message)
        for callback in list(self.on_log):
            try:
                callback(level, message)
            except Exception as exc:
                logger.debug("on_log 콜백 에러: %s", exc)

    def _emit_connection_lost(self, message: str) -> None:
        """Arduino 연결 끊김을 UI에 알린다."""
        for callback in list(self.on_connection_lost):
            try:
                callback(message)
            except Exception as exc:
                logger.debug("on_connection_lost 콜백 에러: %s", exc)

    def _emit_reconnected(self) -> None:
        """Arduino 재연결 성공을 UI에 알린다."""
        for callback in list(self.on_reconnected):
            try:
                callback()
            except Exception as exc:
                logger.debug("on_reconnected 콜백 에러: %s", exc)

    def _emit_stats_summary(self) -> None:
        """실행 통계 요약을 로그로 출력한다."""
        if self._stats_start_time <= 0:
            return
        elapsed = time.monotonic() - self._stats_start_time
        minutes = int(elapsed // 60)
        seconds = int(elapsed % 60)
        time_str = f"{minutes}분 {seconds}초" if minutes > 0 else f"{seconds}초"
        summary = f"실행 통계: {time_str}간 {self._stats_action_count}개 액션 실행"
        if self._stats_error_count > 0:
            summary += f", 에러 {self._stats_error_count}건"
        self._emit_log("INFO", summary)
