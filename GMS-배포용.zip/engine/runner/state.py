from enum import StrEnum


class RunnerState(StrEnum):
    """매크로 실행기 상태."""

    IDLE = "IDLE"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STOPPED = "STOPPED"
    COMPLETED = "COMPLETED"
