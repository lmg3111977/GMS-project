import logging
from collections.abc import Callable
from typing import Any  # noqa: F401

from .state import RunnerState

logger = logging.getLogger(__name__)


class ReconnectMixin:
    MAX_RECONNECT_ATTEMPTS = 60  # reconnect_interval_sec 간격 × 60 ≈ 최대 5분

    def _recover_arduino_link(self, error_msg: str, *, resume_running: bool) -> bool:
        """끊김 알림 → 재연결 루프. resume_running이 True이면 성공 후 RUNNING으로 복귀."""
        self._link_lost_event.clear()
        paused_pc = self._scheduler.program_counter

        if resume_running:
            self._set_state(RunnerState.PAUSED)
        self._emit_log(
            "ERROR",
            f"Arduino 연결 끊김 (액션 #{paused_pc}). " f"일시정지 후 재연결을 시도합니다...",
        )
        self._emit_connection_lost(error_msg)

        reconnected = self._wait_and_reconnect()
        if reconnected:
            if resume_running:
                self._set_state(RunnerState.RUNNING)
            self._emit_log(
                "INFO",
                (
                    f"Arduino 재연결 완료! 액션 #{paused_pc}부터 이어서 실행합니다."
                    if resume_running
                    else (
                        f"Arduino 재연결 완료. 일시정지 상태 유지 — 액션 #{paused_pc}에서 재개하세요."
                    )
                ),
            )
            self._emit_reconnected()
            return True

        self._emit_log("WARNING", "재연결 대기 중 사용자 정지. 매크로를 종료합니다.")
        self._emit_error(error_msg)
        self.stop_macro()
        return False

    def _wait_and_reconnect(self) -> bool:
        """Arduino 재연결을 5초 간격으로 반복 시도한다.

        워커 스레드에서 호출된다.
        상태는 이미 PAUSED이고, scheduler 상태는 보존된 채.
        _stop_event가 set되면(Ctrl+F7 정지) 즉시 중단하고 False를 반환한다.

        Returns:
            True: 재연결 성공 (호출자가 RUNNING으로 전환해야 함)
            False: Ctrl+F7로 중단됨
        """
        from engine.serial_cmd import SerialConnectionError, detect_arduino_port

        if self._serial is None:
            return False

        self._arduino_reconnect_busy.set()
        try:
            return self._wait_and_reconnect_impl(
                SerialConnectionError,
                detect_arduino_port,
            )
        finally:
            self._arduino_reconnect_busy.clear()

    def clear_link_lost_after_external_reconnect(self) -> None:
        """GUI 등에서 시리얼을 다시 연 직후 끊김 플래그를 초기화한다."""
        self._link_lost_event.clear()

    def _wait_and_reconnect_impl(
        self,
        connection_exc: type[Exception],
        port_detector: Callable[..., str | None],
    ) -> bool:
        attempt = 0
        while attempt < self.MAX_RECONNECT_ATTEMPTS:
            if self._stop_event.is_set():
                return False

            if self._stop_event.wait(timeout=self.reconnect_interval_sec):
                return False

            attempt += 1
            self._emit_log(
                "INFO",
                f"Arduino 재연결 시도 {attempt}회...",
            )

            new_port = port_detector()
            if new_port is None:
                self._emit_log("WARNING", f"재연결 시도 {attempt}회: Arduino를 찾을 수 없습니다")
                continue

            try:
                self._serial.connect(port=new_port)
            except connection_exc as exc:
                self._emit_log("WARNING", f"재연결 시도 {attempt}회: 연결 실패 — {exc}")
                continue

            try:
                self._serial.sync_mouse_position_from_os()
            except Exception as exc:
                logger.debug("재연결 후 마우스 위치 동기화 실패: %s", exc)

            self._link_lost_event.clear()
            self._emit_log("INFO", f"Arduino 재연결 성공: {new_port}")
            return True

        self._emit_log(
            "ERROR",
            f"Arduino 재연결 최대 시도 횟수 초과 ({self.MAX_RECONNECT_ATTEMPTS}회, "
            f"{self.MAX_RECONNECT_ATTEMPTS * self.reconnect_interval_sec:.0f}초). "
            "USB 연결을 확인하고 매크로를 다시 시작하세요.",
        )
        return False
