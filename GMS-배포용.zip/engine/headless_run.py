"""헤드리스(콘솔) 매크로 1회 실행 — main.py / player.main 중복 제거."""

from __future__ import annotations

import logging

from engine.runner import MacroRunner
from engine.screen import ScreenAnalyzer
from engine.serial_cmd import SerialCommander, SerialConnectionError
from shared.schema import MacroValidationError, load_macro


def run_macro_blocking_headless(
    macro_path: str,
    *,
    port: str | None = None,
    dry_run: bool = False,
    log: logging.Logger,
    log_engine_prefix: str = "Runner",
    log_runner_state_to_info: bool = False,
    register_serial_recovery_logs: bool = True,
) -> int:
    """매크로 JSON을 로드해 Arduino·화면 연결 후 블로킹 실행한다.

    Args:
        macro_path: JSON 경로.
        port: 시리얼 포트 (dry_run이면 무시).
        dry_run: True면 시리얼 미연결.
        log: 로거.
        log_engine_prefix: on_log 포맷 접두사 (표시용).
        log_runner_state_to_info: True면 상태 전이를 INFO로 남김 (player 전용 스타일).
        register_serial_recovery_logs: True면 연결 끊김/재연결 로그 콜백 등록 (main.py 스타일).

    Returns:
        0 성공, 1 실패.
    """
    try:
        macro = load_macro(macro_path)
        log.info("매크로 로드: %s (%d개 액션)", macro.name, len(macro.actions))
    except (MacroValidationError, FileNotFoundError) as exc:
        log.error("매크로 로드 실패: %s", exc)
        return 1

    serial_commander: SerialCommander | None = None
    screen_analyzer: ScreenAnalyzer | None = None

    if not dry_run:
        serial_commander = SerialCommander(port=port)
        try:
            serial_commander.connect()
            log.info("Arduino 연결됨: %s", serial_commander.port_name)
        except SerialConnectionError as exc:
            log.error("Arduino 연결 실패: %s", exc)
            return 1

        try:
            screen_analyzer = ScreenAnalyzer()
        except Exception as exc:
            log.warning("화면 분석기 초기화 실패: %s", exc)

    runner = MacroRunner(
        serial_commander=serial_commander,
        screen_analyzer=screen_analyzer,
        enable_visual_debug=False,
    )

    if log_runner_state_to_info:
        runner.on_state_changed.append(lambda state: log.info("[상태] %s", state))
    runner.on_error.append(lambda msg: log.error("[에러] %s", msg))
    runner.on_log.append(
        lambda level, msg: log.log(
            getattr(logging, level, logging.INFO),
            "[%s] %s",
            log_engine_prefix,
            msg,
        )
    )
    if register_serial_recovery_logs and serial_commander is not None:
        runner.on_connection_lost.append(lambda msg: log.error("[연결 끊김] %s", msg))
        runner.on_reconnected.append(
            lambda: log.info(
                "[재연결 성공] %s",
                serial_commander.port_name,
            )
        )

    runner.load_macro(macro, source_path=macro_path)
    runner.start_macro()

    log.info("매크로 실행 시작 (Ctrl+C로 정지)")

    try:
        runner.run_blocking()
    except KeyboardInterrupt:
        log.info("사용자 중단 (Ctrl+C)")
        runner.stop_macro()

    if serial_commander is not None:
        serial_commander.disconnect()
    if screen_analyzer is not None:
        screen_analyzer.close()

    log.info("매크로 실행 종료")
    return 0
