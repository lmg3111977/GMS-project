"""픽셀 기반 분석 기능 mixin."""

from __future__ import annotations

import logging
import threading
import time

import numpy as np

from shared.humanizer import sync_human_delay

from .color_utils import _check_pixel_bgr_fast, _color_distance, _parse_color

logger = logging.getLogger(__name__)


class PixelMixin:
    """픽셀 비교/검색 기능."""

    def get_pixel_match_metrics(
        self,
        x: int,
        y: int,
        target_color: str,
        tolerance: int = 10,
    ) -> tuple[bool, float, float]:
        """픽셀 매칭 결과와 거리/유사성을 반환한다.

        Returns:
            (matched, distance, similarity)
            similarity는 0.0~1.0이며 tolerance 기준 상대 점수다.
        """
        actual_color = self.get_pixel_color(x, y)
        distance = float(_color_distance(actual_color, target_color))
        tol = max(0, int(tolerance))
        if tol == 0:
            similarity = 1.0 if distance == 0.0 else 0.0
        else:
            similarity = max(0.0, min(1.0, 1.0 - (distance / float(tol))))
        return distance <= float(tol), distance, similarity

    def check_pixel_color(
        self,
        x: int,
        y: int,
        target_color: str,
        tolerance: int = 10,
    ) -> bool:
        """특정 좌표의 픽셀 색상이 목표 색상과 일치하는지 확인한다.

        Args:
            x: 픽셀 X 좌표
            y: 픽셀 Y 좌표
            target_color: 비교 대상 색상 (#RRGGBB)
            tolerance: 허용 오차 (RGB 유클리드 거리)

        Returns:
            거리가 tolerance 이내이면 True
        """
        img = self.capture_region(x, y, 1, 1)
        bgr = (int(img[0, 0, 0]), int(img[0, 0, 1]), int(img[0, 0, 2]))
        target_rgb = _parse_color(target_color)
        tol = max(0, int(tolerance))
        return _check_pixel_bgr_fast(bgr, target_rgb, float(tol) ** 2)

    def search_pixel(
        self,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        target_color: str,
        tolerance: int = 10,
    ) -> tuple[int, int] | None:
        """영역 내에서 특정 색상의 첫 번째 픽셀을 찾는다.

        numpy 벡터 연산을 사용하여 전체 영역을 한 번에 비교한다.

        Args:
            region_x: 검색 영역 좌상단 X
            region_y: 검색 영역 좌상단 Y
            region_width: 검색 영역 폭
            region_height: 검색 영역 높이
            target_color: 찾을 색상 (#RRGGBB)
            tolerance: 허용 오차

        Returns:
            (절대 x, 절대 y) 또는 None
        """
        img = self.capture_region(region_x, region_y, region_width, region_height)
        target_r, target_g, target_b = _parse_color(target_color)

        img_float = img.astype(np.float32)
        diff_b = img_float[:, :, 0] - target_b
        diff_g = img_float[:, :, 1] - target_g
        diff_r = img_float[:, :, 2] - target_r
        dist_sq = diff_r**2 + diff_g**2 + diff_b**2
        tolerance_sq = float(tolerance) ** 2

        matches = np.where(dist_sq <= tolerance_sq)
        if matches[0].size > 0:
            row, col = int(matches[0][0]), int(matches[1][0])
            return (region_x + col, region_y + row)

        return None

    def wait_for_pixel(
        self,
        x: int,
        y: int,
        color: str,
        tolerance: int = 10,
        timeout_ms: int = 5000,
        stop_event: threading.Event | None = None,
        link_lost_event: threading.Event | None = None,
    ) -> bool:
        """특정 픽셀이 지정 색상이 될 때까지 대기한다."""
        start_time = time.monotonic()
        timeout_sec = timeout_ms / 1000.0
        target_rgb = _parse_color(color)
        tol = max(0, int(tolerance))
        tolerance_sq = float(tol) ** 2

        while time.monotonic() - start_time < timeout_sec:
            if stop_event is not None and stop_event.is_set():
                logger.debug("픽셀 대기 중단 (stop_event): (%d, %d)", x, y)
                return False
            if link_lost_event is not None and link_lost_event.is_set():
                logger.debug("픽셀 대기 중단 (link_lost): (%d, %d)", x, y)
                return False
            img = self.capture_region(x, y, 1, 1)
            bgr = (int(img[0, 0, 0]), int(img[0, 0, 1]), int(img[0, 0, 2]))
            if _check_pixel_bgr_fast(bgr, target_rgb, tolerance_sq):
                logger.debug(
                    "픽셀 대기 완료: (%d, %d) = %s (%.0fms)",
                    x,
                    y,
                    color,
                    (time.monotonic() - start_time) * 1000,
                )
                return True
            sync_human_delay(
                50,
                randomize=False,
                stop_event=stop_event,
                link_lost_event=link_lost_event,
            )

        logger.debug("픽셀 대기 타임아웃: (%d, %d), %dms", x, y, timeout_ms)
        return False
