"""ScreenAnalyzer 조합 클래스."""

from __future__ import annotations

from .capture_mixin import CaptureMixin
from .image_mixin import ImageMixin
from .ocr_mixin import OcrMixin
from .pixel_mixin import PixelMixin


class ScreenAnalyzer(CaptureMixin, PixelMixin, ImageMixin, OcrMixin):
    """화면 캡처 및 분석 클래스."""

    def __init__(self) -> None:
        super().__init__()
