"""이미지 템플릿 매칭 기능 mixin."""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path

import numpy as np

from shared.humanizer import sync_human_delay

logger = logging.getLogger(__name__)


class ImageMixin:
    """템플릿 로드/매칭 기능."""

    MAX_TEMPLATE_CACHE = 50

    def _get_cached_template(self, template_path: str) -> np.ndarray | None:
        """템플릿 원본(BGR)을 캐시에서 가져오거나 파일에서 로드한다."""
        with self._template_cache_lock:
            cached = self._template_cache.get(template_path)
        if cached is not None:
            return cached

        import cv2

        template_file = Path(template_path)
        if not template_file.exists():
            logger.error("템플릿 이미지를 찾을 수 없음: %s", template_path)
            return None

        try:
            template_bytes = template_file.read_bytes()
            template_arr = np.frombuffer(template_bytes, dtype=np.uint8)
            template = cv2.imdecode(template_arr, cv2.IMREAD_COLOR)
        except Exception:
            template = None

        if template is None:
            logger.error("템플릿 이미지 로드 실패(imdecode): %s", template_path)
            return None

        with self._template_cache_lock:
            self._template_cache[template_path] = template
            if len(self._template_cache) > self.MAX_TEMPLATE_CACHE:
                oldest_key = next(iter(self._template_cache))
                del self._template_cache[oldest_key]
        return template

    def _load_template(
        self,
        template_path: str,
        screenshot: np.ndarray,
        grayscale: bool,
    ) -> tuple[np.ndarray, np.ndarray] | None:
        """템플릿 이미지를 로드하고 스크린샷과 함께 전처리한다.

        Windows 한글 경로 대응을 위해 cv2.imread 대신
        파일 바이트 → imdecode 경로를 사용한다.
        """
        try:
            import cv2
        except ImportError:
            logger.error("opencv-python-headless가 설치되지 않음 (이미지 매칭 불가)")
            return None

        template = self._get_cached_template(template_path)
        if template is None:
            return None

        proc_screenshot = screenshot
        if grayscale:
            proc_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
            template = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)

        if (
            template.shape[0] > proc_screenshot.shape[0]
            or template.shape[1] > proc_screenshot.shape[1]
        ):
            logger.warning(
                "템플릿(%dx%d)이 검색 영역(%dx%d)보다 큼",
                template.shape[1],
                template.shape[0],
                proc_screenshot.shape[1],
                proc_screenshot.shape[0],
            )
            return None

        return proc_screenshot, template

    def search_image_with_similarity(
        self,
        template_path: str,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        confidence: float = 0.85,
        grayscale: bool = False,
    ) -> tuple[tuple[int, int, float] | None, float]:
        """영역 내 템플릿 매칭 결과와 최대 유사성을 함께 반환한다."""
        import cv2

        screenshot = self.capture_region(region_x, region_y, region_width, region_height)
        loaded = self._load_template(template_path, screenshot, grayscale)
        if loaded is None:
            return None, 0.0
        proc_screenshot, template = loaded

        result = cv2.matchTemplate(proc_screenshot, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)
        similarity = float(max_val)

        if similarity >= confidence:
            center_x = region_x + max_loc[0] + template.shape[1] // 2
            center_y = region_y + max_loc[1] + template.shape[0] // 2
            logger.debug(
                "이미지 매칭 성공: (%d, %d), 신뢰도=%.3f",
                center_x,
                center_y,
                similarity,
            )
            return (center_x, center_y, similarity), similarity

        logger.debug("이미지 매칭 실패: 최대 신뢰도=%.3f < %.3f", similarity, confidence)
        return None, similarity

    def search_image(
        self,
        template_path: str,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        confidence: float = 0.85,
        grayscale: bool = False,
    ) -> tuple[int, int, float] | None:
        """영역 내에서 템플릿 이미지를 찾는다."""
        match, _similarity = self.search_image_with_similarity(
            template_path,
            region_x,
            region_y,
            region_width,
            region_height,
            confidence,
            grayscale,
        )
        return match

    def search_image_multi(
        self,
        template_path: str,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        confidence: float = 0.85,
        grayscale: bool = False,
        max_results: int = 10,
    ) -> list[tuple[int, int, float]]:
        """영역 내에서 템플릿 이미지를 여러 개 찾는다."""
        import cv2

        screenshot = self.capture_region(region_x, region_y, region_width, region_height)
        loaded = self._load_template(template_path, screenshot, grayscale)
        if loaded is None:
            return []
        proc_screenshot, template = loaded

        result = cv2.matchTemplate(proc_screenshot, template, cv2.TM_CCOEFF_NORMED)
        locations = np.where(result >= confidence)

        matches: list[tuple[int, int, float]] = []
        th, tw = template.shape[:2]
        cell_w = max(1, tw // 2)
        cell_h = max(1, th // 2)
        grid: dict[tuple[int, int], list[tuple[int, int]]] = {}

        for pt_y, pt_x in zip(*locations, strict=False):
            cx = region_x + int(pt_x) + tw // 2
            cy = region_y + int(pt_y) + th // 2
            gx, gy = cx // cell_w, cy // cell_h

            too_close = False
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for mx, my in grid.get((gx + dx, gy + dy), ()):
                        if abs(cx - mx) < cell_w and abs(cy - my) < cell_h:
                            too_close = True
                            break
                    if too_close:
                        break
                if too_close:
                    break

            if not too_close:
                conf = float(result[pt_y, pt_x])
                matches.append((cx, cy, conf))
                grid.setdefault((gx, gy), []).append((cx, cy))
                if len(matches) >= max_results:
                    break

        matches.sort(key=lambda m: m[2], reverse=True)
        return matches

    def wait_for_image(
        self,
        template_path: str,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        confidence: float = 0.85,
        grayscale: bool = False,
        timeout_ms: int = 10000,
        stop_event: threading.Event | None = None,
        link_lost_event: threading.Event | None = None,
    ) -> tuple[int, int, float] | None:
        """이미지가 나타날 때까지 대기한다."""
        match, _similarity = self.wait_for_image_with_similarity(
            template_path,
            region_x,
            region_y,
            region_width,
            region_height,
            confidence,
            grayscale,
            timeout_ms,
            stop_event=stop_event,
            link_lost_event=link_lost_event,
        )
        return match

    def wait_for_image_with_similarity(
        self,
        template_path: str,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        confidence: float = 0.85,
        grayscale: bool = False,
        timeout_ms: int = 10000,
        stop_event: threading.Event | None = None,
        link_lost_event: threading.Event | None = None,
    ) -> tuple[tuple[int, int, float] | None, float]:
        """이미지 대기 결과와 타임아웃까지의 최대 유사성을 반환한다."""
        start_time = time.monotonic()
        timeout_sec = timeout_ms / 1000.0
        best_similarity = 0.0

        while True:
            if stop_event is not None and stop_event.is_set():
                logger.debug("이미지 대기 중단 (stop_event): %s", template_path)
                return None, best_similarity
            if link_lost_event is not None and link_lost_event.is_set():
                logger.debug("이미지 대기 중단 (link_lost): %s", template_path)
                return None, best_similarity

            match, similarity = self.search_image_with_similarity(
                template_path,
                region_x,
                region_y,
                region_width,
                region_height,
                confidence,
                grayscale,
            )
            best_similarity = max(best_similarity, similarity)
            if match is not None:
                return match, best_similarity

            elapsed = time.monotonic() - start_time
            if timeout_ms > 0 and elapsed >= timeout_sec:
                break

            sync_human_delay(
                100,
                randomize=False,
                stop_event=stop_event,
                link_lost_event=link_lost_event,
            )

        return None, best_similarity
