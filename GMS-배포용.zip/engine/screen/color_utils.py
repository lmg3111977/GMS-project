"""색상 유틸리티 함수."""

import math


def _parse_color(color_str: str) -> tuple[int, int, int]:
    """#RRGGBB 문자열을 (R, G, B) 튜플로 파싱한다.

    Args:
        color_str: "#RRGGBB" 형식 색상 문자열

    Returns:
        (R, G, B) 0~255 정수 튜플
    """
    color_str = color_str.lstrip("#")
    return (
        int(color_str[0:2], 16),
        int(color_str[2:4], 16),
        int(color_str[4:6], 16),
    )


def _color_distance(color1: str, color2: str) -> float:
    """두 색상 사이의 RGB 유클리드 거리를 계산한다.

    Args:
        color1: 첫 번째 색상 (#RRGGBB)
        color2: 두 번째 색상 (#RRGGBB)

    Returns:
        유클리드 거리 (0.0 ~ 441.67)
    """
    r1, g1, b1 = _parse_color(color1)
    r2, g2, b2 = _parse_color(color2)
    return math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2)


def _color_distance_sq(color1: str, color2: str) -> float:
    """두 색상의 RGB 유클리드 거리의 제곱 (sqrt 생략)."""
    r1, g1, b1 = _parse_color(color1)
    r2, g2, b2 = _parse_color(color2)
    return float((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2)


def _check_pixel_bgr_fast(
    bgr_pixel: tuple[int, int, int],
    target_rgb: tuple[int, int, int],
    tolerance_sq: float,
) -> bool:
    """BGR 픽셀과 RGB 타겟을 제곱 거리로 비교. 문자열 변환 없음."""
    dr = bgr_pixel[2] - target_rgb[0]
    dg = bgr_pixel[1] - target_rgb[1]
    db = bgr_pixel[0] - target_rgb[2]
    return float(dr * dr + dg * dg + db * db) <= tolerance_sq
