"""화면 캡처 관련 기능 mixin."""

from __future__ import annotations

import logging
import threading
from pathlib import Path  # noqa: F401

import numpy as np

logger = logging.getLogger(__name__)


class CaptureMixin:
    """mss 캡처 및 템플릿/리소스 관리 기능."""

    def __init__(self) -> None:
        self._local = threading.local()
        self._all_sct_refs: list[object] = []
        self._sct_lock = threading.Lock()
        self._template_cache: dict[str, np.ndarray] = {}
        self._template_cache_lock = threading.Lock()

    def _get_sct(self) -> object:
        """현재 스레드용 mss 인스턴스를 반환한다 (지연 생성)."""
        if not hasattr(self._local, "sct"):
            import mss

            sct = mss.mss()
            self._local.sct = sct
            with self._sct_lock:
                self._all_sct_refs.append(sct)
        return self._local.sct

    def capture_region(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
    ) -> np.ndarray:
        """화면의 특정 영역을 캡처한다.

        Args:
            x: 좌상단 X 좌표
            y: 좌상단 Y 좌표
            width: 캡처 폭 (px)
            height: 캡처 높이 (px)

        Returns:
            BGR numpy 배열 (shape: height, width, 3)
        """
        sct = self._get_sct()
        monitor = {"left": x, "top": y, "width": width, "height": height}
        screenshot = sct.grab(monitor)
        img = np.array(screenshot)
        return img[:, :, :3]  # BGRA → BGR (알파 채널 제거)

    def capture_square_thumbnail_bgr(self, cx: int, cy: int, size: int = 30) -> np.ndarray | None:
        """(cx, cy) 중심의 화면 일부를 캡처한 뒤 정확히 size×size BGR로 맞춘다.

        에디터 디버그 썸네일용. 모니터 가장자리에서는 잘린 뒤 리사이즈한다.
        """
        try:
            import cv2
        except ImportError:
            return None
        if size < 1:
            return None
        half = size // 2
        sct = self._get_sct()
        mon = sct.monitors[0]
        ml, mt, mw, mh = mon["left"], mon["top"], mon["width"], mon["height"]
        x0 = max(ml, min(cx - half, ml + max(1, mw) - size))
        y0 = max(mt, min(cy - half, mt + max(1, mh) - size))
        rw = min(size, ml + mw - x0)
        rh = min(size, mt + mh - y0)
        if rw < 1 or rh < 1:
            return None
        patch = self.capture_region(x0, y0, rw, rh)
        if patch.shape[0] != size or patch.shape[1] != size:
            patch = cv2.resize(patch, (size, size), interpolation=cv2.INTER_AREA)
        return patch

    def get_pixel_color(self, x: int, y: int) -> str:
        """단일 픽셀의 색상을 반환한다.

        Args:
            x: 픽셀 X 좌표
            y: 픽셀 Y 좌표

        Returns:
            색상 문자열 "#RRGGBB"
        """
        img = self.capture_region(x, y, 1, 1)
        b, g, r = int(img[0, 0, 0]), int(img[0, 0, 1]), int(img[0, 0, 2])
        return f"#{r:02X}{g:02X}{b:02X}"

    def close(self) -> None:
        """모든 스레드의 mss 리소스를 해제한다.

        mss는 스레드 로컬이라 다른 스레드에서 close()를 호출해도
        해당 스레드의 인스턴스만 닫힙니다. 이 메서드는 추적된
        모든 mss 인스턴스를 일괄 해제합니다.
        """
        with self._sct_lock:
            for sct in self._all_sct_refs:
                try:
                    sct.close()
                except Exception as exc:
                    logger.debug("mss close 실패: %s", exc)
            self._all_sct_refs.clear()

        with self._template_cache_lock:
            self._template_cache.clear()

        if hasattr(self._local, "sct"):
            del self._local.sct
