"""OCR 기능 mixin."""

from __future__ import annotations

import logging
import os
import shutil
import threading
import time
from pathlib import Path

import numpy as np

from shared.humanizer import sync_human_delay

logger = logging.getLogger(__name__)


class OcrMixin:
    """OCR 읽기/대기 기능."""

    _tesseract_configured: bool = False

    @staticmethod
    def _configure_tesseract_cmd(pytesseract_module: object) -> None:
        """PATH 미설정 환경에서도 tesseract 실행 파일을 찾고,
        TESSDATA_PREFIX를 올바른 tessdata 디렉토리로 보정한다.

        Tesseract 5.x는 TESSDATA_PREFIX가 tessdata/ 디렉토리 자체를
        가리켜야 한다. 설치 루트(상위 폴더)로 잘못 설정된 경우도 보정한다.
        """

        def _fix_tessdata_prefix(install_dir: Path) -> None:
            """install_dir 기준으로 TESSDATA_PREFIX를 올바르게 설정한다."""
            tessdata_dir = install_dir / "tessdata"
            if not tessdata_dir.exists():
                return

            current = os.environ.get("TESSDATA_PREFIX", "")
            current_path = Path(current) if current else None

            if current_path is not None and current_path == tessdata_dir:
                return

            if (
                not current
                or current_path == install_dir
                or not (current_path / "eng.traineddata").exists()
            ):
                os.environ["TESSDATA_PREFIX"] = str(tessdata_dir)
                logger.info("TESSDATA_PREFIX 보정: '%s' → '%s'", current or "(unset)", tessdata_dir)

        tesseract_in_path = shutil.which("tesseract")
        if tesseract_in_path:
            tesseract_path = Path(tesseract_in_path)
            _fix_tessdata_prefix(tesseract_path.parent)
            return

        common_paths = [
            Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"),
            Path(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"),
        ]
        local_appdata = os.environ.get("LOCALAPPDATA", "")
        if local_appdata:
            common_paths.append(Path(local_appdata) / "Tesseract-OCR" / "tesseract.exe")
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            common_paths.append(Path(appdata) / "Tesseract-OCR" / "tesseract.exe")

        for candidate in common_paths:
            if candidate.exists():
                pytesseract_module.pytesseract.tesseract_cmd = str(candidate)
                logger.info("Tesseract 경로 자동 설정: %s", candidate)
                _fix_tessdata_prefix(candidate.parent)
                return

    def ocr_read_text(
        self,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        lang: str = "eng",
        psm: int = 7,
        whitelist: str = "",
        grayscale: bool = True,
        invert: bool = False,
        threshold: int = 0,
    ) -> str:
        """화면 영역에서 OCR로 텍스트를 인식한다."""
        try:
            import pytesseract
        except ImportError:
            logger.error("pytesseract가 설치되지 않음 (pip install pytesseract)")
            return ""
        if not OcrMixin._tesseract_configured:
            self._configure_tesseract_cmd(pytesseract)
            OcrMixin._tesseract_configured = True

        try:
            import cv2
        except ImportError:
            logger.error("opencv-python-headless가 설치되지 않음 (OCR 전처리 불가)")
            return ""

        screenshot = self.capture_region(region_x, region_y, region_width, region_height)
        screenshot = self._upscale_for_ocr_if_needed(screenshot)
        processed = self._preprocess_for_ocr(screenshot, grayscale, invert, threshold)

        config_parts = [f"--psm {psm}"]
        if whitelist:
            config_parts.append(f"-c tessedit_char_whitelist={whitelist}")
        config_str = " ".join(config_parts)

        try:
            from PIL import Image

            arr = processed
            if len(arr.shape) == 3:
                arr = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(arr)
            text: str = pytesseract.image_to_string(pil_image, lang=lang, config=config_str)
            logger.debug(
                "OCR 결과: region=(%d,%d,%d,%d) lang=%s → '%s'",
                region_x,
                region_y,
                region_width,
                region_height,
                lang,
                text.strip()[:50],
            )
            return text
        except Exception as exc:
            if "Failed loading language" in str(exc) or "traineddata" in str(exc):
                tessdata_prefix = os.environ.get("TESSDATA_PREFIX", "(unset)")
                logger.error(
                    "OCR 언어 데이터 누락: lang=%s, TESSDATA_PREFIX=%s\n"
                    "  → 해결: https://github.com/tesseract-ocr/tessdata 에서 '%s.traineddata'를 다운로드하여\n"
                    "     '%s' 폴더에 넣어주세요.",
                    lang,
                    tessdata_prefix,
                    lang.split("+")[0],
                    tessdata_prefix,
                )
            logger.error("OCR 실행 실패: %s", exc)
            return ""

    def ocr_wait_for_text(
        self,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        pattern: str,
        use_regex: bool = False,
        lang: str = "eng",
        psm: int = 7,
        whitelist: str = "",
        grayscale: bool = True,
        invert: bool = False,
        threshold: int = 0,
        timeout_ms: int = 10000,
        poll_interval_ms: int = 500,
        stop_event: threading.Event | None = None,
        link_lost_event: threading.Event | None = None,
    ) -> str | None:
        """특정 텍스트가 화면에 나타날 때까지 대기한다."""
        import re

        start_time = time.monotonic()
        timeout_sec = timeout_ms / 1000.0

        while True:
            if stop_event is not None and stop_event.is_set():
                logger.debug("OCR 대기 중단 (stop_event): pattern='%s'", pattern)
                return None
            if link_lost_event is not None and link_lost_event.is_set():
                logger.debug("OCR 대기 중단 (link_lost): pattern='%s'", pattern)
                return None

            text = self.ocr_read_text(
                region_x,
                region_y,
                region_width,
                region_height,
                lang,
                psm,
                whitelist,
                grayscale,
                invert,
                threshold,
            )
            stripped = text.strip()

            if use_regex:
                try:
                    if re.search(pattern, stripped):
                        logger.debug(
                            "OCR 대기 완료 (regex '%s'): '%s'",
                            pattern,
                            stripped[:50],
                        )
                        return stripped
                except re.error as exc:
                    logger.error("OCR 정규식 오류: %s", exc)
                    return None
            else:
                if pattern in stripped:
                    logger.debug(
                        "OCR 대기 완료 (text '%s'): '%s'",
                        pattern,
                        stripped[:50],
                    )
                    return stripped

            elapsed = time.monotonic() - start_time
            if timeout_ms > 0 and elapsed >= timeout_sec:
                break

            if timeout_ms == 0:
                break

            sync_human_delay(
                poll_interval_ms,
                randomize=False,
                stop_event=stop_event,
                link_lost_event=link_lost_event,
            )

        logger.debug(
            "OCR 대기 타임아웃: pattern='%s', timeout=%dms",
            pattern,
            timeout_ms,
        )
        return None

    @staticmethod
    def _preprocess_for_ocr(
        image: np.ndarray,
        grayscale: bool,
        invert: bool,
        threshold: int,
    ) -> np.ndarray:
        """OCR 전에 이미지를 전처리한다."""
        import cv2

        needs_processing = (
            (grayscale and len(image.shape) == 3)
            or invert
            or (len(image.shape) == 2 or (grayscale and len(image.shape) == 3))
        )
        result = image if needs_processing else image.copy()

        if grayscale and len(result.shape) == 3:
            result = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)

        if invert:
            result = cv2.bitwise_not(result)

        if threshold > 0 and len(result.shape) == 2:
            _, result = cv2.threshold(result, threshold, 255, cv2.THRESH_BINARY)
        elif threshold == 0 and len(result.shape) == 2:
            _, result = cv2.threshold(result, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        if result is image:
            result = image.copy()

        return result

    @staticmethod
    def _upscale_for_ocr_if_needed(image: np.ndarray) -> np.ndarray:
        """캡처가 작으면 Tesseract가 획을 못 잡는 경우가 많아 선형 확대한다."""
        import cv2

        h, w = image.shape[:2]
        short = min(w, h)
        target_short = 56
        if short >= target_short:
            return image

        scale = min(4.0, target_short / float(short))
        nw = max(1, int(round(w * scale)))
        nh = max(1, int(round(h * scale)))
        max_side = 1600
        if max(nw, nh) > max_side:
            cap = max_side / max(nw, nh)
            nw = max(1, int(round(nw * cap)))
            nh = max(1, int(round(nh * cap)))

        return cv2.resize(image, (nw, nh), interpolation=cv2.INTER_CUBIC)
