"""액션 데이터 모델 패키지.

1202줄의 단일 파일을 카테고리별로 분리한 패키지.
기존 `from shared.models import X` 임포트가 그대로 동작하도록
모든 공개 심볼을 여기서 re-export한다.
"""

from shared.models.base import _BaseAction, _generate_action_id, _generate_schedule_rule_id
from shared.models.enums import ActionType, MouseButton
from shared.models.flow import (
    BreakAction,
    CommentAction,
    DelayAction,
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    PixelWaitAction,
)
from shared.models.function import (
    FunctionCallAction,
    FunctionDefAction,
    FunctionEndAction,
    ReturnAction,
)
from shared.models.image import (
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
)
from shared.models.keyboard import (
    KeyComboAction,
    KeyDownAction,
    KeyPressAction,
    KeyUpAction,
    TypeTextAction,
)
from shared.models.macro import (
    Action,
    Macro,
    MacroSettings,
    ScheduleRule,
)
from shared.models.mouse import (
    MouseClickAction,
    MouseDownAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
    MouseUpAction,
)
from shared.models.ocr import (
    OCRReadAction,
    OCRWaitAction,
)
from shared.models.variable import (
    IfVariableAction,
    SubMacroCallAction,
    VariableSetAction,
)

__all__ = [
    # Enums
    "ActionType",
    "MouseButton",
    # Base
    "_BaseAction",
    "_generate_action_id",
    "_generate_schedule_rule_id",
    # Mouse
    "MouseMoveAction",
    "MouseClickAction",
    "MouseDownAction",
    "MouseUpAction",
    "MouseDragAction",
    "MouseScrollAction",
    # Keyboard
    "KeyPressAction",
    "KeyDownAction",
    "KeyUpAction",
    "KeyComboAction",
    "TypeTextAction",
    # Flow
    "DelayAction",
    "CommentAction",
    "LoopStartAction",
    "LoopEndAction",
    "BreakAction",
    "LabelAction",
    "GotoAction",
    "IfPixelAction",
    "ElseAction",
    "EndIfAction",
    "PixelWaitAction",
    "FunctionDefAction",
    "FunctionEndAction",
    "FunctionCallAction",
    "ReturnAction",
    # Image
    "ImageSearchAction",
    "ImageWaitAction",
    "ImageClickAction",
    # Variable
    "SubMacroCallAction",
    "VariableSetAction",
    "IfVariableAction",
    # OCR
    "OCRReadAction",
    "OCRWaitAction",
    # Macro
    "Action",
    "MacroSettings",
    "ScheduleRule",
    "Macro",
]
