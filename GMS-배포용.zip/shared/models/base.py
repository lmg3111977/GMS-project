"""액션 베이스 클래스 및 ID 생성 유틸리티."""

from __future__ import annotations

import uuid

from pydantic import BaseModel, Field


def _generate_action_id() -> str:
    """액션 고유 ID를 UUID4 문자열로 생성한다."""
    return str(uuid.uuid4())


def _generate_schedule_rule_id() -> str:
    """스케줄 규칙 ID를 UUID4 문자열로 생성한다."""
    return str(uuid.uuid4())


class _BaseAction(BaseModel):
    """모든 액션의 공통 필드를 정의하는 내부 베이스 클래스.

    직접 인스턴스화하지 않는다. 각 액션 모델이 이를 상속한다.
    """

    action_id: str = Field(
        default_factory=_generate_action_id,
        description="액션 고유 식별자 (UUID4)",
    )
    enabled: bool = Field(
        default=True,
        description="False이면 실행 시 건너뜀",
    )
    comment: str = Field(
        default="",
        description="사용자 코멘트 (에디터 표시용)",
    )
