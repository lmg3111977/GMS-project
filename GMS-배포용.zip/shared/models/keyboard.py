"""키보드 액션 모델."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from shared.models.base import _BaseAction
from shared.models.enums import ActionType


class KeyPressAction(_BaseAction):
    """키 한번 누르고 떼기 액션."""

    type: Literal[ActionType.KEY_PRESS] = Field(
        default=ActionType.KEY_PRESS, description="액션 타입"
    )
    key: str = Field(default="", description="키 이름 (keymap.py 참조)")
    count: int = Field(default=1, ge=1, le=50, description="키 반복 입력 횟수")


class KeyDownAction(_BaseAction):
    """키 누름 액션 (조합키 시작)."""

    type: Literal[ActionType.KEY_DOWN] = Field(default=ActionType.KEY_DOWN, description="액션 타입")
    key: str = Field(default="", description="키 이름")


class KeyUpAction(_BaseAction):
    """키 떼기 액션 (조합키 끝)."""

    type: Literal[ActionType.KEY_UP] = Field(default=ActionType.KEY_UP, description="액션 타입")
    key: str = Field(default="", description="키 이름")


class KeyComboAction(_BaseAction):
    """조합키 액션 (예: Ctrl+C, Alt+Tab)."""

    type: Literal[ActionType.KEY_COMBO] = Field(
        default=ActionType.KEY_COMBO, description="액션 타입"
    )
    modifiers: list[str] = Field(default_factory=list, description="수정자 키 목록")
    key: str = Field(default="", description="조합할 키")


class TypeTextAction(_BaseAction):
    """문자열 타이핑 액션."""

    type: Literal[ActionType.TYPE_TEXT] = Field(
        default=ActionType.TYPE_TEXT, description="액션 타입"
    )
    text: str = Field(default="", description="타이핑할 문자열")
    interval_ms: int = Field(default=50, ge=0, le=1000, description="글자 간 간격 (ms)")
    count: int = Field(default=1, ge=1, le=50, description="문자열 반복 입력 횟수")
