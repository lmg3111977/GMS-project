"""액션 타입 및 열거형 정의."""

from __future__ import annotations

from enum import StrEnum


class ActionType(StrEnum):
    """매크로 액션 타입 열거."""

    MOUSE_MOVE = "MOUSE_MOVE"
    MOUSE_CLICK = "MOUSE_CLICK"
    MOUSE_DOWN = "MOUSE_DOWN"
    MOUSE_UP = "MOUSE_UP"
    MOUSE_DRAG = "MOUSE_DRAG"
    MOUSE_SCROLL = "MOUSE_SCROLL"
    KEY_PRESS = "KEY_PRESS"
    KEY_DOWN = "KEY_DOWN"
    KEY_UP = "KEY_UP"
    KEY_COMBO = "KEY_COMBO"
    TYPE_TEXT = "TYPE_TEXT"
    DELAY = "DELAY"
    COMMENT = "COMMENT"
    LOOP_START = "LOOP_START"
    LOOP_END = "LOOP_END"
    LABEL = "LABEL"
    GOTO = "GOTO"
    IF_PIXEL = "IF_PIXEL"
    ELSE = "ELSE"
    END_IF = "END_IF"
    PIXEL_WAIT = "PIXEL_WAIT"
    IMAGE_SEARCH = "IMAGE_SEARCH"
    BREAK = "BREAK"
    SUB_MACRO_CALL = "SUB_MACRO_CALL"
    VARIABLE_SET = "VARIABLE_SET"
    IF_VARIABLE = "IF_VARIABLE"
    IMAGE_WAIT = "IMAGE_WAIT"
    IMAGE_CLICK = "IMAGE_CLICK"
    OCR_READ = "OCR_READ"
    OCR_WAIT = "OCR_WAIT"
    FUNCTION_DEF = "FUNCTION_DEF"
    FUNCTION_CALL = "FUNCTION_CALL"
    RETURN = "RETURN"
    FUNCTION_END = "FUNCTION_END"


class MouseButton(StrEnum):
    """마우스 버튼 열거."""

    LEFT = "LEFT"
    RIGHT = "RIGHT"
    MIDDLE = "MIDDLE"
