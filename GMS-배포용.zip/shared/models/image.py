"""이미지 매칭 액션 모델 — ImageSearch, ImageWait, ImageClick."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from shared.models.base import _BaseAction
from shared.models.enums import ActionType, MouseButton


class ImageSearchAction(_BaseAction):
    """이미지 템플릿 매칭 액션.

    지정한 화면 영역에서 템플릿 이미지를 검색하고,
    발견된 좌표를 변수에 저장한다.
    """

    type: Literal[ActionType.IMAGE_SEARCH] = Field(
        default=ActionType.IMAGE_SEARCH, description="액션 타입"
    )
    template_path: str = Field(default="", description="템플릿 이미지 파일 경로")
    region_x: int = Field(default=0, ge=0, description="검색 영역 좌상단 X")
    region_y: int = Field(default=0, ge=0, description="검색 영역 좌상단 Y")
    region_x_expression: str | None = Field(default=None, description="검색 영역 X 식")
    region_y_expression: str | None = Field(default=None, description="검색 영역 Y 식")
    region_xy_expression: str | None = Field(default=None, description="검색 영역 좌표식")
    region_end_x_expression: str | None = Field(default=None, description="검색 영역 끝 X 식")
    region_end_y_expression: str | None = Field(default=None, description="검색 영역 끝 Y 식")
    region_end_xy_expression: str | None = Field(default=None, description="검색 영역 끝 좌표식")
    region_width: int = Field(default=1920, ge=1, description="검색 영역 폭")
    region_height: int = Field(default=1080, ge=1, description="검색 영역 높이")
    confidence: float = Field(default=0.85, ge=0.0, le=1.0, description="최소 매칭 신뢰도")
    grayscale: bool = Field(default=False, description="그레이스케일 매칭")
    max_retry: int = Field(default=1, ge=1, le=100, description="검색 시도 횟수")
    retry_interval_ms: int = Field(default=500, ge=100, le=30000, description="재시도 간격 (ms)")
    click_on_found: bool = Field(default=False, description="발견 시 자동 클릭")
    click_button: MouseButton = Field(default=MouseButton.LEFT, description="자동 클릭 버튼")
    click_offset_x: int = Field(default=0, ge=-500, le=500, description="클릭 오프셋 X")
    click_offset_y: int = Field(default=0, ge=-500, le=500, description="클릭 오프셋 Y")
    click_offset_x_expression: str | None = Field(default=None, description="클릭 오프셋 X 식")
    click_offset_y_expression: str | None = Field(default=None, description="클릭 오프셋 Y 식")
    click_offset_xy_expression: str | None = Field(default=None, description="클릭 오프셋 좌표식")
    move_on_found: bool = Field(default=False, description="발견 시 커서 이동")
    move_duration_ms: int = Field(default=0, ge=0, le=10000, description="이동 소요 시간 (ms)")
    store_x_var: str = Field(default="img_x", description="발견된 X 저장 변수")
    store_y_var: str = Field(default="img_y", description="발견된 Y 저장 변수")
    store_xy_combined_var: str = Field(default="", description="X,Y 합산 변수")
    store_found_var: str = Field(default="", description="검색 결과 변수 ('1'/'0')")
    store_confidence_var: str = Field(default="", description="매칭 신뢰도 변수")


class ImageWaitAction(_BaseAction):
    """이미지가 화면에 나타날 때까지 대기하는 액션."""

    type: Literal[ActionType.IMAGE_WAIT] = Field(
        default=ActionType.IMAGE_WAIT, description="액션 타입"
    )
    template_path: str = Field(default="", description="대기할 템플릿 이미지 경로")
    region_x: int = Field(default=0, ge=0, description="검색 영역 좌상단 X")
    region_y: int = Field(default=0, ge=0, description="검색 영역 좌상단 Y")
    region_x_expression: str | None = Field(default=None, description="검색 영역 X 식")
    region_y_expression: str | None = Field(default=None, description="검색 영역 Y 식")
    region_xy_expression: str | None = Field(default=None, description="검색 영역 좌표식")
    region_end_x_expression: str | None = Field(default=None, description="검색 영역 끝 X 식")
    region_end_y_expression: str | None = Field(default=None, description="검색 영역 끝 Y 식")
    region_end_xy_expression: str | None = Field(default=None, description="검색 영역 끝 좌표식")
    region_width: int = Field(default=1920, ge=1, description="검색 영역 폭")
    region_height: int = Field(default=1080, ge=1, description="검색 영역 높이")
    confidence: float = Field(default=0.85, ge=0.0, le=1.0, description="최소 매칭 신뢰도")
    grayscale: bool = Field(default=False, description="그레이스케일 매칭")
    timeout_ms: int = Field(default=10000, ge=0, le=3_600_000, description="최대 대기 시간 (ms)")
    store_x_var: str = Field(default="img_x", description="발견된 X 저장 변수")
    store_y_var: str = Field(default="img_y", description="발견된 Y 저장 변수")


class ImageClickAction(_BaseAction):
    """이미지를 찾아서 클릭하는 복합 액션."""

    type: Literal[ActionType.IMAGE_CLICK] = Field(
        default=ActionType.IMAGE_CLICK, description="액션 타입"
    )
    template_path: str = Field(default="", description="클릭 대상 템플릿 이미지 경로")
    region_x: int = Field(default=0, ge=0, description="검색 영역 좌상단 X")
    region_y: int = Field(default=0, ge=0, description="검색 영역 좌상단 Y")
    region_x_expression: str | None = Field(default=None, description="검색 영역 X 식")
    region_y_expression: str | None = Field(default=None, description="검색 영역 Y 식")
    region_xy_expression: str | None = Field(default=None, description="검색 영역 좌표식")
    region_end_x_expression: str | None = Field(default=None, description="검색 영역 끝 X 식")
    region_end_y_expression: str | None = Field(default=None, description="검색 영역 끝 Y 식")
    region_end_xy_expression: str | None = Field(default=None, description="검색 영역 끝 좌표식")
    region_width: int = Field(default=1920, ge=1, description="검색 영역 폭")
    region_height: int = Field(default=1080, ge=1, description="검색 영역 높이")
    confidence: float = Field(default=0.85, ge=0.0, le=1.0, description="최소 매칭 신뢰도")
    grayscale: bool = Field(default=False, description="그레이스케일 매칭")
    click_button: MouseButton = Field(default=MouseButton.LEFT, description="클릭 버튼")
    click_offset_x: int = Field(default=0, ge=-500, le=500, description="클릭 오프셋 X")
    click_offset_y: int = Field(default=0, ge=-500, le=500, description="클릭 오프셋 Y")
    click_offset_x_expression: str | None = Field(default=None, description="클릭 오프셋 X 식")
    click_offset_y_expression: str | None = Field(default=None, description="클릭 오프셋 Y 식")
    click_offset_xy_expression: str | None = Field(default=None, description="클릭 오프셋 좌표식")
    max_retry: int = Field(default=1, ge=1, le=100, description="검색 시도 횟수")
    retry_interval_ms: int = Field(default=500, ge=100, le=30000, description="재시도 간격 (ms)")
