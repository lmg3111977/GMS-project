"""변수·서브매크로 액션 모델."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from shared.models.base import _BaseAction
from shared.models.enums import ActionType


class SubMacroCallAction(_BaseAction):
    """다른 매크로를 서브루틴처럼 호출하는 액션."""

    type: Literal[ActionType.SUB_MACRO_CALL] = Field(
        default=ActionType.SUB_MACRO_CALL, description="액션 타입"
    )
    macro_path: str = Field(default="", description="호출할 매크로 JSON 파일 경로")


class VariableSetAction(_BaseAction):
    """런타임 변수를 설정하는 액션."""

    type: Literal[ActionType.VARIABLE_SET] = Field(
        default=ActionType.VARIABLE_SET, description="액션 타입"
    )
    var_name: str = Field(
        default="", max_length=30, pattern=r"^[a-zA-Z0-9_]*$", description="변수 이름"
    )
    value: str = Field(default="", description="직접 설정할 값")
    expression: str | None = Field(
        default=None, description="수식 (예: '{counter} + 1'). None이면 value 사용"
    )


class IfVariableAction(_BaseAction):
    """변수 값을 비교하여 조건 분기하는 액션."""

    type: Literal[ActionType.IF_VARIABLE] = Field(
        default=ActionType.IF_VARIABLE, description="액션 타입"
    )
    var_name: str = Field(default="", max_length=30, description="비교할 변수 이름")
    operator: Literal["==", "!=", ">", "<", ">=", "<="] = Field(
        default="==", description="비교 연산자"
    )
    compare_value: str = Field(default="", description="비교 대상 값")
