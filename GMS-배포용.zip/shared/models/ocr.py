"""OCR 텍스트 인식 액션 모델."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from shared.models.base import _BaseAction
from shared.models.enums import ActionType


class OCRReadAction(_BaseAction):
    """OCR 텍스트 인식 액션.

    화면의 지정 영역에서 텍스트를 인식하여 변수에 저장한다.
    """

    type: Literal[ActionType.OCR_READ] = Field(default=ActionType.OCR_READ, description="액션 타입")
    region_x: int = Field(default=0, ge=0, description="OCR 영역 좌상단 X")
    region_y: int = Field(default=0, ge=0, description="OCR 영역 좌상단 Y")
    region_x_expression: str | None = Field(default=None, description="OCR 영역 X 식")
    region_y_expression: str | None = Field(default=None, description="OCR 영역 Y 식")
    region_xy_expression: str | None = Field(default=None, description="OCR 영역 좌표식")
    region_end_x_expression: str | None = Field(default=None, description="OCR 영역 끝 X 식")
    region_end_y_expression: str | None = Field(default=None, description="OCR 영역 끝 Y 식")
    region_end_xy_expression: str | None = Field(default=None, description="OCR 영역 끝 좌표식")
    region_width: int = Field(default=200, ge=1, description="OCR 영역 폭")
    region_height: int = Field(default=50, ge=1, description="OCR 영역 높이")
    lang: str = Field(default="eng", description="OCR 언어: eng | kor | eng+kor")
    psm: int = Field(default=7, ge=0, le=13, description="글자 배치 가정값(PSM). 7=한 줄(기본)")
    whitelist: str = Field(default="", description="인식 후보 문자 (비우면 제한 없음)")
    grayscale: bool = Field(default=True, description="그레이스케일 변환")
    invert: bool = Field(default=False, description="색상 반전")
    threshold: int = Field(default=0, ge=0, le=255, description="흑백 이진화 기준 (0=자동 Otsu)")
    store_var: str = Field(default="ocr_text", description="인식된 텍스트 저장 변수")
    strip_whitespace: bool = Field(default=True, description="결과 앞뒤 공백 제거")


class OCRWaitAction(_BaseAction):
    """OCR 텍스트 대기 액션.

    화면을 주기적으로 스캔하여 특정 텍스트가 나타날 때까지 대기한다.
    """

    type: Literal[ActionType.OCR_WAIT] = Field(default=ActionType.OCR_WAIT, description="액션 타입")
    region_x: int = Field(default=0, ge=0, description="OCR 영역 좌상단 X")
    region_y: int = Field(default=0, ge=0, description="OCR 영역 좌상단 Y")
    region_x_expression: str | None = Field(default=None, description="OCR 영역 X 식")
    region_y_expression: str | None = Field(default=None, description="OCR 영역 Y 식")
    region_xy_expression: str | None = Field(default=None, description="OCR 영역 좌표식")
    region_end_x_expression: str | None = Field(default=None, description="OCR 영역 끝 X 식")
    region_end_y_expression: str | None = Field(default=None, description="OCR 영역 끝 Y 식")
    region_end_xy_expression: str | None = Field(default=None, description="OCR 영역 끝 좌표식")
    region_width: int = Field(default=200, ge=1, description="OCR 영역 폭")
    region_height: int = Field(default=50, ge=1, description="OCR 영역 높이")
    pattern: str = Field(default="", description="대기할 텍스트 또는 정규식 패턴")
    use_regex: bool = Field(default=False, description="정규식 모드")
    lang: str = Field(default="eng", description="OCR 언어")
    psm: int = Field(default=7, ge=0, le=13, description="글자 배치 가정값(PSM)")
    whitelist: str = Field(default="", description="인식 후보 문자")
    grayscale: bool = Field(default=True, description="그레이스케일 변환")
    invert: bool = Field(default=False, description="색상 반전")
    threshold: int = Field(default=0, ge=0, le=255, description="흑백 이진화 기준")
    timeout_ms: int = Field(default=10000, ge=0, le=3_600_000, description="최대 대기 시간 (ms)")
    poll_interval_ms: int = Field(default=500, ge=100, le=10000, description="OCR 폴링 간격 (ms)")
    store_var: str = Field(default="ocr_text", description="인식된 텍스트 저장 변수")
    strip_whitespace: bool = Field(default=True, description="결과 앞뒤 공백 제거")
