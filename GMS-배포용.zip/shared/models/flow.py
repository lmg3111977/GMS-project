"""흐름 제어 액션 모델 — 대기, 루프, 점프, 조건 분기."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from shared.models.base import _BaseAction
from shared.models.enums import ActionType


class DelayAction(_BaseAction):
    """대기 액션 (고정 또는 랜덤)."""

    type: Literal[ActionType.DELAY] = Field(default=ActionType.DELAY, description="액션 타입")
    ms: int = Field(default=1000, ge=0, le=3_600_000, description="기본 대기 시간 (ms)")
    random_min: int | None = Field(default=None, ge=0, le=3_600_000, description="랜덤 범위 최소")
    random_max: int | None = Field(default=None, ge=0, le=3_600_000, description="랜덤 범위 최대")


class CommentAction(_BaseAction):
    """실행에는 영향을 주지 않는 주석 액션."""

    type: Literal[ActionType.COMMENT] = Field(
        default=ActionType.COMMENT,
        description="액션 타입",
    )


class LoopStartAction(_BaseAction):
    """루프 시작 액션."""

    type: Literal[ActionType.LOOP_START] = Field(
        default=ActionType.LOOP_START, description="액션 타입"
    )
    label: str = Field(default="", max_length=50, description="루프 식별자 (디버그용)")
    count: int = Field(default=-1, ge=-1, description="반복 횟수. -1이면 무한 루프")
    count_expression: str | None = Field(
        default=None,
        description="비우면 count 사용. 있으면 평가해 반복 횟수로 사용",
    )
    range_start_expression: str | None = Field(
        default=None,
        description="범위 반복 시작 식. range_end_expression과 함께 사용",
    )
    range_end_expression: str | None = Field(
        default=None,
        description="범위 반복 끝 식. for(i=start; i<end; i++) 규칙",
    )
    range_end_inclusive: bool = Field(
        default=False,
        description="끝값 포함 여부. 켜면 for(i=start; i<=end; i++)",
    )


class LoopEndAction(_BaseAction):
    """루프 끝 액션. 대응하는 LoopStart와 짝을 이룬다."""

    type: Literal[ActionType.LOOP_END] = Field(default=ActionType.LOOP_END, description="액션 타입")


class BreakAction(_BaseAction):
    """루프를 빠져나오는 Break 액션."""

    type: Literal[ActionType.BREAK] = Field(default=ActionType.BREAK, description="액션 타입")


class LabelAction(_BaseAction):
    """레이블 액션 — Goto/IfPixel 점프 대상."""

    type: Literal[ActionType.LABEL] = Field(default=ActionType.LABEL, description="액션 타입")
    name: str = Field(
        default="", max_length=50, pattern=r"^[a-zA-Z0-9_]*$", description="레이블 이름"
    )


class GotoAction(_BaseAction):
    """레이블로 점프하는 액션."""

    type: Literal[ActionType.GOTO] = Field(default=ActionType.GOTO, description="액션 타입")
    target: str = Field(default="", max_length=50, description="점프할 Label 이름")


class IfPixelAction(_BaseAction):
    """픽셀 색상 조건 분기 액션."""

    type: Literal[ActionType.IF_PIXEL] = Field(default=ActionType.IF_PIXEL, description="액션 타입")
    x: int = Field(default=0, ge=0, le=7680, description="확인할 픽셀 X")
    y: int = Field(default=0, ge=0, le=4320, description="확인할 픽셀 Y")
    x_expression: str | None = Field(default=None, description="픽셀 X 식")
    y_expression: str | None = Field(default=None, description="픽셀 Y 식")
    xy_expression: str | None = Field(default=None, description="픽셀 좌표식")
    color: str = Field(
        default="#000000", pattern=r"^#[0-9A-Fa-f]{6}$", description="비교 색상 (#RRGGBB)"
    )
    tolerance: int = Field(default=10, ge=0, le=442, description="색상 허용 오차")
    detect_change: bool = Field(
        default=False,
        description="True면 기준 색상과 일치할 때가 아니라 달라졌을 때 조건 성공",
    )


class ElseAction(_BaseAction):
    """If 블록의 else 구간 시작 마커."""

    type: Literal[ActionType.ELSE] = Field(default=ActionType.ELSE, description="액션 타입")


class EndIfAction(_BaseAction):
    """If 블록의 끝 마커."""

    type: Literal[ActionType.END_IF] = Field(default=ActionType.END_IF, description="액션 타입")


class PixelWaitAction(_BaseAction):
    """특정 픽셀 색상이 나타날 때까지 대기하는 액션."""

    type: Literal[ActionType.PIXEL_WAIT] = Field(
        default=ActionType.PIXEL_WAIT, description="액션 타입"
    )
    x: int = Field(default=0, ge=0, le=7680, description="감시할 픽셀 X")
    y: int = Field(default=0, ge=0, le=4320, description="감시할 픽셀 Y")
    x_expression: str | None = Field(default=None, description="감시 X 식")
    y_expression: str | None = Field(default=None, description="감시 Y 식")
    xy_expression: str | None = Field(default=None, description="감시 좌표식")
    color: str = Field(default="#000000", pattern=r"^#[0-9A-Fa-f]{6}$", description="대기 색상")
    tolerance: int = Field(default=10, ge=0, le=442, description="색상 허용 오차")
    detect_change: bool = Field(
        default=False,
        description="True면 기준 색상과 달라질 때까지 대기",
    )
    change_reference: Literal["target", "runtime"] = Field(
        default="target",
        description="변화 감지 기준. target=입력 색상, runtime=액션 시작 시점의 실제 색상",
    )
    timeout_ms: int = Field(default=5000, ge=0, le=3_600_000, description="최대 대기 시간 (ms)")
