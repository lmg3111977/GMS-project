"""마우스 액션 모델."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from shared.models.base import _BaseAction
from shared.models.enums import ActionType, MouseButton


class MouseMoveAction(_BaseAction):
    """마우스 이동 액션.

    절대 좌표(is_relative=False) 또는 상대 이동(is_relative=True)을 지원한다.
    duration_ms > 0이면 베지어 커브로 자연스럽게 이동한다.
    """

    type: Literal[ActionType.MOUSE_MOVE] = Field(
        default=ActionType.MOUSE_MOVE,
        description="액션 타입 (discriminator)",
    )
    x: int = Field(default=0, description="목표 X 좌표 (절대) 또는 이동량 (상대)")
    y: int = Field(default=0, description="목표 Y 좌표 (절대) 또는 이동량 (상대)")
    x_expression: str | None = Field(default=None, description="실행 시 평가할 X 좌표 식")
    y_expression: str | None = Field(default=None, description="실행 시 평가할 Y 좌표 식")
    xy_expression: str | None = Field(default=None, description="실행 시 평가할 좌표 식")
    is_relative: bool = Field(default=False, description="True: 상대 이동, False: 절대 좌표")
    duration_ms: int = Field(default=0, ge=0, le=10000, description="이동 소요 시간 (ms)")


class MouseClickAction(_BaseAction):
    """마우스 클릭 액션."""

    type: Literal[ActionType.MOUSE_CLICK] = Field(
        default=ActionType.MOUSE_CLICK, description="액션 타입"
    )
    button: MouseButton = Field(default=MouseButton.LEFT, description="클릭할 버튼")
    count: int = Field(default=1, ge=1, le=5, description="클릭 횟수 (2=더블클릭)")


class MouseDownAction(_BaseAction):
    """마우스 버튼 누름 액션 (드래그 시작 등)."""

    type: Literal[ActionType.MOUSE_DOWN] = Field(
        default=ActionType.MOUSE_DOWN, description="액션 타입"
    )
    button: MouseButton = Field(default=MouseButton.LEFT, description="누를 버튼")


class MouseUpAction(_BaseAction):
    """마우스 버튼 떼기 액션 (드래그 끝 등)."""

    type: Literal[ActionType.MOUSE_UP] = Field(default=ActionType.MOUSE_UP, description="액션 타입")
    button: MouseButton = Field(default=MouseButton.LEFT, description="뗄 버튼")


class MouseDragAction(_BaseAction):
    """마우스 드래그 액션 (시작점 → 끝점)."""

    type: Literal[ActionType.MOUSE_DRAG] = Field(
        default=ActionType.MOUSE_DRAG, description="액션 타입"
    )
    start_x: int = Field(default=0, ge=0, le=7680, description="드래그 시작 X")
    start_y: int = Field(default=0, ge=0, le=4320, description="드래그 시작 Y")
    end_x: int = Field(default=0, ge=0, le=7680, description="드래그 끝 X")
    end_y: int = Field(default=0, ge=0, le=4320, description="드래그 끝 Y")
    start_x_expression: str | None = Field(default=None, description="드래그 시작 X 식")
    start_y_expression: str | None = Field(default=None, description="드래그 시작 Y 식")
    end_x_expression: str | None = Field(default=None, description="드래그 끝 X 식")
    end_y_expression: str | None = Field(default=None, description="드래그 끝 Y 식")
    start_xy_expression: str | None = Field(default=None, description="드래그 시작 좌표식")
    end_xy_expression: str | None = Field(default=None, description="드래그 끝 좌표식")
    duration_ms: int = Field(default=200, ge=0, le=10000, description="드래그 소요 시간 (ms)")


class MouseScrollAction(_BaseAction):
    """마우스 스크롤 액션."""

    type: Literal[ActionType.MOUSE_SCROLL] = Field(
        default=ActionType.MOUSE_SCROLL, description="액션 타입"
    )
    amount: int = Field(default=3, ge=1, le=10, description="스크롤 양")
    direction: Literal["up", "down"] = Field(default="down", description="스크롤 방향")
