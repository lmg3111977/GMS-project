"""함수 정의·호출·반환 액션 모델."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from shared.models.base import _BaseAction
from shared.models.enums import ActionType


class FunctionDefAction(_BaseAction):
    """함수 정의 시작."""

    type: Literal[ActionType.FUNCTION_DEF] = Field(
        default=ActionType.FUNCTION_DEF,
        description="액션 타입",
    )
    name: str = Field(
        default="",
        max_length=30,
        pattern=r"^[a-zA-Z_][a-zA-Z0-9_]*$",
        description="함수 이름",
    )
    params: list[str] = Field(default_factory=list, description="매개변수 이름 목록")


class FunctionEndAction(_BaseAction):
    """함수 정의 끝 마커."""

    type: Literal[ActionType.FUNCTION_END] = Field(
        default=ActionType.FUNCTION_END,
        description="액션 타입",
    )


class FunctionCallAction(_BaseAction):
    """함수 호출."""

    type: Literal[ActionType.FUNCTION_CALL] = Field(
        default=ActionType.FUNCTION_CALL,
        description="액션 타입",
    )
    target: str = Field(default="", max_length=30, description="호출할 함수 이름")
    args: list[str] = Field(default_factory=list, description="인자 값/수식 목록")
    return_var: str = Field(
        default="",
        max_length=30,
        description="반환값 저장 변수 (빈 문자열이면 무시)",
    )


class ReturnAction(_BaseAction):
    """함수 반환."""

    type: Literal[ActionType.RETURN] = Field(default=ActionType.RETURN, description="액션 타입")
    expression: str = Field(default="", description="반환값 수식")
