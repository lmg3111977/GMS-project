"""매크로 최상위 모델 및 Action 유니온 타입."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field

from shared.models.base import _generate_schedule_rule_id
from shared.models.flow import (
    BreakAction,
    CommentAction,
    DelayAction,
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    PixelWaitAction,
)
from shared.models.function import (
    FunctionCallAction,
    FunctionDefAction,
    FunctionEndAction,
    ReturnAction,
)
from shared.models.image import ImageClickAction, ImageSearchAction, ImageWaitAction
from shared.models.keyboard import (
    KeyComboAction,
    KeyDownAction,
    KeyPressAction,
    KeyUpAction,
    TypeTextAction,
)
from shared.models.mouse import (
    MouseClickAction,
    MouseDownAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
    MouseUpAction,
)
from shared.models.ocr import OCRReadAction, OCRWaitAction
from shared.models.variable import IfVariableAction, SubMacroCallAction, VariableSetAction


class ScheduleRule(BaseModel):
    """에디터 독립 스케줄 규칙."""

    rule_id: str = Field(
        default_factory=_generate_schedule_rule_id, description="스케줄 규칙 고유 ID"
    )
    enabled: bool = Field(default=True, description="False이면 트리거 비활성화")
    time_hhmm: str = Field(
        default="20:00", pattern=r"^([01]\d|2[0-3]):([0-5]\d)$", description="실행 시각 (HH:MM)"
    )
    macro_path: str = Field(default="", description="SubMacroCall로 호출할 매크로 경로")
    on_trigger_during_run: Literal["resume", "restart", "stop"] = Field(
        default="resume",
        description="실행 중 트리거 시 동작 (resume/restart/stop)",
    )


# Discriminated Union — 모든 Action 타입의 합집합
Action = Annotated[
    (
        MouseMoveAction
        | MouseClickAction
        | MouseDownAction
        | MouseUpAction
        | MouseDragAction
        | MouseScrollAction
        | KeyPressAction
        | KeyDownAction
        | KeyUpAction
        | KeyComboAction
        | TypeTextAction
        | DelayAction
        | CommentAction
        | LoopStartAction
        | LoopEndAction
        | BreakAction
        | LabelAction
        | GotoAction
        | IfPixelAction
        | ElseAction
        | EndIfAction
        | PixelWaitAction
        | ImageSearchAction
        | SubMacroCallAction
        | VariableSetAction
        | IfVariableAction
        | ImageWaitAction
        | ImageClickAction
        | OCRReadAction
        | OCRWaitAction
        | FunctionDefAction
        | FunctionEndAction
        | FunctionCallAction
        | ReturnAction
    ),
    Field(discriminator="type"),
]


class MacroSettings(BaseModel):
    """매크로 실행 설정."""

    humanize: bool = Field(default=True, description="휴머나이저(액션 사이 무작위 대기) 활성화")
    base_delay_ms: int = Field(
        default=50, ge=0, le=10000, description="휴머나이저 기준 딜레이 중심값 (ms)"
    )
    micro_afk_enabled: bool = Field(
        default=False,
        description="마이크로 AFK(가끔 길게 멈춤) 활성화",
    )
    micro_afk_chance_percent: int = Field(
        default=2,
        ge=0,
        le=100,
        description="마이크로 AFK 발생 확률 (%)",
    )
    micro_afk_min_ms: int = Field(
        default=800,
        ge=0,
        le=10000,
        description="마이크로 AFK 최소 시간 (ms)",
    )
    micro_afk_max_ms: int = Field(
        default=2500,
        ge=0,
        le=10000,
        description="마이크로 AFK 최대 시간 (ms)",
    )
    schedule_rules: list[ScheduleRule] = Field(
        default_factory=list,
        description="시각별 SubMacroCall 스케줄 규칙 목록",
    )


class Macro(BaseModel):
    """매크로 최상위 모델."""

    name: str = Field(default="새 매크로", max_length=100, description="매크로 이름")
    version: str = Field(default="1.0", description="스키마 버전")
    hotkey: str = Field(default="F6", description="매크로 시작/정지 핫키")
    settings: MacroSettings = Field(default_factory=MacroSettings, description="실행 설정")
    actions: list[Action] = Field(default_factory=list, description="액션 리스트")


Macro.model_rebuild()
