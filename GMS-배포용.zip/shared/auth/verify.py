"""인증 응답 검증기."""

from __future__ import annotations

import hashlib
import hmac
import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class VerifyConfig:
    """서명 검증 설정."""

    app_secrets: dict[str, str]
    allowed_clock_skew_sec: int = 120


class AuthVerifyError(RuntimeError):
    """응답 검증 실패."""


def canonical_payload(response: dict[str, Any]) -> str:
    """고정 필드 순서로 서명 대상 문자열을 만든다."""
    ok_value = "1" if bool(response.get("ok")) else "0"
    return "|".join(
        [
            ok_value,
            str(response.get("code", "")),
            str(response.get("message", "")),
            str(response.get("serverTs", "")),
            str(response.get("nonce", "")),
            str(response.get("expiresAt", "")),
            str(response.get("kid", "")),
        ]
    )


def verify_response(
    response: dict[str, Any],
    *,
    expected_nonce: str,
    config: VerifyConfig,
) -> None:
    """응답 필드/시간/nonce/HMAC를 검증한다."""
    required = ("ok", "code", "message", "serverTs", "nonce", "expiresAt", "kid", "sig")
    for field in required:
        if field not in response:
            raise AuthVerifyError(f"필수 필드 누락: {field}")

    server_ts_raw = response.get("serverTs")
    if not isinstance(server_ts_raw, (int, float)):
        raise AuthVerifyError("serverTs 형식 오류")
    server_ts = int(server_ts_raw)
    now_ts = int(time.time())
    if abs(now_ts - server_ts) > config.allowed_clock_skew_sec:
        raise AuthVerifyError("서버 시간 허용 오차 초과")

    nonce = str(response.get("nonce", ""))
    if nonce != expected_nonce:
        raise AuthVerifyError("nonce 불일치")

    kid = str(response.get("kid", ""))
    secret = config.app_secrets.get(kid)
    if not secret:
        raise AuthVerifyError(f"지원하지 않는 kid: {kid}")

    expected_sig = hmac.new(
        secret.encode("utf-8"),
        canonical_payload(response).encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    received_sig = str(response.get("sig", ""))
    if not hmac.compare_digest(expected_sig, received_sig):
        raise AuthVerifyError("HMAC 서명 검증 실패")

    if not bool(response.get("ok")):
        code = str(response.get("code", "UNKNOWN"))
        message = str(response.get("message", "인증 실패"))
        raise AuthVerifyError(f"{code}: {message}")
