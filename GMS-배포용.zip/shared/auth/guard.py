"""실행 전 로그인 가드."""

from __future__ import annotations

import getpass
import logging
import os
import queue
import sys
import threading
from contextlib import suppress

from .client import AuthClientConfig, AuthHttpClient, AuthNetworkError

logger = logging.getLogger(__name__)


def authenticate_or_exit(
    user_id: str | None = None,
    password: str | None = None,
    *,
    endpoint: str | None = None,
    use_gui_prompt: bool = False,
) -> tuple[str, str]:
    """로그인 실패 시 즉시 종료한다. API URL은 설정/환경변수/CLI만 사용한다."""
    auth_url = (endpoint or os.getenv("GMS_AUTH_URL", "")).strip()
    if not auth_url:
        if sys.stdin.isatty():
            auth_url = input("로그인 API URL을 입력하세요: ").strip()
        if not auth_url:
            _die("인증 URL이 필요합니다. (config.json의 auth_url, --auth-url 또는 GMS_AUTH_URL)")

    uid = (user_id or os.getenv("GMS_USER_ID", "")).strip()
    pwd = password if password is not None else os.getenv("GMS_PASSWORD", "")
    if not isinstance(pwd, str):
        pwd = str(pwd)

    timeout_sec = _read_float("GMS_AUTH_TIMEOUT_SEC", default=20.0)
    retries = _read_int("GMS_AUTH_RETRIES", default=1)

    expires_at = ""
    if not uid or not pwd:
        if use_gui_prompt:
            creds = _prompt_login_gui(
                auth_url=auth_url,
                initial_user_id=uid,
                timeout_sec=timeout_sec,
                retries=retries,
            )
            if creds is None:
                _die("로그인이 취소되었습니다.")
            uid, pwd, expires_at = creds[0].strip(), creds[1], creds[2]
        if (not uid or not pwd) and sys.stdin.isatty():
            if not uid:
                uid = input("아이디: ").strip()
            if not pwd:
                pwd = getpass.getpass("비밀번호: ")
    if not uid:
        _die("아이디가 필요합니다.")
    if not pwd:
        _die("비밀번호가 필요합니다.")

    if not expires_at:
        client = AuthHttpClient(
            AuthClientConfig(endpoint=auth_url, timeout_sec=timeout_sec, retries=retries)
        )
        try:
            response = client.verify_login(user_id=uid, password=pwd)
            if not bool(response.get("ok")):
                code = str(response.get("code", "LOGIN_FAILED"))
                message = str(response.get("message", "로그인 실패"))
                _die(f"{code}: {message}")
            expires_at = str(response.get("expiresAt", ""))
        except (AuthNetworkError, OSError, ValueError) as exc:
            _die(f"인증 실패: {exc}")

    logger.info("로그인 성공")
    return uid, expires_at


def _read_int(name: str, *, default: int) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    return int(raw)


def _read_float(name: str, *, default: float) -> float:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    return float(raw)


def _die(message: str) -> None:
    logger.error(message)
    sys.exit(1)


def _prompt_login_gui(
    *,
    auth_url: str,
    initial_user_id: str,
    timeout_sec: float,
    retries: int,
) -> tuple[str, str, str] | None:
    """Tkinter로 아이디·비밀번호를 한 창에서 입력받는다."""
    try:
        import tkinter as tk
        from tkinter import ttk
    except Exception:
        return None

    root = tk.Tk()
    root.withdraw()
    dlg = tk.Toplevel(root)
    dlg.title("GameMacroStudio 로그인")
    dlg.resizable(False, False)

    user_var = tk.StringVar()
    pwd_var = tk.StringVar()
    error_var = tk.StringVar(value="")
    user_var.set(initial_user_id)
    result: list[tuple[str, str, str] | None] = [None]
    client = AuthHttpClient(AuthClientConfig(endpoint=auth_url, timeout_sec=timeout_sec, retries=retries))
    msg_queue: queue.Queue[tuple[str, object]] = queue.Queue()
    poll_scheduled = False
    max_wait_seconds = int(
        round(
            sum(timeout_sec * (1.0 + (0.5 * attempt)) for attempt in range(retries + 1))
            + sum(0.2 * (attempt + 1) for attempt in range(retries))
        )
    )

    def _poll_queue() -> None:
        nonlocal poll_scheduled
        try:
            while True:
                kind, payload = msg_queue.get_nowait()
                if kind == "ok":
                    u, p, exp = payload  # type: ignore[misc]
                    result[0] = (u, p, exp)
                    dlg.destroy()
                    root.destroy()
                    poll_scheduled = False
                    return
                if kind == "fail":
                    error_var.set(str(payload))
                    for w in dlg.winfo_children():
                        with suppress(tk.TclError):
                            w.configure(state="normal")
        except queue.Empty:
            pass
        dlg.after(100, _poll_queue)

    def submit() -> None:
        nonlocal poll_scheduled
        uid = user_var.get().strip()
        pwd = pwd_var.get()
        if not uid or not pwd:
            error_var.set("아이디와 비밀번호를 입력하세요.")
            return
        error_var.set(f"로그인 중... 최대 약 {max_wait_seconds}초 소요될 수 있습니다.")
        for w in dlg.winfo_children():
            with suppress(tk.TclError):
                w.configure(state="disabled")

        def _do_login() -> None:
            try:
                response = client.verify_login(user_id=uid, password=pwd)
                if not bool(response.get("ok")):
                    code = str(response.get("code", "LOGIN_FAILED"))
                    message = str(response.get("message", "로그인 실패"))
                    msg_queue.put(("fail", f"아이디 [{uid}] - {code}: {message}"))
                    return
                msg_queue.put(("ok", (uid, pwd, str(response.get("expiresAt", "")))))
            except (AuthNetworkError, OSError, ValueError) as exc:
                msg_queue.put(("fail", f"아이디 [{uid}] - 인증 실패: {exc}"))

        threading.Thread(target=_do_login, daemon=True).start()
        if not poll_scheduled:
            poll_scheduled = True
            dlg.after(100, _poll_queue)

    def cancel() -> None:
        dlg.destroy()
        root.destroy()

    ttk.Label(dlg, text="아이디").grid(row=0, column=0, padx=8, pady=4, sticky="e")
    user_entry = ttk.Entry(dlg, textvariable=user_var, width=32)
    user_entry.grid(row=0, column=1, padx=8, pady=4)
    ttk.Label(dlg, text="비밀번호").grid(row=1, column=0, padx=8, pady=4, sticky="e")
    pwd_entry = ttk.Entry(dlg, textvariable=pwd_var, width=32, show="*")
    pwd_entry.grid(row=1, column=1, padx=8, pady=4)
    tk.Label(dlg, textvariable=error_var, fg="red").grid(
        row=2, column=0, columnspan=2, padx=8, pady=(2, 0), sticky="w"
    )

    btnf = ttk.Frame(dlg)
    btnf.grid(row=3, column=0, columnspan=2, pady=8)
    ttk.Button(btnf, text="확인", command=submit).pack(side=tk.LEFT, padx=4)
    ttk.Button(btnf, text="취소", command=cancel).pack(side=tk.LEFT, padx=4)

    dlg.update_idletasks()
    width = dlg.winfo_width()
    height = dlg.winfo_height()
    screen_w = dlg.winfo_screenwidth()
    screen_h = dlg.winfo_screenheight()
    x = (screen_w - width) // 2
    y = (screen_h - height) // 2
    dlg.geometry(f"+{x}+{y}")

    dlg.bind("<Return>", lambda event: submit())
    dlg.protocol("WM_DELETE_WINDOW", cancel)
    dlg.grab_set()
    if initial_user_id:
        pwd_entry.focus_force()
    else:
        user_entry.focus_force()
    root.wait_window(dlg)
    if result[0] is None:
        return None
    u, p, exp = result[0]
    return (u.strip(), p, exp)
