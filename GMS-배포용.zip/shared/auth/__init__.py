"""라이선스 인증 패키지."""

from .guard import authenticate_or_exit

__all__ = ["authenticate_or_exit"]
