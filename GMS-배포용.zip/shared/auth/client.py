"""GAS 인증 API 클라이언트."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any
from urllib import error, request

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class AuthClientConfig:
    """인증 클라이언트 설정."""

    endpoint: str
    timeout_sec: float = 15.0
    retries: int = 2
    user_agent: str = "GameMacroStudio/1.0"


class AuthNetworkError(RuntimeError):
    """네트워크/응답 오류."""


class AuthHttpClient:
    """GAS 인증 API 호출기."""

    def __init__(self, config: AuthClientConfig) -> None:
        self._config = config

    def verify_login(self, *, user_id: str, password: str) -> dict[str, Any]:
        """아이디·비밀번호 로그인 요청을 전송하고 JSON 응답을 반환한다."""
        payload = {"userId": user_id, "password": password}
        data = json.dumps(payload).encode("utf-8")
        last_error: Exception | None = None

        for attempt in range(self._config.retries + 1):
            try:
                # GAS 콜드스타트/일시 지연을 고려해 재시도 시 타임아웃을 점진적으로 늘린다.
                attempt_timeout = self._config.timeout_sec * (1.0 + (0.5 * attempt))
                req = request.Request(
                    self._config.endpoint,
                    data=data,
                    headers={
                        "Content-Type": "application/json",
                        "User-Agent": self._config.user_agent,
                    },
                    method="POST",
                )
                with request.urlopen(req, timeout=attempt_timeout) as resp:
                    body = resp.read().decode("utf-8")
                parsed = json.loads(body)
                if not isinstance(parsed, dict):
                    msg = "인증 응답이 JSON 객체가 아닙니다."
                    raise AuthNetworkError(msg)
                return parsed
            except (error.URLError, TimeoutError, json.JSONDecodeError, AuthNetworkError) as exc:
                last_error = exc
                logger.warning(
                    "인증 요청 실패 (%s/%s, timeout=%.1fs): %s",
                    attempt + 1,
                    self._config.retries + 1,
                    attempt_timeout,
                    exc,
                )
                if attempt < self._config.retries:
                    time.sleep(0.2 * (attempt + 1))

        raise AuthNetworkError(f"인증 서버 통신 실패: {last_error}")
