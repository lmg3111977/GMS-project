"""시리얼 통신 프로토콜 정의.

PC ↔ Arduino Leonardo 간 바이너리 패킷 프로토콜의
명령 코드, 인코딩, 디코딩을 담당한다.

패킷 구조: [STX 0x02][CMD 1B][LENGTH 1B][PAYLOAD 0~60B][CHECKSUM 1B][ETX 0x03]
체크섬: CMD XOR LENGTH XOR (각 PAYLOAD 바이트)
"""

from __future__ import annotations

import logging
import struct
from enum import IntEnum

from shared.keymap import get_keycode, get_mouse_button_code
from shared.models import (
    Action,
    KeyComboAction,
    KeyDownAction,
    KeyPressAction,
    KeyUpAction,
    MouseClickAction,
    MouseDownAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
    MouseUpAction,
    TypeTextAction,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 상수
# ---------------------------------------------------------------------------

PACKET_STX: int = 0x02
PACKET_ETX: int = 0x03
MAX_PAYLOAD_SIZE: int = 60


# ---------------------------------------------------------------------------
# 명령 코드
# ---------------------------------------------------------------------------


class SerialCommand(IntEnum):
    """시리얼 명령 코드 열거."""

    MOUSE_MOVE_REL = 0x01
    MOUSE_CLICK = 0x02
    MOUSE_DOWN = 0x03
    MOUSE_UP = 0x04
    MOUSE_SCROLL = 0x05
    KEY_PRESS = 0x10
    KEY_DOWN = 0x11
    KEY_UP = 0x12
    KEY_RELEASE_ALL = 0x13
    TYPE_CHAR = 0x20
    HANDSHAKE = 0xF0
    ACK = 0xF1
    EMERGENCY_STOP = 0xFF


# ---------------------------------------------------------------------------
# 커스텀 예외
# ---------------------------------------------------------------------------


class InvalidPacketError(Exception):
    """잘못된 시리얼 패킷 에러.

    체크섬 불일치, STX/ETX 누락, 잘린 패킷 등에 사용한다.
    """


# ---------------------------------------------------------------------------
# 패킷 인코딩 / 디코딩
# ---------------------------------------------------------------------------


def _calculate_checksum(cmd: int, payload: bytes) -> int:
    """체크섬을 계산한다.

    Args:
        cmd: 명령 코드
        payload: 페이로드 바이트

    Returns:
        XOR 체크섬 값 (0~255)
    """
    checksum = cmd ^ len(payload)
    for byte in payload:
        checksum ^= byte
    return checksum & 0xFF


def encode_command(cmd: SerialCommand, payload: bytes = b"") -> bytes:
    """시리얼 패킷을 조립한다.

    Args:
        cmd: 명령 코드
        payload: 페이로드 바이트 (최대 60바이트)

    Returns:
        완전한 패킷 바이트열 [STX][CMD][LENGTH][PAYLOAD][CHECKSUM][ETX]

    Raises:
        ValueError: 페이로드가 60바이트를 초과할 때
    """
    if len(payload) > MAX_PAYLOAD_SIZE:
        raise ValueError(f"페이로드 크기 초과: {len(payload)}B (최대 {MAX_PAYLOAD_SIZE}B)")

    length = len(payload)
    checksum = _calculate_checksum(cmd, payload)

    packet = bytes([PACKET_STX, cmd, length]) + payload + bytes([checksum, PACKET_ETX])
    logger.debug("패킷 인코딩: %s", packet.hex())
    return packet


def decode_packet(data: bytes) -> tuple[SerialCommand, bytes]:
    """시리얼 패킷을 파싱한다.

    Args:
        data: 수신된 바이트열 (STX부터 ETX까지 포함)

    Returns:
        (명령 코드, 페이로드) 튜플

    Raises:
        InvalidPacketError: 패킷이 잘못되었을 때
    """
    if len(data) < 5:
        raise InvalidPacketError(f"패킷 너무 짧음: {len(data)}B (최소 5B)")

    if data[0] != PACKET_STX:
        raise InvalidPacketError(f"잘못된 STX: 0x{data[0]:02X} (기대값: 0x02)")

    if data[-1] != PACKET_ETX:
        raise InvalidPacketError(f"잘못된 ETX: 0x{data[-1]:02X} (기대값: 0x03)")

    cmd_byte = data[1]
    length = data[2]

    expected_total = 5 + length
    if len(data) != expected_total:
        raise InvalidPacketError(f"패킷 길이 불일치: {len(data)}B (기대값: {expected_total}B)")

    payload = data[3 : 3 + length]
    received_checksum = data[3 + length]
    expected_checksum = _calculate_checksum(cmd_byte, payload)

    if received_checksum != expected_checksum:
        raise InvalidPacketError(
            f"체크섬 불일치: 0x{received_checksum:02X} " f"(기대값: 0x{expected_checksum:02X})"
        )

    try:
        cmd = SerialCommand(cmd_byte)
    except ValueError as exc:
        raise InvalidPacketError(f"알 수 없는 CMD: 0x{cmd_byte:02X}") from exc

    logger.debug("패킷 디코딩: CMD=0x%02X, payload=%s", cmd_byte, payload.hex())
    return cmd, payload


# ---------------------------------------------------------------------------
# 개별 명령 인코더
# ---------------------------------------------------------------------------


def encode_mouse_move(dx: int, dy: int) -> bytes:
    """마우스 상대 이동 패킷을 생성한다.

    Args:
        dx: X축 이동량 (int16 범위)
        dy: Y축 이동량 (int16 범위)

    Returns:
        완전한 MOUSE_MOVE_REL 패킷
    """
    dx = max(-32768, min(32767, dx))
    dy = max(-32768, min(32767, dy))
    payload = struct.pack("<hh", dx, dy)
    return encode_command(SerialCommand.MOUSE_MOVE_REL, payload)


def encode_mouse_click(button_code: int, count: int = 1) -> bytes:
    """마우스 클릭 패킷을 생성한다.

    Args:
        button_code: 마우스 버튼 코드 (1=LEFT, 2=RIGHT, 4=MIDDLE)
        count: 클릭 횟수

    Returns:
        완전한 MOUSE_CLICK 패킷
    """
    payload = struct.pack("BB", button_code, count)
    return encode_command(SerialCommand.MOUSE_CLICK, payload)


def encode_mouse_down(button_code: int) -> bytes:
    """마우스 버튼 누름 패킷을 생성한다."""
    payload = struct.pack("B", button_code)
    return encode_command(SerialCommand.MOUSE_DOWN, payload)


def encode_mouse_up(button_code: int) -> bytes:
    """마우스 버튼 떼기 패킷을 생성한다."""
    payload = struct.pack("B", button_code)
    return encode_command(SerialCommand.MOUSE_UP, payload)


def encode_mouse_scroll(amount: int) -> bytes:
    """마우스 스크롤 패킷을 생성한다.

    Args:
        amount: 스크롤 양 (양수=위, 음수=아래). int8 범위.
    """
    amount = max(-128, min(127, amount))
    payload = struct.pack("b", amount)
    return encode_command(SerialCommand.MOUSE_SCROLL, payload)


def encode_key_press(keycode: int) -> bytes:
    """키 누르고 떼기 패킷을 생성한다."""
    payload = struct.pack("B", keycode)
    return encode_command(SerialCommand.KEY_PRESS, payload)


def encode_key_down(keycode: int) -> bytes:
    """키 누름 패킷을 생성한다."""
    payload = struct.pack("B", keycode)
    return encode_command(SerialCommand.KEY_DOWN, payload)


def encode_key_up(keycode: int) -> bytes:
    """키 떼기 패킷을 생성한다."""
    payload = struct.pack("B", keycode)
    return encode_command(SerialCommand.KEY_UP, payload)


def encode_key_release_all() -> bytes:
    """모든 키 해제 패킷을 생성한다."""
    return encode_command(SerialCommand.KEY_RELEASE_ALL)


def encode_type_char(char: str) -> bytes:
    """단일 문자 타이핑 패킷을 생성한다.

    Args:
        char: 타이핑할 문자 (ASCII 1글자)
    """
    ascii_code = ord(char) & 0xFF
    payload = struct.pack("B", ascii_code)
    return encode_command(SerialCommand.TYPE_CHAR, payload)


def build_handshake(version: int = 1) -> bytes:
    """핸드셰이크 패킷을 생성한다."""
    payload = struct.pack("B", version)
    return encode_command(SerialCommand.HANDSHAKE, payload)


def build_emergency_stop() -> bytes:
    """비상 정지 패킷을 생성한다."""
    return encode_command(SerialCommand.EMERGENCY_STOP)


# ---------------------------------------------------------------------------
# Action → 시리얼 명령 변환
# ---------------------------------------------------------------------------


def _split_int8(value: int) -> list[int]:
    """int 값을 int8 범위(-128~127)로 분할한다.

    Args:
        value: 분할할 정수

    Returns:
        int8 범위 값의 리스트. 합산하면 원래 value와 같다.
    """
    if value == 0:
        return [0]

    parts: list[int] = []
    remaining = value
    while remaining != 0:
        step = min(remaining, 127) if remaining > 0 else max(remaining, -128)
        parts.append(step)
        remaining -= step
    return parts


def _split_move_proportional(dx: int, dy: int) -> list[tuple[int, int]]:
    """dx, dy를 비율을 유지하면서 int8 범위 스텝들로 동시 분할한다.

    독립 분할+zip 방식은 X/Y 분할 개수 차이로 지그재그 경로가 생기는데,
    이 함수는 매 스텝마다 X/Y를 비율에 맞게 함께 분할하여 직선에 가까운
    경로를 만든다. OS 마우스 가속 환경에서 일관된 이동을 보장한다.
    """
    if dx == 0 and dy == 0:
        return [(0, 0)]

    steps: list[tuple[int, int]] = []
    remaining_dx = dx
    remaining_dy = dy

    while remaining_dx != 0 or remaining_dy != 0:
        abs_dx = abs(remaining_dx)
        abs_dy = abs(remaining_dy)
        max_abs = max(abs_dx, abs_dy)

        if max_abs <= 127:
            steps.append((remaining_dx, remaining_dy))
            break

        ratio = 127.0 / max_abs
        step_dx = int(remaining_dx * ratio)
        step_dy = int(remaining_dy * ratio)

        step_dx = max(-128, min(127, step_dx))
        step_dy = max(-128, min(127, step_dy))

        if step_dx == 0 and remaining_dx != 0:
            step_dx = 1 if remaining_dx > 0 else -1
        if step_dy == 0 and remaining_dy != 0:
            step_dy = 1 if remaining_dy > 0 else -1

        steps.append((step_dx, step_dy))
        remaining_dx -= step_dx
        remaining_dy -= step_dy

    return steps


def action_to_commands(
    action: Action,
    current_mouse_pos: tuple[int, int] = (0, 0),
) -> list[bytes]:
    """Action 모델을 시리얼 명령 패킷 목록으로 변환한다.

    마우스/키보드 I/O 액션만 변환한다.
    흐름 제어 액션(Delay, Loop, Goto, Label, IfPixel 등)은 빈 리스트를 반환한다.

    Args:
        action: 변환할 Action 인스턴스
        current_mouse_pos: 현재 마우스 커서 위치 (x, y). 절대 이동 계산용.

    Returns:
        시리얼 패킷 바이트열의 리스트
    """
    packets: list[bytes] = []

    if isinstance(action, MouseMoveAction):
        if action.is_relative:
            dx, dy = action.x, action.y
        else:
            dx = action.x - current_mouse_pos[0]
            dy = action.y - current_mouse_pos[1]

        for step_dx, step_dy in _split_move_proportional(dx, dy):
            packets.append(encode_mouse_move(step_dx, step_dy))

    elif isinstance(action, MouseClickAction):
        button_code = get_mouse_button_code(action.button.value)
        packets.append(encode_mouse_click(button_code, action.count))

    elif isinstance(action, MouseDownAction):
        button_code = get_mouse_button_code(action.button.value)
        packets.append(encode_mouse_down(button_code))

    elif isinstance(action, MouseUpAction):
        button_code = get_mouse_button_code(action.button.value)
        packets.append(encode_mouse_up(button_code))

    elif isinstance(action, MouseDragAction):
        drag_dx = action.end_x - action.start_x
        drag_dy = action.end_y - action.start_y

        start_dx = action.start_x - current_mouse_pos[0]
        start_dy = action.start_y - current_mouse_pos[1]
        for step_dx, step_dy in _split_move_proportional(start_dx, start_dy):
            packets.append(encode_mouse_move(step_dx, step_dy))

        button_code = get_mouse_button_code("LEFT")
        packets.append(encode_mouse_down(button_code))

        for step_dx, step_dy in _split_move_proportional(drag_dx, drag_dy):
            packets.append(encode_mouse_move(step_dx, step_dy))

        packets.append(encode_mouse_up(button_code))

    elif isinstance(action, MouseScrollAction):
        amount = action.amount if action.direction == "up" else -action.amount
        packets.append(encode_mouse_scroll(amount))

    elif isinstance(action, KeyPressAction):
        keycode = get_keycode(action.key)
        for _ in range(action.count):
            packets.append(encode_key_press(keycode))

    elif isinstance(action, KeyDownAction):
        keycode = get_keycode(action.key)
        packets.append(encode_key_down(keycode))

    elif isinstance(action, KeyUpAction):
        keycode = get_keycode(action.key)
        packets.append(encode_key_up(keycode))

    elif isinstance(action, KeyComboAction):
        modifier_keycodes: list[int] = []
        for mod_name in action.modifiers:
            mod_code = get_keycode(mod_name)
            modifier_keycodes.append(mod_code)
            packets.append(encode_key_down(mod_code))

        if action.key:
            main_keycode = get_keycode(action.key)
            packets.append(encode_key_press(main_keycode))

        for mod_code in reversed(modifier_keycodes):
            packets.append(encode_key_up(mod_code))

    elif isinstance(action, TypeTextAction):
        for _ in range(action.count):
            for char in action.text:
                packets.append(encode_type_char(char))

    return packets
