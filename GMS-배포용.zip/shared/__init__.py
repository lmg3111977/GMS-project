"""GameMacroStudio 공통 핵심 모듈.

shared 패키지는 editor와 engine 양쪽에서 사용하는 공통 데이터 모델,
시리얼 프로토콜, 유틸리티를 제공한다.

외부 의존: pydantic만 허용 (표준 라이브러리 + pydantic)
"""

from shared.models import (  # noqa: F401
    Action,
    ActionType,
    BreakAction,
    DelayAction,
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    KeyComboAction,
    KeyDownAction,
    KeyPressAction,
    KeyUpAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    Macro,
    MacroSettings,
    MouseButton,
    MouseClickAction,
    MouseDownAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
    MouseUpAction,
    OCRReadAction,
    OCRWaitAction,
    PixelWaitAction,
    SubMacroCallAction,
    TypeTextAction,
    VariableSetAction,
)
from shared.protocol import (  # noqa: F401
    InvalidPacketError,
    SerialCommand,
    action_to_commands,
    build_emergency_stop,
    build_handshake,
    decode_packet,
    encode_command,
)
from shared.schema import (  # noqa: F401
    MacroValidationError,
    load_macro,
    save_macro,
    validate_macro_logic,
)

__all__ = [
    # Enums
    "ActionType",
    "MouseButton",
    # Action Models
    "Action",
    "MouseMoveAction",
    "MouseClickAction",
    "MouseDownAction",
    "MouseUpAction",
    "MouseDragAction",
    "MouseScrollAction",
    "KeyPressAction",
    "KeyDownAction",
    "KeyUpAction",
    "KeyComboAction",
    "TypeTextAction",
    "DelayAction",
    "ElseAction",
    "EndIfAction",
    "LoopStartAction",
    "LoopEndAction",
    "BreakAction",
    "LabelAction",
    "GotoAction",
    "IfPixelAction",
    "PixelWaitAction",
    "ImageSearchAction",
    "ImageWaitAction",
    "ImageClickAction",
    "SubMacroCallAction",
    "VariableSetAction",
    "IfVariableAction",
    "OCRReadAction",
    "OCRWaitAction",
    # Macro Models
    "MacroSettings",
    "Macro",
]
