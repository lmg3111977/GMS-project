"""실행용 액션 리스트 유틸리티."""

from __future__ import annotations

from collections.abc import Iterable

from shared.models import (
    Action,
    SubMacroCallAction,
)


class BranchFlattenError(ValueError):
    """레거시 호환용 예외 타입."""


def flatten_actions_for_execution(
    actions: list[Action],
    *,
    _depth: int = 0,
) -> list[Action]:
    _ = _depth
    return list(actions)


def iter_sub_macro_calls_deep(actions: Iterable[Action]) -> Iterable[SubMacroCallAction]:
    """액션 목록에서 SubMacroCall을 찾는다."""
    for action in actions:
        if isinstance(action, SubMacroCallAction):
            yield action
