"""키 이름 ↔ Arduino HID 키코드 매핑.

사용자가 에디터에서 보는 키 이름(예: "Ctrl", "F1", "a")을
Arduino Keyboard.h가 이해하는 HID 키코드로 변환한다.

참조: Arduino Keyboard.h 키코드 정의
https://www.arduino.cc/reference/en/language/functions/usb/keyboard/
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 키보드 매핑 테이블
# ---------------------------------------------------------------------------

KEY_MAP: dict[str, int] = {
    # ── 알파벳 (소문자) ──
    "a": 0x61,
    "b": 0x62,
    "c": 0x63,
    "d": 0x64,
    "e": 0x65,
    "f": 0x66,
    "g": 0x67,
    "h": 0x68,
    "i": 0x69,
    "j": 0x6A,
    "k": 0x6B,
    "l": 0x6C,
    "m": 0x6D,
    "n": 0x6E,
    "o": 0x6F,
    "p": 0x70,
    "q": 0x71,
    "r": 0x72,
    "s": 0x73,
    "t": 0x74,
    "u": 0x75,
    "v": 0x76,
    "w": 0x77,
    "x": 0x78,
    "y": 0x79,
    "z": 0x7A,
    # ── 숫자 ──
    "0": 0x30,
    "1": 0x31,
    "2": 0x32,
    "3": 0x33,
    "4": 0x34,
    "5": 0x35,
    "6": 0x36,
    "7": 0x37,
    "8": 0x38,
    "9": 0x39,
    # ── F 키 ──
    "F1": 0xC2,
    "F2": 0xC3,
    "F3": 0xC4,
    "F4": 0xC5,
    "F5": 0xC6,
    "F6": 0xC7,
    "F7": 0xC8,
    "F8": 0xC9,
    "F9": 0xCA,
    "F10": 0xCB,
    "F11": 0xCC,
    "F12": 0xCD,
    # ── 수정자 키 (왼쪽) ──
    "LeftCtrl": 0x80,
    "LeftShift": 0x81,
    "LeftAlt": 0x82,
    "LeftGUI": 0x83,
    # ── 수정자 키 (오른쪽) ──
    "RightCtrl": 0x84,
    "RightShift": 0x85,
    "RightAlt": 0x86,
    "RightGUI": 0x87,
    # ── 수정자 키 (편의 별칭 → 왼쪽 키로 매핑) ──
    "Ctrl": 0x80,
    "Shift": 0x81,
    "Alt": 0x82,
    "Win": 0x83,
    "GUI": 0x83,
    # ── 특수 키 ──
    "Enter": 0xB0,
    "Return": 0xB0,
    "Esc": 0xB1,
    "Escape": 0xB1,
    "Backspace": 0xB2,
    "Tab": 0xB3,
    "Space": 0x20,
    "CapsLock": 0xC1,
    "PrintScreen": 0xCE,
    "ScrollLock": 0xCF,
    "Pause": 0xD0,
    # ── 내비게이션 키 ──
    "Insert": 0xD1,
    "Home": 0xD2,
    "PageUp": 0xD3,
    "Delete": 0xD4,
    "End": 0xD5,
    "PageDown": 0xD6,
    # ── 방향 키 ──
    "Right": 0xD7,
    "Left": 0xD8,
    "Down": 0xD9,
    "Up": 0xDA,
    # ── 기호 키 (시프트 없이 입력 가능한 것) ──
    "-": 0x2D,
    "=": 0x3D,
    "[": 0x5B,
    "]": 0x5D,
    "\\": 0x5C,
    ";": 0x3B,
    "'": 0x27,
    "`": 0x60,
    ",": 0x2C,
    ".": 0x2E,
    "/": 0x2F,
    # ── 넘패드 (Arduino에서 일반 키로 처리) ──
    "Num0": 0xEA,
    "Num1": 0xE1,
    "Num2": 0xE2,
    "Num3": 0xE3,
    "Num4": 0xE4,
    "Num5": 0xE5,
    "Num6": 0xE6,
    "Num7": 0xE7,
    "Num8": 0xE8,
    "Num9": 0xE9,
    "NumDivide": 0xDC,
    "NumMultiply": 0xDD,
    "NumSubtract": 0xDE,
    "NumAdd": 0xDF,
    "NumEnter": 0xE0,
    "NumDot": 0xEB,
    # ── 미디어 키 (일부 Arduino HID 확장) ──
    "Menu": 0xED,
}

# 역방향 조회 테이블 (keycode → 키 이름)
# 중복 코드(별칭)는 첫 번째 등록된 이름 우선
_REVERSE_KEY_MAP: dict[int, str] = {}
for _name, _code in KEY_MAP.items():
    if _code not in _REVERSE_KEY_MAP:
        _REVERSE_KEY_MAP[_code] = _name


# ---------------------------------------------------------------------------
# 마우스 버튼 매핑 테이블
# ---------------------------------------------------------------------------

MOUSE_BUTTON_MAP: dict[str, int] = {
    "LEFT": 1,
    "RIGHT": 2,
    "MIDDLE": 4,
}

_REVERSE_MOUSE_MAP: dict[int, str] = {v: k for k, v in MOUSE_BUTTON_MAP.items()}


# ---------------------------------------------------------------------------
# 조회 함수
# ---------------------------------------------------------------------------


def get_keycode(key_name: str) -> int:
    """키 이름으로 HID 키코드를 조회한다.

    Args:
        key_name: 키 이름 (예: "a", "F1", "Ctrl", "Enter")

    Returns:
        Arduino HID 키코드 (int)

    Raises:
        KeyError: 매핑되지 않은 키 이름
    """
    if key_name not in KEY_MAP:
        raise KeyError(f"알 수 없는 키 이름: '{key_name}'")
    return KEY_MAP[key_name]


def get_key_name(keycode: int) -> str:
    """HID 키코드로 키 이름을 역방향 조회한다.

    Args:
        keycode: Arduino HID 키코드

    Returns:
        키 이름 (str)

    Raises:
        KeyError: 매핑되지 않은 키코드
    """
    if keycode not in _REVERSE_KEY_MAP:
        raise KeyError(f"알 수 없는 키코드: 0x{keycode:02X}")
    return _REVERSE_KEY_MAP[keycode]


def get_all_key_names() -> list[str]:
    """사용 가능한 모든 키 이름을 정렬하여 반환한다.

    에디터의 키 선택 드롭다운에 표시할 목록.

    Returns:
        정렬된 키 이름 리스트
    """
    return sorted(KEY_MAP.keys())


def get_mouse_button_code(button_name: str) -> int:
    """마우스 버튼 이름으로 HID 버튼 코드를 조회한다.

    Args:
        button_name: "LEFT", "RIGHT", "MIDDLE"

    Returns:
        마우스 버튼 코드 (1, 2, 4)

    Raises:
        KeyError: 매핑되지 않은 버튼 이름
    """
    upper_name = button_name.upper()
    if upper_name not in MOUSE_BUTTON_MAP:
        raise KeyError(f"알 수 없는 마우스 버튼: '{button_name}'")
    return MOUSE_BUTTON_MAP[upper_name]


def get_mouse_button_name(button_code: int) -> str:
    """마우스 버튼 코드로 이름을 역방향 조회한다.

    Args:
        button_code: 마우스 버튼 코드 (1, 2, 4)

    Returns:
        버튼 이름 ("LEFT", "RIGHT", "MIDDLE")

    Raises:
        KeyError: 매핑되지 않은 버튼 코드
    """
    if button_code not in _REVERSE_MOUSE_MAP:
        raise KeyError(f"알 수 없는 마우스 버튼 코드: {button_code}")
    return _REVERSE_MOUSE_MAP[button_code]


def is_modifier_key(key_name: str) -> bool:
    """주어진 키 이름이 수정자 키(Ctrl, Shift, Alt, GUI)인지 확인한다.

    Args:
        key_name: 키 이름

    Returns:
        수정자 키이면 True
    """
    modifier_names = {
        "LeftCtrl",
        "LeftShift",
        "LeftAlt",
        "LeftGUI",
        "RightCtrl",
        "RightShift",
        "RightAlt",
        "RightGUI",
        "Ctrl",
        "Shift",
        "Alt",
        "Win",
        "GUI",
    }
    return key_name in modifier_names
