"""앱 설정 관리 (config.json).

헌법 7.2조: 마지막 사용 COM 포트, 핫키 설정, 창 위치/크기, 최근 파일 목록을 저장한다.
설정 파일이 없으면 기본값으로 동작한다 (에러 아님).
"""

from __future__ import annotations

import json
import logging
import os
from contextlib import suppress
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_PATH: Path = Path("config.json")

_DEFAULTS: dict[str, Any] = {
    "last_port": "",
    "auth_url": "",
    "remember_login_username": False,
    "login_username": "",
    "license_expires_at": "",
    "window_x": 100,
    "window_y": 100,
    "window_width": 1200,
    "window_height": 800,
    "recent_files": [],
    "max_recent_files": 10,
}


def load_config(path: Path | None = None) -> dict[str, Any]:
    """config.json을 읽어 딕셔너리로 반환한다.

    파일이 없거나 파싱 실패 시 기본값을 반환한다.

    Args:
        path: 설정 파일 경로. None이면 프로그램 실행 디렉토리의 config.json.

    Returns:
        설정 딕셔너리
    """
    config_path = path or DEFAULT_CONFIG_PATH
    config: dict[str, Any] = dict(_DEFAULTS)

    if not config_path.exists():
        logger.debug("설정 파일 없음, 기본값 사용: %s", config_path)
        return config

    try:
        with open(config_path, encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            config.update(loaded)
            logger.debug("설정 로드 완료: %s", config_path)
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("설정 파일 읽기 실패 (기본값 사용): %s — %s", config_path, exc)

    return config


def save_config(config: dict[str, Any], path: Path | None = None) -> None:
    """설정 딕셔너리를 config.json에 저장한다.

    Args:
        config: 저장할 설정 딕셔너리
        path: 저장 경로. None이면 프로그램 실행 디렉토리의 config.json.
    """
    config_path = path or DEFAULT_CONFIG_PATH
    tmp_path = config_path.with_suffix(".tmp")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, config_path)
        logger.debug("설정 저장 완료: %s", config_path)
    except OSError as exc:
        logger.warning("설정 파일 저장 실패: %s — %s", config_path, exc)
        with suppress(OSError):
            tmp_path.unlink()


def add_recent_file(config: dict[str, Any], file_path: str) -> None:
    """최근 파일 목록에 경로를 추가한다.

    이미 있으면 맨 앞으로 이동한다.
    max_recent_files를 초과하면 가장 오래된 항목을 제거한다.

    Args:
        config: 설정 딕셔너리 (직접 수정됨)
        file_path: 추가할 파일 경로
    """
    recent: list[str] = config.get("recent_files", [])
    abs_path = str(Path(file_path).resolve())

    if abs_path in recent:
        recent.remove(abs_path)
    recent.insert(0, abs_path)

    max_count = config.get("max_recent_files", 10)
    config["recent_files"] = recent[:max_count]
