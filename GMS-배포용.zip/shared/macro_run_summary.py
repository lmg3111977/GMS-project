"""실행 전 매크로 요약(액션 수, 대기 시간 추정, 위험 액션 등)."""

from __future__ import annotations

from shared.models import (
    DelayAction,
    KeyPressAction,
    Macro,
    MouseClickAction,
    SubMacroCallAction,
    TypeTextAction,
)


def summarize_macro_run(macro: Macro) -> dict[str, object]:
    """매크로 실행 전 통계를 계산한다 (정적 추정)."""
    actions = macro.actions
    n = len(actions)
    click_like = 0
    key_like = 0
    text_like = 0
    delay_ms_sum = 0
    sub_calls = 0
    schedule_rules = len(macro.settings.schedule_rules)

    hid_risk = 0
    for a in actions:
        if isinstance(a, MouseClickAction):
            click_like += int(a.count)
            hid_risk += 1
        elif isinstance(a, (KeyPressAction,)):
            key_like += 1
            hid_risk += 1
        elif isinstance(a, TypeTextAction):
            text_like += 1
            hid_risk += len(a.text) if a.text else 1
        elif isinstance(a, DelayAction):
            if (
                a.random_min is None
                and a.random_max is None
                and not (a.comment or "").strip().startswith("--------")
            ):
                delay_ms_sum += int(a.ms)
        elif isinstance(a, SubMacroCallAction):
            sub_calls += 1

    return {
        "action_count": n,
        "click_actions": click_like,
        "key_press_actions": key_like,
        "type_text_actions": text_like,
        "delay_ms_static_sum": delay_ms_sum,
        "sub_macro_calls": sub_calls,
        "schedule_rules": schedule_rules,
        "hid_risk_score": hid_risk,
    }


def format_run_summary_text(macro: Macro) -> str:
    """실행 전 확인 대화상자에 넣을 사람이 읽기 쉬운 텍스트."""
    s = summarize_macro_run(macro)
    lines = [
        f"액션 개수: {s['action_count']}",
        f"스케줄 규칙: {s['schedule_rules']}개",
        f"마우스 클릭(횟수 합): {s['click_actions']}",
        f"키 입력 액션: {s['key_press_actions']}",
        f"텍스트 입력 액션: {s['type_text_actions']}",
        f"고정 Delay 합계(추정): {s['delay_ms_static_sum']} ms " "(랜덤 딜레이·식 기반 값은 제외)",
        f"SubMacro 호출: {s['sub_macro_calls']}",
        "",
        "HID 관련 위험도(대략): 클릭·키·텍스트 액션 수 기준 "
        f"점수 {s['hid_risk_score']} — 실제 장치 연결 시 입력이 전송됩니다.",
        "",
        "리허설을 켜면 Arduino로 HID를 보내지 않고 Stub 로그만 남깁니다.",
    ]
    return "\n".join(lines)
