"""입력 휴머나이저 — 매크로 동작을 사람처럼 보이게 만드는 유틸리티.

일정한 간격의 클릭, 정확한 좌표, 동일한 딜레이는 안티치트에 탐지될 수 있다.
이 모듈은 랜덤 딜레이, 좌표 노이즈, 타이핑 속도 변동을 추가하여
사람의 입력 패턴에 가깝게 만든다.

주의: time.sleep() 직접 호출 금지 (constitution 섹션 8).
      이 모듈의 human_delay() 또는 sync_human_delay()를 대신 사용할 것.
"""

from __future__ import annotations

import asyncio
import logging
import math
import random
import time

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 공통 딜레이 계산
# ---------------------------------------------------------------------------


def _calc_gaussian_delay(base_ms: int, randomize: bool) -> float:
    """가우시안 분포 기반 딜레이 값을 계산한다 (실제 sleep 없이).

    Args:
        base_ms: 기본 대기 시간 (ms)
        randomize: True이면 ±20% 가우시안, False이면 정확히 base_ms

    Returns:
        계산된 딜레이 (ms)
    """
    if randomize:
        sigma = base_ms * 0.2
        delay_ms = random.gauss(base_ms, sigma)
        return max(base_ms * 0.5, min(base_ms * 1.5, delay_ms))
    return float(base_ms)


def _calc_lognormal_delay(base_ms: int) -> float:
    """로그정규 분포 기반 딜레이 값을 계산한다.

    중앙값이 base_ms가 되도록 설정하고, 극단값은 0.3x~3.0x로 제한한다.
    """
    if base_ms <= 0:
        return 0.0

    # lognormal의 median = exp(mu)이므로 mu=log(base_ms)로 고정한다.
    mu = math.log(base_ms)
    sigma = 0.35
    delay_ms = random.lognormvariate(mu, sigma)
    return max(base_ms * 0.3, min(base_ms * 3.0, delay_ms))


def _maybe_micro_afk(
    enabled: bool = False,
    chance: float = 0.02,
    min_ms: float = 800.0,
    max_ms: float = 2500.0,
) -> float:
    """낮은 확률로 짧은 멈칫(마이크로 AFK) 시간을 반환한다.

    기본값은 비활성화로 두어, 일반 매크로 실행에서 체감 끊김이 생기지 않게 한다.
    """
    if not enabled:
        return 0.0
    actual_chance = max(0.0, min(1.0, chance))
    actual_min = max(0.0, min(min_ms, max_ms))
    actual_max = max(actual_min, max(min_ms, max_ms))
    if random.random() < actual_chance:
        return random.uniform(actual_min, actual_max)
    return 0.0


def _calc_uniform_delay(min_ms: int, max_ms: int) -> float:
    """균등 분포 딜레이 값을 계산한다 (실제 sleep 없이).

    Args:
        min_ms: 최소 대기 시간 (ms)
        max_ms: 최대 대기 시간 (ms)

    Returns:
        계산된 딜레이 (ms)
    """
    actual_min = max(0, min(min_ms, max_ms))
    actual_max = max(actual_min, max(min_ms, max_ms))
    return random.uniform(actual_min, actual_max)


# ---------------------------------------------------------------------------
# 딜레이 함수
# ---------------------------------------------------------------------------


async def human_delay(base_ms: int, randomize: bool = True) -> None:
    """가우시안 분포 기반 비동기 딜레이.

    asyncio.sleep()을 사용하므로 이벤트 루프를 차단하지 않는다.

    Args:
        base_ms: 기본 대기 시간 (ms)
        randomize: True이면 가우시안 분포 적용, False이면 정확히 base_ms
    """
    if base_ms <= 0:
        return

    delay_ms = _calc_gaussian_delay(base_ms, randomize)
    logger.debug("human_delay: %.0fms (base=%dms, randomize=%s)", delay_ms, base_ms, randomize)
    await asyncio.sleep(delay_ms / 1000.0)


async def random_delay(min_ms: int, max_ms: int) -> None:
    """균등 분포 비동기 랜덤 딜레이.

    Args:
        min_ms: 최소 대기 시간 (ms)
        max_ms: 최대 대기 시간 (ms)
    """
    if min_ms <= 0 and max_ms <= 0:
        return

    delay_ms = _calc_uniform_delay(min_ms, max_ms)
    logger.debug("random_delay: %.0fms (range=%d~%d)", delay_ms, min_ms, max_ms)
    await asyncio.sleep(delay_ms / 1000.0)


def sync_human_delay(
    base_ms: int,
    randomize: bool = True,
    allow_micro_afk: bool = False,
    micro_afk_chance_percent: int = 2,
    micro_afk_min_ms: int = 800,
    micro_afk_max_ms: int = 2500,
    stop_event: object | None = None,
    link_lost_event: object | None = None,
) -> None:
    """가우시안 분포 기반 동기 딜레이.

    QThread 등 asyncio 루프가 없는 환경에서 사용한다.
    내부적으로 time.sleep()을 래핑한다.

    Args:
        base_ms: 기본 대기 시간 (ms)
        randomize: True이면 가우시안 분포 적용
        allow_micro_afk: True면 낮은 확률의 추가 멈칫(0.8~2.5초)을 허용
        micro_afk_chance_percent: 마이크로 AFK 발생 확률 (%)
        micro_afk_min_ms: 마이크로 AFK 최소 시간 (ms)
        micro_afk_max_ms: 마이크로 AFK 최대 시간 (ms)
        stop_event: threading.Event — set 시 즉시 중단 (선택)
        link_lost_event: Arduino 끊김 시 즉시 중단 (선택)
    """
    if base_ms <= 0:
        return

    if randomize:
        delay_ms = _calc_lognormal_delay(base_ms) + _maybe_micro_afk(
            enabled=allow_micro_afk,
            chance=(micro_afk_chance_percent / 100.0),
            min_ms=float(micro_afk_min_ms),
            max_ms=float(micro_afk_max_ms),
        )
    else:
        delay_ms = float(base_ms)
    logger.debug("sync_human_delay: %.0fms (base=%dms)", delay_ms, base_ms)
    _interruptible_sleep(delay_ms / 1000.0, stop_event, link_lost_event)


def sync_random_delay(
    min_ms: int,
    max_ms: int,
    stop_event: object | None = None,
    link_lost_event: object | None = None,
) -> None:
    """균등 분포 동기 랜덤 딜레이.

    Args:
        min_ms: 최소 대기 시간 (ms)
        max_ms: 최대 대기 시간 (ms)
        stop_event: threading.Event — set 시 즉시 중단 (선택)
        link_lost_event: Arduino 끊김 시 즉시 중단 (선택)
    """
    if min_ms <= 0 and max_ms <= 0:
        return

    delay_ms = _calc_uniform_delay(min_ms, max_ms)
    logger.debug("sync_random_delay: %.0fms", delay_ms)
    _interruptible_sleep(delay_ms / 1000.0, stop_event, link_lost_event)


def _interruptible_sleep(
    seconds: float,
    stop_event: object | None = None,
    link_lost_event: object | None = None,
) -> None:
    """stop_event / link_lost_event가 있으면 50ms 단위로 쪼개서 중단 체크하며 대기한다."""
    if (stop_event is None and link_lost_event is None) or seconds <= 0.05:
        time.sleep(max(0, seconds))
        return

    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if hasattr(stop_event, "is_set") and stop_event.is_set():
            return
        if hasattr(link_lost_event, "is_set") and link_lost_event.is_set():
            return
        remaining = deadline - time.monotonic()
        time.sleep(min(0.05, max(0, remaining)))


# ---------------------------------------------------------------------------
# 좌표 노이즈
# ---------------------------------------------------------------------------


def add_coordinate_noise(x: int, y: int, sigma: float = 4.0) -> tuple[int, int]:
    """좌표에 가우시안 노이즈를 추가한다.

    사람은 정확히 같은 좌표를 클릭하지 않으므로,
    작은 랜덤 오프셋을 추가하여 자연스럽게 만든다.

    Args:
        x: 원본 X 좌표
        y: 원본 Y 좌표
        sigma: 표준편차 (픽셀 단위, 기본 4.0)

    Returns:
        (noisy_x, noisy_y) 노이즈가 추가된 좌표
    """
    noisy_x = round(x + random.gauss(0, sigma))
    noisy_y = round(y + random.gauss(0, sigma))

    noisy_x = max(0, noisy_x)
    noisy_y = max(0, noisy_y)

    return noisy_x, noisy_y


# ---------------------------------------------------------------------------
# 간격 변동
# ---------------------------------------------------------------------------


def randomize_click_interval(base_ms: int) -> int:
    """클릭 간격에 ±20% 변동을 추가한다.

    Args:
        base_ms: 기본 클릭 간격 (ms)

    Returns:
        변동된 간격 (ms). 최소 1ms.
    """
    if base_ms <= 0:
        return 0
    variation = base_ms * 0.2
    result = round(random.uniform(base_ms - variation, base_ms + variation))
    return max(1, result)


def randomize_typing_interval(base_ms: int) -> int:
    """타이핑 간격에 ±30% 변동을 추가한다.

    사람은 키마다 타이핑 속도가 다르므로,
    클릭보다 더 큰 변동을 준다.

    Args:
        base_ms: 기본 타이핑 간격 (ms)

    Returns:
        변동된 간격 (ms). 최소 1ms.
    """
    if base_ms <= 0:
        return 0
    variation = base_ms * 0.3
    result = round(random.uniform(base_ms - variation, base_ms + variation))
    return max(1, result)
