"""마우스 좌표 변환 및 이동 유틸리티.

절대 좌표 → 상대 이동 변환, Mouse.move()의 int8 제한(-128~127)에 따른
분할 전송 로직, 베지어 커브 기반 자연스러운 마우스 궤적 생성을 담당한다.
"""

from __future__ import annotations

import math
import random


def clamp(value: int, min_val: int, max_val: int) -> int:
    """값을 지정 범위로 제한한다.

    Args:
        value: 입력값
        min_val: 최소값
        max_val: 최대값

    Returns:
        min_val ≤ 결과 ≤ max_val
    """
    return max(min_val, min(max_val, value))


def calculate_relative_move(
    current_x: int,
    current_y: int,
    target_x: int,
    target_y: int,
) -> tuple[int, int]:
    """절대 좌표에서 상대 이동량을 계산한다.

    Args:
        current_x: 현재 X 좌표
        current_y: 현재 Y 좌표
        target_x: 목표 X 좌표
        target_y: 목표 Y 좌표

    Returns:
        (dx, dy) 상대 이동량
    """
    return target_x - current_x, target_y - current_y


def split_mouse_move(dx: int, dy: int) -> list[tuple[int, int]]:
    """큰 이동을 int8 범위(-128~127) 스텝으로 분할한다.

    Mouse.move()의 매개변수가 signed char (int8)이므로,
    127px을 초과하는 이동은 여러 스텝으로 나눠야 한다.

    Args:
        dx: X축 총 이동량
        dy: Y축 총 이동량

    Returns:
        (step_dx, step_dy) 튜플의 리스트. 각 값은 -128~127 범위.
        모든 step_dx 합산 = dx, 모든 step_dy 합산 = dy.
    """
    if dx == 0 and dy == 0:
        return [(0, 0)]

    steps: list[tuple[int, int]] = []
    remaining_dx = dx
    remaining_dy = dy

    while remaining_dx != 0 or remaining_dy != 0:
        step_dx = clamp(remaining_dx, -128, 127)
        step_dy = clamp(remaining_dy, -128, 127)
        steps.append((step_dx, step_dy))
        remaining_dx -= step_dx
        remaining_dy -= step_dy

    return steps


def generate_linear_path(
    start_x: int,
    start_y: int,
    end_x: int,
    end_y: int,
    num_points: int = 10,
) -> list[tuple[int, int]]:
    """직선 이동 경로를 생성한다.

    Args:
        start_x: 시작 X
        start_y: 시작 Y
        end_x: 끝 X
        end_y: 끝 Y
        num_points: 경로 상의 점 개수 (최소 2)

    Returns:
        (x, y) 절대 좌표 리스트. 첫 번째 = 시작점, 마지막 = 끝점.
    """
    num_points = max(2, num_points)
    path: list[tuple[int, int]] = []

    for i in range(num_points):
        t = i / (num_points - 1)
        x = round(start_x + (end_x - start_x) * t)
        y = round(start_y + (end_y - start_y) * t)
        path.append((x, y))

    return path


def generate_bezier_path(
    start_x: int,
    start_y: int,
    end_x: int,
    end_y: int,
    num_points: int | None = None,
) -> list[tuple[int, int]]:
    """3차 베지어 커브로 자연스러운 마우스 이동 경로를 생성한다.

    제어점은 시작~끝 사이에 랜덤 오프셋으로 배치하여
    사람의 마우스 이동 궤적을 모방한다.

    Args:
        start_x: 시작 X
        start_y: 시작 Y
        end_x: 끝 X
        end_y: 끝 Y
        num_points: 경로 점 개수. None이면 거리에 비례하여 자동 결정.

    Returns:
        (x, y) 절대 좌표 리스트.
    """
    distance = math.sqrt((end_x - start_x) ** 2 + (end_y - start_y) ** 2)

    if num_points is None:
        num_points = max(5, round(distance / 5))
    num_points = max(2, num_points)

    offset_range = max(10, distance * 0.1)

    cp1_x = start_x + (end_x - start_x) * 0.25 + random.gauss(0, offset_range)
    cp1_y = start_y + (end_y - start_y) * 0.25 + random.gauss(0, offset_range)
    cp2_x = start_x + (end_x - start_x) * 0.75 + random.gauss(0, offset_range)
    cp2_y = start_y + (end_y - start_y) * 0.75 + random.gauss(0, offset_range)

    path: list[tuple[int, int]] = []
    for i in range(num_points):
        t = i / (num_points - 1)
        inv_t = 1 - t

        x = inv_t**3 * start_x + 3 * inv_t**2 * t * cp1_x + 3 * inv_t * t**2 * cp2_x + t**3 * end_x
        y = inv_t**3 * start_y + 3 * inv_t**2 * t * cp1_y + 3 * inv_t * t**2 * cp2_y + t**3 * end_y
        path.append((round(x), round(y)))

    path[0] = (start_x, start_y)
    path[-1] = (end_x, end_y)

    return path


def path_to_relative_steps(path: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """절대 좌표 경로를 상대 이동 스텝으로 변환한다.

    Args:
        path: (x, y) 절대 좌표 리스트

    Returns:
        (dx, dy) 상대 이동 리스트. 각 값은 이전 점에서 현재 점으로의 이동량.
    """
    if len(path) < 2:
        return []

    steps: list[tuple[int, int]] = []
    for i in range(1, len(path)):
        dx = path[i][0] - path[i - 1][0]
        dy = path[i][1] - path[i - 1][1]
        steps.append((dx, dy))

    return steps


def calculate_move_duration(distance: float, speed: str = "normal") -> int:
    """이동 거리에 적절한 이동 시간(ms)을 계산한다.

    Args:
        distance: 이동 거리 (픽셀)
        speed: "slow", "normal", "fast"

    Returns:
        이동 소요 시간 (ms)
    """
    speed_factors: dict[str, float] = {
        "slow": 1.5,
        "normal": 1.0,
        "fast": 0.5,
    }

    factor = speed_factors.get(speed, 1.0)
    base_ms = distance * 0.5 * factor
    return max(10, round(base_ms))
