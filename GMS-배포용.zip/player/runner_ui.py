"""플레이어 UI와 MacroRunner 연결 — 중복 제거용 헬퍼.

MiniControlPanel + 경량 Runner 콜백은 PlayerSession·PlayerTrayApp에서 동일하므로
한곳에서 연결한다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from engine.runner import MacroRunner, RunnerState
from engine.serial_cmd import SerialCommander

if TYPE_CHECKING:
    from .tray_app import MiniControlPanel


def attach_player_runner_callbacks(
    runner: MacroRunner,
    panel: MiniControlPanel,
    *,
    serial: SerialCommander | None,
) -> None:
    """플레이어용 최소 Runner→패널 콜백을 연결한다.

    Args:
        runner: 플레이어 인스턴스.
        panel: 미니 컨트롤 패널.
        serial: 메시지용 포트명 표시에 사용. None(dry-run 등)이면 연결 끊김/복구 로그는 건너뜀.
    """
    runner.on_state_changed.append(panel.playback_ui_state.emit)
    runner.on_error.append(lambda msg: panel.player_log_line.emit("ERROR", msg))
    runner.on_log.append(lambda level, msg: panel.player_log_line.emit(level, msg))
    if serial is not None:
        runner.on_connection_lost.append(
            lambda msg: panel.player_log_line.emit("ERROR", f"Arduino 연결 끊김: {msg}")
        )
        runner.on_reconnected.append(
            lambda: panel.player_log_line.emit(
                "INFO",
                f"Arduino 재연결 성공: {serial.port_name}",
            )
        )


def toggle_runner_pause_resume(runner: MacroRunner | None) -> None:
    """실행 중이면 일시정지, 일시정지 중이면 재개 (Ctrl+F6 공통 처리)."""
    if runner is None:
        return
    if runner.state == RunnerState.RUNNING:
        runner.pause_macro()
    elif runner.state == RunnerState.PAUSED:
        runner.resume_macro()
