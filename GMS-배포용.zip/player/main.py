"""플레이어 독립 실행 진입점.

통합 런처(main.py)를 사용하는 것을 권장합니다.
이 파일은 player/ 디렉터리에서 직접 실행할 때를 위한 호환 진입점입니다.
"""

from __future__ import annotations

import sys
from pathlib import Path

# 프로젝트 루트를 경로에 추가
_root = str(Path(__file__).resolve().parent.parent)
if _root not in sys.path:
    sys.path.insert(0, _root)

from main import main  # noqa: E402

if __name__ == "__main__":
    main()
