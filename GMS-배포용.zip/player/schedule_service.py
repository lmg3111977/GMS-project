"""플레이어 전용 스케줄러 서비스.

에디터 모듈 의존 없이 QTimer 기반으로 스케줄 트리거만 제공한다.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

from PyQt6.QtCore import QObject, QTimer

from shared.models import Macro, ScheduleRule


class PlayerScheduleService(QObject):
    """현재 플레이어 매크로 설정을 감시해 예약 트리거를 발생시킨다."""

    def __init__(
        self,
        macro_supplier: Callable[[], Macro | None],
        on_fire: Callable[[ScheduleRule], None],
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._macro_supplier = macro_supplier
        self._on_fire = on_fire
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)
        self._last_fired_keys: set[str] = set()
        self._last_seen_date = datetime.now().date().isoformat()

    def start(self) -> None:
        self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    def _tick(self) -> None:
        macro = self._macro_supplier()
        if macro is None:
            return

        now = datetime.now()
        today = now.date().isoformat()
        if today != self._last_seen_date:
            # 날짜가 바뀌면 중복방지 키를 정리해 메모리 누적을 막는다.
            self._last_fired_keys.clear()
            self._last_seen_date = today
        for rule in macro.settings.schedule_rules:
            if not rule.enabled:
                continue
            if not rule.macro_path.strip():
                continue
            if len(rule.time_hhmm) != 5 or ":" not in rule.time_hhmm:
                continue
            hh_text, mm_text = rule.time_hhmm.split(":", 1)
            try:
                target_hh = int(hh_text)
                target_mm = int(mm_text)
            except ValueError:
                continue
            if now.hour != target_hh or now.minute != target_mm:
                continue
            fire_key = f"{today}|{target_hh:02d}:{target_mm:02d}|{rule.rule_id}"
            if fire_key in self._last_fired_keys:
                continue
            self._last_fired_keys.add(fire_key)
            self._on_fire(rule)
