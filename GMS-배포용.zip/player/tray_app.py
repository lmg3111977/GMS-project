"""시스템 트레이 기반 플레이어 UI.

에디터의 1,652줄 main_window.py 대비 ~200줄.
on_action_executed / on_variables_changed 를 등록하지 않아
매 스텝 UI repaint가 발생하지 않는다.
"""

from __future__ import annotations

import logging
import threading
import time

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (
    QAction,
    QCloseEvent,
    QColor,
    QFont,
    QIcon,
    QPainter,
    QPixmap,
    QShowEvent,
)
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QSystemTrayIcon,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from engine.runner import MacroRunner, RunnerState
from engine.screen import ScreenAnalyzer
from engine.serial_cmd import SerialCommander, SerialConnectionError
from shared.models import MacroSettings
from shared.schema import MacroValidationError, load_macro

from .runner_ui import attach_player_runner_callbacks, toggle_runner_pause_resume

logger = logging.getLogger(__name__)


def _make_tray_icon(letter: str = "P", bg_color: str = "#2E7D32") -> QIcon:
    """단순한 텍스트 기반 트레이 아이콘을 생성한다."""
    pixmap = QPixmap(32, 32)
    pixmap.fill(QColor(bg_color))
    painter = QPainter(pixmap)
    painter.setPen(QColor("white"))
    painter.setFont(QFont("Arial", 18, QFont.Weight.Bold))
    painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, letter)
    painter.end()
    return QIcon(pixmap)


class MiniControlPanel(QWidget):
    """매크로 플레이어 미니 컨트롤 패널.

    표시 항목: 매크로 이름, 실행 상태, 실행(Ctrl+F5)/일시정지·재개(Ctrl+F6)/정지(Ctrl+F7), 로그.
    에디터의 param_panel(100KB), action_list(17KB) 등 편집 위젯을 전혀 포함하지 않음.
    """

    run_requested = pyqtSignal()
    stop_requested = pyqtSignal()
    pause_toggle_requested = pyqtSignal()
    switch_to_editor_requested = pyqtSignal()
    reconnect_requested = pyqtSignal()
    # 워커 스레드 → UI: QTimer.singleShot은 비-GUI 스레드에서 신뢰할 수 없음.
    playback_ui_state = pyqtSignal(object)
    player_log_line = pyqtSignal(str, str)

    def __init__(self, macro_name: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("PlayerPanelRoot")
        self.setWindowTitle("GameMacro Player — 대기")
        self.setFixedSize(340, 330)
        self.setWindowFlags(Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(6)

        # 매크로 이름
        self._name_label = QLabel(macro_name or "(로드 안 됨)")
        self._name_label.setStyleSheet("font-weight: bold; font-size: 13px;")
        layout.addWidget(self._name_label)

        # 실행 설정 요약
        self._settings_label = QLabel("설정: 휴머나이저 정보 없음")
        self._settings_label.setWordWrap(True)
        self._settings_label.setStyleSheet("font-size: 11px; color: #444;")
        layout.addWidget(self._settings_label)

        # 상태 표시 (스타일은 set_state에서 통일)
        self._state_label = QLabel("○ 대기")
        self._state_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self._state_label)

        # 버튼 행: 실행 / 일시정지·재개 / 정지
        btn_row = QHBoxLayout()
        self._run_btn = QPushButton("▶ Ctrl+F5")
        self._run_btn.setToolTip("매크로 실행 (Ctrl+F5)")
        self._run_btn.clicked.connect(self.run_requested.emit)
        btn_row.addWidget(self._run_btn)

        self._pause_btn = QPushButton("⏸ Ctrl+F6")
        self._pause_btn.setToolTip("실행 중: 일시정지 / 일시정지 중: 재개 (Ctrl+F6)")
        self._pause_btn.clicked.connect(self.pause_toggle_requested.emit)
        btn_row.addWidget(self._pause_btn)

        self._stop_btn = QPushButton("■ Ctrl+F7")
        self._stop_btn.setToolTip("매크로 정지 (Ctrl+F7)")
        self._stop_btn.clicked.connect(self.stop_requested.emit)
        btn_row.addWidget(self._stop_btn)
        layout.addLayout(btn_row)

        # 로그 (최근 3줄)
        self._log_text = QTextEdit()
        self._log_text.setReadOnly(True)
        self._log_text.setMaximumHeight(60)
        self._log_text.setStyleSheet("font-size: 11px; background: #F5F5F5;")
        layout.addWidget(self._log_text)

        # 에디터 모드 전환 버튼
        self._editor_btn = QPushButton("📝 에디터 모드로 전환")
        self._editor_btn.setStyleSheet(
            "QPushButton { background: #6A1B9A; color: #FFFFFF; border: none; "
            "border-radius: 4px; padding: 6px; font-weight: bold; }"
            "QPushButton:pressed { padding-top: 7px; }"
        )
        self._editor_btn.setToolTip("매크로 에디터로 전환합니다")
        self._editor_btn.clicked.connect(self._on_switch_to_editor)
        layout.addWidget(self._editor_btn)

        # 재연결 버튼
        self._reconnect_btn = QPushButton("🔌 Arduino 재연결")
        self._reconnect_btn.setStyleSheet(
            "QPushButton { background: #E65100; color: #FFFFFF; border: none; "
            "border-radius: 4px; padding: 6px; font-weight: bold; }"
            "QPushButton:pressed { padding-top: 7px; }"
        )
        self._reconnect_btn.setToolTip("Arduino에 수동으로 재연결을 시도합니다")
        self._reconnect_btn.clicked.connect(self.reconnect_requested.emit)
        layout.addWidget(self._reconnect_btn)

        self.set_state("IDLE")

        self.playback_ui_state.connect(self.set_state)
        self.player_log_line.connect(self.append_log)

        # 글로벌 핫키: 통합 런처(main.py)가 __init__ 직후 setWindowFlags로 네이티브 창을 바꾸므로,
        # RegisterHotKey는 첫 showEvent 이후에 건다(에디터는 QMainWindow로 창 타입이 안 바뀜).
        self._hotkey_thread = None
        self._hotkey_thread_running = False
        self._last_hotkey_at: dict[str, float] = {}
        self._global_hotkeys_installed = False

    def showEvent(self, event: QShowEvent) -> None:  # noqa: N802
        super().showEvent(event)
        if self._global_hotkeys_installed:
            return
        self._global_hotkeys_installed = True
        self._setup_global_hotkeys()

    def set_macro_name(self, name: str) -> None:
        """매크로 이름을 패널에 표시한다."""
        self._name_label.setText(name)

    def set_macro_settings(self, settings: MacroSettings | None) -> None:
        """매크로 실행 설정 요약을 패널에 표시한다."""
        if settings is None:
            self._settings_label.setText("설정: 휴머나이저 정보 없음")
            return
        if not settings.humanize:
            self._settings_label.setText("설정: 휴머나이저 꺼짐")
            return

        if settings.micro_afk_enabled:
            self._settings_label.setText(
                "설정: 휴머나이저 켜짐 · 기본 딜레이 "
                f"{settings.base_delay_ms}ms · 마이크로 AFK "
                f"{settings.micro_afk_chance_percent}% "
                f"({settings.micro_afk_min_ms}~{settings.micro_afk_max_ms}ms)"
            )
            return

        self._settings_label.setText(
            "설정: 휴머나이저 켜짐 · 기본 딜레이 " f"{settings.base_delay_ms}ms · 마이크로 AFK 꺼짐"
        )

    def set_state(self, state: str | RunnerState) -> None:
        """실행 상태 배지·버튼·창 테두리를 갱신한다."""
        key = state.value if isinstance(state, RunnerState) else str(state)
        display_map = {
            "IDLE": ("○ 대기", "#555", "#E8E8E8", "2px solid #B0BEC5"),
            "RUNNING": ("▶ 실행 중", "#FFF", "#2E7D32", "3px solid #2E7D32"),
            "PAUSED": ("⏸ 일시정지", "#FFF", "#F57C00", "3px solid #F57C00"),
            "STOPPED": ("■ 정지됨", "#FFF", "#C62828", "2px solid #E57373"),
            "COMPLETED": ("✓ 매크로 종료", "#FFF", "#1565C0", "2px solid #1976D2"),
        }
        row = display_map.get(
            key,
            (key, "#555", "#E8E8E8", "2px solid #B0BEC5"),
        )
        text, fg, bg, border = row
        self._state_label.setText(text)
        self._state_label.setStyleSheet(
            f"font-size: 14px; font-weight: bold; padding: 6px 8px; "
            f"color: {fg}; background: {bg}; border-radius: 6px; border: {border};"
        )
        titles = {
            "IDLE": "GameMacro Player — 대기",
            "RUNNING": "GameMacro Player — 실행 중",
            "PAUSED": "GameMacro Player — 일시정지",
            "STOPPED": "GameMacro Player — 정지됨",
            "COMPLETED": "GameMacro Player — 종료됨",
        }
        self.setWindowTitle(titles.get(key, f"GameMacro Player — {key}"))
        self._sync_playback_ui(key)

    def _sync_playback_ui(self, key: str) -> None:
        """실행/정지에 맞춰 버튼 활성화와 강조 스타일을 맞춘다."""
        idle_like = key in ("IDLE", "STOPPED", "COMPLETED")
        active = key in ("RUNNING", "PAUSED")

        self._run_btn.setEnabled(idle_like)
        self._stop_btn.setEnabled(active)
        pause_active = key in ("RUNNING", "PAUSED")
        self._pause_btn.setEnabled(pause_active)
        if key == "RUNNING":
            self._pause_btn.setText("⏸ Ctrl+F6")
            self._pause_btn.setToolTip("일시정지 (Ctrl+F6)")
        elif key == "PAUSED":
            self._pause_btn.setText("▶ Ctrl+F6")
            self._pause_btn.setToolTip("재개 (Ctrl+F6)")
        else:
            self._pause_btn.setText("⏸ Ctrl+F6")
            self._pause_btn.setToolTip("실행 중일 때 사용 (Ctrl+F6)")

        run_on = (
            "QPushButton { background: #2E7D32; color: #FFFFFF; border: none; "
            "border-radius: 6px; padding: 8px; font-weight: bold; }"
            "QPushButton:hover { background: #388E3C; }"
            "QPushButton:pressed { padding-top: 9px; }"
            "QPushButton:disabled { background: #E0E0E0; color: #9E9E9E; }"
        )
        run_off = (
            "QPushButton { background: #EEEEEE; color: #9E9E9E; border: 1px solid #E0E0E0; "
            "border-radius: 6px; padding: 8px; font-weight: bold; }"
            "QPushButton:disabled { background: #EEEEEE; color: #BDBDBD; }"
        )
        stop_on = (
            "QPushButton { background: #C62828; color: #FFFFFF; border: none; "
            "border-radius: 6px; padding: 8px; font-weight: bold; }"
            "QPushButton:hover { background: #D32F2F; }"
            "QPushButton:pressed { padding-top: 9px; }"
            "QPushButton:disabled { background: #E0E0E0; color: #9E9E9E; }"
        )
        stop_off = (
            "QPushButton { background: #EEEEEE; color: #9E9E9E; border: 1px solid #E0E0E0; "
            "border-radius: 6px; padding: 8px; font-weight: bold; }"
            "QPushButton:disabled { background: #EEEEEE; color: #BDBDBD; }"
        )
        pause_on = (
            "QPushButton { background: #F57C00; color: #FFFFFF; border: none; "
            "border-radius: 6px; padding: 8px; font-weight: bold; }"
            "QPushButton:hover { background: #FB8C00; }"
            "QPushButton:pressed { padding-top: 9px; }"
            "QPushButton:disabled { background: #E0E0E0; color: #9E9E9E; }"
        )
        pause_off = (
            "QPushButton { background: #EEEEEE; color: #9E9E9E; border: 1px solid #E0E0E0; "
            "border-radius: 6px; padding: 8px; font-weight: bold; }"
            "QPushButton:disabled { background: #EEEEEE; color: #BDBDBD; }"
        )

        self._run_btn.setStyleSheet(run_on if idle_like else run_off)
        self._pause_btn.setStyleSheet(pause_on if pause_active else pause_off)
        self._stop_btn.setStyleSheet(stop_on if active else stop_off)

        frame_idle = (
            "#PlayerPanelRoot { border: 2px solid #CFD8DC; border-radius: 10px; "
            "background: #FFFFFF; }"
        )
        frame_run = (
            "#PlayerPanelRoot { border: 3px solid #2E7D32; border-radius: 10px; "
            "background: #F1F8F4; }"
        )
        frame_pause = (
            "#PlayerPanelRoot { border: 3px solid #F57C00; border-radius: 10px; "
            "background: #FFF8F0; }"
        )
        frame_stop = (
            "#PlayerPanelRoot { border: 2px solid #E57373; border-radius: 10px; "
            "background: #FFF5F5; }"
        )
        frame_done = (
            "#PlayerPanelRoot { border: 2px solid #1976D2; border-radius: 10px; "
            "background: #E3F2FD; }"
        )
        frame = {
            "IDLE": frame_idle,
            "STOPPED": frame_stop,
            "COMPLETED": frame_done,
            "RUNNING": frame_run,
            "PAUSED": frame_pause,
        }.get(key, frame_idle)
        self.setStyleSheet(frame)

    def append_log(self, level: str, message: str) -> None:
        """로그 메시지를 패널 하단에 추가한다."""
        color = {"ERROR": "#C62828", "WARNING": "#F57C00"}.get(level, "#333")
        self._log_text.append(f'<span style="color:{color}">[{level}] {message}</span>')
        # 최대 20줄 유지
        doc = self._log_text.document()
        if doc and doc.blockCount() > 20:
            cursor = self._log_text.textCursor()
            cursor.movePosition(cursor.MoveOperation.Start)
            cursor.movePosition(cursor.MoveOperation.Down, cursor.MoveMode.KeepAnchor)
            cursor.removeSelectedText()
            cursor.deleteChar()

    def _on_switch_to_editor(self) -> None:
        """에디터 모드 전환을 요청한다."""
        self.switch_to_editor_requested.emit()

    def _stop_win32_hotkey_thread(self) -> None:
        """PeekMessage 스레드 루프를 멈춘다(UnregisterHotKey는 스레드 종료 시 수행)."""
        self._hotkey_thread_running = False

    def _setup_global_hotkeys(self) -> None:
        """Win32 RegisterHotKey로 전역 핫키를 등록한다.

        에디터와 동일한 커널 레벨 방식으로, 게임 독점 모드에서도 작동한다.
        비-Windows에서는 pynput 폴백을 사용한다.
        """
        import sys

        if sys.platform.startswith("win"):
            success = self._setup_win32_hotkeys()
            if success:
                return
            self.append_log("WARNING", "Win32 핫키 실패. pynput 폴백 시도.")

        self._setup_pynput_hotkeys()

    def _setup_win32_hotkeys(self) -> bool:
        """에디터와 같이 전용 스레드에서 RegisterHotKey(NULL) + PeekMessage.

        nativeEvent에서 ctypes로 message를 MSG*로 캐스팅하면 PyQt6 빌드에 따라
        잘못된 주소를 읽어 프로세스가 무음 종료(접근 위반)할 수 있어 사용하지 않음.
        """
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        mod_control = 0x0002
        mod_norepeat = 0x4000
        hotkey_mods = mod_control | mod_norepeat

        vk_labels = {0x74: "Ctrl+F5", 0x75: "Ctrl+F6", 0x76: "Ctrl+F7"}
        hotkey_defs = [
            (5001, 0x74, "run", self.run_requested.emit),
            (5006, 0x75, "pause", self.pause_toggle_requested.emit),
            (5007, 0x76, "stop", self.stop_requested.emit),
        ]
        panel_ref = self

        def _hotkey_thread() -> None:
            registered: list[int] = []
            ok_labels: list[str] = []
            fail_labels: list[str] = []
            for hk_id, vk, name, _cb in hotkey_defs:
                kernel32.SetLastError(0)
                if user32.RegisterHotKey(None, hk_id, hotkey_mods, vk):
                    registered.append(hk_id)
                    ok_labels.append(vk_labels.get(vk, f"VK{vk:#x}"))
                else:
                    err = int(kernel32.GetLastError())
                    lbl = vk_labels.get(vk, f"VK{vk:#x}")
                    fail_labels.append(f"{lbl} err={err}")
                    logger.warning(
                        "플레이어 RegisterHotKey 실패: %s vk=%s (err=%d)",
                        name,
                        lbl,
                        err,
                    )

            panel_ref._win32_hotkey_ok_labels = ok_labels
            panel_ref._win32_hotkey_fail_labels = fail_labels

            if not registered:
                return

            panel_ref._hotkey_thread_running = True
            cb_map = {hk_id: (name, cb) for hk_id, _vk, name, cb in hotkey_defs}
            msg = wintypes.MSG()

            while panel_ref._hotkey_thread_running:
                result = user32.PeekMessageW(
                    ctypes.byref(msg),
                    None,
                    0x0312,
                    0x0312,
                    0x0001,
                )
                if result:
                    hk_wp = msg.wParam
                    entry = cb_map.get(hk_wp)
                    if entry is None:
                        try:
                            entry = cb_map.get(int(hk_wp))
                        except (TypeError, ValueError):
                            entry = None
                    if entry:
                        name, callback = entry
                        now = time.monotonic()
                        prev = panel_ref._last_hotkey_at.get(name, 0.0)
                        if now - prev >= 0.2:
                            panel_ref._last_hotkey_at[name] = now
                            try:
                                callback()
                            except Exception as exc:
                                logger.debug(
                                    "플레이어 Win32 핫키 콜백 에러 (%s): %s",
                                    name,
                                    exc,
                                )
                else:
                    threading.Event().wait(timeout=0.05)

            for hk_id in registered:
                user32.UnregisterHotKey(None, hk_id)

        self._hotkey_thread = threading.Thread(
            target=_hotkey_thread,
            daemon=True,
            name="PlayerWin32Hotkey",
        )
        self._hotkey_thread.start()

        from PyQt6.QtCore import QThread

        QThread.msleep(150)

        if self._hotkey_thread_running:
            ok = getattr(self, "_win32_hotkey_ok_labels", [])
            bad = getattr(self, "_win32_hotkey_fail_labels", [])
            self.append_log(
                "INFO",
                "전역 핫키 (Win32): Ctrl+F5 실행, Ctrl+F6 일시정지/재개, Ctrl+F7 정지 | 성공: "
                + ", ".join(ok),
            )
            if bad:
                self.append_log(
                    "WARNING",
                    "다음 키는 등록 실패(다른 프로그램이 먼저 쓰는 경우가 많음): " + "; ".join(bad),
                )
            return True

        return False

    def _setup_pynput_hotkeys(self) -> None:
        """pynput GlobalHotKeys 폴백 (비-Windows 또는 Win32 실패 시)."""
        import time as _time

        try:
            from pynput import keyboard
        except ImportError:
            self.append_log("WARNING", "전역 핫키 비활성화: pynput 미설치")
            return

        panel_ref = self

        def _trigger(name: str, callback: object) -> None:
            now = _time.monotonic()
            if now - panel_ref._last_hotkey_at.get(name, 0.0) < 0.2:
                return
            panel_ref._last_hotkey_at[name] = now
            try:
                callback()  # pyqtSignal.emit — pynput 스레드에서 호출해도 큐 연결로 UI 스레드에서 실행
            except Exception as exc:
                logger.debug("플레이어 pynput 핫키 콜백 에러 (%s): %s", name, exc)

        try:
            listener = keyboard.GlobalHotKeys(
                {
                    "<ctrl>+<f5>": lambda: _trigger("run", self.run_requested.emit),
                    "<ctrl>+<f6>": lambda: _trigger("pause", self.pause_toggle_requested.emit),
                    "<ctrl>+<f7>": lambda: _trigger("stop", self.stop_requested.emit),
                }
            )
            listener.start()
            self._hotkey_thread = listener
            self.append_log(
                "INFO",
                "전역 핫키 (pynput): Ctrl+F5 실행, Ctrl+F6 일시정지/재개, Ctrl+F7 정지",
            )
        except Exception as exc:
            self.append_log("WARNING", f"전역 핫키 실패: {exc}")

    def closeEvent(self, event: object) -> None:  # noqa: N802
        """플레이어 패널 종료 시 핫키 스레드를 정리한다."""
        self._stop_win32_hotkey_thread()
        if self._hotkey_thread is not None:
            try:
                if hasattr(self._hotkey_thread, "stop"):
                    self._hotkey_thread.stop()
                elif hasattr(self._hotkey_thread, "join"):
                    self._hotkey_thread.join(timeout=0.5)
            except Exception:
                pass
            self._hotkey_thread = None
        event.accept()  # type: ignore[union-attr]
        # 통합 런처: setWindowFlags 등으로 비자발적 close가 올 수 있음 → 무조건 quit 하면 앱이 바로 종료됨.
        # 사용자가 창 X로 닫았을 때만 quit (QCloseEvent.spontaneous()).
        if not getattr(self, "_gamemacro_integrated_player", False):
            return
        if getattr(self, "_gamemacro_player_close_to_editor", False):
            self._gamemacro_player_close_to_editor = False
            return
        ce = event
        user_closed = isinstance(ce, QCloseEvent) and ce.spontaneous()
        if user_closed:
            app_inst = QApplication.instance()
            if app_inst is not None:
                QTimer.singleShot(0, app_inst.quit)


class PlayerTrayApp:
    """시스템 트레이 기반 플레이어 앱 컨트롤러."""

    def __init__(
        self,
        macro_path: str | None = None,
        port: str | None = None,
        dry_run: bool = False,
    ) -> None:
        self._macro_path = macro_path
        self._port = port
        self._dry_run = dry_run

        self._runner: MacroRunner | None = None
        self._runner_thread: threading.Thread | None = None
        self._serial: SerialCommander | None = None
        self._screen: ScreenAnalyzer | None = None
        self._macro = None

        # UI
        self._tray: QSystemTrayIcon | None = None
        self._panel = MiniControlPanel()
        self._panel.run_requested.connect(self._on_run, Qt.ConnectionType.QueuedConnection)
        self._panel.stop_requested.connect(self._on_stop, Qt.ConnectionType.QueuedConnection)
        self._panel.pause_toggle_requested.connect(
            self._on_pause_toggle, Qt.ConnectionType.QueuedConnection
        )

    def show_tray(self) -> None:
        """시스템 트레이 아이콘과 컨텍스트 메뉴를 생성한다."""
        self._tray = QSystemTrayIcon(_make_tray_icon(), QApplication.instance())

        menu = QMenu()
        show_action = QAction("패널 열기", menu)
        show_action.triggered.connect(self._panel.show)
        menu.addAction(show_action)

        open_action = QAction("매크로 열기...", menu)
        open_action.triggered.connect(self._on_open_macro)
        menu.addAction(open_action)

        menu.addSeparator()
        run_action = QAction("▶ 실행 (Ctrl+F5)", menu)
        run_action.triggered.connect(self._on_run)
        menu.addAction(run_action)

        pause_action = QAction("⏸ 일시정지 / ▶ 재개 (Ctrl+F6)", menu)
        pause_action.triggered.connect(self._on_pause_toggle)
        menu.addAction(pause_action)

        stop_action = QAction("■ 정지 (Ctrl+F7)", menu)
        stop_action.triggered.connect(self._on_stop)
        menu.addAction(stop_action)

        menu.addSeparator()
        quit_action = QAction("종료", menu)
        quit_action.triggered.connect(self._on_quit)
        menu.addAction(quit_action)

        self._tray.setContextMenu(menu)
        self._tray.activated.connect(self._on_tray_activated)
        self._tray.show()

        # 전역 핫키는 MiniControlPanel.__init__에서만 등록 (중복 pynput/Win32 방지)

        # 매크로 로드
        if self._macro_path:
            self._load_macro(self._macro_path)

        # 미니 패널 표시
        self._panel.show()

    def _on_open_macro(self) -> None:
        """파일 선택 다이얼로그로 매크로를 열거나 교체한다."""
        if self._runner is not None and self._runner.state in (
            RunnerState.RUNNING,
            RunnerState.PAUSED,
        ):
            self._panel.append_log("WARNING", "실행 중에는 매크로를 교체할 수 없습니다.")
            return

        path, _ = QFileDialog.getOpenFileName(
            self._panel,
            "매크로 파일 열기",
            "macros",
            "JSON 매크로 (*.json);;모든 파일 (*)",
        )
        if path:
            self._load_macro(path)

    def _load_macro(self, path: str) -> None:
        try:
            self._macro = load_macro(path)
            self._panel.set_macro_name(self._macro.name)
            self._panel.set_macro_settings(self._macro.settings)
            self._panel.append_log(
                "INFO", f"로드 완료: {self._macro.name} ({len(self._macro.actions)}개)"
            )
            logger.info("매크로 로드: %s", self._macro.name)
        except (MacroValidationError, FileNotFoundError) as exc:
            self._panel.append_log("ERROR", f"로드 실패: {exc}")
            logger.error("매크로 로드 실패: %s", exc)

    def _ensure_engine(self) -> bool:
        """엔진(시리얼+화면분석+러너)을 초기화한다. 성공 시 True."""
        if self._runner is not None:
            return True

        if not self._dry_run:
            self._serial = SerialCommander(port=self._port)
            try:
                self._serial.connect()
                self._panel.append_log("INFO", f"Arduino 연결: {self._serial.port_name}")
            except SerialConnectionError as exc:
                self._panel.append_log("ERROR", f"Arduino 연결 실패: {exc}")
                return False

            try:
                self._screen = ScreenAnalyzer()
            except Exception as exc:
                logger.warning("화면 분석기 초기화 실패: %s", exc)

        self._runner = MacroRunner(
            serial_commander=self._serial if not self._dry_run else None,
            screen_analyzer=self._screen,
            enable_visual_debug=False,
        )

        attach_player_runner_callbacks(
            self._runner,
            self._panel,
            serial=None if self._dry_run else self._serial,
        )

        return True

    def _on_run(self) -> None:
        if self._macro is None:
            self._panel.append_log("WARNING", "매크로가 로드되지 않았습니다.")
            return

        if not self._ensure_engine():
            return

        runner = self._runner
        assert runner is not None

        if runner.state in (RunnerState.RUNNING, RunnerState.PAUSED):
            self._panel.append_log("WARNING", "이미 실행 중입니다.")
            return

        # 이전 스레드 정리
        if self._runner_thread is not None and self._runner_thread.is_alive():
            self._runner_thread.join(timeout=0.5)

        runner.load_macro(self._macro, source_path=self._macro_path)
        runner.start_macro()

        self._runner_thread = threading.Thread(target=runner.run_blocking, daemon=False)
        self._runner_thread.start()

    def _on_stop(self) -> None:
        if self._runner is not None:
            self._runner.stop_macro()

    def _on_pause_toggle(self) -> None:
        """Ctrl+F6: 실행 중이면 일시정지, 일시정지 중이면 재개."""
        toggle_runner_pause_resume(self._runner)

    def _on_tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self._panel.show()
            self._panel.activateWindow()

    def _on_quit(self) -> None:
        if self._runner is not None and self._runner.state in (
            RunnerState.RUNNING,
            RunnerState.PAUSED,
        ):
            self._runner.stop_macro()
        QApplication.instance().quit()  # type: ignore[union-attr]

    def cleanup(self) -> None:
        """앱 종료 시 리소스 정리."""
        if self._runner is not None and self._runner.state in (
            RunnerState.RUNNING,
            RunnerState.PAUSED,
        ):
            self._runner.stop_macro()

        if self._runner_thread is not None and self._runner_thread.is_alive():
            self._runner_thread.join(timeout=2.0)

        if self._serial is not None and self._serial.is_connected():
            self._serial.disconnect()

        if self._screen is not None:
            self._screen.close()
