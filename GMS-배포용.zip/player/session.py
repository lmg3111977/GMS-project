"""플레이어 모드 세션 컨트롤러.

에디터에서 작성한 매크로를 최소한의 오버헤드로 빠르게 실행하는 경량 세션.

성능 최적화 핵심 — 에디터 대비 비활성화된 기능:
  ✗ on_action_executed   미등록 → 매 액션 UI 갱신 제거
  ✗ on_variables_changed 미등록 → 변수 모니터 갱신 제거
  ✗ on_visual_debug      미등록 → 디버그 캡처 UI 제거
  ✗ enable_visual_debug=False   → 디버그용 썸네일 캡처만 스킵(본 매칭 캡처는 유지)
  ✗ 로그 포워딩 핸들러 없음     → 엔진 로그 → GUI 변환 오버헤드 제거
  ✗ 브레이크포인트/스텝 실행 없음

Runner→패널 콜백은 .runner_ui.attach_player_runner_callbacks 에서 PlayerTrayApp과 공통 처리한다.
"""

from __future__ import annotations

import threading
from collections import deque
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from player.tray_app import MiniControlPanel

from engine.runner import MacroRunner, RunnerState
from engine.serial_cmd import SerialConnectionError
from shared.models import Macro, MacroSettings, ScheduleRule, SubMacroCallAction

from .runner_ui import attach_player_runner_callbacks, toggle_runner_pause_resume
from .schedule_service import PlayerScheduleService


class PlayerSession:
    """플레이어 모드 세션.

    MiniControlPanel을 생성하고, Runner에 최소 콜백만 등록하여
    매크로를 최대 속도로 실행한다.
    """

    def __init__(self, ctx: Any) -> None:
        self._ctx = ctx
        self._panel: MiniControlPanel | None = None
        self._runner: MacroRunner | None = None
        self._runner_thread: threading.Thread | None = None
        self._schedule_service: PlayerScheduleService | None = None
        self._scheduled_queue: deque[ScheduleRule] = deque()
        self._resume_after_schedule_macro: Macro | None = None
        self._resume_after_schedule_src: str | None = None
        self._resume_after_schedule_index: int | None = None
        self._stop_requested_by_schedule: bool = False

    @property
    def panel(self) -> MiniControlPanel | None:
        return self._panel

    def launch(
        self,
        shared_state: dict[str, object],
        on_switch_to_editor: Callable[[], None],
    ) -> None:
        """플레이어 패널을 생성하고 표시한다."""
        from PyQt6.QtCore import Qt, QTimer

        from player.tray_app import MiniControlPanel

        ctx = self._ctx

        panel = MiniControlPanel()
        self._panel = panel
        panel.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint)
        panel._gamemacro_integrated_player = True

        # Runner — enable_visual_debug=False → 디버그 썸네일만 스킵
        runner = MacroRunner(
            serial_commander=ctx.serial_commander if not ctx.dry_run else None,
            screen_analyzer=ctx.screen_analyzer,
            enable_visual_debug=False,
        )
        self._runner = runner
        ctx.gui_runner_holder["runner"] = runner

        attach_player_runner_callbacks(
            runner,
            panel,
            serial=None if ctx.dry_run else ctx.serial_commander,
        )

        # 매크로 복원
        macro = shared_state.get("macro")
        macro_path_raw = shared_state.get("macro_path")
        macro_src = str(macro_path_raw) if macro_path_raw else None
        if isinstance(macro, Macro) and macro.actions:
            panel.set_macro_name(macro.name)
            panel.set_macro_settings(macro.settings)
            panel.append_log(
                "INFO",
                f"매크로 로드됨: {macro.name} ({len(macro.actions)}개 액션)",
            )
        else:
            panel.set_macro_name("(매크로 없음)")
            panel.set_macro_settings(None)
            panel.append_log(
                "WARNING",
                "실행할 매크로가 없습니다. 에디터에서 먼저 로드하세요.",
            )

        def _build_schedule_subcall_macro(rule: ScheduleRule) -> Macro:
            return Macro(
                name=f"스케줄 실행 {rule.time_hhmm}",
                settings=MacroSettings(
                    humanize=False,
                    base_delay_ms=0,
                    schedule_rules=[],
                ),
                actions=[SubMacroCallAction(macro_path=rule.macro_path)],
            )

        def _start_runner(
            run_macro: Macro,
            src: str | None,
            *,
            origin: str,
        ) -> None:
            if self._runner_thread is not None and self._runner_thread.is_alive():
                self._runner_thread.join(timeout=0.5)
                if self._runner_thread.is_alive():
                    panel.append_log("WARNING", "이전 실행 스레드가 아직 종료되지 않았습니다.")
                    return
            if runner.state in (RunnerState.RUNNING, RunnerState.PAUSED):
                panel.append_log("WARNING", f"이미 실행 중입니다. ({origin})")
                return
            if not ctx.dry_run and not ctx.serial_commander.is_connected():
                try:
                    ctx.serial_commander.connect()
                except SerialConnectionError as exc:
                    panel.append_log("ERROR", f"Arduino 연결 실패: {exc}")
                    return
            runner.load_macro(run_macro, source_path=src)
            runner.start_macro()
            self._runner_thread = threading.Thread(
                target=runner.run_blocking,
                daemon=False,
            )
            self._runner_thread.start()

        def _on_runner_state_changed(state: RunnerState) -> None:
            schedule_stop = state == RunnerState.STOPPED and self._stop_requested_by_schedule
            if schedule_stop:
                self._stop_requested_by_schedule = False
            if state not in (RunnerState.STOPPED, RunnerState.COMPLETED):
                return
            if self._scheduled_queue:
                if state == RunnerState.STOPPED and not schedule_stop:
                    return
                next_rule = self._scheduled_queue.popleft()
                panel.append_log("INFO", f"스케줄 실행 시작: {next_rule.time_hhmm}")
                _start_runner(
                    _build_schedule_subcall_macro(next_rule),
                    None,
                    origin="스케줄-큐",
                )
                return
            if self._resume_after_schedule_macro is not None and state == RunnerState.COMPLETED:
                resume_macro = self._resume_after_schedule_macro
                resume_src = self._resume_after_schedule_src
                resume_index = self._resume_after_schedule_index
                self._resume_after_schedule_macro = None
                self._resume_after_schedule_src = None
                self._resume_after_schedule_index = None
                if resume_index is not None and resume_index > 0:
                    resume_actions = list(resume_macro.actions[resume_index:])
                    if resume_actions:
                        resume_macro = resume_macro.model_copy(deep=True)
                        resume_macro.actions = resume_actions
                        panel.append_log(
                            "INFO",
                            f"스케줄 실행 완료: 이전 매크로 이어서 재개 (#{resume_index + 1}부터)",
                        )
                        _start_runner(resume_macro, resume_src, origin="스케줄-재개")
                        return
                panel.append_log("INFO", "스케줄 실행 완료: 이전 매크로 자동 재개")
                _start_runner(resume_macro, resume_src, origin="스케줄-재개")

        runner.on_state_changed.append(_on_runner_state_changed)

        def _supply_macro() -> Macro | None:
            if isinstance(macro, Macro):
                return macro
            return None

        def _on_schedule_fire(rule: ScheduleRule) -> None:
            if runner.state in (RunnerState.RUNNING, RunnerState.PAUSED):
                mode = rule.on_trigger_during_run
                should_restart = mode == "restart"
                should_resume = mode == "resume"
                if (
                    (should_restart or should_resume)
                    and self._resume_after_schedule_macro is None
                    and runner.macro is not None
                ):
                    self._resume_after_schedule_macro = runner.macro.model_copy(deep=True)
                    self._resume_after_schedule_src = macro_src
                    self._resume_after_schedule_index = (
                        runner.program_counter if should_resume else None
                    )
                self._scheduled_queue.append(rule.model_copy(deep=False))
                if should_resume:
                    panel.append_log(
                        "WARNING",
                        (
                            f"스케줄 트리거 감지({rule.time_hhmm}) - 현재 실행 중단 후 스케줄 실행, "
                            "완료 시 중단 지점부터 이어서 재개"
                        ),
                    )
                elif should_restart:
                    panel.append_log(
                        "WARNING",
                        (
                            f"스케줄 트리거 감지({rule.time_hhmm}) - 현재 실행 중단 후 스케줄 실행, "
                            "완료 시 이전 매크로 자동 재개"
                        ),
                    )
                else:
                    self._resume_after_schedule_macro = None
                    self._resume_after_schedule_src = None
                    self._resume_after_schedule_index = None
                    panel.append_log(
                        "WARNING",
                        f"스케줄 트리거 감지({rule.time_hhmm}) - 현재 실행 중단 후 스케줄만 실행",
                    )
                self._stop_requested_by_schedule = True
                runner.stop_macro()
                return
            panel.append_log("INFO", f"스케줄 트리거 감지({rule.time_hhmm}) - 스케줄 실행 시작")
            _start_runner(
                _build_schedule_subcall_macro(rule),
                None,
                origin="스케줄",
            )

        has_valid_schedule = isinstance(macro, Macro) and any(
            r.enabled and bool(r.macro_path.strip()) for r in macro.settings.schedule_rules
        )
        if has_valid_schedule:
            self._schedule_service = PlayerScheduleService(
                macro_supplier=_supply_macro,
                on_fire=_on_schedule_fire,
                parent=panel,
            )
            self._schedule_service.start()
            panel.append_log("INFO", "스케줄러 활성화: 플레이어 자동 예약 실행")
        else:
            panel.append_log("INFO", "스케줄러 비활성: 유효한 스케줄 규칙 없음")

        # 실행 시그널
        def _on_player_run() -> None:
            if not isinstance(macro, Macro) or not macro.actions:
                panel.append_log("WARNING", "실행할 매크로가 없습니다.")
                return
            _start_runner(macro, macro_src, origin="수동")

        def _on_player_stop() -> None:
            runner.stop_macro()

        def _on_pause_toggle() -> None:
            toggle_runner_pause_resume(runner)

        panel.run_requested.connect(_on_player_run, Qt.ConnectionType.QueuedConnection)
        panel.stop_requested.connect(_on_player_stop, Qt.ConnectionType.QueuedConnection)
        panel.pause_toggle_requested.connect(_on_pause_toggle, Qt.ConnectionType.QueuedConnection)

        # 플레이어 → 에디터 모드 전환
        def _on_switch_to_editor() -> None:
            if runner.state in (RunnerState.RUNNING, RunnerState.PAUSED):
                panel.append_log("WARNING", "매크로 실행 중에는 모드를 전환할 수 없습니다.")
                return
            self._teardown()
            panel._gamemacro_player_close_to_editor = True
            ctx.set_quit_on_last_window_closed(False)
            panel.close()
            QTimer.singleShot(200, on_switch_to_editor)

        panel.switch_to_editor_requested.connect(_on_switch_to_editor)

        # 수동 재연결
        def _on_player_reconnect() -> None:
            if ctx.serial_commander.is_connected():
                panel.append_log("INFO", "이미 연결되어 있습니다.")
                return
            panel.append_log("INFO", "Arduino 재연결 시도 중...")
            try:
                ctx.serial_commander.connect()
                panel.append_log(
                    "INFO",
                    f"Arduino 재연결 성공: {ctx.serial_commander.port_name}",
                )
            except SerialConnectionError as exc:
                panel.append_log("ERROR", f"Arduino 재연결 실패: {exc}")

        panel.reconnect_requested.connect(_on_player_reconnect)

        # 연결 모니터 콜백 (플레이어 UI 대상으로 교체)
        ctx.on_monitor_disconnected.clear()
        ctx.on_monitor_reconnected.clear()
        ctx.on_monitor_disconnected.append(
            lambda: panel.append_log("WARNING", "Arduino 연결 끊김 감지")
        )
        ctx.on_monitor_reconnected.append(
            lambda: panel.append_log("INFO", "Arduino 연결 복구 감지")
        )

        panel.show()
        ctx.set_quit_on_last_window_closed(True)
        panel.append_log(
            "INFO",
            "플레이어 모드: Ctrl+F5 실행, Ctrl+F6 일시정지/재개, Ctrl+F7 정지",
        )

    def get_quit_cleanup(self) -> Callable[[], None] | None:
        """앱 종료 시 Runner·스레드 정리 함수를 반환한다."""
        runner = self._runner
        runner_thread = self._runner_thread
        if runner is None:
            return None

        def cleanup() -> None:
            if runner.state not in (
                RunnerState.IDLE,
                RunnerState.STOPPED,
                RunnerState.COMPLETED,
            ):
                runner.stop_macro()
            if runner_thread is not None and runner_thread.is_alive():
                runner_thread.join(timeout=3.0)

        return cleanup

    def _teardown(self) -> None:
        """Runner·스레드를 정리한다."""
        if self._schedule_service is not None:
            self._schedule_service.stop()
            self._schedule_service = None
        self._scheduled_queue.clear()
        self._resume_after_schedule_macro = None
        self._resume_after_schedule_src = None
        self._resume_after_schedule_index = None
        self._stop_requested_by_schedule = False
        if self._runner is not None and self._runner.state != RunnerState.IDLE:
            self._runner.stop_macro()
        if self._runner_thread is not None and self._runner_thread.is_alive():
            self._runner_thread.join(timeout=1.0)
        self._ctx.gui_runner_holder["runner"] = None
        self._runner = None
