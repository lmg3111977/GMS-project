"""GameMacroStudio Player — 경량 매크로 실행기."""
