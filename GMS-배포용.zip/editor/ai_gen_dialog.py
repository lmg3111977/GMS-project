"""AI 매크로 생성 도우미 다이얼로그."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from pydantic import ValidationError
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication,
    QDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from editor.action_list.constants import UI_COLORS
from shared.models import Action, Macro

logger = logging.getLogger(__name__)

_BUILTIN_PROMPT_PATH = Path(__file__).resolve().parent.parent / "skills" / "macro_gen_prompt.md"

# 다이얼로그를 여러 번 열어도 매번 md를 읽지 않도록 캐시 (프로세스당 1회 로드)
_system_prompt_holder: list[str | None] = [None]

# AI 삽입 시 빈 comment에 붙이는 힌트 (window.py와 문구 일치 유지)
AI_INSERT_EMPTY_COMMENT_HINT = "위 [AI 자연어 요청]과 같은 입력으로 생성됨"

_FALLBACK_PROMPT = """\
너는 게임 매크로 **액션 목록**만 JSON으로 생성하는 도우미야.

# 출력 형식 (둘 중 하나만)
1) 순수 JSON 배열: [ { "type": "DELAY", ... }, ... ]
2) 객체 한 개: { "actions": [ ... ] } — name 등 다른 키는 생략해도 됨

매크로 이름·버전·hotkey·settings(humanize, base_delay_ms, micro_afk_*, schedule_rules 등)는 **에디터에서 관리하므로 출력하지 마세요.** 내가 에디터에 붙여넣으면 액션만 삽입된다.

# 모든 액션 공통 필드 (반드시 포함)
- "action_id": UUID4 문자열 (액션마다 고유)
- "enabled": true
- "comment": "" (가능하면 한글로 역할 요약)
- "type": 아래 타입 중 하나

# 액션 타입·주요 필드 (한 줄 요약)

마우스: MOUSE_MOVE: x,y,is_relative(false),duration_ms(0) | MOUSE_CLICK: button,count | MOUSE_DOWN/UP: button | MOUSE_DRAG: start_x,start_y,end_x,end_y,duration_ms | MOUSE_SCROLL: amount,direction

키보드: KEY_PRESS: key,count | KEY_DOWN/UP: key | KEY_COMBO: modifiers,key | TYPE_TEXT: text,interval_ms,count

대기/주석: DELAY: ms,random_min,random_max | COMMENT: (comment 필드에 설명)

루프/점프: LOOP_START: label,count,count_expression | LOOP_END | BREAK | LABEL: name | GOTO: target

If: IF_PIXEL: x,y,color(#RRGGBB),tolerance,detect_change | IF_VARIABLE: var_name,operator,compare_value | ELSE | END_IF

조건형(성공/실패 분기 — 반드시 END_IF): PIXEL_WAIT: ...,timeout_ms,change_reference | IMAGE_SEARCH: template_path,region_*,confidence,click_*,store_found_var,max_retry,... | IMAGE_WAIT | IMAGE_CLICK | OCR_WAIT: pattern,timeout_ms,store_var

기타: VARIABLE_SET: var_name,value,expression | SUB_MACRO_CALL: macro_path | OCR_READ: region_*,lang,store_var | FUNCTION_DEF/FUNCTION_END | FUNCTION_CALL | RETURN: expression

# 구조 규칙
1. IF_PIXEL, IF_VARIABLE → END_IF 필수. ELSE 선택.
2. PIXEL_WAIT, IMAGE_SEARCH, IMAGE_WAIT, IMAGE_CLICK, OCR_WAIT → 조건형, END_IF 필수.
3. LOOP_START → LOOP_END 필수.
4. FUNCTION_DEF → FUNCTION_END 필수.

# 생성 규칙
- 좌표는 0, template_path는 "TODO_이미지경로", macro_path는 "TODO_매크로경로"
- action_id는 매번 새 UUID4, expression 관련은 null, 색상 "#RRGGBB"
- 키 이름 소문자: a~z, 0~9, f1~f12, enter, space, tab, escape, shift, ctrl, alt, 방향키 등
- 출력은 유효한 JSON만. 마크다운 코드블록이나 설명 문장 없이.
"""


def _extract_first_markdown_fence_body(md: str) -> str | None:
    """첫 번째 펜스 블록 본문을 반환. ``` 또는 ```lang 형태 지원."""
    start = md.find("```")
    if start == -1:
        return None
    line_end = md.find("\n", start)
    if line_end == -1:
        return None
    inner_start = line_end + 1
    end = md.find("```", inner_start)
    if end == -1:
        return None
    return md[inner_start:end].strip()


def _load_system_prompt() -> str:
    """macro_gen_prompt.md에서 첫 펜스 블록을 추출한다.

    파일이 없거나 파싱 실패 시 내장 fallback 프롬프트를 사용한다.
    결과는 프로세스 단위로 캐시한다.
    """
    if _system_prompt_holder[0] is not None:
        return _system_prompt_holder[0]

    out = _FALLBACK_PROMPT
    try:
        text = _BUILTIN_PROMPT_PATH.read_text(encoding="utf-8")
        body = _extract_first_markdown_fence_body(text)
        if body:
            out = body
    except (FileNotFoundError, OSError):
        logger.warning("프롬프트 파일 없음, 내장 fallback 사용: %s", _BUILTIN_PROMPT_PATH)

    _system_prompt_holder[0] = out
    return out


def normalize_pasted_json_text(text: str) -> str:
    """AI가 마크다운 코드펜스로 감싼 JSON을 붙여넣은 경우 본문만 남긴다."""
    s = text.strip()
    if not s.startswith("```"):
        return s
    line_end = s.find("\n")
    if line_end == -1:
        return s.removeprefix("```").removesuffix("```").strip()
    body = s[line_end + 1 :]
    body = body.rstrip()
    if body.endswith("```"):
        body = body[:-3].rstrip()
    return body.strip()


def parse_ai_macro_json(raw: str) -> tuple[list[Action], str | None]:
    """AI가 붙여넣은 문자열을 JSON으로 파싱하고 Macro 스키마로 검증한다.

    Returns:
        (actions, None) 성공 시
        ([], error_message) 실패 시 (JSON 파싱, 형식, Pydantic)
    """
    text = normalize_pasted_json_text(raw)
    if not text:
        return [], "empty"

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        return [], f"JSON 파싱 실패: {e}"

    if isinstance(data, dict) and "actions" in data:
        actions_data = data["actions"]
        macro_name = data.get("name", "AI 생성 매크로")
    elif isinstance(data, list):
        actions_data = data
        macro_name = "AI 생성 매크로"
    else:
        return (
            [],
            "JSON에 'actions' 배열이 없습니다. 배열 [...] 또는 {\"actions\": [...]} 형식을 사용하세요.",
        )

    if not isinstance(actions_data, list):
        return [], f"'actions' 값은 JSON 배열이어야 합니다. (현재: {type(actions_data).__name__})"

    try:
        wrapper = {"name": macro_name, "version": "1.0", "actions": actions_data}
        macro = Macro.model_validate(wrapper)
    except ValidationError as e:
        logger.error("AI 매크로 검증 실패:\n%s", e)
        errs = e.errors()
        if errs:
            first = errs[0]
            loc = " → ".join(str(x) for x in first.get("loc", ()))
            msg = first.get("msg", "")
            tail = f" ({loc})" if loc else ""
            brief = f"{msg}{tail}"
            if len(brief) > 280:
                brief = brief[:277] + "..."
        else:
            brief = "로그 확인"
        return [], f"검증 실패 {e.error_count()}건. 첫 오류: {brief}"

    return list(macro.actions), None


class AIGenDialog(QDialog):
    """AI 매크로 생성 도우미 다이얼로그.

    왼쪽: 자연어 입력 + 클립보드 복사
    오른쪽: AI 응답 JSON 붙여넣기 + 검증 + 삽입
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI 매크로 생성 도우미")
        self.setMinimumSize(800, 500)
        self.resize(900, 550)
        self._result_actions: list[Action] = []
        self._user_request_text: str = ""
        self._system_prompt = _load_system_prompt()
        self._setup_ui()

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)

        info = QLabel(
            "매크로 이름·핫키·휴머나이저·스케줄 등 설정은 에디터에서 관리합니다. AI에는 **액션 목록 JSON만** 받습니다.\n"
            "① 왼쪽에 동작을 자연어로 작성 → [클립보드 복사] → AI에 붙여넣기\n"
            '② AI가 만든 **액션 JSON**(배열 또는 {"actions": [...]})을 오른쪽에 붙여넣기 → [검증 및 삽입]\n'
            "삽입 위치: 이 창을 열 때 선택된 행 **바로 아래**에 한꺼번에 들어갑니다. 선택이 없으면 목록 **맨 아래**입니다."
        )
        info.setStyleSheet("color: #555; padding: 4px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # === 왼쪽: 자연어 입력 ===
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)

        left_label = QLabel("매크로 동작 설명 (자연어)")
        left_label.setStyleSheet("font-weight: bold;")
        left_layout.addWidget(left_label)

        self._input_edit = QTextEdit()
        self._input_edit.setPlaceholderText(
            "예시:\n"
            "- 무한루프로 이미지 탐색해서 클릭, 못 찾으면 1초 대기\n"
            "- HP바 색상이 검정이 아니면 2번 키 누르기\n"
            "- 3번 반복: 클릭 → 0.5초 대기 → F5"
        )
        left_layout.addWidget(self._input_edit)

        copy_btn = QPushButton("클립보드 복사 (프롬프트 + 설명)")
        copy_btn.setStyleSheet(
            "QPushButton { background: #4f46e5; color: white; border: none; "
            "border-radius: 4px; padding: 8px; font-weight: bold; }"
            "QPushButton:hover { background: #4338ca; }"
        )
        copy_btn.clicked.connect(self._copy_to_clipboard)
        left_layout.addWidget(copy_btn)

        splitter.addWidget(left_widget)

        # === 오른쪽: JSON 붙여넣기 ===
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)

        right_label = QLabel("AI 생성 액션 JSON 붙여넣기")
        right_label.setStyleSheet("font-weight: bold;")
        right_layout.addWidget(right_label)

        self._json_edit = QTextEdit()
        self._json_edit.setPlaceholderText(
            '액션 배열 [...] 또는 {"actions": [...]}. '
            "마크다운 ``` 코드블록으로 감싸져 있어도 됩니다. 전체 매크로 JSON이면 actions만 사용됩니다."
        )
        right_layout.addWidget(self._json_edit)

        self._status_label = QLabel("")
        right_layout.addWidget(self._status_label)

        btn_row = QHBoxLayout()
        validate_btn = QPushButton("검증 및 삽입")
        validate_btn.setStyleSheet(
            "QPushButton { background: #16a34a; color: white; border: none; "
            "border-radius: 4px; padding: 8px; font-weight: bold; }"
            "QPushButton:hover { background: #15803d; }"
        )
        validate_btn.clicked.connect(self._validate_and_accept)
        btn_row.addWidget(validate_btn)

        cancel_btn = QPushButton("취소")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        right_layout.addLayout(btn_row)
        splitter.addWidget(right_widget)

        splitter.setSizes([400, 500])
        layout.addWidget(splitter)

    def _copy_to_clipboard(self) -> None:
        """시스템 프롬프트 + 사용자 설명을 클립보드에 복사."""
        user_text = self._input_edit.toPlainText().strip()
        if not user_text:
            QMessageBox.warning(self, "입력 필요", "매크로 동작 설명을 입력해주세요.")
            return

        full_text = self._system_prompt + "\n\n---\n\n# 사용자 요청\n" + user_text
        clipboard = QApplication.clipboard()
        clipboard.setText(full_text)
        self._status_label.setText("클립보드에 복사 완료! AI에 붙여넣으세요.")
        self._status_label.setStyleSheet(f"color: {UI_COLORS['success']}; font-weight: bold;")

    def _validate_and_accept(self) -> None:
        """붙여넣은 JSON을 파싱·검증하고 액션 리스트를 저장."""
        raw = self._json_edit.toPlainText()
        if not raw.strip():
            QMessageBox.warning(self, "입력 필요", "JSON을 붙여넣어 주세요.")
            return

        actions, err = parse_ai_macro_json(raw)
        if err:
            self._status_label.setText(err)
            self._status_label.setStyleSheet(f"color: {UI_COLORS['error']}; font-weight: bold;")
            return

        if not actions:
            self._status_label.setText("액션이 하나도 없습니다. JSON 배열에 동작을 넣어 주세요.")
            self._status_label.setStyleSheet(f"color: {UI_COLORS['error']}; font-weight: bold;")
            return

        self._result_actions = actions
        self._user_request_text = self._input_edit.toPlainText().strip()
        count = len(self._result_actions)
        self._status_label.setText(f"검증 성공! {count}개 액션. 삽입합니다.")
        self._status_label.setStyleSheet(f"color: {UI_COLORS['success']}; font-weight: bold;")
        self.accept()

    def get_actions(self) -> list[Action]:
        """검증 통과한 액션 리스트를 반환한다."""
        return self._result_actions

    def get_user_request_text(self) -> str:
        """검증 성공 시점에 왼쪽에 적어 둔 자연어 설명(빈 문자열 가능)."""
        return self._user_request_text
