from __future__ import annotations

import contextlib
import threading

from engine.runner import RunnerState
from engine.scheduler import SchedulerError
from engine.serial_cmd import SerialConnectionError
from shared.models import Macro


class RunnerCallbacksMixin:
    def _on_runner_state_changed(self, state: RunnerState) -> None:
        runner = self._runner
        window = self._window
        if runner is None or window is None:
            return

        window.update_runner_state(state)
        schedule_stop = state == RunnerState.STOPPED and self._stop_requested_by_schedule
        if schedule_stop:
            self._stop_requested_by_schedule = False
        if self._active_schedule_rule is not None and state in (
            RunnerState.STOPPED,
            RunnerState.COMPLETED,
        ):
            window.update_schedule_runtime(
                self._active_schedule_rule.rule_id,
                state == RunnerState.COMPLETED,
            )
            self._active_schedule_rule = None
        if state not in (RunnerState.STOPPED, RunnerState.COMPLETED):
            return
        if not self._scheduled_queue:
            if self._resume_after_schedule_macro is not None and state == RunnerState.COMPLETED:
                resume_macro = self._resume_after_schedule_macro
                resume_src = self._resume_after_schedule_src
                resume_index = self._resume_after_schedule_index
                self._resume_after_schedule_macro = None
                self._resume_after_schedule_src = None
                self._resume_after_schedule_index = None
                if resume_index is not None and resume_index > 0:
                    resume_actions = list(resume_macro.actions[resume_index:])
                    if resume_actions:
                        resume_macro = resume_macro.model_copy(deep=True)
                        resume_macro.actions = resume_actions
                        window.log_message(
                            "INFO",
                            f"스케줄 실행 완료: 이전 매크로 이어서 재개 (#{resume_index + 1}부터)",
                        )
                        self._start_runner(resume_macro, resume_src, origin="스케줄-재개")
                        return
                window.log_message("INFO", "스케줄 실행 완료: 이전 매크로 자동 재개")
                self._start_runner(resume_macro, resume_src, origin="스케줄-재개")
            return
        if state == RunnerState.STOPPED and not schedule_stop:
            return
        next_rule = self._scheduled_queue.popleft()
        window.log_message("INFO", f"스케줄 실행 시작: {next_rule.time_hhmm}")
        schedule_macro = self._build_schedule_subcall_macro(next_rule)
        self._start_runner(
            schedule_macro,
            None,
            origin="스케줄-큐",
            scheduled_rule=next_rule,
        )

    def _start_runner(
        self,
        macro: Macro,
        src: str | None,
        *,
        origin: str,
        scheduled_rule=None,
    ) -> None:
        runner = self._runner
        window = self._window
        ctx = self._ctx
        if runner is None or window is None:
            return

        if self._runner_thread is not None and self._runner_thread.is_alive():
            self._runner_thread.join(timeout=2.0)
            if self._runner_thread.is_alive():
                window.log_message(
                    "ERROR",
                    "이전 실행 스레드가 2초 내 종료되지 않았습니다. "
                    "진행 중인 이미지/OCR 대기가 있으면 먼저 정지(Ctrl+F7)해주세요.",
                )
                return
        if runner.state in (RunnerState.RUNNING, RunnerState.PAUSED):
            window.log_message("WARNING", f"이미 실행 중입니다. ({origin})")
            return
        if not ctx.dry_run and not ctx.serial_commander.is_connected():
            window.log_message("INFO", "Arduino 연결 중...")
            connect_result: dict[str, object] = {}

            def _connect() -> None:
                try:
                    ctx.serial_commander.connect()
                    connect_result["ok"] = True
                    connect_result["port"] = ctx.serial_commander.port_name or ""
                except SerialConnectionError as exc:
                    connect_result["ok"] = False
                    connect_result["error"] = str(exc)

            t = threading.Thread(target=_connect, daemon=True, name="RunConnect")
            t.start()
            t.join(timeout=5.0)

            if not connect_result.get("ok"):
                window.update_arduino_status(False)
                window.log_message(
                    "ERROR",
                    f"Arduino 연결 실패: {connect_result.get('error', '타임아웃')}",
                )
                return
            window.update_arduino_status(True, str(connect_result["port"]))
        runner.load_macro(macro, source_path=src)
        if origin.startswith("스케줄"):
            runner.set_breakpoints(set())
            self._active_schedule_rule = scheduled_rule
        else:
            runner.set_breakpoints(window.get_breakpoint_indices())
            self._active_schedule_rule = None
        runner.start_macro()
        self._runner_thread = threading.Thread(
            target=runner.run_blocking,
            daemon=False,
        )
        self._runner_thread.start()

    def _on_run_requested(self, macro: object) -> None:
        runner = self._runner
        window = self._window
        ctx = self._ctx
        if runner is None or window is None:
            return
        if not isinstance(macro, Macro):
            return
        src = str(window._current_file) if window._current_file else None
        rehearsal = bool(getattr(window, "_pending_rehearsal_run", False))
        window._pending_rehearsal_run = False
        saved_serial = None
        if rehearsal and not ctx.dry_run:
            saved_serial = runner._serial
            runner.set_serial_commander(None)
            window.log_message("INFO", "리허설: HID 경로 비활성(Stub). 종료 시 복원됩니다.")

            def _restore_serial_after_run() -> None:
                if saved_serial is not None:
                    runner.set_serial_commander(saved_serial)
                    window.log_message("INFO", "리허설 종료: Arduino HID 경로 복원")
                with contextlib.suppress(ValueError):
                    runner.on_finished.remove(_restore_serial_after_run)

            runner.on_finished[:] = [
                cb
                for cb in runner.on_finished
                if getattr(cb, "__name__", "") != "_restore_serial_after_run"
            ]
            runner.on_finished.append(_restore_serial_after_run)

        try:
            self._start_runner(macro, src, origin="수동")
        except SchedulerError as exc:
            window.log_message("ERROR", f"실행 시작 실패: {exc}")

    def _on_switch_to_player(self, on_switch_to_player_cb) -> None:
        runner = self._runner
        window = self._window
        ctx = self._ctx
        if runner is None or window is None:
            return

        if runner.state in (RunnerState.RUNNING, RunnerState.PAUSED):
            window.log_message("WARNING", "매크로 실행 중에는 모드를 전환할 수 없습니다.")
            return
        window._macro.actions = window._action_list.get_all_actions()
        if window._current_file is not None and window._macro.name == "새 매크로":
            window._macro.name = window._current_file.stem
        self._shared_state["macro"] = window._macro
        self._shared_state["macro_path"] = (
            str(window._current_file) if window._current_file else None
        )
        self._shared_state["is_modified"] = window._is_modified
        geo = window.geometry()
        ctx.app_config["window_x"] = geo.x()
        ctx.app_config["window_y"] = geo.y()
        ctx.app_config["window_width"] = geo.width()
        ctx.app_config["window_height"] = geo.height()

        from shared.config import save_config

        save_config(ctx.app_config)
        self._teardown()
        ctx.set_quit_on_last_window_closed(False)
        window._closing_for_mode_switch = True  # type: ignore[attr-defined]
        window.close()

        from PyQt6.QtCore import QTimer

        QTimer.singleShot(200, on_switch_to_player_cb)

    def _on_file_opened(self, file_path: str) -> None:
        from shared.config import add_recent_file, save_config

        add_recent_file(self._ctx.app_config, file_path)
        save_config(self._ctx.app_config)

    def _on_reconnect_requested(self) -> None:
        window = self._window
        ctx = self._ctx
        if window is None:
            return
        if ctx.serial_commander.is_connected():
            window.log_message("INFO", "이미 연결되어 있습니다.")
            window.update_arduino_status(True, ctx.serial_commander.port_name or "")
            return
        window.log_message("INFO", "Arduino 재연결 시도 중...")
        try:
            ctx.serial_commander.connect()
            window.update_arduino_status(True, ctx.serial_commander.port_name or "")
            window.log_message(
                "INFO",
                f"Arduino 재연결 성공: {ctx.serial_commander.port_name}",
            )
        except SerialConnectionError as exc:
            window.update_arduino_status(False)
            window.log_message("ERROR", f"Arduino 재연결 실패: {exc}")
