"""에디터 모드 세션 컨트롤러."""

from __future__ import annotations

import logging
import threading
from collections import deque
from collections.abc import Callable
from contextlib import suppress
from typing import TYPE_CHECKING, Any

from PyQt6.QtCore import Q_ARG, QMetaObject, QTimer, Qt

if TYPE_CHECKING:
    from editor.main_window import MacroEditorWindow

from editor.schedule_service import EditorScheduleService
from engine.runner import MacroRunner, RunnerState
from engine.serial_cmd import SerialConnectionError
from shared.models import Macro, ScheduleRule

from .log_handler import _GuiForwardHandler
from .runner_callbacks import RunnerCallbacksMixin
from .schedule_mixin import ScheduleMixin

logger = logging.getLogger(__name__)


class EditorSession(RunnerCallbacksMixin, ScheduleMixin):
    def __init__(self, ctx: Any) -> None:
        self._ctx = ctx
        self._window: MacroEditorWindow | None = None
        self._runner: MacroRunner | None = None
        self._runner_thread: threading.Thread | None = None
        self._gui_handler: logging.Handler | None = None
        self._schedule_service: EditorScheduleService | None = None
        self._scheduled_queue: deque[ScheduleRule] = deque()
        self._active_schedule_rule: ScheduleRule | None = None
        self._resume_after_schedule_macro: Macro | None = None
        self._resume_after_schedule_src: str | None = None
        self._resume_after_schedule_index: int | None = None
        self._stop_requested_by_schedule: bool = False
        self._shared_state: dict[str, object] | None = None

    @property
    def window(self) -> MacroEditorWindow | None:
        return self._window

    def launch(
        self,
        shared_state: dict[str, object],
        on_switch_to_player: Callable[[], None],
    ) -> None:
        from editor.main_window import MacroEditorWindow

        ctx = self._ctx
        self._shared_state = shared_state

        window = MacroEditorWindow()
        self._window = window
        window._app_ctx = ctx  # noqa: SLF001

        window.setGeometry(
            int(ctx.app_config.get("window_x", 100)),
            int(ctx.app_config.get("window_y", 100)),
            int(ctx.app_config.get("window_width", 1200)),
            int(ctx.app_config.get("window_height", 800)),
        )

        self._gui_handler = _GuiForwardHandler(window)
        self._gui_handler.setLevel(logging.DEBUG)
        logging.getLogger().addHandler(self._gui_handler)

        runner = MacroRunner(
            serial_commander=ctx.serial_commander if not ctx.dry_run else None,
            screen_analyzer=ctx.screen_analyzer,
            enable_visual_debug=True,
        )
        self._runner = runner
        ctx.gui_runner_holder["runner"] = runner

        runner.on_state_changed.append(self._on_runner_state_changed)
        runner.on_log.append(lambda level, msg: window.log_message(level, msg))
        runner.on_action_executed.append(window.update_execution_row)
        runner.on_variables_changed.append(window.update_variable_display)
        runner.on_visual_debug.append(lambda k, r, s, ok: window.update_visual_debug(k, r, s, ok))
        runner.on_connection_lost.append(lambda msg: window.update_arduino_status(False))
        runner.on_reconnected.append(
            lambda: window.update_arduino_status(True, ctx.serial_commander.port_name or "")
        )

        # pyqtSignal 연결 — 클래스 레벨 시그널이므로 _build_ui 전에도 안전
        self._signal_connections = [
            (window.macro_run_requested, self._on_run_requested),
            (window.macro_stop_requested, runner.stop_macro),
            (window.macro_pause_requested, runner.pause_macro),
            (window.macro_resume_requested, runner.resume_macro),
            (window.macro_step_requested, runner.request_step),
        ]
        for signal, slot in self._signal_connections:
            signal.connect(slot)
        window.breakpoints_changed.connect(lambda rows: runner.set_breakpoints(set(rows)))
        window.switch_to_player_requested.connect(
            lambda: self._on_switch_to_player(on_switch_to_player)
        )
        window.file_opened.connect(self._on_file_opened)
        window.reconnect_requested.connect(self._on_reconnect_requested)

        ctx.on_monitor_disconnected.clear()
        ctx.on_monitor_reconnected.clear()

        ctx.on_monitor_disconnected.append(
            lambda: QMetaObject.invokeMethod(
                window,
                "update_arduino_status",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(bool, False),
                Q_ARG(str, ""),
            )
        )
        ctx.on_monitor_disconnected.append(
            lambda: QMetaObject.invokeMethod(
                window,
                "log_message",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, "WARNING"),
                Q_ARG(str, "Arduino 연결 끊김 감지"),
            )
        )
        ctx.on_monitor_reconnected.append(
            lambda: QMetaObject.invokeMethod(
                window,
                "update_arduino_status",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(bool, True),
                Q_ARG(str, ctx.serial_commander.port_name or ""),
            )
        )
        ctx.on_monitor_reconnected.append(
            lambda: QMetaObject.invokeMethod(
                window,
                "log_message",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, "INFO"),
                Q_ARG(str, "Arduino 연결 복구 감지"),
            )
        )

        # 윈도우 프레임 즉시 표시 (UI 위젯은 _build_ui에서 비동기 빌드)
        window.show()
        ctx.set_quit_on_last_window_closed(True)

        # _build_ui (QTimer.singleShot(0)) 완료 후 UI 의존 초기화 실행
        def _post_ui_setup() -> None:
            window.set_license_expiry(str(ctx.app_config.get("license_expires_at", "")))

            if shared_state["macro"] is not None:
                macro = shared_state["macro"]
                if isinstance(macro, Macro) and macro.actions:
                    window._macro = macro
                    window._action_list.set_actions(list(macro.actions))
                    window._param_undo_snapshot_taken = False
                    window._update_title()

            if ctx.serial_commander.is_connected():
                window.update_arduino_status(True, ctx.serial_commander.port_name or "")
            else:
                window.update_arduino_status(False)

            def _supply_window_macro() -> Macro | None:
                if self._window is None:
                    return None
                self._window._macro.actions = self._window._action_list.get_all_actions()
                return self._window._macro

            self._schedule_service = EditorScheduleService(
                macro_supplier=_supply_window_macro,
                on_fire=self._on_schedule_fire,
                parent=window,
            )
            self._schedule_service.start()

            window.log_message(
                "INFO",
                "에디터 시작: 단축키(Ctrl+F5 실행, Ctrl+F6 일시정지, Ctrl+F7 정지)",
            )

            if ctx.screen_analyzer is None and not ctx.dry_run:

                def _startup_screen_analyzer() -> None:
                    try:
                        from engine.screen import ScreenAnalyzer

                        analyzer = ScreenAnalyzer()
                        ctx.screen_analyzer = analyzer
                        runner.set_screen_analyzer(analyzer)
                        window.log_message("INFO", "화면 분석기 초기화 완료")
                    except Exception as exc:
                        window.log_message("WARNING", f"화면 분석기 초기화 실패: {exc}")

                threading.Thread(
                    target=_startup_screen_analyzer,
                    daemon=True,
                    name="StartupScreenAnalyzer",
                ).start()

            if not ctx.dry_run and not ctx.serial_commander.is_connected():

                def _startup_serial_connect() -> None:
                    try:
                        ctx.serial_commander.connect()
                        pn = ctx.serial_commander.port_name or ""
                        if pn:
                            ctx.app_config["last_port"] = pn
                            from shared.config import save_config

                            save_config(ctx.app_config)
                        window.log_message(
                            "INFO",
                            f"Arduino 연결 성공: {pn}" if pn else "Arduino 연결 성공",
                        )
                        window.update_arduino_status(True, pn)
                    except SerialConnectionError as exc:
                        window.log_message(
                            "WARNING",
                            f"Arduino 자동 연결 실패 (실행 시 또는 재연결로 다시 시도): {exc}",
                        )
                        window.update_arduino_status(False)

                threading.Thread(
                    target=_startup_serial_connect,
                    daemon=True,
                    name="StartupSerial",
                ).start()

        # _build_ui는 QTimer.singleShot(0)으로 실행 → 그 다음 틱에 _post_ui_setup
        QTimer.singleShot(10, _post_ui_setup)

    def _teardown(self) -> None:
        for signal, slot in getattr(self, "_signal_connections", []):
            with suppress(RuntimeError, TypeError):
                signal.disconnect(slot)
        self._signal_connections = []

        if self._runner is not None:  # noqa: SIM102
            if self._runner.state != RunnerState.IDLE:
                self._runner.stop_macro()
        if self._schedule_service is not None:
            self._schedule_service.stop()
            self._schedule_service = None
        self._scheduled_queue.clear()
        self._active_schedule_rule = None
        self._resume_after_schedule_macro = None
        self._resume_after_schedule_src = None
        self._resume_after_schedule_index = None
        self._stop_requested_by_schedule = False
        if self._runner_thread is not None and self._runner_thread.is_alive():
            self._runner_thread.join(timeout=1.0)
        self._ctx.gui_runner_holder["runner"] = None
        if self._gui_handler is not None:
            logging.getLogger().removeHandler(self._gui_handler)
            self._gui_handler = None
        self._runner = None
