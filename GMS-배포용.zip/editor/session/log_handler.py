import logging


class _GuiForwardHandler(logging.Handler):
    def __init__(self, window) -> None:
        super().__init__()
        self._window = window

    def emit(self, record: logging.LogRecord) -> None:
        if record.name.startswith(("engine.screen", "engine.scheduler")):
            try:  # noqa: SIM105
                self._window.log_message(record.levelname, record.getMessage())
            except Exception:
                pass
