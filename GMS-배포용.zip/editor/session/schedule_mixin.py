from __future__ import annotations

from collections import deque  # noqa: F401

from engine.runner import RunnerState
from shared.models import Macro, MacroSettings, ScheduleRule, SubMacroCallAction


class ScheduleMixin:
    def _on_schedule_fire(self, rule: ScheduleRule) -> None:
        runner = self._runner
        window = self._window
        if runner is None or window is None:
            return

        if not rule.macro_path.strip():
            return
        if runner.state in (RunnerState.RUNNING, RunnerState.PAUSED):
            mode = rule.on_trigger_during_run
            should_restart = mode == "restart"
            should_resume = mode == "resume"
            if (
                (should_restart or should_resume)
                and self._resume_after_schedule_macro is None
                and runner.macro is not None
            ):
                self._resume_after_schedule_macro = runner.macro.model_copy(deep=True)
                self._resume_after_schedule_src = (
                    str(window._current_file) if window._current_file else None
                )
                self._resume_after_schedule_index = (
                    runner.program_counter if should_resume else None
                )
            self._scheduled_queue.appendleft(rule.model_copy(deep=True))
            if should_resume:
                window.log_message(
                    "WARNING",
                    (
                        f"스케줄 트리거 감지({rule.time_hhmm}) - 현재 실행 중단 후 스케줄 실행, "
                        "완료 시 중단 지점부터 이어서 재개"
                    ),
                )
            elif should_restart:
                window.log_message(
                    "WARNING",
                    (
                        f"스케줄 트리거 감지({rule.time_hhmm}) - 현재 실행 중단 후 스케줄 실행, "
                        "완료 시 이전 매크로 자동 재개"
                    ),
                )
            else:
                self._resume_after_schedule_macro = None
                self._resume_after_schedule_src = None
                self._resume_after_schedule_index = None
                window.log_message(
                    "WARNING",
                    f"스케줄 트리거 감지({rule.time_hhmm}) - 현재 실행 중단 후 스케줄만 실행",
                )
            self._stop_requested_by_schedule = True
            runner.stop_macro()
            return

        schedule_macro = self._build_schedule_subcall_macro(rule)
        window.log_message(
            "INFO",
            f"스케줄 트리거 감지({rule.time_hhmm}) - SubCall 스케줄 실행 시작",
        )
        self._start_runner(
            schedule_macro,
            None,
            origin="스케줄",
            scheduled_rule=rule,
        )

    def _build_schedule_subcall_macro(self, rule: ScheduleRule) -> Macro:
        """스케줄 규칙 1개를 SubCall 단일 매크로로 래핑한다."""
        return Macro(
            name=f"스케줄 실행 {rule.time_hhmm}",
            settings=MacroSettings(humanize=False, base_delay_ms=0, schedule_rules=[]),
            actions=[SubMacroCallAction(macro_path=rule.macro_path)],
        )
