"""에디터 전역: 액션 추가 버튼용 팔레트 (main_window / 분기 내부 리스트 공용)."""

from __future__ import annotations

from editor.action_list.constants import ACTION_COLORS
from shared.models import (
    Action,
    BreakAction,
    CommentAction,
    DelayAction,
    ElseAction,
    EndIfAction,
    FunctionCallAction,
    FunctionDefAction,
    FunctionEndAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    KeyComboAction,
    KeyDownAction,
    KeyPressAction,
    KeyUpAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    MouseClickAction,
    MouseDownAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
    MouseUpAction,
    OCRReadAction,
    OCRWaitAction,
    PixelWaitAction,
    ReturnAction,
    SubMacroCallAction,
    TypeTextAction,
    VariableSetAction,
)

ACTION_BUTTONS: dict[str, list[tuple[str, type[Action], str]]] = {
    "마우스 입력": [
        ("Delay", DelayAction, ACTION_COLORS["delay"]),
        ("Move", MouseMoveAction, ACTION_COLORS["mouse"]),
        ("Click", MouseClickAction, ACTION_COLORS["mouse"]),
        ("Down", MouseDownAction, ACTION_COLORS["mouse"]),
        ("Up", MouseUpAction, ACTION_COLORS["mouse"]),
        ("Drag", MouseDragAction, ACTION_COLORS["mouse"]),
        ("Scroll", MouseScrollAction, ACTION_COLORS["mouse"]),
    ],
    "키보드 입력": [
        ("Press", KeyPressAction, ACTION_COLORS["keyboard"]),
        ("Down", KeyDownAction, ACTION_COLORS["keyboard"]),
        ("Up", KeyUpAction, ACTION_COLORS["keyboard"]),
        ("Combo", KeyComboAction, ACTION_COLORS["keyboard"]),
        ("Text", TypeTextAction, ACTION_COLORS["keyboard"]),
    ],
    "화면 감지/조건": [
        ("IfPixel", IfPixelAction, ACTION_COLORS["screen"]),
        ("IfVar", IfVariableAction, ACTION_COLORS["flow"]),
        ("VarSet", VariableSetAction, ACTION_COLORS["variable"]),
        ("PixWait", PixelWaitAction, ACTION_COLORS["screen"]),
        ("ImgSearch", ImageSearchAction, ACTION_COLORS["screen"]),
        ("ImgWait", ImageWaitAction, ACTION_COLORS["screen"]),
        ("ImgClick", ImageClickAction, ACTION_COLORS["screen"]),
        ("OCR읽기", OCRReadAction, ACTION_COLORS["delay"]),
        ("OCR대기", OCRWaitAction, ACTION_COLORS["delay"]),
    ],
    "반복/분기": [
        ("Comment", CommentAction, ACTION_COLORS["variable"]),
        ("For(Loop+)", LoopStartAction, ACTION_COLORS["flow"]),
        ("EndFor(Loop-)", LoopEndAction, ACTION_COLORS["flow"]),
        ("Else", ElseAction, ACTION_COLORS["flow"]),
        ("EndIf", EndIfAction, ACTION_COLORS["flow"]),
        ("Break", BreakAction, ACTION_COLORS["flow"]),
    ],
    "점프/서브매크로": [
        ("Label", LabelAction, ACTION_COLORS["flow"]),
        ("Goto", GotoAction, ACTION_COLORS["flow"]),
        ("SubCall", SubMacroCallAction, ACTION_COLORS["variable"]),
    ],
    "함수": [
        ("함수 정의", FunctionDefAction, ACTION_COLORS["function"]),
        ("함수 끝", FunctionEndAction, ACTION_COLORS["function"]),
        ("함수 호출", FunctionCallAction, ACTION_COLORS["function"]),
        ("반환", ReturnAction, ACTION_COLORS["function"]),
    ],
}

# 액션 추가 버튼 툴팁 — 화면 라벨과 동일한 용어(For/EndFor 등)로 통일
ACTION_BUTTON_TOOLTIPS: dict[type[Action], str] = {
    MouseMoveAction: (
        "마우스 커서를 지정 좌표로 옮깁니다.\n"
        "절대/상대 이동, 이동 시간(ms), {변수} 식 좌표를 쓸 수 있습니다."
    ),
    MouseClickAction: "지정한 버튼으로 클릭합니다. 연속 클릭 횟수를 바꿀 수 있습니다.",
    MouseDownAction: "버튼을 누른 상태로 유지합니다. 드래그 시작 등에 씁니다.",
    MouseUpAction: "눌려 있던 버튼을 뗍니다. Mouse Down과 짝을 맞춥니다.",
    MouseDragAction: "한 좌표에서 다른 좌표로 끌어 이동합니다(드래그).",
    MouseScrollAction: "마우스 휠로 위·아래 스크롤합니다. 양과 방향을 지정합니다.",
    KeyPressAction: "키를 한 번(또는 여러 번) 누릅니다. 단일 키 입력에 씁니다.",
    KeyDownAction: "키를 누른 채로 둡니다. Key Up과 짝을 맞춥니다.",
    KeyUpAction: "눌린 키를 뗍니다.",
    KeyComboAction: "Ctrl, Shift, Alt 등 조합키와 함께 키를 누릅니다.",
    TypeTextAction: "문자열을 타이핑하듯 한 글자씩 입력합니다. 채팅·검색창에 적합합니다.",
    DelayAction: (
        "지정한 시간(ms)만큼 아무 동작 없이 기다립니다.\n"
        "랜덤 최소~최대 대기로 사람처럼 보이게 할 수 있습니다."
    ),
    CommentAction: "실행되지 않는 메모 줄입니다. 나중에 읽기 쉽게 구간 설명을 적습니다.",
    VariableSetAction: (
        "변수에 값을 넣습니다.\n"
        "「값」만 쓰거나, {변수} 치환·간단한 수식으로 계산한 결과를 저장할 수 있습니다."
    ),
    IfPixelAction: (
        "화면 한 점의 색이 조건과 맞는지 봅니다.\n"
        "추가 시 If·Else·EndIf 블록이 함께 만들어집니다. F8로 좌표·색을 캡처할 수 있습니다."
    ),
    IfVariableAction: (
        "저장된 변수 값을 숫자 또는 문자열로 비교해 갈림길을 만듭니다.\n"
        "If·Else·EndIf 블록이 함께 붙습니다."
    ),
    PixelWaitAction: (
        "지정 색이 나타나거나(또는 변할 때까지) 타임아웃까지 기다린 뒤 then/else로 갑니다.\n"
        "If·Else·EndIf 블록이 함께 붙습니다."
    ),
    ImageSearchAction: (
        "화면 영역에서 참조 이미지를 찾아 위치를 변수(예: img_x, img_y)에 넣습니다.\n"
        "If·Else·EndIf 블록이 함께 붙습니다."
    ),
    ImageWaitAction: (
        "참조 이미지가 보일 때까지 기다렸다가, 찾으면 then·못 찾으면 else로 갑니다.\n"
        "If·Else·EndIf 블록이 함께 붙습니다."
    ),
    ImageClickAction: (
        "이미지를 찾은 위치에서 클릭합니다. 오프셋·버튼을 바꿀 수 있습니다.\n"
        "If·Else·EndIf 블록이 함께 붙습니다."
    ),
    OCRReadAction: (
        "화면의 지정 영역에서 글자를 한 번 읽어 변수에 저장합니다.\n"
        "「OCR대기」와 달리 기다리지 않고 즉시 한 번만 실행합니다."
    ),
    OCRWaitAction: (
        "OCR로 글자 패턴(또는 정규식)이 보일 때까지 기다린 뒤 then/else로 갑니다.\n"
        "If·Else·EndIf 블록이 함께 붙습니다."
    ),
    SubMacroCallAction: (
        "다른 매크로 JSON 파일을 불러 그 안의 액션을 실행합니다.\n"
        "공통 루틴을 나눌 때 사용합니다(호출 깊이 제한 있음)."
    ),
    LoopStartAction: (
        "For(Loop+): 반복 블록의 시작입니다.\n"
        "횟수, 수식({변수}), 또는 숫자 범위로 for 루프를 엽니다. EndFor(Loop-)와 짝을 맞춥니다."
    ),
    LoopEndAction: (
        "EndFor(Loop-): For(Loop+)와 짝을 이루어 반복 블록을 닫습니다."
    ),
    ElseAction: "현재 조건 블록에서 «실패·거짓» 쪽으로 실행할 구간의 시작 표시입니다.",
    EndIfAction: "현재 If/조건형 블록을 끝냅니다.",
    BreakAction: (
        "가장 안쪽 For(Loop) 반복만 즉시 빠져나갑니다.\n"
        "루프 안에서만 의미가 있습니다."
    ),
    LabelAction: "이름 붙인 지점을 만듭니다. Goto가 여기로 점프할 수 있습니다.",
    GotoAction: "지정한 Label 이름으로 실행 위치를 옮깁니다(조건 없는 점프).",
    FunctionDefAction: (
        "함수 정의의 시작입니다.\n"
        "1) 함수 정의 → 2) 안쪽 액션 작성 → 3) 함수 끝으로 닫기\n"
        "예) 이름 heal_if_low, 매개변수 hp, limit"
    ),
    FunctionEndAction: (
        "함수 정의의 끝입니다. 함수 정의와 반드시 1:1로 짝을 맞추세요."
    ),
    FunctionCallAction: (
        "만든 함수를 실행합니다.\n"
        "인자와 반환 변수 이름을 지정합니다. 다음 IfVar 등에서 반환값을 씁니다."
    ),
    ReturnAction: (
        "함수에서 값을 돌려줍니다.\n"
        "예) 1, 0, {hp} — 호출한 쪽의 반환 변수에 저장됩니다."
    ),
}
