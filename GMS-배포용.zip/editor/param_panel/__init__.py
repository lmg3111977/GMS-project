"""액션 파라미터 편집 패널 패키지."""

from editor.param_panel.panel import ParamPanel

__all__ = ["ParamPanel"]
