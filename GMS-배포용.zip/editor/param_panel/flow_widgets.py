"""흐름 제어 관련 파라미터 위젯.

화면 감지(픽셀) 액션 편집기:
- IfPixel → ``IfPixelParamWidget`` (``shared.models.flow.IfPixelAction``)
- PixelWait → ``PixelWaitParamWidget`` (``PixelWaitAction``)
"""

from __future__ import annotations

from typing import Any

from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from editor.coord_preview import try_move_cursor_to
from editor.param_panel.base import (
    _BaseParamWidget,
    _parse_clipboard_xy_color,
    _show_clipboard_format_error,
    configure_param_form_layout,
    get_active_capture_text,
)
from editor.variable_suggestions import create_editable_var_combo, refill_var_combo_items
from editor.widgets.color_swatch import apply_color_swatch_label
from editor.widgets.help_text import (
    STYLE_SECTION_HINT,
    STYLE_SECTION_NOTE,
    style_form_hint_label,
)
from editor.widgets.region_flash_overlay import flash_screen_rect
from shared.models import (
    Action,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    LabelAction,
    LoopStartAction,
    PixelWaitAction,
    SubMacroCallAction,
    VariableSetAction,
)


class LoopStartParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        mode_hint = QLabel(
            "For(Loop+) 반복 설정: 아래 둘 중 하나만 쓰는 것을 권장합니다.\n"
            "1) 기본 반복(횟수 또는 {변수} 식)  2) 숫자 범위 반복(start~end)"
        )
        mode_hint.setWordWrap(True)
        mode_hint.setStyleSheet(STYLE_SECTION_HINT)
        layout.addRow(mode_hint)

        self.edit_label = QLineEdit()
        self.edit_label.setToolTip(
            "루프에 이름을 붙여 구분할 수 있습니다 (선택사항). 비워둬도 됩니다."
        )
        self.edit_label.setPlaceholderText("선택사항 (예: main_loop)")
        self.edit_label.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("루프 이름 (선택):", self.edit_label)

        basic_group = QGroupBox("기본 반복 (횟수 또는 식)")
        basic_layout = QFormLayout(basic_group)
        configure_param_form_layout(basic_layout)
        self.spin_count = QSpinBox()
        self.spin_count.setRange(-1, 100000)
        self.spin_count.setSpecialValueText("무한")
        self.spin_count.setToolTip(
            "이 루프를 몇 번 반복할지 설정합니다.\n"
            "• -1 (무한): 수동으로 정지할 때까지 영원히 반복\n"
            "• 1: 1번만 실행 (루프 의미 없음)\n"
            "• 10: 10번 반복 후 다음으로 넘어감\n"
            "아래 '반복 횟수 식'을 채우면 이 값은 무시됩니다."
        )
        self.spin_count.valueChanged.connect(self.param_changed.emit)
        self.edit_count_expr = QLineEdit()
        self.edit_count_expr.setPlaceholderText("비우면 위 숫자 사용 — 예: {times} 또는 {a} + 1")
        self.edit_count_expr.setToolTip(
            "VariableSet과 같은 규칙으로, 루프에 처음 들어갈 때 한 번만 평가합니다.\n"
            "• 비움: 위 스핀박스의 반복 횟수 사용\n"
            "• {변수명}: 해당 변수 값으로 치환 후 정수로 해석\n"
            "• 예: {stack_count}, {base} * 2 + 1\n"
            "• 평가 결과 -1이면 무한 반복"
        )
        self.edit_count_expr.textChanged.connect(lambda: self.param_changed.emit())
        basic_layout.addRow("반복 횟수 (-1=무한 반복):", self.spin_count)
        basic_layout.addRow("반복 횟수 식 (선택):", self.edit_count_expr)
        layout.addRow(basic_group)

        range_group = QGroupBox("숫자 범위 반복 (start~end, for 스타일)")
        range_layout = QFormLayout(range_group)
        configure_param_form_layout(range_layout)
        self.edit_range_start = QLineEdit()
        self.edit_range_start.setPlaceholderText("예: 0 또는 {start}")
        self.edit_range_start.setToolTip(
            "범위 반복 시작값 식입니다.\n"
            "아래 끝값 식과 함께 채우면 for(i=start; i<end; i++) 형태로 반복 횟수를 계산합니다."
        )
        self.edit_range_start.textChanged.connect(lambda: self.param_changed.emit())
        self.edit_range_end = QLineEdit()
        self.edit_range_end.setPlaceholderText("예: 3 또는 {end}")
        self.edit_range_end.setToolTip(
            "범위 반복 끝값 식입니다.\n"
            "기본은 끝값 미포함(<). 체크 시 끝값 포함(<=)으로 계산합니다."
        )
        self.edit_range_end.textChanged.connect(lambda: self.param_changed.emit())
        self.check_range_inclusive = QCheckBox("끝값 포함 (<=)")
        self.check_range_inclusive.setToolTip(
            "체크: for(i=start; i<=end; i++)\n" "해제: for(i=start; i<end; i++)"
        )
        self.check_range_inclusive.stateChanged.connect(self.param_changed.emit)
        range_layout.addRow("범위 시작 식:", self.edit_range_start)
        range_layout.addRow("범위 끝 식:", self.edit_range_end)
        range_layout.addRow("", self.check_range_inclusive)
        layout.addRow(range_group)

        note = QLabel(
            "팁: 시작·끝 식을 모두 채우면 범위 반복이 횟수 설정보다 우선합니다.\n"
            "범위를 쓰지 않으려면 두 칸을 비우고 위의 반복 횟수만 쓰세요."
        )
        note.setWordWrap(True)
        note.setStyleSheet(STYLE_SECTION_NOTE)
        layout.addRow(note)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, LoopStartAction):
            self.edit_label.setText(action.label)
            self.spin_count.setValue(action.count)
            self.edit_count_expr.setText(action.count_expression or "")
            self.edit_range_start.setText(action.range_start_expression or "")
            self.edit_range_end.setText(action.range_end_expression or "")
            self.check_range_inclusive.setChecked(action.range_end_inclusive)

    def to_action_dict(self) -> dict[str, Any]:
        expr = self.edit_count_expr.text().strip()
        range_start = self.edit_range_start.text().strip()
        range_end = self.edit_range_end.text().strip()
        return {
            "label": self.edit_label.text(),
            "count": self.spin_count.value(),
            "count_expression": expr if expr else None,
            "range_start_expression": range_start if range_start else None,
            "range_end_expression": range_end if range_end else None,
            "range_end_inclusive": self.check_range_inclusive.isChecked(),
        }


class LabelParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.edit_name = QLineEdit()
        self.edit_name.setPlaceholderText("영숫자+_ (예: check_hp, start, retry)")
        self.edit_name.setToolTip(
            "이 위치를 가리키는 고유한 이름표입니다.\n"
            "Goto, IfPixel, IfVariable 등에서 이 이름으로 점프할 수 있습니다.\n"
            "규칙: 영문, 숫자, 밑줄(_)만 사용. 매크로 안에서 중복 불가.\n"
            "예: check_hp, loop_start, found_target"
        )
        self.edit_name.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("라벨 이름 (점프 대상):", self.edit_name)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, LabelAction):
            self.edit_name.setText(action.name)

    def to_action_dict(self) -> dict[str, Any]:
        return {"name": self.edit_name.text()}


class GotoParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.edit_target = QLineEdit()
        self.edit_target.setPlaceholderText("이동할 Label 이름 (예: check_hp)")
        self.edit_target.setToolTip(
            "점프할 Label의 이름을 정확히 입력하세요.\n"
            "매크로 안에 같은 이름의 Label 액션이 있어야 합니다.\n"
            "예: 'check_hp' 라고 입력하면 Label: check_hp 위치로 점프"
        )
        self.edit_target.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("이동할 Label 이름:", self.edit_target)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, GotoAction):
            self.edit_target.setText(action.target)

    def to_action_dict(self) -> dict[str, Any]:
        return {"target": self.edit_target.text()}


class IfPixelParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.spin_x = QSpinBox()
        self.spin_x.setRange(0, 7680)
        self.spin_x.setToolTip("확인할 픽셀의 X 좌표 (화면 가로 위치). F8로 캡처 가능.")
        self.spin_y = QSpinBox()
        self.spin_y.setRange(0, 4320)
        self.spin_y.setToolTip("확인할 픽셀의 Y 좌표 (화면 세로 위치). F8로 캡처 가능.")
        self.edit_color = QLineEdit()
        self.edit_color.setPlaceholderText("#RRGGBB (예: #FF0000 = 빨강)")
        self.edit_color.setToolTip(
            "비교할 색상 코드 (#RRGGBB 형식)\n"
            "예: #FF0000=빨강, #00FF00=초록, #0000FF=파랑, #FFFFFF=흰색\n"
            "팁: F8을 눌러 원하는 위치의 색상을 자동 캡처하세요."
        )
        self.spin_tolerance = QSpinBox()
        self.spin_tolerance.setRange(0, 442)
        self.spin_tolerance.setToolTip(
            "색상 허용 오차 (0~442)\n"
            "• 0: 정확히 같은 색만 인정\n"
            "• 10~30: 약간의 색상 차이 허용 (권장)\n"
            "• 100+: 매우 관대하게 비교\n"
            "게임 화면은 미세하게 변할 수 있으므로 10~30 정도를 추천합니다."
        )
        for w in [self.spin_x, self.spin_y, self.spin_tolerance]:
            w.valueChanged.connect(self.param_changed.emit)
        for w in [self.edit_color]:
            w.textChanged.connect(lambda: self.param_changed.emit())
        self.check_detect_change = QCheckBox("기준 색상에서 달라졌을 때 성공")
        self.check_detect_change.setToolTip(
            "체크 해제: 지정 색상과 일치하면 성공\n체크: 지정 색상과 달라지면 성공"
        )
        self.check_detect_change.stateChanged.connect(self.param_changed.emit)
        layout.addRow("픽셀 X (가로 위치):", self.spin_x)
        layout.addRow("픽셀 Y (세로 위치):", self.spin_y)
        self.group_expr = QGroupBox("고급(변수식)")
        self.group_expr.setCheckable(True)
        self.group_expr.setChecked(False)
        self.group_expr.toggled.connect(self.param_changed.emit)
        expr_layout = QFormLayout(self.group_expr)
        configure_param_form_layout(expr_layout)
        expr_hint = QLabel("규칙: XY식 > X/Y식 > 숫자 좌표")
        style_form_hint_label(expr_hint)
        expr_layout.addRow(expr_hint)
        self.edit_xy_expr = QLineEdit()
        self.edit_xy_expr.setPlaceholderText("XY식 (예: {img_x},{img_y})")
        self.edit_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("XY 좌표식:", self.edit_xy_expr)
        self.edit_x_expr = QLineEdit()
        self.edit_x_expr.setPlaceholderText("X식 (예: {img_x})")
        self.edit_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("X 식:", self.edit_x_expr)
        self.edit_y_expr = QLineEdit()
        self.edit_y_expr.setPlaceholderText("Y식 (예: {img_y})")
        self.edit_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("Y 식:", self.edit_y_expr)
        layout.addRow(self.group_expr)
        color_row = QWidget()
        color_h = QHBoxLayout(color_row)
        color_h.setContentsMargins(0, 0, 0, 0)
        color_h.addWidget(self.edit_color, stretch=1)
        self._color_swatch_ifpixel = QLabel()
        self._color_swatch_ifpixel.setFixedSize(44, 26)
        color_h.addWidget(self._color_swatch_ifpixel)
        self.edit_color.textChanged.connect(self._on_ifpixel_color_changed)
        layout.addRow("비교 색상 (#RRGGBB):", color_row)
        layout.addRow("색상 허용 오차 (0=정확):", self.spin_tolerance)
        layout.addRow("", self.check_detect_change)

        pixel_nav = QWidget()
        pnh = QHBoxLayout(pixel_nav)
        pnh.setContentsMargins(0, 0, 0, 0)
        self._btn_ifpixel_cursor = QPushButton("커서 → 픽셀 위치")
        self._btn_ifpixel_flash = QPushButton("픽셀 위치 화면에 표시")
        tip_px = "고급(변수식)이 꺼져 있을 때만 숫자 좌표로 동작합니다."
        self._btn_ifpixel_cursor.setToolTip(f"감시 픽셀 (X,Y)로 커서를 이동합니다.\n{tip_px}")
        self._btn_ifpixel_flash.setToolTip(f"해당 좌표 주변을 화면에서 잠시 강조합니다.\n{tip_px}")
        self._btn_ifpixel_cursor.clicked.connect(self._on_ifpixel_move_cursor)
        self._btn_ifpixel_flash.clicked.connect(self._on_ifpixel_flash_region)
        pnh.addWidget(self._btn_ifpixel_cursor)
        pnh.addWidget(self._btn_ifpixel_flash)
        self.group_expr.toggled.connect(self._sync_ifpixel_screen_nav)
        self.spin_x.valueChanged.connect(self._sync_ifpixel_screen_nav)
        self.spin_y.valueChanged.connect(self._sync_ifpixel_screen_nav)
        layout.addRow("화면에서 확인:", pixel_nav)
        self._ifpixel_flash_ref: object | None = None
        self._on_ifpixel_color_changed()
        self._sync_ifpixel_screen_nav()

        btn_from_clip = QPushButton("F8 좌표/색상 자동 입력")
        btn_from_clip.setToolTip("F8로 캡처한 좌표와 색상을 X, Y, 색상 필드에 자동 입력합니다")
        btn_from_clip.clicked.connect(self._apply_from_clipboard)
        layout.addRow(btn_from_clip)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, IfPixelAction):
            self.spin_x.setValue(action.x)
            self.spin_y.setValue(action.y)
            self.group_expr.setChecked(
                bool(
                    (action.xy_expression or "").strip()
                    or (action.x_expression or "").strip()
                    or (action.y_expression or "").strip()
                )
            )
            self.edit_xy_expr.setText(action.xy_expression or "")
            self.edit_x_expr.setText(action.x_expression or "")
            self.edit_y_expr.setText(action.y_expression or "")
            self.edit_color.setText(action.color)
            self.spin_tolerance.setValue(action.tolerance)
            self.check_detect_change.setChecked(action.detect_change)
            self._on_ifpixel_color_changed()
            self._sync_ifpixel_screen_nav()

    def to_action_dict(self) -> dict[str, Any]:
        xy_expr = self.edit_xy_expr.text().strip() if self.group_expr.isChecked() else ""
        x_expr = self.edit_x_expr.text().strip() if self.group_expr.isChecked() else ""
        y_expr = self.edit_y_expr.text().strip() if self.group_expr.isChecked() else ""
        if xy_expr:
            x_expr = ""
            y_expr = ""
        return {
            "x": self.spin_x.value(),
            "y": self.spin_y.value(),
            "xy_expression": xy_expr or None,
            "x_expression": x_expr or None,
            "y_expression": y_expr or None,
            "color": self.edit_color.text(),
            "tolerance": self.spin_tolerance.value(),
            "detect_change": self.check_detect_change.isChecked(),
        }

    def _on_ifpixel_color_changed(self, _t: str = "") -> None:
        apply_color_swatch_label(self._color_swatch_ifpixel, self.edit_color.text())

    def _sync_ifpixel_screen_nav(self) -> None:
        ok = not self.group_expr.isChecked()
        self._btn_ifpixel_cursor.setEnabled(ok)
        self._btn_ifpixel_flash.setEnabled(ok)

    def _on_ifpixel_move_cursor(self) -> None:
        if self.group_expr.isChecked():
            return
        try_move_cursor_to(self, self.spin_x.value(), self.spin_y.value())

    def _on_ifpixel_flash_region(self) -> None:
        if self.group_expr.isChecked():
            return
        x, y = self.spin_x.value(), self.spin_y.value()
        self._ifpixel_flash_ref = flash_screen_rect(x - 4, y - 4, x + 4, y + 4)

    def _apply_from_clipboard(self) -> None:
        """클립보드("x,y,#RRGGBB")에서 좌표/색상을 읽어와 필드에 적용한다."""
        text = get_active_capture_text(self._capture_history)
        if text is None:
            text = QGuiApplication.clipboard().text().strip()
        if not text:
            QMessageBox.warning(
                self,
                "F8 캡처 없음",
                "캡처된 좌표가 없습니다.\nF8을 눌러 좌표를 먼저 캡처하세요.",
            )
            return
        parsed = _parse_clipboard_xy_color(text)
        if parsed is None:
            _show_clipboard_format_error(self)
            return
        x, y, color = parsed

        self.spin_x.setValue(x)
        self.spin_y.setValue(y)
        if color.startswith("#") and len(color) == 7:
            self.edit_color.setText(color)
        self.param_changed.emit()


class PixelWaitParamWidget(_BaseParamWidget):
    """PixelWait 전용 파라미터 위젯 (타임아웃 포함)."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        self.spin_x = QSpinBox()
        self.spin_x.setRange(0, 7680)
        self.spin_x.setToolTip("감시할 픽셀의 X 좌표 (화면 가로 위치)")
        self.spin_y = QSpinBox()
        self.spin_y.setRange(0, 4320)
        self.spin_y.setToolTip("감시할 픽셀의 Y 좌표 (화면 세로 위치)")
        self.edit_color = QLineEdit()
        self.edit_color.setPlaceholderText("#RRGGBB (예: #FF0000)")
        self.edit_color.setToolTip("이 색상이 나타날 때까지 대기합니다. F8로 캡처 가능.")
        self.spin_tolerance = QSpinBox()
        self.spin_tolerance.setRange(0, 442)
        self.spin_tolerance.setToolTip("색상 허용 오차. 10~30 권장. 0이면 정확한 일치만 인정.")
        self.spin_timeout = QSpinBox()
        self.spin_timeout.setRange(0, 3_600_000)
        self.spin_timeout.setSuffix(" ms")
        self.spin_timeout.setToolTip(
            "최대 대기 시간 (밀리초). 1000=1초, 5000=5초\n"
            "이 시간 안에 색상이 나타나지 않으면 타임아웃 동작을 수행합니다."
        )

        for w in [self.spin_x, self.spin_y, self.spin_tolerance, self.spin_timeout]:
            w.valueChanged.connect(self.param_changed.emit)
        for w in [self.edit_color]:
            w.textChanged.connect(lambda: self.param_changed.emit())
        self.check_detect_change = QCheckBox("기준 색상에서 달라질 때까지 대기")
        self.check_detect_change.setToolTip(
            "체크 해제: 지정 색상이 나타날 때까지 대기\n체크: 지정 색상에서 벗어날 때까지 대기"
        )
        self.check_detect_change.stateChanged.connect(self.param_changed.emit)
        self.check_detect_change.toggled.connect(self._sync_change_reference_enabled)
        self.combo_change_reference = QComboBox()
        self.combo_change_reference.addItem("입력한 색상 기준", "target")
        self.combo_change_reference.addItem("실행 시점 색상 기준", "runtime")
        self.combo_change_reference.setToolTip(
            "변화 감지 모드에서 기준 색상을 선택합니다.\n"
            "- 입력한 색상 기준: 색상 칸의 #RRGGBB를 기준으로 벗어남 감지\n"
            "- 실행 시점 색상 기준: 액션 시작 순간의 실제 픽셀색을 기준으로 벗어남 감지"
        )
        self.combo_change_reference.currentIndexChanged.connect(self.param_changed.emit)

        layout.addRow("감시 픽셀 X (가로 위치):", self.spin_x)
        layout.addRow("감시 픽셀 Y (세로 위치):", self.spin_y)
        self.group_expr = QGroupBox("고급(변수식)")
        self.group_expr.setCheckable(True)
        self.group_expr.setChecked(False)
        self.group_expr.toggled.connect(self.param_changed.emit)
        expr_layout = QFormLayout(self.group_expr)
        configure_param_form_layout(expr_layout)
        expr_hint_pw = QLabel("규칙: XY식 > X/Y식 > 숫자 좌표")
        style_form_hint_label(expr_hint_pw)
        expr_layout.addRow(expr_hint_pw)
        self.edit_xy_expr = QLineEdit()
        self.edit_xy_expr.setPlaceholderText("XY식 (예: {img_x},{img_y})")
        self.edit_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("XY 좌표식:", self.edit_xy_expr)
        self.edit_x_expr = QLineEdit()
        self.edit_x_expr.setPlaceholderText("X식 (예: {img_x})")
        self.edit_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("X 식:", self.edit_x_expr)
        self.edit_y_expr = QLineEdit()
        self.edit_y_expr.setPlaceholderText("Y식 (예: {img_y})")
        self.edit_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("Y 식:", self.edit_y_expr)
        layout.addRow(self.group_expr)
        color_row_pw = QWidget()
        color_h_pw = QHBoxLayout(color_row_pw)
        color_h_pw.setContentsMargins(0, 0, 0, 0)
        color_h_pw.addWidget(self.edit_color, stretch=1)
        self._color_swatch_pixelwait = QLabel()
        self._color_swatch_pixelwait.setFixedSize(44, 26)
        color_h_pw.addWidget(self._color_swatch_pixelwait)
        self.edit_color.textChanged.connect(self._on_pixelwait_color_changed)
        layout.addRow("대기할 색상 (#RRGGBB):", color_row_pw)
        layout.addRow("색상 허용 오차 (0=정확):", self.spin_tolerance)
        layout.addRow("", self.check_detect_change)
        layout.addRow("변화 감지 기준:", self.combo_change_reference)
        layout.addRow("최대 대기 시간 (1000=1초):", self.spin_timeout)

        pixel_nav_pw = QWidget()
        pnh_pw = QHBoxLayout(pixel_nav_pw)
        pnh_pw.setContentsMargins(0, 0, 0, 0)
        self._btn_pixelwait_cursor = QPushButton("커서 → 픽셀 위치")
        self._btn_pixelwait_flash = QPushButton("픽셀 위치 화면에 표시")
        tip_pw = "고급(변수식)이 꺼져 있을 때만 숫자 좌표로 동작합니다."
        self._btn_pixelwait_cursor.setToolTip(f"감시 픽셀 (X,Y)로 커서를 이동합니다.\n{tip_pw}")
        self._btn_pixelwait_flash.setToolTip(
            f"해당 좌표 주변을 화면에서 잠시 강조합니다.\n{tip_pw}"
        )
        self._btn_pixelwait_cursor.clicked.connect(self._on_pixelwait_move_cursor)
        self._btn_pixelwait_flash.clicked.connect(self._on_pixelwait_flash_region)
        pnh_pw.addWidget(self._btn_pixelwait_cursor)
        pnh_pw.addWidget(self._btn_pixelwait_flash)
        self.group_expr.toggled.connect(self._sync_pixelwait_screen_nav)
        self.spin_x.valueChanged.connect(self._sync_pixelwait_screen_nav)
        self.spin_y.valueChanged.connect(self._sync_pixelwait_screen_nav)
        layout.addRow("화면에서 확인:", pixel_nav_pw)
        self._pixelwait_flash_ref: object | None = None
        self._on_pixelwait_color_changed()
        self._sync_pixelwait_screen_nav()

        btn_from_clip = QPushButton("F8 좌표/색상 자동 입력")
        btn_from_clip.setToolTip("F8로 캡처한 좌표와 색상을 자동 입력합니다")
        btn_from_clip.clicked.connect(self._apply_from_clipboard)
        layout.addRow(btn_from_clip)
        self._sync_change_reference_enabled()

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, PixelWaitAction):
            self.spin_x.setValue(action.x)
            self.spin_y.setValue(action.y)
            self.group_expr.setChecked(
                bool(
                    (action.xy_expression or "").strip()
                    or (action.x_expression or "").strip()
                    or (action.y_expression or "").strip()
                )
            )
            self.edit_xy_expr.setText(action.xy_expression or "")
            self.edit_x_expr.setText(action.x_expression or "")
            self.edit_y_expr.setText(action.y_expression or "")
            self.edit_color.setText(action.color)
            self.spin_tolerance.setValue(action.tolerance)
            self.check_detect_change.setChecked(action.detect_change)
            idx = self.combo_change_reference.findData(action.change_reference)
            if idx < 0:
                idx = 0
            self.combo_change_reference.setCurrentIndex(idx)
            self._sync_change_reference_enabled()
            self.spin_timeout.setValue(action.timeout_ms)
            self._on_pixelwait_color_changed()
            self._sync_pixelwait_screen_nav()

    def to_action_dict(self) -> dict[str, Any]:
        xy_expr = self.edit_xy_expr.text().strip() if self.group_expr.isChecked() else ""
        x_expr = self.edit_x_expr.text().strip() if self.group_expr.isChecked() else ""
        y_expr = self.edit_y_expr.text().strip() if self.group_expr.isChecked() else ""
        if xy_expr:
            x_expr = ""
            y_expr = ""
        return {
            "x": self.spin_x.value(),
            "y": self.spin_y.value(),
            "xy_expression": xy_expr or None,
            "x_expression": x_expr or None,
            "y_expression": y_expr or None,
            "color": self.edit_color.text(),
            "tolerance": self.spin_tolerance.value(),
            "detect_change": self.check_detect_change.isChecked(),
            "change_reference": str(self.combo_change_reference.currentData()),
            "timeout_ms": self.spin_timeout.value(),
        }

    def _on_pixelwait_color_changed(self, _t: str = "") -> None:
        apply_color_swatch_label(self._color_swatch_pixelwait, self.edit_color.text())

    def _sync_pixelwait_screen_nav(self) -> None:
        ok = not self.group_expr.isChecked()
        self._btn_pixelwait_cursor.setEnabled(ok)
        self._btn_pixelwait_flash.setEnabled(ok)

    def _on_pixelwait_move_cursor(self) -> None:
        if self.group_expr.isChecked():
            return
        try_move_cursor_to(self, self.spin_x.value(), self.spin_y.value())

    def _on_pixelwait_flash_region(self) -> None:
        if self.group_expr.isChecked():
            return
        x, y = self.spin_x.value(), self.spin_y.value()
        self._pixelwait_flash_ref = flash_screen_rect(x - 4, y - 4, x + 4, y + 4)

    def _sync_change_reference_enabled(self) -> None:
        self.combo_change_reference.setEnabled(self.check_detect_change.isChecked())

    def _apply_from_clipboard(self) -> None:
        text = get_active_capture_text(self._capture_history)
        if text is None:
            text = QGuiApplication.clipboard().text().strip()
        if not text:
            QMessageBox.warning(
                self,
                "F8 캡처 없음",
                "캡처된 좌표가 없습니다.\nF8을 눌러 좌표를 먼저 캡처하세요.",
            )
            return
        parsed = _parse_clipboard_xy_color(text)
        if parsed is None:
            _show_clipboard_format_error(self)
            return
        x, y, color = parsed
        self.spin_x.setValue(x)
        self.spin_y.setValue(y)
        if color.startswith("#") and len(color) == 7:
            self.edit_color.setText(color)
        self.param_changed.emit()


class VariableSetParamWidget(_BaseParamWidget):
    """VariableSet 파라미터 위젯."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        self.combo_name = create_editable_var_combo()
        self.combo_name.setPlaceholderText("영숫자+_ (예: counter, hp_flag)")
        self.combo_name.setToolTip(
            "이름 붙은 저장소 하나를 가리킵니다. 영문·숫자·밑줄(_)만, 최대 30자.\n"
            "같은 이름으로 VarSet을 다시 실행하면 값이 덮어써집니다.\n"
            "드롭다운: 이 매크로에 이미 나온 변수명 제안. 목록에 없어도 직접 입력 가능."
        )
        self.combo_name.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("변수 이름:", self.combo_name)
        self._var_combos_varset = (self.combo_name,)

        self.edit_value = QLineEdit()
        self.edit_value.setPlaceholderText("직접 설정할 값 (예: 0, hello)")
        self.edit_value.setToolTip(
            "수식 칸이 비어 있을 때만 사용됩니다. 이 문자열이 변수에 그대로 저장됩니다.\n"
            "수식 칸에 뭔가 적혀 있으면 이 칸은 무시됩니다."
        )
        self.edit_value.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("값:", self.edit_value)

        self.edit_expr = QLineEdit()
        self.edit_expr.setPlaceholderText("수식 (예: {counter} + 1, {img_x} * 2)")
        self.edit_expr.setToolTip(
            "비우면 → 「값」 필드만 저장.\n"
            "적으면 → {변수명} 치환 후 숫자 수식만 계산(+ - * / % // ** 괄호). 결과가 변수에 저장됩니다.\n"
            "예: {cnt} + 1. 아직 없는 변수는 치환 시 0으로 들어가 계산될 수 있습니다.\n"
            "문자열을 이어 붙이는 식은 지원하지 않습니다(숫자 계산 위주)."
        )
        self.edit_expr.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("수식:", self.edit_expr)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, VariableSetAction):
            self.combo_name.setCurrentText(action.var_name)
            self.edit_value.setText(action.value)
            self.edit_expr.setText(action.expression or "")

    def to_action_dict(self) -> dict[str, Any]:
        expr = self.edit_expr.text().strip()
        return {
            "var_name": self.combo_name.currentText().strip(),
            "value": self.edit_value.text(),
            "expression": expr or None,
        }

    def apply_variable_suggestions(self, names: list[str]) -> None:
        for c in self._var_combos_varset:
            refill_var_combo_items(c, names)


class SubMacroCallParamWidget(_BaseParamWidget):
    """SubMacroCall 파라미터 위젯."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        path_row = QHBoxLayout()
        self.edit_path = QLineEdit()
        self.edit_path.setPlaceholderText("호출할 매크로 JSON 파일 경로")
        self.edit_path.setToolTip(
            "다른 매크로 파일(.json)을 서브루틴처럼 실행합니다.\n"
            "해당 매크로의 모든 액션을 실행한 후 돌아와서 다음 액션을 계속합니다.\n"
            "공통 동작(로그인, 초기화 등)을 별도 파일로 분리해 재사용할 때 유용합니다."
        )
        self.edit_path.textChanged.connect(lambda: self.param_changed.emit())
        btn_browse = QPushButton("찾기...")
        btn_browse.setFixedWidth(70)
        btn_browse.clicked.connect(self._on_browse)
        path_row.addWidget(self.edit_path, stretch=1)
        path_row.addWidget(btn_browse)
        layout.addRow("호출할 매크로 파일:", path_row)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, SubMacroCallAction):
            self.edit_path.setText(action.macro_path)

    def to_action_dict(self) -> dict[str, Any]:
        return {"macro_path": self.edit_path.text()}

    def _on_browse(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "매크로 파일 선택",
            "macros/",
            "매크로 (*.json);;전체 (*)",
        )
        if file_path:
            self.edit_path.setText(file_path)
            self.param_changed.emit()


class IfVariableParamWidget(_BaseParamWidget):
    """IfVariable 파라미터 위젯."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        self.combo_var = create_editable_var_combo()
        self.combo_var.setPlaceholderText("비교할 변수 이름 (예: counter, found)")
        self.combo_var.setToolTip(
            "VarSet·ImageSearch·OCR 등이 넣어 둔 값을 읽습니다. 이름이 틀리면 빈 문자열로 읽힙니다.\n"
            "드롭다운은 매크로에 등장한 이름 제안일 뿐입니다."
        )
        self.combo_var.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("변수 이름:", self.combo_var)
        self._var_combos_ifvar = (self.combo_var,)

        self.combo_op = QComboBox()
        self.combo_op.addItems(["==", "!=", ">", "<", ">=", "<="])
        self.combo_op.setToolTip(
            "변수 값과 「비교 값」을 둘 다 숫자로 읽을 수 있으면 숫자 비교.\n"
            "아니면 == / != 만 문자열 전체 일치·불일치. > < 등은 숫자일 때만 의미가 안정적입니다."
        )
        self.combo_op.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("연산자:", self.combo_op)

        self.edit_compare = QLineEdit()
        self.edit_compare.setPlaceholderText("비교 대상 값/식 (예: 1, {target_hp}, {x}+5)")
        self.edit_compare.setToolTip(
            "IfVar가 읽은 변수 문자열과 이 칸을 비교합니다.\n"
            "이 칸에서도 {변수명} 참조와 숫자식(+ - * / % // ** 괄호)을 사용할 수 있습니다.\n"
            '예: 발견 여부 변수가 "1"이면 비교 값도 1 (숫자 비교), 문자 플래그면 정확히 같은 글자.'
        )
        self.edit_compare.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("비교 값:", self.edit_compare)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, IfVariableAction):
            self.combo_var.setCurrentText(action.var_name)
            self.combo_op.setCurrentText(action.operator)
            self.edit_compare.setText(action.compare_value)

    def to_action_dict(self) -> dict[str, Any]:
        return {
            "var_name": self.combo_var.currentText().strip(),
            "operator": self.combo_op.currentText(),
            "compare_value": self.edit_compare.text(),
        }

    def apply_variable_suggestions(self, names: list[str]) -> None:
        for c in self._var_combos_ifvar:
            refill_var_combo_items(c, names)


class EmptyParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        _empty_hint = QLabel(
            "이 액션 종류는 추가 필드가 없습니다.\n"
            "위쪽 「메모(주석)」만 적을 수 있으며, Else·EndIf·Comment 등은 실행 순서만 맞추면 됩니다."
        )
        _empty_hint.setWordWrap(True)
        style_form_hint_label(_empty_hint)
        layout.addWidget(_empty_hint)

    def set_from_action(self, action: Action) -> None:
        pass

    def to_action_dict(self) -> dict[str, Any]:
        return {}
