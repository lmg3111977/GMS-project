"""함수 액션 파라미터 위젯."""

from __future__ import annotations

from typing import Any

from PyQt6.QtWidgets import QFormLayout, QLineEdit, QWidget

from editor.param_panel.base import _BaseParamWidget, configure_param_form_layout
from shared.models import Action, FunctionCallAction, FunctionDefAction, ReturnAction


def _split_csv(raw: str) -> list[str]:
    return [part.strip() for part in raw.split(",") if part.strip()]


class FunctionDefParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.edit_name = QLineEdit()
        self.edit_name.setPlaceholderText("함수 이름 (예: hp_check)")
        self.edit_name.setToolTip(
            "함수 이름을 입력합니다.\n"
            "권장: 영문/숫자/_ 조합 (예: heal_if_low)\n"
            "이 이름을 나중에 함수 호출의 「함수 이름」칸에 그대로 적습니다."
        )
        self.edit_name.textChanged.connect(lambda: self.param_changed.emit())
        self.edit_params = QLineEdit()
        self.edit_params.setPlaceholderText("매개변수 (쉼표 구분, 예: hp, threshold)")
        self.edit_params.setToolTip(
            "함수에 전달받을 입력 이름 목록입니다(쉼표 구분).\n"
            "예: hp, limit\n"
            "함수 내부에서는 {hp}, {limit}처럼 참조합니다."
        )
        self.edit_params.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("함수 이름:", self.edit_name)
        layout.addRow("매개변수:", self.edit_params)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, FunctionDefAction):
            self.edit_name.setText(action.name)
            self.edit_params.setText(", ".join(action.params))

    def to_action_dict(self) -> dict[str, Any]:
        return {
            "name": self.edit_name.text().strip(),
            "params": _split_csv(self.edit_params.text()),
        }


class FunctionCallParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.edit_target = QLineEdit()
        self.edit_target.setPlaceholderText("호출 함수 이름 (예: hp_check)")
        self.edit_target.setToolTip(
            "실행할 함수 이름입니다.\n"
            "함수 정의에 적은 이름과 정확히 같아야 합니다.\n"
            "예: heal_if_low"
        )
        self.edit_target.textChanged.connect(lambda: self.param_changed.emit())
        self.edit_args = QLineEdit()
        self.edit_args.setPlaceholderText("인자 (쉼표 구분, 예: {hp}, 10)")
        self.edit_args.setToolTip(
            "정의한 매개변수 순서대로 넘길 값을 적습니다(쉼표 구분).\n"
            "예: {hp}, 30\n"
            "첫 번째 값이 첫 번째 매개변수로 들어갑니다."
        )
        self.edit_args.textChanged.connect(lambda: self.param_changed.emit())
        self.edit_return_var = QLineEdit()
        self.edit_return_var.setPlaceholderText("반환 변수 이름 (선택)")
        self.edit_return_var.setToolTip(
            "함수가 반환한 값을 넣을 변수 이름입니다.\n"
            "예: result\n"
            "다음 액션에서 IfVar result == 1 처럼 바로 사용할 수 있습니다."
        )
        self.edit_return_var.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("함수 이름:", self.edit_target)
        layout.addRow("인자:", self.edit_args)
        layout.addRow("반환 변수:", self.edit_return_var)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, FunctionCallAction):
            self.edit_target.setText(action.target)
            self.edit_args.setText(", ".join(action.args))
            self.edit_return_var.setText(action.return_var)

    def to_action_dict(self) -> dict[str, Any]:
        return {
            "target": self.edit_target.text().strip(),
            "args": _split_csv(self.edit_args.text()),
            "return_var": self.edit_return_var.text().strip(),
        }


class ReturnParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.edit_expression = QLineEdit()
        self.edit_expression.setPlaceholderText("반환 수식 (예: {hp} + 10)")
        self.edit_expression.setToolTip(
            "함수 결과로 돌려줄 값/수식을 입력합니다.\n"
            "예: 1, 0, {hp}, {count} + 1\n"
            "이 값은 호출한 함수 호출의 「반환 변수」에 저장됩니다."
        )
        self.edit_expression.textChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("반환 수식:", self.edit_expression)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, ReturnAction):
            self.edit_expression.setText(action.expression)

    def to_action_dict(self) -> dict[str, Any]:
        return {"expression": self.edit_expression.text()}
