"""OCR 관련 파라미터 위젯.

화면 감지(OCR) 액션:
- OCRRead → ``OCRReadParamWidget`` (``shared.models.ocr.OCRReadAction``)
- OCRWait → ``OCRWaitParamWidget`` (``OCRWaitAction``)
"""

from __future__ import annotations

from typing import Any

from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QGroupBox,
    QLineEdit,
    QSpinBox,
    QWidget,
)

from editor.param_panel.base import (
    REGION_HINT_OCR_READ,
    REGION_HINT_OCR_WAIT,
    _BaseParamWidget,
    configure_param_form_layout,
    region_hint_label,
)
from editor.param_panel.image_widgets import _ImageRegionDragMixin
from editor.param_panel.region_nav_mixin import RegionNumericNavMixin
from editor.variable_suggestions import create_editable_var_combo, refill_var_combo_items
from editor.widgets.region_drag_picker import RegionDragPickerButton
from shared.models import Action, OCRReadAction, OCRWaitAction

# OCR 언어 UI: 영어 / 한국어 / 한국어+영어 / 숫자(0~9) 콤보만 사용 (Tesseract lang + 숫자 모드 시 whitelist)
_OCR_LANG_DIGITS_WHITELIST = "0123456789"
_OCR_LANG_COMBO_LABELS = (
    "영어",
    "한국어",
    "한국어 + 영어",
    "숫자 (0~9만)",
)


def _ocr_lang_combo_index(lang: str, whitelist: str) -> int:
    norm = (lang or "").strip().lower().replace(" ", "")
    wl = (whitelist or "").strip()
    if norm in ("eng", "en") and wl == _OCR_LANG_DIGITS_WHITELIST:
        return 3
    if norm in ("kor", "ko"):
        return 1
    if norm in ("eng+kor", "kor+eng", "eng_kor", "kor_eng"):
        return 2
    return 0


def _ocr_lang_combo_tooltip() -> str:
    return (
        "인식에 쓸 문자 종류를 고릅니다.\n\n"
        "• 영어: 영문·라틴 계열 UI\n"
        "• 한국어: 한글 위주\n"
        "• 한국어 + 영어: 한글과 영문이 섞인 UI (Tesseract: eng+kor)\n"
        "• 숫자: 0~9만 인식합니다. 이때 허용 문자는 자동으로 0123456789로 맞춰지며, "
        "해당 칸은 잠시 편집할 수 없습니다.\n\n"
        "그 외 기호·공백까지 제한하려면 「영어」 등을 고른 뒤 아래 「허용할 문자만」에 직접 적으면 됩니다."
    )


def _ocr_lang_apply_combo_change(
    idx: int,
    prev_idx_holder: list[int],
    whitelist_edit: QLineEdit,
) -> None:
    prev = prev_idx_holder[0]
    prev_idx_holder[0] = idx
    whitelist_edit.blockSignals(True)
    try:
        if idx == 3:
            whitelist_edit.setText(_OCR_LANG_DIGITS_WHITELIST)
            whitelist_edit.setReadOnly(True)
        else:
            whitelist_edit.setReadOnly(False)
            if prev == 3 and idx != 3:
                whitelist_edit.clear()
    finally:
        whitelist_edit.blockSignals(False)


def _ocr_lang_load_into_ui(
    combo: QComboBox,
    whitelist_edit: QLineEdit,
    prev_idx_holder: list[int],
    lang: str,
    whitelist: str,
) -> None:
    idx = _ocr_lang_combo_index(lang, whitelist)
    prev_idx_holder[0] = idx
    combo.blockSignals(True)
    try:
        combo.setCurrentIndex(idx)
    finally:
        combo.blockSignals(False)
    whitelist_edit.blockSignals(True)
    try:
        whitelist_edit.setText(whitelist)
        whitelist_edit.setReadOnly(idx == 3)
    finally:
        whitelist_edit.blockSignals(False)


def _ocr_lang_read_for_action(combo: QComboBox, whitelist_edit: QLineEdit) -> tuple[str, str]:
    idx = combo.currentIndex()
    if idx == 3:
        return "eng", _OCR_LANG_DIGITS_WHITELIST
    lang_map = ("eng", "kor", "eng+kor")
    lang = lang_map[idx] if 0 <= idx < 3 else "eng"
    return lang, whitelist_edit.text().strip()


def _ocr_binarize_threshold_tooltip() -> str:
    return (
        "캡처한 영역을 먼저 흑백(회색조)으로 만든 뒤, "
        "「밝은 쪽 / 어두운 쪽」 둘 중 하나로만 나눕니다. "
        "이 과정을 이진화라고 하며, 글자 윤곽이 또렷해지면 OCR이 읽기 쉬워집니다.\n\n"
        "★ 0 (기본, 추천)\n"
        "  프로그램이 그림에 맞춰 기준을 스스로 잡습니다(Otsu). "
        "특별한 문제가 없으면 0으로 두세요.\n\n"
        "1 ~ 255 (직접 지정)\n"
        "  숫자가 클수록 「아주 밝은 부분만 하얗게」 남기고, "
        "그보다 어두운 픽셀은 검정에 가깝게 묶습니다.\n"
        "  • 글자가 하얀 배경에 녹아서 안 보일 때(너무 많이 흰색) → 숫자를 높여 보세요.\n"
        "  • 배경까지 검정 덩어리처럼 뭉칠 때 → 숫자를 낮춰 보세요.\n\n"
        "반전(밝은 글자·어두운 배경)을 켠 뒤에는 여기 값도 함께 조절하는 경우가 많습니다."
    )


class OCRReadParamWidget(RegionNumericNavMixin, _ImageRegionDragMixin, _BaseParamWidget):
    """OCRRead 파라미터 위젯."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        region_group = QGroupBox("OCR 영역 — 시작점(X1,Y1) ~ 끝점(X2,Y2)")
        region_layout = QFormLayout(region_group)
        configure_param_form_layout(region_layout)
        region_layout.addRow(region_hint_label(REGION_HINT_OCR_READ))

        self._btn_region_drag = RegionDragPickerButton()
        self._btn_region_drag.region_picked.connect(self._on_region_drag_picked)
        region_layout.addRow("", self._btn_region_drag)

        self.spin_x1 = QSpinBox()
        self.spin_x1.setRange(0, 7680)
        self.spin_x1.setToolTip("OCR 영역 왼쪽 위 X 좌표")
        self.spin_y1 = QSpinBox()
        self.spin_y1.setRange(0, 4320)
        self.spin_y1.setToolTip("OCR 영역 왼쪽 위 Y 좌표")
        self.spin_x2 = QSpinBox()
        self.spin_x2.setRange(1, 7680)
        self.spin_x2.setValue(200)
        self.spin_x2.setToolTip("OCR 영역 오른쪽 아래 X 좌표")
        self.spin_y2 = QSpinBox()
        self.spin_y2.setRange(1, 4320)
        self.spin_y2.setValue(50)
        self.spin_y2.setToolTip("OCR 영역 오른쪽 아래 Y 좌표")
        for s in [self.spin_x1, self.spin_y1, self.spin_x2, self.spin_y2]:
            s.valueChanged.connect(self.param_changed.emit)
        region_layout.addRow("시작 X1:", self.spin_x1)
        region_layout.addRow("시작 Y1:", self.spin_y1)
        region_layout.addRow("끝 X2:", self.spin_x2)
        region_layout.addRow("끝 Y2:", self.spin_y2)
        self.group_region_expr = QGroupBox("고급(변수식) - OCR 영역 시작 좌표")
        self.group_region_expr.setCheckable(True)
        self.group_region_expr.setChecked(False)
        self.group_region_expr.toggled.connect(self.param_changed.emit)
        region_expr_layout = QFormLayout(self.group_region_expr)
        configure_param_form_layout(region_expr_layout)
        self.edit_region_xy_expr = QLineEdit()
        self.edit_region_xy_expr.setPlaceholderText("영역 XY식 (예: {rx},{ry})")
        self.edit_region_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 XY식:", self.edit_region_xy_expr)
        self.edit_region_x_expr = QLineEdit()
        self.edit_region_x_expr.setPlaceholderText("영역 X식")
        self.edit_region_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 X식:", self.edit_region_x_expr)
        self.edit_region_y_expr = QLineEdit()
        self.edit_region_y_expr.setPlaceholderText("영역 Y식")
        self.edit_region_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 Y식:", self.edit_region_y_expr)
        self.edit_region_end_xy_expr = QLineEdit()
        self.edit_region_end_xy_expr.setPlaceholderText("영역 끝 XY식 (예: {rx2},{ry2})")
        self.edit_region_end_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 XY식:", self.edit_region_end_xy_expr)
        self.edit_region_end_x_expr = QLineEdit()
        self.edit_region_end_x_expr.setPlaceholderText("영역 끝 X식")
        self.edit_region_end_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 X식:", self.edit_region_end_x_expr)
        self.edit_region_end_y_expr = QLineEdit()
        self.edit_region_end_y_expr.setPlaceholderText("영역 끝 Y식")
        self.edit_region_end_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 Y식:", self.edit_region_end_y_expr)
        region_layout.addRow(self.group_region_expr)
        self._append_region_numeric_nav_row(region_layout)
        layout.addRow(region_group)

        ocr_group = QGroupBox("OCR 설정")
        ocr_layout = QFormLayout(ocr_group)
        configure_param_form_layout(ocr_layout)

        self.combo_ocr_lang = QComboBox()
        for label in _OCR_LANG_COMBO_LABELS:
            self.combo_ocr_lang.addItem(label)
        self.combo_ocr_lang.setToolTip(_ocr_lang_combo_tooltip())
        self._ocr_lang_prev_idx = [0]
        self.combo_ocr_lang.currentIndexChanged.connect(self._on_ocr_lang_combo_changed)
        ocr_layout.addRow("인식 언어:", self.combo_ocr_lang)

        self.spin_psm = QSpinBox()
        self.spin_psm.setRange(0, 13)
        self.spin_psm.setValue(7)
        self.spin_psm.setToolTip(
            "「글자가 화면 안에서 어떤 모양으로 배치되어 있다고 가정할지」를 정하는 값입니다. "
            "Tesseract 내부 이름은 PSM(Page Segmentation Mode)입니다.\n\n"
            "★ 대부분의 경우 기본값 7을 그대로 쓰면 됩니다.\n"
            "  • 7: 가로로 한 줄짜리 글(대화 한 줄, HP 숫자 한 줄, 짧은 라벨 등)에 가장 흔히 맞습니다.\n\n"
            "다른 값은 이렇게만 참고하세요.\n"
            "  • 8: 한 덩어리를 「단어 하나」처럼 볼 때(짧은 영문 단어 등).\n"
            "  • 6: 여러 줄이 한 블록으로 붙어 있을 때.\n"
            "  • 10: 글자를 한 글자씩만 있다고 볼 때.\n\n"
            "인식이 이상하면 7을 유지한 채 영역·전처리를 먼저 조절하고, 그다음에 8 또는 6만 바꿔 보세요."
        )
        self.spin_psm.valueChanged.connect(self.param_changed.emit)
        ocr_layout.addRow("글자 배치 (PSM, 보통 7):", self.spin_psm)

        self.edit_whitelist = QLineEdit()
        self.edit_whitelist.setPlaceholderText("비움 = 모든 문자 후보 | 예: 0123456789 (숫자만)")
        self.edit_whitelist.setToolTip(
            "「인식 결과로 나올 수 있는 글자」를 여기 적은 것만으로 한정합니다. "
            "(영어로는 화이트리스트(whitelist)라고 부릅니다.)\n\n"
            "왜 쓰나요?\n"
            "  • 숫자만 있어야 하는 칸에서 O와 0, l과 1처럼 비슷한 글자로 헷갈리는 것을 줄입니다.\n"
            "  • 후보가 줄어들면 그만큼 엔진이 덜 헷갈려 할 수 있습니다.\n\n"
            "비워 두면\n"
            "  • 숫자·영문·한글 등 가능한 범위를 넓게 시도합니다. 문장을 통째로 읽을 때는 보통 비웁니다.\n\n"
            "적을 때 주의\n"
            "  • 공백, 콜론(:), 퍼센트(%) 등도 인식에 필요하면 반드시 같이 적어야 합니다.\n"
            "  • 한글 문장은 위 콤보에서 「한국어」 또는 「한국어 + 영어」를 고르고, "
            "여기서는 비우는 편이 좋습니다.\n\n"
            "예시\n"
            "  • 0123456789  → 숫자만\n"
            "  • 0123456789-/  → 숫자와 빼기, 슬래시(쿨타임 30-60 등)\n"
            "  • ABCDEFGHIJKLMNOPQRSTUVWXYZ  → 대문자 영문만"
        )
        self.edit_whitelist.textChanged.connect(lambda: self.param_changed.emit())
        ocr_layout.addRow("허용할 문자만 (선택):", self.edit_whitelist)
        layout.addRow(ocr_group)

        preproc_group = QGroupBox("이미지 전처리")
        preproc_layout = QFormLayout(preproc_group)
        configure_param_form_layout(preproc_layout)

        self.check_grayscale = QCheckBox("그레이스케일 변환 (권장)")
        self.check_grayscale.setChecked(True)
        self.check_grayscale.setToolTip("컬러 → 흑백 변환. 대부분의 경우 정확도가 올라갑니다.")
        self.check_grayscale.stateChanged.connect(self.param_changed.emit)
        preproc_layout.addRow(self.check_grayscale)

        self.check_invert = QCheckBox("색상 반전 (밝은 글자/어두운 배경일 때)")
        self.check_invert.setToolTip(
            "기본적으로 Tesseract는 밝은 배경 + 어두운 글자를 잘 인식합니다.\n"
            "게임 UI처럼 어두운 배경에 밝은 글자가 있으면 체크하세요."
        )
        self.check_invert.stateChanged.connect(self.param_changed.emit)
        preproc_layout.addRow(self.check_invert)

        self.spin_threshold = QSpinBox()
        self.spin_threshold.setRange(0, 255)
        self.spin_threshold.setToolTip(_ocr_binarize_threshold_tooltip())
        self.spin_threshold.valueChanged.connect(self.param_changed.emit)
        preproc_layout.addRow("흑백 분리 (임계값, 0=자동):", self.spin_threshold)
        layout.addRow(preproc_group)

        result_group = QGroupBox("결과 저장")
        result_layout = QFormLayout(result_group)
        configure_param_form_layout(result_layout)

        self.combo_store_var = create_editable_var_combo()
        self.combo_store_var.setCurrentText("ocr_text")
        self.combo_store_var.setToolTip(
            "인식된 텍스트를 저장할 변수 이름. IfVariable과 함께 사용하여 분기 가능."
        )
        self.combo_store_var.currentTextChanged.connect(lambda: self.param_changed.emit())
        self._var_combos_ocrread = (self.combo_store_var,)
        result_layout.addRow("결과 저장 변수:", self.combo_store_var)

        self.check_strip = QCheckBox("앞뒤 공백/줄바꿈 제거")
        self.check_strip.setChecked(True)
        self.check_strip.setToolTip("인식 결과에서 앞뒤 공백과 줄바꿈을 자동 제거합니다.")
        self.check_strip.stateChanged.connect(self.param_changed.emit)
        result_layout.addRow(self.check_strip)
        layout.addRow(result_group)

    def _on_ocr_lang_combo_changed(self, idx: int) -> None:
        _ocr_lang_apply_combo_change(
            idx,
            self._ocr_lang_prev_idx,
            self.edit_whitelist,
        )
        self.param_changed.emit()

    def set_from_action(self, action: Action) -> None:
        if not isinstance(action, OCRReadAction):
            return
        self.spin_x1.setValue(action.region_x)
        self.spin_y1.setValue(action.region_y)
        self.spin_x2.setValue(action.region_x + action.region_width)
        self.spin_y2.setValue(action.region_y + action.region_height)
        self.group_region_expr.setChecked(
            bool(
                (action.region_xy_expression or "").strip()
                or (action.region_x_expression or "").strip()
                or (action.region_y_expression or "").strip()
                or (action.region_end_xy_expression or "").strip()
                or (action.region_end_x_expression or "").strip()
                or (action.region_end_y_expression or "").strip()
            )
        )
        self.edit_region_xy_expr.setText(action.region_xy_expression or "")
        self.edit_region_x_expr.setText(action.region_x_expression or "")
        self.edit_region_y_expr.setText(action.region_y_expression or "")
        self.edit_region_end_xy_expr.setText(action.region_end_xy_expression or "")
        self.edit_region_end_x_expr.setText(action.region_end_x_expression or "")
        self.edit_region_end_y_expr.setText(action.region_end_y_expression or "")
        _ocr_lang_load_into_ui(
            self.combo_ocr_lang,
            self.edit_whitelist,
            self._ocr_lang_prev_idx,
            action.lang,
            action.whitelist,
        )
        self.spin_psm.setValue(action.psm)
        self.check_grayscale.setChecked(action.grayscale)
        self.check_invert.setChecked(action.invert)
        self.spin_threshold.setValue(action.threshold)
        self.combo_store_var.setCurrentText(action.store_var)
        self.check_strip.setChecked(action.strip_whitespace)

    def to_action_dict(self) -> dict[str, Any]:
        x1, y1 = self.spin_x1.value(), self.spin_y1.value()
        x2, y2 = self.spin_x2.value(), self.spin_y2.value()
        lang, wl = _ocr_lang_read_for_action(self.combo_ocr_lang, self.edit_whitelist)
        region_xy_expr = (
            self.edit_region_xy_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_x_expr = (
            self.edit_region_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_y_expr = (
            self.edit_region_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_xy_expr:
            region_x_expr = ""
            region_y_expr = ""
        region_end_xy_expr = (
            self.edit_region_end_xy_expr.text().strip()
            if self.group_region_expr.isChecked()
            else ""
        )
        region_end_x_expr = (
            self.edit_region_end_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_end_y_expr = (
            self.edit_region_end_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_end_xy_expr:
            region_end_x_expr = ""
            region_end_y_expr = ""
        return {
            "region_x": x1,
            "region_y": y1,
            "region_xy_expression": region_xy_expr or None,
            "region_x_expression": region_x_expr or None,
            "region_y_expression": region_y_expr or None,
            "region_end_xy_expression": region_end_xy_expr or None,
            "region_end_x_expression": region_end_x_expr or None,
            "region_end_y_expression": region_end_y_expr or None,
            "region_width": max(1, x2 - x1),
            "region_height": max(1, y2 - y1),
            "lang": lang,
            "psm": self.spin_psm.value(),
            "whitelist": wl,
            "grayscale": self.check_grayscale.isChecked(),
            "invert": self.check_invert.isChecked(),
            "threshold": self.spin_threshold.value(),
            "store_var": self.combo_store_var.currentText().strip() or "ocr_text",
            "strip_whitespace": self.check_strip.isChecked(),
        }

    def apply_variable_suggestions(self, names: list[str]) -> None:
        for c in self._var_combos_ocrread:
            refill_var_combo_items(c, names)


class OCRWaitParamWidget(RegionNumericNavMixin, _ImageRegionDragMixin, _BaseParamWidget):
    """OCRWait 파라미터 위젯."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        region_group = QGroupBox("OCR 영역 — 시작점(X1,Y1) ~ 끝점(X2,Y2)")
        region_layout = QFormLayout(region_group)
        configure_param_form_layout(region_layout)
        region_layout.addRow(region_hint_label(REGION_HINT_OCR_WAIT))
        self._btn_region_drag = RegionDragPickerButton()
        self._btn_region_drag.region_picked.connect(self._on_region_drag_picked)
        region_layout.addRow("", self._btn_region_drag)

        self.spin_x1 = QSpinBox()
        self.spin_x1.setRange(0, 7680)
        self.spin_y1 = QSpinBox()
        self.spin_y1.setRange(0, 4320)
        self.spin_x2 = QSpinBox()
        self.spin_x2.setRange(1, 7680)
        self.spin_x2.setValue(200)
        self.spin_y2 = QSpinBox()
        self.spin_y2.setRange(1, 4320)
        self.spin_y2.setValue(50)
        for s in [self.spin_x1, self.spin_y1, self.spin_x2, self.spin_y2]:
            s.valueChanged.connect(self.param_changed.emit)
        region_layout.addRow("시작 X1:", self.spin_x1)
        region_layout.addRow("시작 Y1:", self.spin_y1)
        region_layout.addRow("끝 X2:", self.spin_x2)
        region_layout.addRow("끝 Y2:", self.spin_y2)
        self.group_region_expr = QGroupBox("고급(변수식) - OCR 영역 시작 좌표")
        self.group_region_expr.setCheckable(True)
        self.group_region_expr.setChecked(False)
        self.group_region_expr.toggled.connect(self.param_changed.emit)
        region_expr_layout = QFormLayout(self.group_region_expr)
        configure_param_form_layout(region_expr_layout)
        self.edit_region_xy_expr = QLineEdit()
        self.edit_region_xy_expr.setPlaceholderText("영역 XY식 (예: {rx},{ry})")
        self.edit_region_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 XY식:", self.edit_region_xy_expr)
        self.edit_region_x_expr = QLineEdit()
        self.edit_region_x_expr.setPlaceholderText("영역 X식")
        self.edit_region_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 X식:", self.edit_region_x_expr)
        self.edit_region_y_expr = QLineEdit()
        self.edit_region_y_expr.setPlaceholderText("영역 Y식")
        self.edit_region_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 Y식:", self.edit_region_y_expr)
        self.edit_region_end_xy_expr = QLineEdit()
        self.edit_region_end_xy_expr.setPlaceholderText("영역 끝 XY식 (예: {rx2},{ry2})")
        self.edit_region_end_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 XY식:", self.edit_region_end_xy_expr)
        self.edit_region_end_x_expr = QLineEdit()
        self.edit_region_end_x_expr.setPlaceholderText("영역 끝 X식")
        self.edit_region_end_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 X식:", self.edit_region_end_x_expr)
        self.edit_region_end_y_expr = QLineEdit()
        self.edit_region_end_y_expr.setPlaceholderText("영역 끝 Y식")
        self.edit_region_end_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 Y식:", self.edit_region_end_y_expr)
        region_layout.addRow(self.group_region_expr)
        self._append_region_numeric_nav_row(region_layout)
        layout.addRow(region_group)

        pattern_group = QGroupBox("대기할 텍스트 패턴")
        pattern_layout = QFormLayout(pattern_group)
        configure_param_form_layout(pattern_layout)

        self.edit_pattern = QLineEdit()
        self.edit_pattern.setPlaceholderText("대기할 텍스트 (예: 완료, OK, 100)")
        self.edit_pattern.setToolTip(
            "이 텍스트가 화면에 나타날 때까지 대기합니다.\n"
            "정규식 모드를 사용하면 패턴 매칭도 가능합니다."
        )
        self.edit_pattern.textChanged.connect(lambda: self.param_changed.emit())
        pattern_layout.addRow("패턴:", self.edit_pattern)

        self.check_regex = QCheckBox("정규식 사용")
        self.check_regex.setToolTip(
            "체크하면 패턴을 정규식으로 해석합니다.\n"
            "예: '\\d+' → 숫자 1개 이상\n"
            "예: '(완료|Complete)' → '완료' 또는 'Complete'"
        )
        self.check_regex.stateChanged.connect(self.param_changed.emit)
        pattern_layout.addRow(self.check_regex)
        layout.addRow(pattern_group)

        ocr_group = QGroupBox("OCR 설정")
        ocr_layout = QFormLayout(ocr_group)
        configure_param_form_layout(ocr_layout)

        self.combo_ocr_lang = QComboBox()
        for label in _OCR_LANG_COMBO_LABELS:
            self.combo_ocr_lang.addItem(label)
        self.combo_ocr_lang.setToolTip(_ocr_lang_combo_tooltip())
        self._ocr_lang_prev_idx = [0]
        self.combo_ocr_lang.currentIndexChanged.connect(self._on_ocr_lang_combo_changed)
        ocr_layout.addRow("인식 언어:", self.combo_ocr_lang)

        self.spin_psm = QSpinBox()
        self.spin_psm.setRange(0, 13)
        self.spin_psm.setValue(7)
        self.spin_psm.setToolTip(
            "「글자가 화면 안에서 어떤 모양으로 배치되어 있다고 가정할지」를 정하는 값입니다. "
            "Tesseract 내부 이름은 PSM(Page Segmentation Mode)입니다.\n\n"
            "★ 대부분의 경우 기본값 7을 그대로 쓰면 됩니다.\n"
            "  • 7: 가로로 한 줄짜리 글(대화 한 줄, HP 숫자 한 줄, 짧은 라벨 등)에 가장 흔히 맞습니다.\n\n"
            "다른 값은 이렇게만 참고하세요.\n"
            "  • 8: 한 덩어리를 「단어 하나」처럼 볼 때(짧은 영문 단어 등).\n"
            "  • 6: 여러 줄이 한 블록으로 붙어 있을 때.\n"
            "  • 10: 글자를 한 글자씩만 있다고 볼 때.\n\n"
            "인식이 이상하면 7을 유지한 채 영역·전처리를 먼저 조절하고, 그다음에 8 또는 6만 바꿔 보세요."
        )
        self.spin_psm.valueChanged.connect(self.param_changed.emit)
        ocr_layout.addRow("글자 배치 (PSM, 보통 7):", self.spin_psm)

        self.edit_whitelist = QLineEdit()
        self.edit_whitelist.setPlaceholderText("비움 = 모든 문자 후보 | 예: 0123456789 (숫자만)")
        self.edit_whitelist.setToolTip(
            "「인식 결과로 나올 수 있는 글자」를 여기 적은 것만으로 한정합니다. "
            "(영어로는 화이트리스트(whitelist)라고 부릅니다.)\n\n"
            "왜 쓰나요?\n"
            "  • 숫자만 있어야 하는 칸에서 O와 0, l과 1처럼 비슷한 글자로 헷갈리는 것을 줄입니다.\n"
            "  • 후보가 줄어들면 그만큼 엔진이 덜 헷갈려 할 수 있습니다.\n\n"
            "비워 두면\n"
            "  • 숫자·영문·한글 등 가능한 범위를 넓게 시도합니다. 문장을 통째로 읽을 때는 보통 비웁니다.\n\n"
            "적을 때 주의\n"
            "  • 공백, 콜론(:), 퍼센트(%) 등도 인식에 필요하면 반드시 같이 적어야 합니다.\n"
            "  • 한글 문장은 위 콤보에서 「한국어」 또는 「한국어 + 영어」를 고르고, "
            "여기서는 비우는 편이 좋습니다.\n\n"
            "예시\n"
            "  • 0123456789  → 숫자만\n"
            "  • 0123456789-/  → 숫자와 빼기, 슬래시(쿨타임 30-60 등)\n"
            "  • ABCDEFGHIJKLMNOPQRSTUVWXYZ  → 대문자 영문만"
        )
        self.edit_whitelist.textChanged.connect(lambda: self.param_changed.emit())
        ocr_layout.addRow("허용할 문자만 (선택):", self.edit_whitelist)
        layout.addRow(ocr_group)

        preproc_group = QGroupBox("이미지 전처리")
        preproc_layout = QFormLayout(preproc_group)
        configure_param_form_layout(preproc_layout)

        self.check_grayscale = QCheckBox("그레이스케일 변환 (권장)")
        self.check_grayscale.setChecked(True)
        self.check_grayscale.stateChanged.connect(self.param_changed.emit)
        preproc_layout.addRow(self.check_grayscale)

        self.check_invert = QCheckBox("색상 반전")
        self.check_invert.stateChanged.connect(self.param_changed.emit)
        preproc_layout.addRow(self.check_invert)

        self.spin_threshold = QSpinBox()
        self.spin_threshold.setRange(0, 255)
        self.spin_threshold.setToolTip(_ocr_binarize_threshold_tooltip())
        self.spin_threshold.valueChanged.connect(self.param_changed.emit)
        preproc_layout.addRow("흑백 분리 (임계값, 0=자동):", self.spin_threshold)
        layout.addRow(preproc_group)

        timing_group = QGroupBox("대기 시간 설정")
        timing_layout = QFormLayout(timing_group)
        configure_param_form_layout(timing_layout)

        self.spin_timeout = QSpinBox()
        self.spin_timeout.setRange(0, 3_600_000)
        self.spin_timeout.setValue(10000)
        self.spin_timeout.setSuffix(" ms")
        self.spin_timeout.setToolTip("최대 대기 시간 (ms). 0이면 한 번만 시도.")
        self.spin_timeout.valueChanged.connect(self.param_changed.emit)
        timing_layout.addRow("최대 대기 시간:", self.spin_timeout)

        self.spin_poll = QSpinBox()
        self.spin_poll.setRange(100, 10000)
        self.spin_poll.setValue(500)
        self.spin_poll.setSuffix(" ms")
        self.spin_poll.setToolTip("OCR 검사 주기 (ms). 500~1000ms 권장.")
        self.spin_poll.valueChanged.connect(self.param_changed.emit)
        timing_layout.addRow("OCR 검사 주기:", self.spin_poll)
        layout.addRow(timing_group)

        result_group = QGroupBox("결과 및 타임아웃")
        result_layout = QFormLayout(result_group)
        configure_param_form_layout(result_layout)

        self.combo_store_var = create_editable_var_combo()
        self.combo_store_var.setCurrentText("ocr_text")
        self.combo_store_var.setToolTip("인식된 텍스트를 저장할 변수")
        self.combo_store_var.currentTextChanged.connect(lambda: self.param_changed.emit())
        self._var_combos_ocrwait = (self.combo_store_var,)
        result_layout.addRow("결과 저장 변수:", self.combo_store_var)

        self.check_strip = QCheckBox("앞뒤 공백/줄바꿈 제거")
        self.check_strip.setChecked(True)
        self.check_strip.stateChanged.connect(self.param_changed.emit)
        result_layout.addRow(self.check_strip)

        layout.addRow(result_group)

    def _on_ocr_lang_combo_changed(self, idx: int) -> None:
        _ocr_lang_apply_combo_change(
            idx,
            self._ocr_lang_prev_idx,
            self.edit_whitelist,
        )
        self.param_changed.emit()

    def set_from_action(self, action: Action) -> None:
        if not isinstance(action, OCRWaitAction):
            return
        self.spin_x1.setValue(action.region_x)
        self.spin_y1.setValue(action.region_y)
        self.spin_x2.setValue(action.region_x + action.region_width)
        self.spin_y2.setValue(action.region_y + action.region_height)
        self.group_region_expr.setChecked(
            bool(
                (action.region_xy_expression or "").strip()
                or (action.region_x_expression or "").strip()
                or (action.region_y_expression or "").strip()
                or (action.region_end_xy_expression or "").strip()
                or (action.region_end_x_expression or "").strip()
                or (action.region_end_y_expression or "").strip()
            )
        )
        self.edit_region_xy_expr.setText(action.region_xy_expression or "")
        self.edit_region_x_expr.setText(action.region_x_expression or "")
        self.edit_region_y_expr.setText(action.region_y_expression or "")
        self.edit_region_end_xy_expr.setText(action.region_end_xy_expression or "")
        self.edit_region_end_x_expr.setText(action.region_end_x_expression or "")
        self.edit_region_end_y_expr.setText(action.region_end_y_expression or "")
        self.edit_pattern.setText(action.pattern)
        self.check_regex.setChecked(action.use_regex)
        _ocr_lang_load_into_ui(
            self.combo_ocr_lang,
            self.edit_whitelist,
            self._ocr_lang_prev_idx,
            action.lang,
            action.whitelist,
        )
        self.spin_psm.setValue(action.psm)
        self.check_grayscale.setChecked(action.grayscale)
        self.check_invert.setChecked(action.invert)
        self.spin_threshold.setValue(action.threshold)
        self.spin_timeout.setValue(action.timeout_ms)
        self.spin_poll.setValue(action.poll_interval_ms)
        self.combo_store_var.setCurrentText(action.store_var)
        self.check_strip.setChecked(action.strip_whitespace)

    def to_action_dict(self) -> dict[str, Any]:
        x1, y1 = self.spin_x1.value(), self.spin_y1.value()
        x2, y2 = self.spin_x2.value(), self.spin_y2.value()
        lang, wl = _ocr_lang_read_for_action(self.combo_ocr_lang, self.edit_whitelist)
        region_xy_expr = (
            self.edit_region_xy_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_x_expr = (
            self.edit_region_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_y_expr = (
            self.edit_region_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_xy_expr:
            region_x_expr = ""
            region_y_expr = ""
        region_end_xy_expr = (
            self.edit_region_end_xy_expr.text().strip()
            if self.group_region_expr.isChecked()
            else ""
        )
        region_end_x_expr = (
            self.edit_region_end_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_end_y_expr = (
            self.edit_region_end_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_end_xy_expr:
            region_end_x_expr = ""
            region_end_y_expr = ""
        return {
            "region_x": x1,
            "region_y": y1,
            "region_xy_expression": region_xy_expr or None,
            "region_x_expression": region_x_expr or None,
            "region_y_expression": region_y_expr or None,
            "region_end_xy_expression": region_end_xy_expr or None,
            "region_end_x_expression": region_end_x_expr or None,
            "region_end_y_expression": region_end_y_expr or None,
            "region_width": max(1, x2 - x1),
            "region_height": max(1, y2 - y1),
            "pattern": self.edit_pattern.text(),
            "use_regex": self.check_regex.isChecked(),
            "lang": lang,
            "psm": self.spin_psm.value(),
            "whitelist": wl,
            "grayscale": self.check_grayscale.isChecked(),
            "invert": self.check_invert.isChecked(),
            "threshold": self.spin_threshold.value(),
            "timeout_ms": self.spin_timeout.value(),
            "poll_interval_ms": self.spin_poll.value(),
            "store_var": self.combo_store_var.currentText().strip() or "ocr_text",
            "strip_whitespace": self.check_strip.isChecked(),
        }

    def apply_variable_suggestions(self, names: list[str]) -> None:
        for c in self._var_combos_ocrwait:
            refill_var_combo_items(c, names)
