"""검색/OCR 영역 숫자 좌표로 커서 이동·영역 플래시 (변수식 비활성 시에만)."""

from __future__ import annotations

from PyQt6.QtWidgets import QFormLayout, QGroupBox, QHBoxLayout, QPushButton, QWidget

from editor.coord_preview import try_move_cursor_to
from editor.widgets.region_flash_overlay import flash_screen_rect


class RegionNumericNavMixin:
    """`spin_x1`~`spin_y2`, `group_region_expr` 속성이 있는 파라미터 위젯에서 사용."""

    _region_flash_ref: object | None = None

    def _append_region_numeric_nav_row(self, region_layout: QFormLayout) -> None:
        nav = QWidget()
        h = QHBoxLayout(nav)
        h.setContentsMargins(0, 0, 0, 0)
        self._btn_reg_tl = QPushButton("커서 → 왼쪽 위")
        self._btn_reg_c = QPushButton("커서 → 중앙")
        self._btn_reg_flash = QPushButton("영역 화면에 표시")
        tip_base = "고급(변수식)이 꺼져 있을 때만 숫자 좌표로 동작합니다."
        self._btn_reg_tl.setToolTip(f"영역 왼쪽 위(X1,Y1)로 커서를 이동합니다.\n{tip_base}")
        self._btn_reg_c.setToolTip(f"영역 중심으로 커서를 이동합니다.\n{tip_base}")
        self._btn_reg_flash.setToolTip(f"영역을 화면에서 잠시 강조합니다.\n{tip_base}")
        self._btn_reg_tl.clicked.connect(self._on_region_nav_tl)
        self._btn_reg_c.clicked.connect(self._on_region_nav_center)
        self._btn_reg_flash.clicked.connect(self._on_region_nav_flash)
        for b in (self._btn_reg_tl, self._btn_reg_c, self._btn_reg_flash):
            h.addWidget(b)
        region_layout.addRow("화면에서 확인:", nav)
        expr: QGroupBox = self.group_region_expr
        expr.toggled.connect(self._sync_region_numeric_nav)
        for s in (self.spin_x1, self.spin_y1, self.spin_x2, self.spin_y2):
            s.valueChanged.connect(self._sync_region_numeric_nav)
        self._sync_region_numeric_nav()

    def _sync_region_numeric_nav(self) -> None:
        ok = not self.group_region_expr.isChecked()
        self._btn_reg_tl.setEnabled(ok)
        self._btn_reg_c.setEnabled(ok)
        self._btn_reg_flash.setEnabled(ok)

    def _on_region_nav_tl(self) -> None:
        if self.group_region_expr.isChecked():
            return
        try_move_cursor_to(self, self.spin_x1.value(), self.spin_y1.value())

    def _on_region_nav_center(self) -> None:
        if self.group_region_expr.isChecked():
            return
        cx = (self.spin_x1.value() + self.spin_x2.value()) // 2
        cy = (self.spin_y1.value() + self.spin_y2.value()) // 2
        try_move_cursor_to(self, cx, cy)

    def _on_region_nav_flash(self) -> None:
        if self.group_region_expr.isChecked():
            return
        self._region_flash_ref = flash_screen_rect(
            self.spin_x1.value(),
            self.spin_y1.value(),
            self.spin_x2.value(),
            self.spin_y2.value(),
        )
