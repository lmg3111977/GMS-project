"""이미지 검색/대기/클릭 파라미터 위젯.

화면 감지 계열(ImageSearch / ImageWait / ImageClick)은 ``shared.models.image`` 와 대응하며
템플릿 경로·검색 영역 등을 편집한다. 미리보기·영역 커서 이동은 변수식(고급) 사용 시 비활성화된다.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QWidget,
)

from editor.param_panel.base import (
    REGION_HINT_IMAGE_RECT_COMPACT,
    REGION_HINT_IMAGE_SEARCH,
    _BaseParamWidget,
    configure_param_form_layout,
    region_hint_label,
)
from editor.param_panel.region_nav_mixin import RegionNumericNavMixin
from editor.variable_suggestions import create_editable_var_combo, refill_var_combo_items
from editor.widgets.region_drag_picker import RegionDragPickerButton
from shared.models import Action, ImageClickAction, ImageSearchAction, ImageWaitAction

_TEMPLATE_PREVIEW_PX = 120


def _set_template_preview_label(label: QLabel, path: str) -> None:
    raw = path.strip()
    if not raw:
        label.clear()
        label.setPixmap(QPixmap())
        label.setText("(경로 없음)")
        return
    p = Path(raw)
    if not p.is_file():
        label.clear()
        label.setPixmap(QPixmap())
        label.setText("(파일 없음)")
        return
    pm = QPixmap(str(p))
    if pm.isNull():
        label.clear()
        label.setPixmap(QPixmap())
        label.setText("(이미지 로드 실패)")
        return
    label.setText("")
    label.setPixmap(
        pm.scaled(
            _TEMPLATE_PREVIEW_PX,
            _TEMPLATE_PREVIEW_PX,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
    )


class _TemplatePreviewMixin:
    """``edit_template`` 과 ``_tpl_preview`` QLabel이 있어야 한다."""

    def _init_template_preview_row(self, form: QFormLayout) -> None:
        self._tpl_preview = QLabel()
        self._tpl_preview.setFixedSize(_TEMPLATE_PREVIEW_PX, _TEMPLATE_PREVIEW_PX)
        self._tpl_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._tpl_preview.setStyleSheet(
            "border: 1px solid #c5c5c5; border-radius: 4px; background: #fafafa; "
            "color: #4a4540; font-size: 12px;"
        )
        self._tpl_preview.setWordWrap(True)
        self.edit_template.textChanged.connect(self._refresh_template_preview_slot)
        form.addRow("템플릿 미리보기:", self._tpl_preview)

    def _refresh_template_preview_slot(self, _t: str = "") -> None:
        _set_template_preview_label(self._tpl_preview, self.edit_template.text())


class _ImageRegionDragMixin:
    """ImageSearch / ImageWait / ImageClick / OCRRead / OCRWait 공통: 화면 드래그로 영역 스핀에 반영."""

    def _on_region_drag_picked(self, x1: int, y1: int, x2: int, y2: int) -> None:
        self.spin_x1.setValue(x1)
        self.spin_y1.setValue(y1)
        self.spin_x2.setValue(x2)
        self.spin_y2.setValue(y2)
        self.param_changed.emit()


class ImageSearchParamWidget(
    _TemplatePreviewMixin, RegionNumericNavMixin, _ImageRegionDragMixin, _BaseParamWidget
):
    """ImageSearch 파라미터 위젯 — 고급 옵션 포함."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        # ── 템플릿 경로 ──
        template_row = QHBoxLayout()
        self.edit_template = QLineEdit()
        self.edit_template.setPlaceholderText("찾을 이미지 파일 경로 (PNG/JPG)")
        self.edit_template.setToolTip(
            "검색할 템플릿 이미지 파일을 지정합니다.\n"
            "게임 화면에서 찾고 싶은 아이콘, 버튼 등을 캡처하여 저장한 파일을 선택하세요.\n"
            "팁: 배경이 변하지 않는 고유한 부분을 캡처하면 정확도가 높아집니다."
        )
        self.edit_template.textChanged.connect(lambda: self.param_changed.emit())
        btn_browse = QPushButton("찾기...")
        btn_browse.setFixedWidth(70)
        btn_browse.clicked.connect(self._on_browse_template)
        template_row.addWidget(self.edit_template, stretch=1)
        template_row.addWidget(btn_browse)
        layout.addRow("템플릿 이미지:", template_row)
        self._init_template_preview_row(layout)

        # ── 검색 영역 (시작점/끝점 방식) ──
        region_group = QGroupBox("검색 영역 — 시작점(X1,Y1) ~ 끝점(X2,Y2)")
        region_layout = QFormLayout(region_group)
        configure_param_form_layout(region_layout)

        region_layout.addRow(region_hint_label(REGION_HINT_IMAGE_SEARCH))

        self._btn_region_drag = RegionDragPickerButton()
        self._btn_region_drag.region_picked.connect(self._on_region_drag_picked)
        region_layout.addRow("", self._btn_region_drag)

        self.spin_x1 = QSpinBox()
        self.spin_x1.setRange(0, 7680)
        self.spin_x1.setToolTip(
            "검색 영역의 왼쪽 위 모서리 X 좌표\n화면 왼쪽 끝=0, 오른쪽 끝=1920 (FHD)"
        )
        self.spin_y1 = QSpinBox()
        self.spin_y1.setRange(0, 4320)
        self.spin_y1.setToolTip(
            "검색 영역의 왼쪽 위 모서리 Y 좌표\n화면 맨 위=0, 맨 아래=1080 (FHD)"
        )
        self.spin_x2 = QSpinBox()
        self.spin_x2.setRange(1, 7680)
        self.spin_x2.setToolTip("검색 영역의 오른쪽 아래 모서리 X 좌표\n시작 X1보다 커야 합니다")
        self.spin_y2 = QSpinBox()
        self.spin_y2.setRange(1, 4320)
        self.spin_y2.setToolTip("검색 영역의 오른쪽 아래 모서리 Y 좌표\n시작 Y1보다 커야 합니다")
        for s in [self.spin_x1, self.spin_y1, self.spin_x2, self.spin_y2]:
            s.valueChanged.connect(self.param_changed.emit)
        region_layout.addRow("시작 X1 (왼쪽):", self.spin_x1)
        region_layout.addRow("시작 Y1 (위):", self.spin_y1)
        region_layout.addRow("끝 X2 (오른쪽):", self.spin_x2)
        region_layout.addRow("끝 Y2 (아래):", self.spin_y2)
        self.group_region_expr = QGroupBox("고급(변수식) - 검색 영역 시작 좌표")
        self.group_region_expr.setCheckable(True)
        self.group_region_expr.setChecked(False)
        self.group_region_expr.toggled.connect(self.param_changed.emit)
        region_expr_layout = QFormLayout(self.group_region_expr)
        configure_param_form_layout(region_expr_layout)
        self.edit_region_xy_expr = QLineEdit()
        self.edit_region_xy_expr.setPlaceholderText("영역 XY식 (예: {rx},{ry})")
        self.edit_region_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 XY식:", self.edit_region_xy_expr)
        self.edit_region_x_expr = QLineEdit()
        self.edit_region_x_expr.setPlaceholderText("영역 X식 (예: {img_x}-100)")
        self.edit_region_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 X식:", self.edit_region_x_expr)
        self.edit_region_y_expr = QLineEdit()
        self.edit_region_y_expr.setPlaceholderText("영역 Y식 (예: {img_y}-100)")
        self.edit_region_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 Y식:", self.edit_region_y_expr)
        self.edit_region_end_xy_expr = QLineEdit()
        self.edit_region_end_xy_expr.setPlaceholderText("영역 끝 XY식 (예: {rx2},{ry2})")
        self.edit_region_end_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 XY식:", self.edit_region_end_xy_expr)
        self.edit_region_end_x_expr = QLineEdit()
        self.edit_region_end_x_expr.setPlaceholderText("영역 끝 X식")
        self.edit_region_end_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 X식:", self.edit_region_end_x_expr)
        self.edit_region_end_y_expr = QLineEdit()
        self.edit_region_end_y_expr.setPlaceholderText("영역 끝 Y식")
        self.edit_region_end_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 Y식:", self.edit_region_end_y_expr)
        region_layout.addRow(self.group_region_expr)
        self._append_region_numeric_nav_row(region_layout)
        layout.addRow(region_group)

        # ── 매칭 옵션 ──
        match_group = QGroupBox("매칭 설정")
        match_layout = QFormLayout(match_group)
        configure_param_form_layout(match_layout)
        self.spin_conf = QDoubleSpinBox()
        self.spin_conf.setRange(0.0, 1.0)
        self.spin_conf.setSingleStep(0.01)
        self.spin_conf.setDecimals(2)
        self.spin_conf.setToolTip(
            "매칭 신뢰도 임계값 (0.0~1.0)\n"
            "높을수록 엄격 (정확한 일치만 인정), 낮을수록 관대\n"
            "권장: 0.80~0.90. 미세한 변화가 있으면 0.75 정도로 낮추세요."
        )
        self.spin_conf.valueChanged.connect(self.param_changed.emit)
        match_layout.addRow("신뢰도 ≥:", self.spin_conf)

        self.check_grayscale = QCheckBox("그레이스케일 매칭")
        self.check_grayscale.setToolTip(
            "색상을 무시하고 밝기만으로 매칭합니다.\n"
            "장점: 색상 변화(밤/낮, 버프 효과 등)에 강건하고 속도가 빠릅니다.\n"
            "단점: 색상만 다른 유사한 이미지를 구분하지 못할 수 있습니다."
        )
        self.check_grayscale.stateChanged.connect(self.param_changed.emit)
        match_layout.addRow(self.check_grayscale)
        layout.addRow(match_group)

        # ── 재시도 옵션 ──
        retry_group = QGroupBox("재시도 설정 (이미지 로딩 대기 등에 유용)")
        retry_layout = QFormLayout(retry_group)
        configure_param_form_layout(retry_layout)
        self.spin_retry = QSpinBox()
        self.spin_retry.setRange(1, 100)
        self.spin_retry.setToolTip(
            "검색 시도 횟수. 1=한 번만 시도, 2이상=실패 시 재시도.\n"
            "화면 전환 중이거나 애니메이션이 있을 때 여러 번 시도하면 성공률이 높아집니다."
        )
        self.spin_retry.valueChanged.connect(self.param_changed.emit)
        self.spin_retry_interval = QSpinBox()
        self.spin_retry_interval.setRange(100, 30000)
        self.spin_retry_interval.setSuffix(" ms")
        self.spin_retry_interval.setToolTip(
            "재시도 간격 (밀리초). 너무 짧으면 CPU 부하가 높아집니다."
        )
        self.spin_retry_interval.valueChanged.connect(self.param_changed.emit)
        retry_layout.addRow("시도 횟수:", self.spin_retry)
        retry_layout.addRow("시도 간격:", self.spin_retry_interval)
        layout.addRow(retry_group)

        # ── 자동 마우스 옵션 ──
        click_group = QGroupBox("자동 마우스 (발견 시)")
        click_layout = QFormLayout(click_group)
        configure_param_form_layout(click_layout)
        self.check_click = QCheckBox("이미지 발견 시 자동 클릭")
        self.check_click.setToolTip(
            "이미지를 찾으면 해당 위치를 자동으로 클릭합니다.\n"
            "별도로 MouseMove+MouseClick 액션을 추가할 필요가 없습니다."
        )
        self.check_click.stateChanged.connect(self.param_changed.emit)
        click_layout.addRow(self.check_click)

        self.check_move = QCheckBox("이미지 발견 시 커서만 이동 (클릭 없음)")
        self.check_move.setToolTip(
            "이미지를 찾은 좌표(±오프셋)로 마우스 커서만 이동합니다.\n"
            "자동 클릭과 함께 켜면: 이동 시간(ms)이 0보다 크면 먼저 부드럽게 이동한 뒤 클릭합니다."
        )
        self.check_move.stateChanged.connect(self.param_changed.emit)
        click_layout.addRow(self.check_move)

        self.spin_move_duration = QSpinBox()
        self.spin_move_duration.setRange(0, 10000)
        self.spin_move_duration.setSuffix(" ms")
        self.spin_move_duration.setToolTip(
            "커서 이동에 걸리는 시간(밀리초). 0이면 즉시 이동.\n"
            "자동 클릭과 함께 사용할 때만 의미가 있으며, 0이면 기존처럼 즉시 이동 후 클릭합니다."
        )
        self.spin_move_duration.valueChanged.connect(self.param_changed.emit)
        click_layout.addRow("이동 시간 (0=즉시):", self.spin_move_duration)

        self.combo_click_btn = QComboBox()
        self.combo_click_btn.addItems(["LEFT", "RIGHT", "MIDDLE"])
        self.combo_click_btn.setToolTip("자동 클릭 시 사용할 마우스 버튼")
        self.combo_click_btn.currentTextChanged.connect(lambda: self.param_changed.emit())
        click_layout.addRow("클릭 버튼:", self.combo_click_btn)

        self.spin_click_ox = QSpinBox()
        self.spin_click_ox.setRange(-500, 500)
        self.spin_click_ox.setToolTip("이미지 중심에서 X방향 오프셋 (양수=오른쪽)")
        self.spin_click_ox.valueChanged.connect(self.param_changed.emit)
        self.spin_click_oy = QSpinBox()
        self.spin_click_oy.setRange(-500, 500)
        self.spin_click_oy.setToolTip("이미지 중심에서 Y방향 오프셋 (양수=아래쪽)")
        self.spin_click_oy.valueChanged.connect(self.param_changed.emit)
        click_layout.addRow("X 오프셋:", self.spin_click_ox)
        click_layout.addRow("Y 오프셋:", self.spin_click_oy)
        self.group_offset_expr = QGroupBox("고급(변수식) - 클릭 오프셋")
        self.group_offset_expr.setCheckable(True)
        self.group_offset_expr.setChecked(False)
        self.group_offset_expr.toggled.connect(self.param_changed.emit)
        offset_expr_layout = QFormLayout(self.group_offset_expr)
        configure_param_form_layout(offset_expr_layout)
        self.edit_offset_xy_expr = QLineEdit()
        self.edit_offset_xy_expr.setPlaceholderText("오프셋 XY식 (예: {ox},{oy})")
        self.edit_offset_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        offset_expr_layout.addRow("오프셋 XY식:", self.edit_offset_xy_expr)
        self.edit_offset_x_expr = QLineEdit()
        self.edit_offset_x_expr.setPlaceholderText("오프셋 X식")
        self.edit_offset_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        offset_expr_layout.addRow("오프셋 X식:", self.edit_offset_x_expr)
        self.edit_offset_y_expr = QLineEdit()
        self.edit_offset_y_expr.setPlaceholderText("오프셋 Y식")
        self.edit_offset_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        offset_expr_layout.addRow("오프셋 Y식:", self.edit_offset_y_expr)
        click_layout.addRow(self.group_offset_expr)
        layout.addRow(click_group)

        # ── 변수 저장 ──
        var_group = QGroupBox("결과 변수 저장")
        var_layout = QFormLayout(var_group)
        configure_param_form_layout(var_layout)
        self.combo_store_xy_combined = create_editable_var_combo()
        self.combo_store_xy_combined.setPlaceholderText("비워두면 미사용 — 예: pos")
        self.combo_store_xy_combined.setToolTip(
            "X와 Y를 하나의 변수에 '123,456' 형식으로 저장합니다.\n"
            "여러 이미지 검색 시 변수 개수를 줄여 성능·가독성에 유리합니다.\n"
            "아래 X/Y를 비우고 이 항목만 쓰면 좌표 변수는 하나만 생깁니다."
        )
        self.combo_store_x = create_editable_var_combo()
        self.combo_store_x.setPlaceholderText("img_x")
        self.combo_store_x.setToolTip("발견된 이미지 중심 X 좌표를 저장할 변수 이름")
        self.combo_store_y = create_editable_var_combo()
        self.combo_store_y.setPlaceholderText("img_y")
        self.combo_store_y.setToolTip("발견된 이미지 중심 Y 좌표를 저장할 변수 이름")
        self.combo_store_found = create_editable_var_combo()
        self.combo_store_found.setPlaceholderText("비워두면 저장 안 함")
        self.combo_store_found.setToolTip(
            "검색 성공 여부를 저장할 변수 이름.\n"
            "'1'=발견, '0'=미발견. IfVariable과 함께 사용하면 분기 처리 가능."
        )
        self.combo_store_conf = create_editable_var_combo()
        self.combo_store_conf.setPlaceholderText("비워두면 저장 안 함")
        self.combo_store_conf.setToolTip("실제 매칭 신뢰도(0.0~1.0)를 저장할 변수 이름")
        for w in [
            self.combo_store_xy_combined,
            self.combo_store_x,
            self.combo_store_y,
            self.combo_store_found,
            self.combo_store_conf,
        ]:
            w.currentTextChanged.connect(lambda: self.param_changed.emit())
        self._var_combos_imgsearch = (
            self.combo_store_xy_combined,
            self.combo_store_x,
            self.combo_store_y,
            self.combo_store_found,
            self.combo_store_conf,
        )
        var_layout.addRow("통합 좌표 (x,y):", self.combo_store_xy_combined)
        var_layout.addRow("X 좌표 변수:", self.combo_store_x)
        var_layout.addRow("Y 좌표 변수:", self.combo_store_y)
        var_layout.addRow("발견 여부 변수:", self.combo_store_found)
        var_layout.addRow("신뢰도 변수:", self.combo_store_conf)
        layout.addRow(var_group)

    def set_from_action(self, action: Action) -> None:
        if not isinstance(action, ImageSearchAction):
            return
        self.edit_template.setText(action.template_path)
        self.spin_x1.setValue(action.region_x)
        self.spin_y1.setValue(action.region_y)
        self.spin_x2.setValue(action.region_x + action.region_width)
        self.spin_y2.setValue(action.region_y + action.region_height)
        self.group_region_expr.setChecked(
            bool(
                (action.region_xy_expression or "").strip()
                or (action.region_x_expression or "").strip()
                or (action.region_y_expression or "").strip()
                or (action.region_end_xy_expression or "").strip()
                or (action.region_end_x_expression or "").strip()
                or (action.region_end_y_expression or "").strip()
            )
        )
        self.edit_region_xy_expr.setText(action.region_xy_expression or "")
        self.edit_region_x_expr.setText(action.region_x_expression or "")
        self.edit_region_y_expr.setText(action.region_y_expression or "")
        self.edit_region_end_xy_expr.setText(action.region_end_xy_expression or "")
        self.edit_region_end_x_expr.setText(action.region_end_x_expression or "")
        self.edit_region_end_y_expr.setText(action.region_end_y_expression or "")
        self.spin_conf.setValue(action.confidence)
        self.check_grayscale.setChecked(action.grayscale)
        self.spin_retry.setValue(action.max_retry)
        self.spin_retry_interval.setValue(action.retry_interval_ms)
        self.check_click.setChecked(action.click_on_found)
        self.combo_click_btn.setCurrentText(action.click_button.value)
        self.spin_click_ox.setValue(action.click_offset_x)
        self.spin_click_oy.setValue(action.click_offset_y)
        self.group_offset_expr.setChecked(
            bool(
                (action.click_offset_xy_expression or "").strip()
                or (action.click_offset_x_expression or "").strip()
                or (action.click_offset_y_expression or "").strip()
            )
        )
        self.edit_offset_xy_expr.setText(action.click_offset_xy_expression or "")
        self.edit_offset_x_expr.setText(action.click_offset_x_expression or "")
        self.edit_offset_y_expr.setText(action.click_offset_y_expression or "")
        self.check_move.setChecked(action.move_on_found)
        self.spin_move_duration.setValue(action.move_duration_ms)
        self.combo_store_xy_combined.setCurrentText(action.store_xy_combined_var)
        self.combo_store_x.setCurrentText(action.store_x_var)
        self.combo_store_y.setCurrentText(action.store_y_var)
        self.combo_store_found.setCurrentText(action.store_found_var)
        self.combo_store_conf.setCurrentText(action.store_confidence_var)
        self._refresh_template_preview_slot()

    def _resolve_image_search_store_fields(self) -> tuple[str, str, str]:
        """X/Y/통합 변수 필드에서 모델용 store_* 문자열을 만든다."""
        combined = self.combo_store_xy_combined.currentText().strip()
        sx = self.combo_store_x.currentText().strip()
        sy = self.combo_store_y.currentText().strip()
        if not sx and not sy:
            if combined:
                return "", "", combined
            return "img_x", "img_y", ""
        if not sx:
            sx = "img_x"
        if not sy:
            sy = "img_y"
        return sx, sy, combined

    def to_action_dict(self) -> dict[str, Any]:
        x1, y1 = self.spin_x1.value(), self.spin_y1.value()
        x2, y2 = self.spin_x2.value(), self.spin_y2.value()
        w = max(1, x2 - x1)
        h = max(1, y2 - y1)
        sx, sy, combined = self._resolve_image_search_store_fields()
        region_xy_expr = (
            self.edit_region_xy_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_x_expr = (
            self.edit_region_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_y_expr = (
            self.edit_region_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_xy_expr:
            region_x_expr = ""
            region_y_expr = ""
        region_end_xy_expr = (
            self.edit_region_end_xy_expr.text().strip()
            if self.group_region_expr.isChecked()
            else ""
        )
        region_end_x_expr = (
            self.edit_region_end_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_end_y_expr = (
            self.edit_region_end_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_end_xy_expr:
            region_end_x_expr = ""
            region_end_y_expr = ""
        offset_xy_expr = (
            self.edit_offset_xy_expr.text().strip() if self.group_offset_expr.isChecked() else ""
        )
        offset_x_expr = (
            self.edit_offset_x_expr.text().strip() if self.group_offset_expr.isChecked() else ""
        )
        offset_y_expr = (
            self.edit_offset_y_expr.text().strip() if self.group_offset_expr.isChecked() else ""
        )
        if offset_xy_expr:
            offset_x_expr = ""
            offset_y_expr = ""
        d: dict[str, Any] = {
            "template_path": self.edit_template.text(),
            "region_x": x1,
            "region_y": y1,
            "region_xy_expression": region_xy_expr or None,
            "region_x_expression": region_x_expr or None,
            "region_y_expression": region_y_expr or None,
            "region_end_xy_expression": region_end_xy_expr or None,
            "region_end_x_expression": region_end_x_expr or None,
            "region_end_y_expression": region_end_y_expr or None,
            "region_width": w,
            "region_height": h,
            "confidence": float(self.spin_conf.value()),
            "grayscale": self.check_grayscale.isChecked(),
            "max_retry": self.spin_retry.value(),
            "retry_interval_ms": self.spin_retry_interval.value(),
            "click_on_found": self.check_click.isChecked(),
            "click_button": self.combo_click_btn.currentText(),
            "click_offset_x": self.spin_click_ox.value(),
            "click_offset_y": self.spin_click_oy.value(),
            "click_offset_xy_expression": offset_xy_expr or None,
            "click_offset_x_expression": offset_x_expr or None,
            "click_offset_y_expression": offset_y_expr or None,
            "move_on_found": self.check_move.isChecked(),
            "move_duration_ms": self.spin_move_duration.value(),
            "store_x_var": sx,
            "store_y_var": sy,
            "store_xy_combined_var": combined,
            "store_found_var": self.combo_store_found.currentText().strip(),
            "store_confidence_var": self.combo_store_conf.currentText().strip(),
        }
        return d

    def apply_variable_suggestions(self, names: list[str]) -> None:
        for c in self._var_combos_imgsearch:
            refill_var_combo_items(c, names)

    def _on_browse_template(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "템플릿 이미지 선택",
            "macros/",
            "이미지 파일 (*.png *.jpg *.jpeg *.bmp);;모든 파일 (*)",
        )
        if file_path:
            self.edit_template.setText(file_path)
            self.param_changed.emit()


class ImageWaitParamWidget(
    _TemplatePreviewMixin, RegionNumericNavMixin, _ImageRegionDragMixin, _BaseParamWidget
):
    """ImageWait 파라미터 위젯."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        template_row = QHBoxLayout()
        self.edit_template = QLineEdit()
        self.edit_template.setPlaceholderText("나타날 때까지 기다릴 이미지 파일")
        self.edit_template.setToolTip(
            "화면에 나타나기를 기다릴 템플릿 이미지 파일을 선택하세요.\n예: 로딩 완료 아이콘, 확인 버튼 등"
        )
        self.edit_template.textChanged.connect(lambda: self.param_changed.emit())
        btn_browse = QPushButton("찾기...")
        btn_browse.setFixedWidth(70)
        btn_browse.clicked.connect(self._on_browse)
        template_row.addWidget(self.edit_template, stretch=1)
        template_row.addWidget(btn_browse)
        layout.addRow("대기할 이미지:", template_row)
        self._init_template_preview_row(layout)

        region_group = QGroupBox("검색 영역 — 시작점(X1,Y1) ~ 끝점(X2,Y2)")
        region_layout = QFormLayout(region_group)
        configure_param_form_layout(region_layout)
        region_layout.addRow(region_hint_label(REGION_HINT_IMAGE_RECT_COMPACT))
        self._btn_region_drag = RegionDragPickerButton()
        self._btn_region_drag.region_picked.connect(self._on_region_drag_picked)
        region_layout.addRow("", self._btn_region_drag)
        self.spin_x1 = QSpinBox()
        self.spin_x1.setRange(0, 7680)
        self.spin_x1.setToolTip("검색 영역 왼쪽 위 X 좌표")
        self.spin_y1 = QSpinBox()
        self.spin_y1.setRange(0, 4320)
        self.spin_y1.setToolTip("검색 영역 왼쪽 위 Y 좌표")
        self.spin_x2 = QSpinBox()
        self.spin_x2.setRange(1, 7680)
        self.spin_x2.setToolTip("검색 영역 오른쪽 아래 X 좌표 (X1보다 커야 함)")
        self.spin_y2 = QSpinBox()
        self.spin_y2.setRange(1, 4320)
        self.spin_y2.setToolTip("검색 영역 오른쪽 아래 Y 좌표 (Y1보다 커야 함)")
        for s in [self.spin_x1, self.spin_y1, self.spin_x2, self.spin_y2]:
            s.valueChanged.connect(self.param_changed.emit)
        region_layout.addRow("시작 X1 (왼쪽):", self.spin_x1)
        region_layout.addRow("시작 Y1 (위):", self.spin_y1)
        region_layout.addRow("끝 X2 (오른쪽):", self.spin_x2)
        region_layout.addRow("끝 Y2 (아래):", self.spin_y2)
        self.group_region_expr = QGroupBox("고급(변수식) - 검색 영역 시작 좌표")
        self.group_region_expr.setCheckable(True)
        self.group_region_expr.setChecked(False)
        self.group_region_expr.toggled.connect(self.param_changed.emit)
        region_expr_layout = QFormLayout(self.group_region_expr)
        configure_param_form_layout(region_expr_layout)
        self.edit_region_xy_expr = QLineEdit()
        self.edit_region_xy_expr.setPlaceholderText("영역 XY식 (예: {rx},{ry})")
        self.edit_region_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 XY식:", self.edit_region_xy_expr)
        self.edit_region_x_expr = QLineEdit()
        self.edit_region_x_expr.setPlaceholderText("영역 X식")
        self.edit_region_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 X식:", self.edit_region_x_expr)
        self.edit_region_y_expr = QLineEdit()
        self.edit_region_y_expr.setPlaceholderText("영역 Y식")
        self.edit_region_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 Y식:", self.edit_region_y_expr)
        self.edit_region_end_xy_expr = QLineEdit()
        self.edit_region_end_xy_expr.setPlaceholderText("영역 끝 XY식 (예: {rx2},{ry2})")
        self.edit_region_end_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 XY식:", self.edit_region_end_xy_expr)
        self.edit_region_end_x_expr = QLineEdit()
        self.edit_region_end_x_expr.setPlaceholderText("영역 끝 X식")
        self.edit_region_end_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 X식:", self.edit_region_end_x_expr)
        self.edit_region_end_y_expr = QLineEdit()
        self.edit_region_end_y_expr.setPlaceholderText("영역 끝 Y식")
        self.edit_region_end_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 Y식:", self.edit_region_end_y_expr)
        region_layout.addRow(self.group_region_expr)
        self._append_region_numeric_nav_row(region_layout)
        layout.addRow(region_group)

        self.spin_conf = QDoubleSpinBox()
        self.spin_conf.setRange(0.0, 1.0)
        self.spin_conf.setSingleStep(0.01)
        self.spin_conf.setDecimals(2)
        self.spin_conf.setToolTip("매칭 신뢰도 (0.0~1.0). 높을수록 엄격. 0.80~0.90 권장.")
        self.spin_conf.valueChanged.connect(self.param_changed.emit)
        layout.addRow("매칭 신뢰도 (0.85 권장):", self.spin_conf)

        self.check_grayscale = QCheckBox("그레이스케일 매칭 (색상 무시, 밝기만 비교)")
        self.check_grayscale.setToolTip(
            "색상을 무시하고 밝기만으로 비교. 색상 변화가 있는 환경에서 유용."
        )
        self.check_grayscale.stateChanged.connect(self.param_changed.emit)
        layout.addRow(self.check_grayscale)

        self.spin_timeout = QSpinBox()
        self.spin_timeout.setRange(0, 3_600_000)
        self.spin_timeout.setSuffix(" ms")
        self.spin_timeout.setToolTip(
            "이미지가 나타날 때까지 최대 대기 시간 (밀리초)\n"
            "• 5000 = 5초 동안 기다림\n"
            "• 10000 = 10초 동안 기다림\n"
            "• 0 = 한 번만 검색하고 바로 넘어감"
        )
        self.spin_timeout.valueChanged.connect(self.param_changed.emit)
        layout.addRow("최대 대기 시간 (1000=1초):", self.spin_timeout)

        self.combo_store_x = create_editable_var_combo()
        self.combo_store_x.setPlaceholderText("img_x")
        self.combo_store_x.setToolTip("이미지를 찾으면 중심 X 좌표를 이 변수에 저장")
        self.combo_store_y = create_editable_var_combo()
        self.combo_store_y.setPlaceholderText("img_y")
        self.combo_store_y.setToolTip("이미지를 찾으면 중심 Y 좌표를 이 변수에 저장")
        self.combo_store_x.currentTextChanged.connect(lambda: self.param_changed.emit())
        self.combo_store_y.currentTextChanged.connect(lambda: self.param_changed.emit())
        self._var_combos_imgwait = (self.combo_store_x, self.combo_store_y)
        layout.addRow("찾은 X좌표 저장 변수:", self.combo_store_x)
        layout.addRow("찾은 Y좌표 저장 변수:", self.combo_store_y)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, ImageWaitAction):
            self.edit_template.setText(action.template_path)
            self.spin_x1.setValue(action.region_x)
            self.spin_y1.setValue(action.region_y)
            self.spin_x2.setValue(action.region_x + action.region_width)
            self.spin_y2.setValue(action.region_y + action.region_height)
            self.group_region_expr.setChecked(
                bool(
                    (action.region_xy_expression or "").strip()
                    or (action.region_x_expression or "").strip()
                    or (action.region_y_expression or "").strip()
                    or (action.region_end_xy_expression or "").strip()
                    or (action.region_end_x_expression or "").strip()
                    or (action.region_end_y_expression or "").strip()
                )
            )
            self.edit_region_xy_expr.setText(action.region_xy_expression or "")
            self.edit_region_x_expr.setText(action.region_x_expression or "")
            self.edit_region_y_expr.setText(action.region_y_expression or "")
            self.edit_region_end_xy_expr.setText(action.region_end_xy_expression or "")
            self.edit_region_end_x_expr.setText(action.region_end_x_expression or "")
            self.edit_region_end_y_expr.setText(action.region_end_y_expression or "")
            self.spin_conf.setValue(action.confidence)
            self.check_grayscale.setChecked(action.grayscale)
            self.spin_timeout.setValue(action.timeout_ms)
            self.combo_store_x.setCurrentText(action.store_x_var)
            self.combo_store_y.setCurrentText(action.store_y_var)
            self._refresh_template_preview_slot()

    def to_action_dict(self) -> dict[str, Any]:
        x1, y1 = self.spin_x1.value(), self.spin_y1.value()
        x2, y2 = self.spin_x2.value(), self.spin_y2.value()
        region_xy_expr = (
            self.edit_region_xy_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_x_expr = (
            self.edit_region_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_y_expr = (
            self.edit_region_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_xy_expr:
            region_x_expr = ""
            region_y_expr = ""
        region_end_xy_expr = (
            self.edit_region_end_xy_expr.text().strip()
            if self.group_region_expr.isChecked()
            else ""
        )
        region_end_x_expr = (
            self.edit_region_end_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_end_y_expr = (
            self.edit_region_end_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_end_xy_expr:
            region_end_x_expr = ""
            region_end_y_expr = ""
        return {
            "template_path": self.edit_template.text(),
            "region_x": x1,
            "region_y": y1,
            "region_xy_expression": region_xy_expr or None,
            "region_x_expression": region_x_expr or None,
            "region_y_expression": region_y_expr or None,
            "region_end_xy_expression": region_end_xy_expr or None,
            "region_end_x_expression": region_end_x_expr or None,
            "region_end_y_expression": region_end_y_expr or None,
            "region_width": max(1, x2 - x1),
            "region_height": max(1, y2 - y1),
            "confidence": float(self.spin_conf.value()),
            "grayscale": self.check_grayscale.isChecked(),
            "timeout_ms": self.spin_timeout.value(),
            "store_x_var": self.combo_store_x.currentText() or "img_x",
            "store_y_var": self.combo_store_y.currentText() or "img_y",
        }

    def apply_variable_suggestions(self, names: list[str]) -> None:
        for c in self._var_combos_imgwait:
            refill_var_combo_items(c, names)

    def _on_browse(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "템플릿 이미지 선택",
            "macros/",
            "이미지 파일 (*.png *.jpg *.jpeg *.bmp);;모든 파일 (*)",
        )
        if file_path:
            self.edit_template.setText(file_path)
            self.param_changed.emit()


class ImageClickParamWidget(
    _TemplatePreviewMixin, RegionNumericNavMixin, _ImageRegionDragMixin, _BaseParamWidget
):
    """ImageClick 파라미터 위젯."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        template_row = QHBoxLayout()
        self.edit_template = QLineEdit()
        self.edit_template.setPlaceholderText("찾아서 클릭할 이미지 파일")
        self.edit_template.setToolTip(
            "화면에서 찾아서 클릭할 이미지 파일. 버튼, 아이콘 등을 캡처한 PNG 파일."
        )
        self.edit_template.textChanged.connect(lambda: self.param_changed.emit())
        btn_browse = QPushButton("찾기...")
        btn_browse.setFixedWidth(70)
        btn_browse.clicked.connect(self._on_browse)
        template_row.addWidget(self.edit_template, stretch=1)
        template_row.addWidget(btn_browse)
        layout.addRow("클릭 대상 이미지:", template_row)
        self._init_template_preview_row(layout)

        region_group = QGroupBox("검색 영역 — 시작점(X1,Y1) ~ 끝점(X2,Y2)")
        region_layout = QFormLayout(region_group)
        configure_param_form_layout(region_layout)
        region_layout.addRow(region_hint_label(REGION_HINT_IMAGE_RECT_COMPACT))
        self._btn_region_drag = RegionDragPickerButton()
        self._btn_region_drag.region_picked.connect(self._on_region_drag_picked)
        region_layout.addRow("", self._btn_region_drag)
        self.spin_x1 = QSpinBox()
        self.spin_x1.setRange(0, 7680)
        self.spin_x1.setToolTip("검색 영역 왼쪽 위 X 좌표")
        self.spin_y1 = QSpinBox()
        self.spin_y1.setRange(0, 4320)
        self.spin_y1.setToolTip("검색 영역 왼쪽 위 Y 좌표")
        self.spin_x2 = QSpinBox()
        self.spin_x2.setRange(1, 7680)
        self.spin_x2.setToolTip("검색 영역 오른쪽 아래 X 좌표 (X1보다 커야 함)")
        self.spin_y2 = QSpinBox()
        self.spin_y2.setRange(1, 4320)
        self.spin_y2.setToolTip("검색 영역 오른쪽 아래 Y 좌표 (Y1보다 커야 함)")
        for s in [self.spin_x1, self.spin_y1, self.spin_x2, self.spin_y2]:
            s.valueChanged.connect(self.param_changed.emit)
        region_layout.addRow("시작 X1 (왼쪽):", self.spin_x1)
        region_layout.addRow("시작 Y1 (위):", self.spin_y1)
        region_layout.addRow("끝 X2 (오른쪽):", self.spin_x2)
        region_layout.addRow("끝 Y2 (아래):", self.spin_y2)
        self.group_region_expr = QGroupBox("고급(변수식) - 검색 영역 시작 좌표")
        self.group_region_expr.setCheckable(True)
        self.group_region_expr.setChecked(False)
        self.group_region_expr.toggled.connect(self.param_changed.emit)
        region_expr_layout = QFormLayout(self.group_region_expr)
        configure_param_form_layout(region_expr_layout)
        self.edit_region_xy_expr = QLineEdit()
        self.edit_region_xy_expr.setPlaceholderText("영역 XY식 (예: {rx},{ry})")
        self.edit_region_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 XY식:", self.edit_region_xy_expr)
        self.edit_region_x_expr = QLineEdit()
        self.edit_region_x_expr.setPlaceholderText("영역 X식")
        self.edit_region_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 X식:", self.edit_region_x_expr)
        self.edit_region_y_expr = QLineEdit()
        self.edit_region_y_expr.setPlaceholderText("영역 Y식")
        self.edit_region_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 Y식:", self.edit_region_y_expr)
        self.edit_region_end_xy_expr = QLineEdit()
        self.edit_region_end_xy_expr.setPlaceholderText("영역 끝 XY식 (예: {rx2},{ry2})")
        self.edit_region_end_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 XY식:", self.edit_region_end_xy_expr)
        self.edit_region_end_x_expr = QLineEdit()
        self.edit_region_end_x_expr.setPlaceholderText("영역 끝 X식")
        self.edit_region_end_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 X식:", self.edit_region_end_x_expr)
        self.edit_region_end_y_expr = QLineEdit()
        self.edit_region_end_y_expr.setPlaceholderText("영역 끝 Y식")
        self.edit_region_end_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        region_expr_layout.addRow("영역 끝 Y식:", self.edit_region_end_y_expr)
        region_layout.addRow(self.group_region_expr)
        self._append_region_numeric_nav_row(region_layout)
        layout.addRow(region_group)

        self.spin_conf = QDoubleSpinBox()
        self.spin_conf.setRange(0.0, 1.0)
        self.spin_conf.setSingleStep(0.01)
        self.spin_conf.setDecimals(2)
        self.spin_conf.setToolTip("매칭 신뢰도 (0.0~1.0). 높을수록 엄격. 0.80~0.90 권장.")
        self.spin_conf.valueChanged.connect(self.param_changed.emit)
        layout.addRow("매칭 신뢰도 (0.85 권장):", self.spin_conf)

        self.check_grayscale = QCheckBox("그레이스케일 매칭 (색상 무시, 밝기만 비교)")
        self.check_grayscale.setToolTip(
            "색상을 무시하고 밝기만으로 비교. 색상 변화가 있는 환경에서 유용."
        )
        self.check_grayscale.stateChanged.connect(self.param_changed.emit)
        layout.addRow(self.check_grayscale)

        self.combo_btn = QComboBox()
        self.combo_btn.addItems(["LEFT", "RIGHT", "MIDDLE"])
        self.combo_btn.setToolTip("이미지를 찾았을 때 클릭할 마우스 버튼")
        self.combo_btn.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("클릭할 마우스 버튼:", self.combo_btn)

        self.spin_ox = QSpinBox()
        self.spin_ox.setRange(-500, 500)
        self.spin_ox.setToolTip(
            "이미지 중심에서 X방향 클릭 위치 조정\n"
            "• 0: 이미지 정중앙 클릭\n"
            "• +50: 이미지 중심에서 오른쪽 50px\n"
            "• -30: 이미지 중심에서 왼쪽 30px"
        )
        self.spin_ox.valueChanged.connect(self.param_changed.emit)
        self.spin_oy = QSpinBox()
        self.spin_oy.setRange(-500, 500)
        self.spin_oy.setToolTip(
            "이미지 중심에서 Y방향 클릭 위치 조정\n"
            "• 0: 이미지 정중앙 클릭\n"
            "• +30: 이미지 중심에서 아래 30px\n"
            "• -20: 이미지 중심에서 위 20px"
        )
        self.spin_oy.valueChanged.connect(self.param_changed.emit)
        layout.addRow("클릭 X 오프셋 (0=중앙):", self.spin_ox)
        layout.addRow("클릭 Y 오프셋 (0=중앙):", self.spin_oy)
        self.group_offset_expr = QGroupBox("고급(변수식) - 클릭 오프셋")
        self.group_offset_expr.setCheckable(True)
        self.group_offset_expr.setChecked(False)
        self.group_offset_expr.toggled.connect(self.param_changed.emit)
        offset_expr_layout = QFormLayout(self.group_offset_expr)
        configure_param_form_layout(offset_expr_layout)
        self.edit_offset_xy_expr = QLineEdit()
        self.edit_offset_xy_expr.setPlaceholderText("오프셋 XY식 (예: {ox},{oy})")
        self.edit_offset_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        offset_expr_layout.addRow("오프셋 XY식:", self.edit_offset_xy_expr)
        self.edit_offset_x_expr = QLineEdit()
        self.edit_offset_x_expr.setPlaceholderText("오프셋 X식")
        self.edit_offset_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        offset_expr_layout.addRow("오프셋 X식:", self.edit_offset_x_expr)
        self.edit_offset_y_expr = QLineEdit()
        self.edit_offset_y_expr.setPlaceholderText("오프셋 Y식")
        self.edit_offset_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        offset_expr_layout.addRow("오프셋 Y식:", self.edit_offset_y_expr)
        layout.addRow(self.group_offset_expr)

        self.spin_retry = QSpinBox()
        self.spin_retry.setRange(1, 100)
        self.spin_retry.setToolTip("이미지를 찾을 때까지 시도할 횟수. 1=한 번만, 5=최대 5번 시도.")
        self.spin_retry.valueChanged.connect(self.param_changed.emit)
        self.spin_retry_interval = QSpinBox()
        self.spin_retry_interval.setRange(100, 30000)
        self.spin_retry_interval.setSuffix(" ms")
        self.spin_retry_interval.setToolTip("재시도 사이의 대기 시간 (밀리초). 500~1000 권장.")
        self.spin_retry_interval.valueChanged.connect(self.param_changed.emit)
        layout.addRow("최대 시도 횟수:", self.spin_retry)
        layout.addRow("시도 간격 (재시도 대기):", self.spin_retry_interval)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, ImageClickAction):
            self.edit_template.setText(action.template_path)
            self.spin_x1.setValue(action.region_x)
            self.spin_y1.setValue(action.region_y)
            self.spin_x2.setValue(action.region_x + action.region_width)
            self.spin_y2.setValue(action.region_y + action.region_height)
            self.group_region_expr.setChecked(
                bool(
                    (action.region_xy_expression or "").strip()
                    or (action.region_x_expression or "").strip()
                    or (action.region_y_expression or "").strip()
                    or (action.region_end_xy_expression or "").strip()
                    or (action.region_end_x_expression or "").strip()
                    or (action.region_end_y_expression or "").strip()
                )
            )
            self.edit_region_xy_expr.setText(action.region_xy_expression or "")
            self.edit_region_x_expr.setText(action.region_x_expression or "")
            self.edit_region_y_expr.setText(action.region_y_expression or "")
            self.edit_region_end_xy_expr.setText(action.region_end_xy_expression or "")
            self.edit_region_end_x_expr.setText(action.region_end_x_expression or "")
            self.edit_region_end_y_expr.setText(action.region_end_y_expression or "")
            self.spin_conf.setValue(action.confidence)
            self.check_grayscale.setChecked(action.grayscale)
            self.combo_btn.setCurrentText(action.click_button.value)
            self.spin_ox.setValue(action.click_offset_x)
            self.spin_oy.setValue(action.click_offset_y)
            self.group_offset_expr.setChecked(
                bool(
                    (action.click_offset_xy_expression or "").strip()
                    or (action.click_offset_x_expression or "").strip()
                    or (action.click_offset_y_expression or "").strip()
                )
            )
            self.edit_offset_xy_expr.setText(action.click_offset_xy_expression or "")
            self.edit_offset_x_expr.setText(action.click_offset_x_expression or "")
            self.edit_offset_y_expr.setText(action.click_offset_y_expression or "")
            self.spin_retry.setValue(action.max_retry)
            self.spin_retry_interval.setValue(action.retry_interval_ms)
            self._refresh_template_preview_slot()

    def to_action_dict(self) -> dict[str, Any]:
        x1, y1 = self.spin_x1.value(), self.spin_y1.value()
        x2, y2 = self.spin_x2.value(), self.spin_y2.value()
        region_xy_expr = (
            self.edit_region_xy_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_x_expr = (
            self.edit_region_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_y_expr = (
            self.edit_region_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_xy_expr:
            region_x_expr = ""
            region_y_expr = ""
        region_end_xy_expr = (
            self.edit_region_end_xy_expr.text().strip()
            if self.group_region_expr.isChecked()
            else ""
        )
        region_end_x_expr = (
            self.edit_region_end_x_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        region_end_y_expr = (
            self.edit_region_end_y_expr.text().strip() if self.group_region_expr.isChecked() else ""
        )
        if region_end_xy_expr:
            region_end_x_expr = ""
            region_end_y_expr = ""
        offset_xy_expr = (
            self.edit_offset_xy_expr.text().strip() if self.group_offset_expr.isChecked() else ""
        )
        offset_x_expr = (
            self.edit_offset_x_expr.text().strip() if self.group_offset_expr.isChecked() else ""
        )
        offset_y_expr = (
            self.edit_offset_y_expr.text().strip() if self.group_offset_expr.isChecked() else ""
        )
        if offset_xy_expr:
            offset_x_expr = ""
            offset_y_expr = ""
        return {
            "template_path": self.edit_template.text(),
            "region_x": x1,
            "region_y": y1,
            "region_xy_expression": region_xy_expr or None,
            "region_x_expression": region_x_expr or None,
            "region_y_expression": region_y_expr or None,
            "region_end_xy_expression": region_end_xy_expr or None,
            "region_end_x_expression": region_end_x_expr or None,
            "region_end_y_expression": region_end_y_expr or None,
            "region_width": max(1, x2 - x1),
            "region_height": max(1, y2 - y1),
            "confidence": float(self.spin_conf.value()),
            "grayscale": self.check_grayscale.isChecked(),
            "click_button": self.combo_btn.currentText(),
            "click_offset_x": self.spin_ox.value(),
            "click_offset_y": self.spin_oy.value(),
            "click_offset_xy_expression": offset_xy_expr or None,
            "click_offset_x_expression": offset_x_expr or None,
            "click_offset_y_expression": offset_y_expr or None,
            "max_retry": self.spin_retry.value(),
            "retry_interval_ms": self.spin_retry_interval.value(),
        }

    def _on_browse(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "템플릿 이미지 선택",
            "macros/",
            "이미지 파일 (*.png *.jpg *.jpeg *.bmp);;모든 파일 (*)",
        )
        if file_path:
            self.edit_template.setText(file_path)
            self.param_changed.emit()
