"""ParamPanel — 액션별 파라미터 편집 스택 위젯.

화면 감지 계열 액션(이미지·픽셀·OCR)은 아래 위젯에서 템플릿/색/영역 미리보기 및
화면 확인 버튼을 제공한다.

- IfPixel, PixelWait → ``flow_widgets``
- ImageSearch, ImageWait, ImageClick → ``image_widgets``
- OCRRead, OCRWait → ``ocr_widgets``
- MouseMove(절대), MouseDrag → ``mouse_widgets``
"""

from __future__ import annotations

import logging

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QResizeEvent
from PyQt6.QtWidgets import (
    QLabel,
    QLineEdit,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from editor.param_panel.base import ACTION_DESCRIPTIONS, _BaseParamWidget
from editor.param_panel.flow_widgets import (
    EmptyParamWidget,
    GotoParamWidget,
    IfPixelParamWidget,
    IfVariableParamWidget,
    LabelParamWidget,
    LoopStartParamWidget,
    PixelWaitParamWidget,
    SubMacroCallParamWidget,
    VariableSetParamWidget,
)
from editor.param_panel.function_widgets import (
    FunctionCallParamWidget,
    FunctionDefParamWidget,
    ReturnParamWidget,
)
from editor.param_panel.image_widgets import (
    ImageClickParamWidget,
    ImageSearchParamWidget,
    ImageWaitParamWidget,
)
from editor.param_panel.keyboard_widgets import (
    DelayParamWidget,
    KeyComboParamWidget,
    KeyParamWidget,
    KeyPressParamWidget,
    TypeTextParamWidget,
)
from editor.param_panel.mouse_widgets import (
    MouseButtonParamWidget,
    MouseClickParamWidget,
    MouseDragParamWidget,
    MouseMoveParamWidget,
    MouseScrollParamWidget,
)
from editor.param_panel.ocr_widgets import OCRReadParamWidget, OCRWaitParamWidget
from editor.widgets.help_text import style_panel_action_desc_label
from shared.models import Action, ActionType

# QWidget maximum dimension (Qt QWIDGETSIZE_MAX).
_QWIDGETSIZE_MAX = 16777215

logger = logging.getLogger(__name__)

SCREEN_DETECT_ACTION_TYPES: frozenset[ActionType] = frozenset(
    {
        ActionType.IF_PIXEL,
        ActionType.PIXEL_WAIT,
        ActionType.IMAGE_SEARCH,
        ActionType.IMAGE_WAIT,
        ActionType.IMAGE_CLICK,
        ActionType.OCR_READ,
        ActionType.OCR_WAIT,
    }
)

_WIDGET_MAP: dict[ActionType, type[_BaseParamWidget]] = {
    ActionType.MOUSE_MOVE: MouseMoveParamWidget,
    ActionType.MOUSE_CLICK: MouseClickParamWidget,
    ActionType.MOUSE_DOWN: MouseButtonParamWidget,
    ActionType.MOUSE_UP: MouseButtonParamWidget,
    ActionType.MOUSE_DRAG: MouseDragParamWidget,
    ActionType.MOUSE_SCROLL: MouseScrollParamWidget,
    ActionType.KEY_PRESS: KeyPressParamWidget,
    ActionType.KEY_DOWN: KeyParamWidget,
    ActionType.KEY_UP: KeyParamWidget,
    ActionType.KEY_COMBO: KeyComboParamWidget,
    ActionType.TYPE_TEXT: TypeTextParamWidget,
    ActionType.DELAY: DelayParamWidget,
    ActionType.COMMENT: EmptyParamWidget,
    ActionType.LOOP_START: LoopStartParamWidget,
    ActionType.LOOP_END: EmptyParamWidget,
    ActionType.BREAK: EmptyParamWidget,
    ActionType.ELSE: EmptyParamWidget,
    ActionType.END_IF: EmptyParamWidget,
    ActionType.LABEL: LabelParamWidget,
    ActionType.GOTO: GotoParamWidget,
    ActionType.IF_PIXEL: IfPixelParamWidget,
    ActionType.PIXEL_WAIT: PixelWaitParamWidget,
    ActionType.IMAGE_SEARCH: ImageSearchParamWidget,
    ActionType.SUB_MACRO_CALL: SubMacroCallParamWidget,
    ActionType.VARIABLE_SET: VariableSetParamWidget,
    ActionType.IF_VARIABLE: IfVariableParamWidget,
    ActionType.IMAGE_WAIT: ImageWaitParamWidget,
    ActionType.IMAGE_CLICK: ImageClickParamWidget,
    ActionType.OCR_READ: OCRReadParamWidget,
    ActionType.OCR_WAIT: OCRWaitParamWidget,
    ActionType.FUNCTION_DEF: FunctionDefParamWidget,
    ActionType.FUNCTION_END: EmptyParamWidget,
    ActionType.FUNCTION_CALL: FunctionCallParamWidget,
    ActionType.RETURN: ReturnParamWidget,
}


class ParamPanel(QStackedWidget):
    """액션별 파라미터 편집 패널.

    FIX #7: 상단에 액션 설명 표시.
    FIX #4,#5: 값 변경 시 즉시 시그널 발행.
    """

    action_modified = pyqtSignal(object)
    validation_failed = pyqtSignal(str)

    def __init__(
        self,
        parent: QWidget | None = None,
        *,
        nested_excluded_types: frozenset[ActionType] | None = None,
        capture_history: object | None = None,
    ) -> None:
        super().__init__(parent)

        self._current_action: Action | None = None
        self._last_validation_error: str | None = None
        self._widgets: dict[ActionType, _BaseParamWidget] = {}
        self._containers: dict[ActionType, QWidget] = {}
        self._comment_inputs: dict[ActionType, QLineEdit] = {}

        # 빈 상태
        empty = QLabel("좌측에서 액션을 선택하세요")
        empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty.setStyleSheet("color: #999; font-size: 14px;")
        self.addWidget(empty)

        widget_map_items = [
            (at, wc)
            for at, wc in _WIDGET_MAP.items()
            if nested_excluded_types is None or at not in nested_excluded_types
        ]

        # 각 ActionType별 위젯 생성 (설명 포함)
        for action_type, widget_class in widget_map_items:
            container = QWidget()
            container_layout = QVBoxLayout(container)
            container_layout.setContentsMargins(6, 6, 6, 6)
            container_layout.setSpacing(6)
            container_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)

            comment_input = QLineEdit()
            comment_input.setPlaceholderText("이 액션 메모 (리스트에 함께 표시)")
            comment_input.setToolTip(
                "실행에는 영향 없고, 나중에 읽기 쉽게 적는 칸입니다.\n"
                "액션 리스트에서 이 행 옆·요약에 함께 보입니다."
            )
            comment_input.textChanged.connect(self._on_comment_changed)
            self._comment_inputs[action_type] = comment_input
            container_layout.addWidget(QLabel("메모(주석):"))
            container_layout.addWidget(comment_input)

            # FIX #7: 설명 라벨 (다른 액션과 동일: ACTION_DESCRIPTIONS + style_panel_action_desc_label)
            desc_text = ACTION_DESCRIPTIONS.get(action_type, "")
            if desc_text:
                desc_label = QLabel(desc_text)
                style_panel_action_desc_label(desc_label)
                container_layout.addWidget(desc_label)

            widget = widget_class()
            widget.set_capture_history(capture_history)
            widget.param_changed.connect(self._on_param_changed)
            self._widgets[action_type] = widget
            container_layout.addWidget(widget)

            self._containers[action_type] = container
            self.addWidget(container)

        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        self._sync_current_height()

    def set_variable_suggestions(self, names: list[str]) -> None:
        """매크로 전체에서 수집한 변수명으로 편집 가능 콤보 드롭다운을 채운다."""
        panel_cls = type(self)
        for w in self._widgets.values():
            fn = getattr(w, "apply_variable_suggestions", None)
            if callable(fn):
                fn(names)
        for child in self.findChildren(panel_cls):
            if child is not self:
                child.set_variable_suggestions(names)

    def set_action(self, action: Action) -> None:
        self._current_action = action
        container = self._containers.get(action.type)
        widget = self._widgets.get(action.type)
        if container is not None and widget is not None:
            # set_from_action() 과정에서 QSpinBox/QLineEdit의 signals가
            # 연쇄적으로 param_changed를 발생시킬 수 있으므로 일시 차단한다.
            # QWidget만 대상(QObject 전체는 내부 보조 객체까지 포함되어 불필요하게 무겁다).
            to_block: list[QWidget] = [widget, *widget.findChildren(QWidget)]
            for w in to_block:
                w.blockSignals(True)
            comment_input = self._comment_inputs.get(action.type)
            if comment_input is not None:
                comment_input.blockSignals(True)
            try:
                widget.set_from_action(action)
                if comment_input is not None:
                    comment_input.setText(action.comment)
            finally:
                for w in to_block:
                    w.blockSignals(False)
                if comment_input is not None:
                    comment_input.blockSignals(False)
            self.setCurrentWidget(container)
            self._sync_current_height()
        else:
            self.setCurrentIndex(0)
            self._sync_current_height()

    def get_action(self) -> Action | None:
        if self._current_action is None:
            return None

        widget = self._widgets.get(self._current_action.type)
        if widget is None:
            return self._current_action

        base_data = {
            "type": self._current_action.type,
            "action_id": self._current_action.action_id,
            "enabled": self._current_action.enabled,
            "comment": self._current_action.comment,
        }
        param_data = widget.to_action_dict()
        merged = {**base_data, **param_data}

        try:
            action_class = type(self._current_action)
            validated = action_class.model_validate(merged)
            self._last_validation_error = None
            return validated
        except Exception as exc:
            error_text = str(exc)
            self._last_validation_error = error_text
            logger.warning("파라미터 검증 실패: %s", error_text)
            self.validation_failed.emit(error_text)
            return None

    def clear_panel(self) -> None:
        self._current_action = None
        self._last_validation_error = None
        self.setCurrentIndex(0)
        self._sync_current_height()

    def resizeEvent(self, event: QResizeEvent) -> None:  # noqa: N802
        super().resizeEvent(event)
        # 줄 바꿈으로 minimumSizeHint가 바뀌는 경우(폭 변경) 최소 높이 갱신
        self._sync_current_height()

    def _sync_current_height(self) -> None:
        """최소 높이만 맞추고 세로 상한은 두지 않는다 (스크롤 내부에서 줄 바꿈·펼침 후 잘림 방지)."""
        current = self.currentWidget()
        if current is None:
            return
        min_h = max(120, current.minimumSizeHint().height())
        self.setMinimumHeight(min_h)
        self.setMaximumHeight(_QWIDGETSIZE_MAX)

    def has_validation_error(self) -> bool:
        return bool(self._last_validation_error)

    def get_validation_error(self) -> str:
        return self._last_validation_error or ""

    def _on_param_changed(self) -> None:
        action = self.get_action()
        if action is not None:
            self._current_action = action
            self._sync_current_height()
            self.action_modified.emit(action)

    def _on_comment_changed(self, text: str) -> None:
        if self._current_action is None:
            return
        self._current_action.comment = text
        self.action_modified.emit(self._current_action)
