"""키보드 관련 파라미터 위젯."""

from __future__ import annotations

from typing import Any

from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QGroupBox,
    QLineEdit,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from editor.param_panel.base import _BaseParamWidget, configure_param_form_layout
from shared.keymap import get_all_key_names
from shared.models import Action, DelayAction, KeyComboAction, KeyPressAction, TypeTextAction


class KeyParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.combo_key = QComboBox()
        self.combo_key.addItems(get_all_key_names())
        self.combo_key.setEditable(True)
        self.combo_key.setToolTip(
            "입력할 키를 선택하거나 직접 입력하세요.\n"
            "예: a, b, 1, F1, Enter, Space, Tab, Escape 등\n"
            "드롭다운에서 선택하거나 키 이름을 직접 타이핑할 수 있습니다."
        )
        self.combo_key.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("입력할 키:", self.combo_key)

    def set_from_action(self, action: Action) -> None:
        if hasattr(action, "key"):
            self.combo_key.setCurrentText(action.key)  # type: ignore

    def to_action_dict(self) -> dict[str, Any]:
        return {"key": self.combo_key.currentText()}


class KeyPressParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.combo_key = QComboBox()
        self.combo_key.addItems(get_all_key_names())
        self.combo_key.setEditable(True)
        self.combo_key.setToolTip(
            "입력할 키를 선택하거나 직접 입력하세요.\n"
            "예: a, b, 1, F1, Enter, Space, Tab, Escape 등"
        )
        self.combo_key.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("입력할 키:", self.combo_key)

        self.spin_count = QSpinBox()
        self.spin_count.setRange(1, 50)
        self.spin_count.setToolTip("같은 키를 연속으로 몇 번 입력할지 설정합니다.")
        self.spin_count.valueChanged.connect(self.param_changed.emit)
        layout.addRow("반복 횟수:", self.spin_count)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, KeyPressAction):
            self.combo_key.setCurrentText(action.key)
            self.spin_count.setValue(action.count)

    def to_action_dict(self) -> dict[str, Any]:
        return {"key": self.combo_key.currentText(), "count": self.spin_count.value()}


class KeyComboParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.check_ctrl = QCheckBox("Ctrl")
        self.check_shift = QCheckBox("Shift")
        self.check_alt = QCheckBox("Alt")
        self.check_win = QCheckBox("Win")
        mod_group = QGroupBox("수정자 키 (함께 누를 키를 체크)")
        mod_group.setToolTip(
            "메인 키와 동시에 누를 수정자 키를 선택하세요.\n"
            "예: Ctrl+C → Ctrl 체크 + 메인 키 'c'\n"
            "예: Ctrl+Shift+S → Ctrl, Shift 모두 체크 + 메인 키 's'"
        )
        mod_layout = QVBoxLayout(mod_group)
        for cb in [self.check_ctrl, self.check_shift, self.check_alt, self.check_win]:
            cb.stateChanged.connect(self.param_changed.emit)
            mod_layout.addWidget(cb)
        layout.addRow(mod_group)
        self.combo_key = QComboBox()
        self.combo_key.addItems(get_all_key_names())
        self.combo_key.setEditable(True)
        self.combo_key.setToolTip("수정자 키와 함께 누를 메인 키. 예: c, s, Tab, F5 등")
        self.combo_key.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("메인 키 (함께 누를 키):", self.combo_key)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, KeyComboAction):
            self.check_ctrl.setChecked("Ctrl" in action.modifiers)
            self.check_shift.setChecked("Shift" in action.modifiers)
            self.check_alt.setChecked("Alt" in action.modifiers)
            self.check_win.setChecked("Win" in action.modifiers)
            self.combo_key.setCurrentText(action.key)

    def to_action_dict(self) -> dict[str, Any]:
        mods = []
        if self.check_ctrl.isChecked():
            mods.append("Ctrl")
        if self.check_shift.isChecked():
            mods.append("Shift")
        if self.check_alt.isChecked():
            mods.append("Alt")
        if self.check_win.isChecked():
            mods.append("Win")
        return {"modifiers": mods, "key": self.combo_key.currentText()}


class TypeTextParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.edit_text = QLineEdit()
        self.edit_text.setToolTip(
            "한 글자씩 타이핑할 문자열을 입력하세요.\n예: Hello World, gg, /help 등"
        )
        self.edit_text.textChanged.connect(lambda: self.param_changed.emit())
        self.spin_interval = QSpinBox()
        self.spin_interval.setRange(0, 1000)
        self.spin_interval.setSuffix(" ms")
        self.spin_interval.setToolTip(
            "글자와 글자 사이의 대기 시간 (밀리초)\n"
            "• 0: 최대 속도로 입력\n"
            "• 50~100: 사람이 타이핑하는 것처럼 자연스럽게\n"
            "• 200+: 느리게 한 글자씩"
        )
        self.spin_interval.valueChanged.connect(self.param_changed.emit)
        layout.addRow("타이핑할 텍스트:", self.edit_text)
        layout.addRow("글자 간 간격 (타이핑 속도):", self.spin_interval)

        self.spin_count = QSpinBox()
        self.spin_count.setRange(1, 50)
        self.spin_count.setToolTip("같은 문장을 연속으로 몇 번 입력할지 설정합니다.")
        self.spin_count.valueChanged.connect(self.param_changed.emit)
        layout.addRow("반복 횟수:", self.spin_count)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, TypeTextAction):
            self.edit_text.setText(action.text)
            self.spin_interval.setValue(action.interval_ms)
            self.spin_count.setValue(action.count)

    def to_action_dict(self) -> dict[str, Any]:
        return {
            "text": self.edit_text.text(),
            "interval_ms": self.spin_interval.value(),
            "count": self.spin_count.value(),
        }


class DelayParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.spin_ms = QSpinBox()
        self.spin_ms.setRange(0, 3_600_000)
        self.spin_ms.setSuffix(" ms")
        self.spin_ms.setToolTip(
            "대기할 시간 (밀리초). 1000ms = 1초\n"
            "예: 500 = 0.5초 대기, 2000 = 2초 대기\n"
            "랜덤 딜레이를 체크하면 이 값 대신 아래 범위를 사용합니다."
        )
        self.spin_ms.valueChanged.connect(self.param_changed.emit)
        layout.addRow("대기 시간 (1000ms=1초):", self.spin_ms)

        self.check_random = QCheckBox("랜덤 딜레이 사용 (매번 다른 시간 대기)")
        self.check_random.setToolTip(
            "체크하면 고정 딜레이 대신 최소~최대 범위에서 랜덤한 시간만큼 대기합니다.\n"
            "봇 감지를 피하거나 자연스러운 동작에 유용합니다."
        )
        self.check_random.stateChanged.connect(self.param_changed.emit)
        layout.addRow(self.check_random)

        self.spin_min = QSpinBox()
        self.spin_min.setRange(0, 3_600_000)
        self.spin_min.setSuffix(" ms")
        self.spin_min.setToolTip("랜덤 대기 시간의 최솟값 (밀리초)")
        self.spin_min.valueChanged.connect(self.param_changed.emit)
        self.spin_max = QSpinBox()
        self.spin_max.setRange(0, 3_600_000)
        self.spin_max.setSuffix(" ms")
        self.spin_max.setToolTip("랜덤 대기 시간의 최댓값 (밀리초). 최소보다 크게 설정하세요.")
        self.spin_max.valueChanged.connect(self.param_changed.emit)
        layout.addRow("랜덤 최소 시간:", self.spin_min)
        layout.addRow("랜덤 최대 시간:", self.spin_max)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, DelayAction):
            self.spin_ms.blockSignals(True)
            self.spin_min.blockSignals(True)
            self.spin_max.blockSignals(True)
            self.check_random.blockSignals(True)
            try:
                self.spin_ms.setValue(action.ms)
                has_random = action.random_min is not None
                self.check_random.setChecked(has_random)
                self.spin_min.setValue(action.random_min or 0)
                self.spin_max.setValue(action.random_max or 0)
            finally:
                self.spin_ms.blockSignals(False)
                self.spin_min.blockSignals(False)
                self.spin_max.blockSignals(False)
                self.check_random.blockSignals(False)

    def to_action_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"ms": self.spin_ms.value()}
        if self.check_random.isChecked():
            d["random_min"] = self.spin_min.value()
            d["random_max"] = self.spin_max.value()
        return d
