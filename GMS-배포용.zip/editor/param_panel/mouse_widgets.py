"""마우스 관련 파라미터 위젯.

MouseMove(절대 좌표)·MouseDrag는 숫자 좌표가 있을 때 「화면에서 확인」으로
커서 이동·좌표/영역 강조를 할 수 있다 (변수식 사용 시 비활성).
"""

from __future__ import annotations

from typing import Any

from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QWidget,
)

from editor.coord_preview import try_move_cursor_to
from editor.param_panel.base import (
    _BaseParamWidget,
    _parse_clipboard_xy,
    _show_clipboard_format_error,
    configure_param_form_layout,
    get_active_capture_text,
)
from editor.widgets.help_text import style_form_hint_label
from editor.widgets.region_flash_overlay import flash_screen_rect
from shared.models import (
    Action,
    MouseClickAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
)


class MouseMoveParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        self.spin_x = QSpinBox()
        self.spin_x.setRange(-7680, 7680)
        self.spin_x.setToolTip(
            "마우스를 이동할 X 좌표 (가로 위치)\n"
            "• 절대 모드: 화면 왼쪽 끝=0, 오른쪽 끝=1920 (FHD 기준)\n"
            "• 상대 모드: 현재 위치에서 오른쪽(+) 또는 왼쪽(-) 이동량\n"
            "팁: F8을 눌러 현재 마우스 위치를 클립보드에 복사한 뒤 아래 버튼으로 적용"
        )
        self.spin_x.valueChanged.connect(self.param_changed.emit)
        layout.addRow("X 좌표 (가로 위치):", self.spin_x)

        self.spin_y = QSpinBox()
        self.spin_y.setRange(-4320, 4320)
        self.spin_y.setToolTip(
            "마우스를 이동할 Y 좌표 (세로 위치)\n"
            "• 절대 모드: 화면 맨 위=0, 맨 아래=1080 (FHD 기준)\n"
            "• 상대 모드: 현재 위치에서 아래(+) 또는 위(-) 이동량"
        )
        self.spin_y.valueChanged.connect(self.param_changed.emit)
        layout.addRow("Y 좌표 (세로 위치):", self.spin_y)

        self.group_expr = QGroupBox("고급(변수식)")
        self.group_expr.setCheckable(True)
        self.group_expr.setChecked(False)
        self.group_expr.toggled.connect(self.param_changed.emit)
        expr_layout = QFormLayout(self.group_expr)
        configure_param_form_layout(expr_layout)
        expr_hint = QLabel("규칙: XY식 > X/Y식 > 숫자 좌표")
        style_form_hint_label(expr_hint)
        expr_layout.addRow(expr_hint)
        self.edit_xy_expr = QLineEdit()
        self.edit_xy_expr.setPlaceholderText("좌표식 (예: {img_xy} 또는 {img_x},{img_y})")
        self.edit_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("XY 좌표식:", self.edit_xy_expr)
        self.edit_x_expr = QLineEdit()
        self.edit_x_expr.setPlaceholderText("X 식 (예: {img_x} + 10)")
        self.edit_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("X 식:", self.edit_x_expr)
        self.edit_y_expr = QLineEdit()
        self.edit_y_expr.setPlaceholderText("Y 식 (예: {img_y} - 5)")
        self.edit_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("Y 식:", self.edit_y_expr)
        layout.addRow(self.group_expr)

        self.check_relative = QCheckBox("상대 이동 (현재 위치에서 dx, dy만큼)")
        self.check_relative.setToolTip(
            "체크 해제 (절대 이동): X,Y가 화면의 고정된 위치를 의미합니다.\n"
            "  예: X=500, Y=300 → 화면의 (500, 300) 위치로 이동\n\n"
            "체크 (상대 이동): 현재 마우스 위치에서 X,Y만큼 이동합니다.\n"
            "  예: X=100, Y=-50 → 오른쪽 100px, 위로 50px 이동"
        )
        self.check_relative.stateChanged.connect(self.param_changed.emit)
        layout.addRow(self.check_relative)

        move_nav = QWidget()
        mnh = QHBoxLayout(move_nav)
        mnh.setContentsMargins(0, 0, 0, 0)
        self._btn_mm_cursor = QPushButton("커서 → 목표 좌표")
        self._btn_mm_flash = QPushButton("목표 좌표 화면에 표시")
        tip_mm = (
            "절대 좌표 모드이고 고급(변수식)이 꺼져 있을 때만 동작합니다.\n"
            "상대 이동 모드에서는 목표 화면 위치가 아니라 이동량이므로 비활성화됩니다."
        )
        self._btn_mm_cursor.setToolTip(f"설정한 X,Y(절대 좌표)로 커서를 이동합니다.\n{tip_mm}")
        self._btn_mm_flash.setToolTip(f"해당 좌표 주변을 화면에서 잠시 강조합니다.\n{tip_mm}")
        self._btn_mm_cursor.clicked.connect(self._on_mouse_move_cursor)
        self._btn_mm_flash.clicked.connect(self._on_mouse_move_flash)
        mnh.addWidget(self._btn_mm_cursor)
        mnh.addWidget(self._btn_mm_flash)
        layout.addRow("화면에서 확인:", move_nav)
        self._mouse_move_flash_ref: object | None = None
        self.group_expr.toggled.connect(self._sync_mouse_move_screen_nav)
        self.check_relative.toggled.connect(self._sync_mouse_move_screen_nav)
        self.spin_x.valueChanged.connect(self._sync_mouse_move_screen_nav)
        self.spin_y.valueChanged.connect(self._sync_mouse_move_screen_nav)
        self._sync_mouse_move_screen_nav()

        btn_from_clip = QPushButton("클립보드 좌표 적용 (F8)")
        btn_from_clip.setToolTip("F8로 캡처한 마우스 좌표를 X, Y에 자동 입력합니다")
        btn_from_clip.clicked.connect(self._apply_from_clipboard)
        layout.addRow(btn_from_clip)

        self.spin_duration = QSpinBox()
        self.spin_duration.setRange(0, 10000)
        self.spin_duration.setSuffix(" ms")
        self.spin_duration.setToolTip(
            "마우스 이동에 걸리는 시간 (밀리초)\n"
            "• 0: 즉시 순간이동 (가장 빠름)\n"
            "• 100~500: 부드럽게 슬라이딩 이동 (사람처럼 보임)\n"
            "• 1000 = 1초에 걸쳐 이동"
        )
        self.spin_duration.valueChanged.connect(self.param_changed.emit)
        layout.addRow("이동 시간 (0=즉시 순간이동):", self.spin_duration)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, MouseMoveAction):
            self.spin_x.blockSignals(True)
            self.spin_y.blockSignals(True)
            self.edit_xy_expr.blockSignals(True)
            self.edit_x_expr.blockSignals(True)
            self.edit_y_expr.blockSignals(True)
            self.check_relative.blockSignals(True)
            self.spin_duration.blockSignals(True)
            try:
                self.spin_x.setValue(action.x)
                self.spin_y.setValue(action.y)
                self.group_expr.setChecked(
                    bool(
                        (action.xy_expression or "").strip()
                        or (action.x_expression or "").strip()
                        or (action.y_expression or "").strip()
                    )
                )
                self.edit_xy_expr.setText(action.xy_expression or "")
                self.edit_x_expr.setText(action.x_expression or "")
                self.edit_y_expr.setText(action.y_expression or "")
                self.check_relative.setChecked(action.is_relative)
                self.spin_duration.setValue(action.duration_ms)
            finally:
                self.spin_x.blockSignals(False)
                self.spin_y.blockSignals(False)
                self.edit_xy_expr.blockSignals(False)
                self.edit_x_expr.blockSignals(False)
                self.edit_y_expr.blockSignals(False)
                self.check_relative.blockSignals(False)
                self.spin_duration.blockSignals(False)
            self._sync_mouse_move_screen_nav()

    def to_action_dict(self) -> dict[str, Any]:
        is_relative = self.check_relative.isChecked()
        x_val = self.spin_x.value()
        y_val = self.spin_y.value()

        # 상대 이동이면 dx, dy 그대로 (-값 포함)
        # 절대 이동이면 화면 좌표이므로 0~해상도로 클램프
        if not is_relative:
            x_val = max(0, min(7680, x_val))
            y_val = max(0, min(4320, y_val))

        xy_expr = self.edit_xy_expr.text().strip() if self.group_expr.isChecked() else ""
        x_expr = self.edit_x_expr.text().strip() if self.group_expr.isChecked() else ""
        y_expr = self.edit_y_expr.text().strip() if self.group_expr.isChecked() else ""
        if xy_expr:
            x_expr = ""
            y_expr = ""
        return {
            "x": x_val,
            "y": y_val,
            "xy_expression": xy_expr or None,
            "x_expression": x_expr or None,
            "y_expression": y_expr or None,
            "is_relative": is_relative,
            "duration_ms": self.spin_duration.value(),
        }

    def _apply_from_clipboard(self) -> None:
        """클립보드("x,y,#RRGGBB")에서 좌표를 읽어와 X/Y에 적용한다."""
        text = get_active_capture_text(self._capture_history)
        if text is None:
            text = QGuiApplication.clipboard().text().strip()
        if not text:
            QMessageBox.warning(
                self,
                "F8 캡처 없음",
                "캡처된 좌표가 없습니다.\nF8을 눌러 좌표를 먼저 캡처하세요.",
            )
            return
        parsed = _parse_clipboard_xy(text)
        if parsed is None:
            _show_clipboard_format_error(self)
            return
        x, y = parsed

        self.spin_x.setValue(x)
        self.spin_y.setValue(y)
        self.param_changed.emit()

    def _sync_mouse_move_screen_nav(self) -> None:
        ok = not self.group_expr.isChecked() and not self.check_relative.isChecked()
        self._btn_mm_cursor.setEnabled(ok)
        self._btn_mm_flash.setEnabled(ok)

    def _on_mouse_move_cursor(self) -> None:
        if self.group_expr.isChecked() or self.check_relative.isChecked():
            return
        try_move_cursor_to(self, self.spin_x.value(), self.spin_y.value())

    def _on_mouse_move_flash(self) -> None:
        if self.group_expr.isChecked() or self.check_relative.isChecked():
            return
        x, y = self.spin_x.value(), self.spin_y.value()
        self._mouse_move_flash_ref = flash_screen_rect(x - 4, y - 4, x + 4, y + 4)


class MouseClickParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)

        self.combo_button = QComboBox()
        self.combo_button.addItems(["LEFT", "RIGHT", "MIDDLE"])
        self.combo_button.setToolTip(
            "클릭할 마우스 버튼 선택\n"
            "• LEFT: 왼쪽 버튼 (일반 클릭)\n"
            "• RIGHT: 오른쪽 버튼 (우클릭, 컨텍스트 메뉴)\n"
            "• MIDDLE: 가운데 휠 버튼"
        )
        self.combo_button.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("클릭 버튼:", self.combo_button)

        self.spin_count = QSpinBox()
        self.spin_count.setRange(1, 5)
        self.spin_count.setToolTip(
            "클릭 횟수\n"
            "• 1: 단일 클릭\n"
            "• 2: 더블 클릭 (파일 열기 등)\n"
            "• 3: 트리플 클릭 (텍스트 전체 선택 등)"
        )
        self.spin_count.valueChanged.connect(self.param_changed.emit)
        layout.addRow("클릭 횟수 (2=더블클릭):", self.spin_count)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, MouseClickAction):
            self.combo_button.setCurrentText(action.button.value)
            self.spin_count.setValue(action.count)

    def to_action_dict(self) -> dict[str, Any]:
        return {"button": self.combo_button.currentText(), "count": self.spin_count.value()}


class MouseButtonParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.combo_button = QComboBox()
        self.combo_button.addItems(["LEFT", "RIGHT", "MIDDLE"])
        self.combo_button.setToolTip(
            "누르거나 뗄 마우스 버튼\n• LEFT=왼쪽, RIGHT=오른쪽, MIDDLE=가운데 휠"
        )
        self.combo_button.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("마우스 버튼:", self.combo_button)

    def set_from_action(self, action: Action) -> None:
        if hasattr(action, "button"):
            self.combo_button.setCurrentText(action.button.value)  # type: ignore

    def to_action_dict(self) -> dict[str, Any]:
        return {"button": self.combo_button.currentText()}


class MouseDragParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.spin_sx = QSpinBox()
        self.spin_sx.setRange(0, 7680)
        self.spin_sx.setToolTip("드래그 시작 지점의 X 좌표 (화면 왼쪽=0)")
        self.spin_sy = QSpinBox()
        self.spin_sy.setRange(0, 4320)
        self.spin_sy.setToolTip("드래그 시작 지점의 Y 좌표 (화면 위=0)")
        self.spin_ex = QSpinBox()
        self.spin_ex.setRange(0, 7680)
        self.spin_ex.setToolTip("드래그 끝 지점의 X 좌표")
        self.spin_ey = QSpinBox()
        self.spin_ey.setRange(0, 4320)
        self.spin_ey.setToolTip("드래그 끝 지점의 Y 좌표")
        self.spin_dur = QSpinBox()
        self.spin_dur.setRange(0, 10000)
        self.spin_dur.setSuffix(" ms")
        self.spin_dur.setToolTip("드래그 소요 시간 (밀리초). 200~500ms가 자연스럽습니다.")
        for s in [self.spin_sx, self.spin_sy, self.spin_ex, self.spin_ey, self.spin_dur]:
            s.valueChanged.connect(self.param_changed.emit)
        layout.addRow("시작점 X (드래그 시작 가로):", self.spin_sx)
        layout.addRow("시작점 Y (드래그 시작 세로):", self.spin_sy)
        layout.addRow("끝점 X (드래그 끝 가로):", self.spin_ex)
        layout.addRow("끝점 Y (드래그 끝 세로):", self.spin_ey)
        self.group_expr = QGroupBox("고급(변수식)")
        self.group_expr.setCheckable(True)
        self.group_expr.setChecked(False)
        self.group_expr.toggled.connect(self.param_changed.emit)
        expr_layout = QFormLayout(self.group_expr)
        configure_param_form_layout(expr_layout)
        expr_hint = QLabel("규칙: 시작/끝 각각 XY식 우선, 없으면 X/Y식 사용")
        style_form_hint_label(expr_hint)
        expr_layout.addRow(expr_hint)
        self.edit_start_xy_expr = QLineEdit()
        self.edit_start_xy_expr.setPlaceholderText("시작 XY식 (예: {sx},{sy})")
        self.edit_start_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("시작 XY식:", self.edit_start_xy_expr)
        self.edit_start_x_expr = QLineEdit()
        self.edit_start_x_expr.setPlaceholderText("시작 X식 (예: {img_x})")
        self.edit_start_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("시작 X식:", self.edit_start_x_expr)
        self.edit_start_y_expr = QLineEdit()
        self.edit_start_y_expr.setPlaceholderText("시작 Y식 (예: {img_y})")
        self.edit_start_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("시작 Y식:", self.edit_start_y_expr)
        self.edit_end_xy_expr = QLineEdit()
        self.edit_end_xy_expr.setPlaceholderText("끝 XY식 (예: {ex},{ey})")
        self.edit_end_xy_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("끝 XY식:", self.edit_end_xy_expr)
        self.edit_end_x_expr = QLineEdit()
        self.edit_end_x_expr.setPlaceholderText("끝 X식 (예: {img_x}+20)")
        self.edit_end_x_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("끝 X식:", self.edit_end_x_expr)
        self.edit_end_y_expr = QLineEdit()
        self.edit_end_y_expr.setPlaceholderText("끝 Y식 (예: {img_y}+20)")
        self.edit_end_y_expr.textChanged.connect(lambda: self.param_changed.emit())
        expr_layout.addRow("끝 Y식:", self.edit_end_y_expr)
        layout.addRow(self.group_expr)

        drag_nav = QWidget()
        dnh = QHBoxLayout(drag_nav)
        dnh.setContentsMargins(0, 0, 0, 0)
        self._btn_drag_cursor_start = QPushButton("커서 → 시작점")
        self._btn_drag_cursor_end = QPushButton("커서 → 끝점")
        self._btn_drag_flash = QPushButton("드래그 영역 표시")
        tip_dg = "고급(변수식)이 꺼져 있을 때만 숫자 좌표로 동작합니다."
        self._btn_drag_cursor_start.setToolTip(f"드래그 시작 (X,Y)로 커서를 이동합니다.\n{tip_dg}")
        self._btn_drag_cursor_end.setToolTip(f"드래그 끝 (X,Y)로 커서를 이동합니다.\n{tip_dg}")
        self._btn_drag_flash.setToolTip(
            f"시작점~끝점을 감싼 직사각형을 화면에서 잠시 강조합니다.\n{tip_dg}"
        )
        self._btn_drag_cursor_start.clicked.connect(self._on_drag_cursor_start)
        self._btn_drag_cursor_end.clicked.connect(self._on_drag_cursor_end)
        self._btn_drag_flash.clicked.connect(self._on_drag_flash_drag_rect)
        dnh.addWidget(self._btn_drag_cursor_start)
        dnh.addWidget(self._btn_drag_cursor_end)
        dnh.addWidget(self._btn_drag_flash)
        layout.addRow("화면에서 확인:", drag_nav)
        self._mouse_drag_flash_ref: object | None = None
        self.group_expr.toggled.connect(self._sync_mouse_drag_screen_nav)
        for s in (self.spin_sx, self.spin_sy, self.spin_ex, self.spin_ey):
            s.valueChanged.connect(self._sync_mouse_drag_screen_nav)
        self._sync_mouse_drag_screen_nav()

        layout.addRow("드래그 소요 시간:", self.spin_dur)

        btn_row = QHBoxLayout()
        btn_start = QPushButton("시작점 ← F8 좌표")
        btn_start.setToolTip("F8로 캡처한 좌표를 시작점에 입력")
        btn_end = QPushButton("끝점 ← F8 좌표")
        btn_end.setToolTip("F8로 캡처한 좌표를 끝점에 입력")
        btn_start.clicked.connect(self._apply_start_from_clipboard)
        btn_end.clicked.connect(self._apply_end_from_clipboard)
        btn_row.addWidget(btn_start)
        btn_row.addWidget(btn_end)
        layout.addRow(btn_row)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, MouseDragAction):
            self.spin_sx.setValue(action.start_x)
            self.spin_sy.setValue(action.start_y)
            self.spin_ex.setValue(action.end_x)
            self.spin_ey.setValue(action.end_y)
            self.group_expr.setChecked(
                bool(
                    (action.start_xy_expression or "").strip()
                    or (action.start_x_expression or "").strip()
                    or (action.start_y_expression or "").strip()
                    or (action.end_xy_expression or "").strip()
                    or (action.end_x_expression or "").strip()
                    or (action.end_y_expression or "").strip()
                )
            )
            self.edit_start_xy_expr.setText(action.start_xy_expression or "")
            self.edit_start_x_expr.setText(action.start_x_expression or "")
            self.edit_start_y_expr.setText(action.start_y_expression or "")
            self.edit_end_xy_expr.setText(action.end_xy_expression or "")
            self.edit_end_x_expr.setText(action.end_x_expression or "")
            self.edit_end_y_expr.setText(action.end_y_expression or "")
            self.spin_dur.setValue(action.duration_ms)
            self._sync_mouse_drag_screen_nav()

    def to_action_dict(self) -> dict[str, Any]:
        start_xy = self.edit_start_xy_expr.text().strip() if self.group_expr.isChecked() else ""
        start_x = self.edit_start_x_expr.text().strip() if self.group_expr.isChecked() else ""
        start_y = self.edit_start_y_expr.text().strip() if self.group_expr.isChecked() else ""
        end_xy = self.edit_end_xy_expr.text().strip() if self.group_expr.isChecked() else ""
        end_x = self.edit_end_x_expr.text().strip() if self.group_expr.isChecked() else ""
        end_y = self.edit_end_y_expr.text().strip() if self.group_expr.isChecked() else ""
        if start_xy:
            start_x = ""
            start_y = ""
        if end_xy:
            end_x = ""
            end_y = ""
        return {
            "start_x": self.spin_sx.value(),
            "start_y": self.spin_sy.value(),
            "end_x": self.spin_ex.value(),
            "end_y": self.spin_ey.value(),
            "start_xy_expression": start_xy or None,
            "start_x_expression": start_x or None,
            "start_y_expression": start_y or None,
            "end_xy_expression": end_xy or None,
            "end_x_expression": end_x or None,
            "end_y_expression": end_y or None,
            "duration_ms": self.spin_dur.value(),
        }

    def _apply_start_from_clipboard(self) -> None:
        """클립보드("x,y,#RRGGBB")에서 좌표를 읽어와 시작점에 적용한다."""
        text = get_active_capture_text(self._capture_history)
        if text is None:
            text = QGuiApplication.clipboard().text().strip()
        if not text:
            QMessageBox.warning(
                self,
                "F8 캡처 없음",
                "캡처된 좌표가 없습니다.\nF8을 눌러 좌표를 먼저 캡처하세요.",
            )
            return
        parsed = _parse_clipboard_xy(text)
        if parsed is None:
            _show_clipboard_format_error(self)
            return
        x, y = parsed
        self.spin_sx.setValue(x)
        self.spin_sy.setValue(y)
        self.param_changed.emit()

    def _apply_end_from_clipboard(self) -> None:
        """클립보드("x,y,#RRGGBB")에서 좌표를 읽어와 끝점에 적용한다."""
        text = get_active_capture_text(self._capture_history)
        if text is None:
            text = QGuiApplication.clipboard().text().strip()
        if not text:
            QMessageBox.warning(
                self,
                "F8 캡처 없음",
                "캡처된 좌표가 없습니다.\nF8을 눌러 좌표를 먼저 캡처하세요.",
            )
            return
        parsed = _parse_clipboard_xy(text)
        if parsed is None:
            _show_clipboard_format_error(self)
            return
        x, y = parsed
        self.spin_ex.setValue(x)
        self.spin_ey.setValue(y)
        self.param_changed.emit()

    def _sync_mouse_drag_screen_nav(self) -> None:
        ok = not self.group_expr.isChecked()
        self._btn_drag_cursor_start.setEnabled(ok)
        self._btn_drag_cursor_end.setEnabled(ok)
        self._btn_drag_flash.setEnabled(ok)

    def _on_drag_cursor_start(self) -> None:
        if self.group_expr.isChecked():
            return
        try_move_cursor_to(self, self.spin_sx.value(), self.spin_sy.value())

    def _on_drag_cursor_end(self) -> None:
        if self.group_expr.isChecked():
            return
        try_move_cursor_to(self, self.spin_ex.value(), self.spin_ey.value())

    def _on_drag_flash_drag_rect(self) -> None:
        if self.group_expr.isChecked():
            return
        self._mouse_drag_flash_ref = flash_screen_rect(
            self.spin_sx.value(),
            self.spin_sy.value(),
            self.spin_ex.value(),
            self.spin_ey.value(),
        )


class MouseScrollParamWidget(_BaseParamWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout(self)
        configure_param_form_layout(layout)
        self.spin_amount = QSpinBox()
        self.spin_amount.setRange(1, 10)
        self.spin_amount.setToolTip("스크롤 칸 수. 3=일반 스크롤 한 번 정도, 10=빠르게 많이 스크롤")
        self.combo_dir = QComboBox()
        self.combo_dir.addItems(["up", "down"])
        self.combo_dir.setToolTip(
            "up=위로 스크롤 (페이지 올리기), down=아래로 스크롤 (페이지 내리기)"
        )
        self.spin_amount.valueChanged.connect(self.param_changed.emit)
        self.combo_dir.currentTextChanged.connect(lambda: self.param_changed.emit())
        layout.addRow("스크롤 양 (칸 수):", self.spin_amount)
        layout.addRow("스크롤 방향:", self.combo_dir)

    def set_from_action(self, action: Action) -> None:
        if isinstance(action, MouseScrollAction):
            self.spin_amount.setValue(action.amount)
            self.combo_dir.setCurrentText(action.direction)

    def to_action_dict(self) -> dict[str, Any]:
        return {"amount": self.spin_amount.value(), "direction": self.combo_dir.currentText()}
