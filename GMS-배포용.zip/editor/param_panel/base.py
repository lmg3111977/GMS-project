"""파라미터 위젯 공통 베이스, 헬퍼 함수, 액션 설명 사전."""

from __future__ import annotations

import logging
from typing import Any

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QFormLayout, QLabel, QMessageBox, QWidget

from editor.widgets.help_text import REGION_HINT_STYLE as _REGION_HINT_STYLE
from shared.models import Action, ActionType

logger = logging.getLogger(__name__)


def _parse_clipboard_xy(text: str) -> tuple[int, int] | None:
    parts = text.split(",")
    if len(parts) < 2:
        return None
    try:
        return int(parts[0]), int(parts[1])
    except ValueError:
        return None


def _parse_clipboard_xy_color(text: str) -> tuple[int, int, str] | None:
    parts = text.split(",")
    if len(parts) < 3:
        return None
    try:
        x = int(parts[0])
        y = int(parts[1])
    except ValueError:
        return None
    return x, y, parts[2].strip()


def _show_clipboard_format_error(parent: QWidget) -> None:
    QMessageBox.warning(
        parent,
        "좌표 붙여넣기 실패",
        "클립보드 형식이 올바르지 않습니다.\n예시: 120,340,#A1B2C3",
    )


def get_active_capture_text(history: Any) -> str | None:
    """CaptureHistory에서 활성 항목 텍스트를 반환한다."""
    if history is None:
        return None
    entry = history.active
    return entry.to_clipboard_text() if entry is not None else None


# ── 파라미터 폼 UI 공통 (좁은 폭·긴 라벨 줄바꿈, 필드 확장) ──

REGION_HINT_IMAGE_SEARCH = (
    "이미지를 찾을 화면 영역을 지정합니다.\n"
    "「화면에서 드래그로 영역 선택」으로 마우스로 빠르게 잡거나, 아래 숫자로 직접 입력합니다.\n"
    "예: (100,100)~(300,300) → X1=100, Y1=100, X2=300, Y2=300\n"
    "전체 화면: (0,0)~(1920,1080) [FHD 기준]"
)

REGION_HINT_IMAGE_RECT_COMPACT = (
    "예: (100,100)~(500,400) 영역 → X1=100, Y1=100, X2=500, Y2=400\n"
    "「화면에서 드래그로 영역 선택」으로 잡거나 아래 숫자로 입력합니다.\n"
    "전체 화면: (0,0)~(1920,1080) [FHD]"
)

REGION_HINT_OCR_READ = (
    "텍스트를 인식할 화면 영역을 지정합니다.\n"
    "「화면에서 드래그로 영역 선택」으로 잡거나 아래 숫자로 입력합니다.\n"
    "영역을 최대한 좁게 설정하면 정확도와 속도가 향상됩니다."
)

REGION_HINT_OCR_WAIT = (
    "OCR로 읽을 화면 영역입니다.\n"
    "「화면에서 드래그로 영역 선택」으로 잡거나 아래 숫자로 입력합니다."
)


def configure_param_form_layout(layout: QFormLayout) -> None:
    """QFormLayout 정책 통일: 좁은 폭에서 라벨/필드 겹침 방지."""
    layout.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
    layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
    layout.setLabelAlignment(layout.labelAlignment())
    layout.setFormAlignment(layout.formAlignment())
    layout.setHorizontalSpacing(10)
    layout.setVerticalSpacing(8)


def region_hint_label(text: str) -> QLabel:
    """검색/OCR 영역 안내용 스타일이 적용된 줄바꿈 라벨."""
    lab = QLabel(text)
    lab.setWordWrap(True)
    lab.setStyleSheet(_REGION_HINT_STYLE)
    return lab


# FIX #7: 각 액션 타입별 설명 텍스트
ACTION_DESCRIPTIONS: dict[ActionType, str] = {
    ActionType.MOUSE_MOVE: "마우스를 지정 좌표로 이동합니다. 절대 좌표(화면 위치) 또는 상대 이동(현재 위치에서 이동량)을 선택할 수 있습니다. Duration > 0이면 부드럽게 이동합니다.",
    ActionType.MOUSE_CLICK: "마우스 버튼을 클릭합니다. count=2로 설정하면 더블클릭이 됩니다.",
    ActionType.MOUSE_DOWN: "마우스 버튼을 누른 상태로 유지합니다. 드래그 시작 시 사용합니다. 반드시 MouseUp과 짝으로 사용하세요.",
    ActionType.MOUSE_UP: "눌려있는 마우스 버튼을 뗍니다. 드래그 끝에 사용합니다.",
    ActionType.MOUSE_DRAG: "시작점에서 끝점까지 마우스를 드래그합니다.",
    ActionType.MOUSE_SCROLL: "마우스 휠을 위 또는 아래로 스크롤합니다.",
    ActionType.KEY_PRESS: "키보드 키를 한번 누르고 뗍니다. 일반적인 키 입력에 사용합니다.",
    ActionType.KEY_DOWN: "키를 누른 상태로 유지합니다. 조합키 시작 시 사용하며, 반드시 KeyUp과 짝으로 사용하세요.",
    ActionType.KEY_UP: "눌려있는 키를 뗍니다. KeyDown과 짝으로 사용합니다.",
    ActionType.KEY_COMBO: "Ctrl+C, Alt+Tab 같은 조합키를 입력합니다. 수정자 키를 체크하고 메인 키를 선택하세요.",
    ActionType.TYPE_TEXT: "문자열을 한 글자씩 타이핑합니다. 글자 간 간격을 조절할 수 있습니다.",
    ActionType.DELAY: "지정한 시간만큼 대기합니다. 랜덤 딜레이를 켜면 매번 다른 시간만큼 기다립니다.",
    ActionType.COMMENT: (
        "실행되지 않는 메모 줄입니다. 리스트에서 구간 제목·체크리스트·나중에 읽을 힌트만 남길 때 씁니다."
    ),
    ActionType.LOOP_START: (
        "좌측 버튼 이름은 For(Loop+)입니다. 반복 블록의 시작입니다.\n"
        "반복 횟수는 숫자·{변수} 식 또는 숫자 범위(start~end)로 줄 수 있고, -1이면 무한 반복입니다. "
        "EndFor(Loop-)와 짝을 맞춥니다."
    ),
    ActionType.LOOP_END: (
        "좌측 버튼 이름은 EndFor(Loop-)입니다. For(Loop+)와 짝을 이루는 반복의 끝입니다. "
        "남은 횟수가 있으면 For(Loop+)로 되돌아갑니다."
    ),
    ActionType.BREAK: (
        "가장 안쪽 For(Loop) 반복만 즉시 빠져나옵니다. 중첩 반복에서는 맨 안쪽만 종료됩니다.\n"
        "ImageSearch·ImageClick·PixelWait·ImageWait·OCR대기의 실패/타임아웃 처리에서 "
        "「break」를 고르면 이 액션과 같이 동작합니다(반복 안에서만 의미가 있습니다)."
    ),
    ActionType.ELSE: "조건이 거짓이거나 대기가 실패·타임아웃일 때 타는 구간의 시작 표시입니다. 단독으로는 의미가 없습니다.",
    ActionType.END_IF: "If·조건형 블록 한 덩어리의 끝 표시입니다.",
    ActionType.LABEL: "Goto의 점프 대상이 되는 이름표입니다. 실행 시 아무 동작도 하지 않고 통과합니다.",
    ActionType.GOTO: "지정한 Label 위치로 점프합니다. 루프를 만들거나 특정 위치로 이동할 때 사용합니다.",
    ActionType.IF_PIXEL: (
        "화면 한 점의 픽셀 색을 봅니다. 색 일치·색 변화(기준에서 벗어남) 모드를 고를 수 있습니다. "
        "추가 시 조건 헤더·Else·EndIf가 함께 만들어집니다. F8로 좌표·색을 넣을 수 있습니다."
    ),
    ActionType.PIXEL_WAIT: (
        "화면의 특정 좌표 픽셀이 지정 색상이 될 때까지, 또는 기준 색상에서 벗어날 때까지 대기합니다. "
        "변화 감지 기준은 입력 색상 또는 액션 실행 시점 색상 중 선택할 수 있습니다. "
        "성공은 then, 타임아웃은 else로 처리됩니다."
    ),
    ActionType.IMAGE_SEARCH: (
        "【이미지 찾기】 화면에서 템플릿 이미지를 검색합니다.\n\n"
        "▶ 사용법: 1) 찾을 이미지를 캡처하여 PNG로 저장 → 2) 템플릿 경로에 지정 → "
        "3) 검색 영역을 좁게 설정하면 속도 향상 → 4) 발견된 좌표는 변수에 자동 저장.\n\n"
        "▶ 성공은 then, 미발견은 else로 자동 분기됩니다."
    ),
    ActionType.SUB_MACRO_CALL: "다른 매크로 JSON 파일을 서브루틴처럼 호출합니다. 공통 동작을 재사용할 때 유용합니다.",
    ActionType.VARIABLE_SET: (
        "【VarSet / 변수 설정】 실행 중에 이름 붙은 문자열 변수를 만들거나 덮어씁니다. "
        "값은 항상 문자열로 저장되며, IfVariable·수식·Loop 횟수 등에서 참조합니다.\n\n"
        "▶ 전역 변수 이름은 서로 다른 이름 기준 최대 100개까지 쓸 수 있습니다.\n"
        "▶ 함수(FunctionDef~FunctionEnd) 안에서 VarSet한 이름은 그 함수 안에서만 유효하며, "
        "함수를 빠져나오면 그 로컬 값은 더 이상 보이지 않습니다.\n"
        "▶ 변수 이름: 영문·숫자·밑줄(_)만, 최대 30자. 같은 이름으로 다시 VarSet 하면 이전 값이 바뀝니다.\n"
        "▶ 값 vs 수식 (둘 중 하나만 씁니다)\n"
        "  · 수식 칸이 비어 있으면 → 「값」 칸의 문자열이 그대로 저장됩니다.\n"
        "  · 수식 칸에 무언가 적혀 있으면 → 「값」은 무시되고, 수식만 평가한 결과가 저장됩니다.\n"
        "▶ 수식 문법: 다른 변수는 반드시 {이름} 형태로 감쌉니다. 예: {cnt} + 1, ({img_x} + {img_y}) / 2\n"
        "  지원 연산: + - * / % // ** 와 괄호, 단항 + -.\n"
        "  아직 없는 변수는 0처럼 취급되어 계산될 수 있으니, 먼저 VarSet으로 초기화하는 습관이 안전합니다.\n"
        "▶ 흐름 예시\n"
        "  1) VarSet counter = 0\n"
        "  2) … 동작 …\n"
        "  3) VarSet counter 수식 {counter} + 1  → 반복마다 1씩 증가\n"
        "▶ 연계: ImageSearch의 발견 여부·좌표 변수, OCRRead의 store_var, LoopStart의 count_expression 등과 함께 쓰면 "
        "「찾았는지」「몇 번째인지」를 IfVariable로 나눌 수 있습니다."
    ),
    ActionType.IF_VARIABLE: (
        "【IfVar / 변수 조건】 저장된 변수 문자열을 읽어 비교합니다. 버튼으로 추가하면 if/else/end 구조로 분기됩니다.\n\n"
        "▶ 함수 블록 안에서는 같은 이름이 로컬에 있으면 로컬 값이 우선 읽힙니다.\n"
        "▶ 변수 이름: VarSet·ImageSearch·OCR 등이 값을 넣은 그 이름과 정확히 같아야 합니다(대소문자 구분).\n"
        '  없는 변수는 빈 문자열 ""으로 읽힙니다.\n'
        "▶ 비교 방식\n"
        "  · 「비교 값」도 먼저 {변수명} 치환과 숫자식(+ - * / % // ** 괄호) 평가를 시도합니다.\n"
        "  · 변수 값과 「비교 값」을 모두 숫자로 해석할 수 있으면 → 실수 비교(==, !=, >, <, >=, <=).\n"
        "  · 둘 중 하나라도 숫자가 아니면 → == / != 만 문자열 전체가 같은지 비교합니다.\n"
        "  · 숫자가 아닌데 >, < 등을 쓰면 엔진 동작이 직관과 다를 수 있으니, 플래그는 0·1 같은 숫자 문자열을 권장합니다.\n"
        "▶ 전형적인 패턴\n"
        "  · ImageSearch 후 발견 여부 변수가 1이면 then, 아니면 else.\n"
        "  · VarSet step = 2 후 IfVar step == 2 → 특정 구간만 실행.\n"
    ),
    ActionType.IMAGE_WAIT: (
        "【이미지 대기】 화면에 특정 이미지가 나타날 때까지 대기합니다.\n\n"
        "▶ 사용법: 로딩 화면, 팝업 등 특정 UI가 나타날 때까지 기다린 후 다음 동작을 실행.\n"
        "▶ 성공은 then, 타임아웃은 else로 자동 분기됩니다."
    ),
    ActionType.IMAGE_CLICK: (
        "【이미지 찾아 클릭】 이미지를 찾아서 즉시 클릭하는 복합 액션입니다.\n\n"
        "▶ ImageSearch + MouseClick을 한 번에 수행합니다.\n"
        "▶ 사용법: 버튼, 아이콘 등의 이미지를 지정하면 찾아서 자동 클릭.\n"
        "▶ 재시도: 찾을 때까지 여러 번 시도 가능 (max_retry 설정).\n"
        "▶ 성공은 then, 실패는 else로 자동 분기됩니다."
    ),
    ActionType.OCR_READ: (
        "【OCR 텍스트 읽기】 화면의 지정 영역에서 텍스트를 인식하여 변수에 저장합니다.\n\n"
        "▶ 사전 요구: Tesseract OCR 엔진이 시스템에 설치되어 있어야 합니다.\n"
        "▶ 사용법: 1) 영역 좌표를 설정 → 2) 인식 언어 콤보(영어/한국어/한국어+영어/숫자) 선택 → "
        "3) 인식된 텍스트가 변수에 저장됨.\n"
        "▶ 글자 배치(PSM): 기본값 7은 「한 줄로 된 글」에 맞춥니다. 대부분 그대로 두면 됩니다.\n"
        "▶ 허용 문자: 숫자만 읽을 때처럼 후보를 줄이면 헷갈림이 줄어듭니다. 자세한 설명은 해당 칸 툴팁을 보세요.\n"
        "▶ 팁: 영역을 글자에 맞게 좁게 잡고, 전처리(그레이스케일·반전·이진화)를 조절하면 정확도가 올라갑니다."
    ),
    ActionType.OCR_WAIT: (
        "【OCR 텍스트 대기】 화면에서 특정 텍스트가 나타날 때까지 대기합니다.\n\n"
        "▶ 사전 요구: Tesseract OCR 엔진이 시스템에 설치되어 있어야 합니다.\n"
        "▶ 사용법: 패턴(텍스트/정규식)을 설정하면 해당 텍스트가 나타날 때까지 주기적으로 OCR 스캔.\n"
        "▶ 활용: 로딩 완료 텍스트, 경고 메시지, 숫자 변화 감지 등.\n"
        "▶ 글자 배치(PSM)·허용 문자: OCR 읽기와 동일합니다. 각 칸에 마우스를 올리면 설명이 나옵니다.\n"
        "▶ 성공은 then, 타임아웃은 else로 자동 분기됩니다."
    ),
    ActionType.FUNCTION_DEF: (
        "【함수 정의 시작】반복해서 쓰는 액션 묶음을 이름 붙여 저장합니다.\n\n"
        "▶ 기본 순서: 함수 정의 추가 → 내부 액션 작성 → 반환(선택) → 함수 끝으로 닫기\n"
        "▶ 매개변수: 함수 내부에서 {이름} 형태로 사용합니다.\n"
        "▶ 예시: 이름 heal_if_low, 매개변수 hp, limit"
    ),
    ActionType.FUNCTION_END: (
        "【함수 정의 끝】함수 정의로 시작한 블럭을 닫습니다.\n\n"
        "▶ 규칙: 함수 정의 1개마다 함수 끝 1개가 필요합니다.\n"
        "▶ 팁: 본문 마지막에 반환을 두면 결과 전달이 명확해집니다."
    ),
    ActionType.FUNCTION_CALL: (
        "【함수 호출】미리 만든 함수를 실행합니다.\n\n"
        "▶ 함수 이름: 실행할 함수(정의할 때 적은 이름과 같아야 함)\n"
        "▶ 인자: 넘길 값 목록(쉼표 구분, 정의한 매개변수 순서와 같게)\n"
        "▶ 반환 변수: 함수가 돌려준 값을 저장할 변수 이름(선택)\n"
        "▶ 예시: 함수 이름 heal_if_low, 인자 {hp}, 30, 반환 변수 result"
    ),
    ActionType.RETURN: (
        "【함수 반환】함수 실행 결과를 호출한 쪽으로 돌려줍니다.\n\n"
        "▶ 예시: 1(성공), 0(실패), {hp}(현재 값)\n"
        "▶ 함수 호출에서 반환 변수를 적어 두어야, 다음 액션에서 그 값을 쓸 수 있습니다."
    ),
}


class _BaseParamWidget(QWidget):
    """파라미터 편집 위젯의 베이스 클래스."""

    param_changed = pyqtSignal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._capture_history: Any = None

    def set_capture_history(self, capture_history: Any) -> None:
        self._capture_history = capture_history

    def set_from_action(self, action: Action) -> None:
        raise NotImplementedError

    def to_action_dict(self) -> dict[str, Any]:
        raise NotImplementedError
