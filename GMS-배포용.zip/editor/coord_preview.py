"""에디터에서 화면 좌표 확인: OS 커서 이동 (숫자 좌표 전용)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from PyQt6.QtWidgets import QMessageBox

if TYPE_CHECKING:
    from PyQt6.QtWidgets import QWidget


def try_move_cursor_to(parent: QWidget | None, x: int, y: int) -> bool:
    """마우스 커서를 (x, y)로 이동. 실패 시 메시지 박스 후 False."""
    try:
        from pynput.mouse import Controller
    except ImportError:
        QMessageBox.warning(
            parent,
            "커서 이동 불가",
            "pynput 패키지가 필요합니다.\n프로젝트 의존성을 설치한 뒤 다시 시도하세요.",
        )
        return False
    try:
        Controller().position = (int(x), int(y))
        return True
    except OSError as exc:
        QMessageBox.warning(parent, "커서 이동 실패", f"OS 오류: {exc}")
        return False
