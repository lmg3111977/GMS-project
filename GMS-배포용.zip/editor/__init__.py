"""GameMacroStudio 매크로 에디터 패키지.

Sequential Action List 기반 매크로 생성/편집 UI를 제공한다.
PyQt6 기반이며, 위젯·메인 윈도우 등은 shared 모델만 직접 다룬다.

`editor.session`은 앱 런처와 엔진(MacroRunner) 사이의 어댑터로,
GUI 모드에서만 engine을 import한다 (위젯 모듈에서 engine 의존 금지).
"""
