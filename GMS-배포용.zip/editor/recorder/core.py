from __future__ import annotations

import logging
import sys
import time
from typing import Any

from shared.models import Action, DelayAction

from .constants import MIN_DELAY_MS
from .keyboard_handler import KeyboardHandlerMixin
from .mouse_handler import MouseHandlerMixin

logger = logging.getLogger(__name__)


class MacroRecorder(MouseHandlerMixin, KeyboardHandlerMixin):
    """매크로 녹화기."""

    def __init__(self) -> None:
        self._is_recording: bool = False
        self._actions: list[Action] = []
        self._last_event_time: float = 0.0
        self._last_recorded_pos: tuple[int, int] = (0, 0)
        self._mouse_listener: Any = None
        self._keyboard_listener: Any = None
        self._pressed_modifiers: set[str] = set()
        self._mouse_down: bool = False
        self._mouse_down_pos: tuple[int, int] = (0, 0)
        self._mouse_down_button: str = "LEFT"
        self._mouse_current_pos: tuple[int, int] = (0, 0)
        self._last_click_time: float = 0.0
        self._last_click_pos: tuple[int, int] = (0, 0)
        self._last_click_button: str = "LEFT"

    @property
    def is_recording(self) -> bool:
        return self._is_recording

    def start_recording(self) -> None:
        if self._is_recording:
            return
        try:
            from pynput import keyboard, mouse
        except ImportError:
            logger.error("pynput이 설치되지 않았습니다")
            return

        self._actions = []
        self._last_event_time = time.monotonic()
        self._pressed_modifiers.clear()
        self._mouse_down = False
        self._is_recording = True
        self._last_recorded_pos = self._get_current_mouse_pos()
        self._mouse_current_pos = self._last_recorded_pos

        self._mouse_listener = mouse.Listener(
            on_click=self._on_mouse_click,
            on_scroll=self._on_mouse_scroll,
            on_move=self._on_mouse_move,
        )
        self._keyboard_listener = keyboard.Listener(
            on_press=self._on_key_press,
            on_release=self._on_key_release,
        )

        self._mouse_listener.start()
        self._keyboard_listener.start()
        logger.info("매크로 녹화 시작")

    def stop_recording(self) -> list[Action]:
        if not self._is_recording:
            return []
        self._is_recording = False

        if self._mouse_listener:
            self._mouse_listener.stop()
            self._mouse_listener = None
        if self._keyboard_listener:
            self._keyboard_listener.stop()
            self._keyboard_listener = None

        result = list(self._actions)
        self._actions = []
        logger.info("매크로 녹화 정지: %d개 액션 캡처됨", len(result))
        return result

    def _add_delay(self) -> None:
        now = time.monotonic()
        elapsed_ms = int((now - self._last_event_time) * 1000)
        if elapsed_ms >= MIN_DELAY_MS:
            self._actions.append(DelayAction(ms=elapsed_ms))
        self._last_event_time = now

    @staticmethod
    def _get_current_mouse_pos() -> tuple[int, int]:
        try:
            if sys.platform.startswith("win"):
                import ctypes
                from ctypes import wintypes

                point = wintypes.POINT()
                if ctypes.windll.user32.GetCursorPos(ctypes.byref(point)):
                    return (int(point.x), int(point.y))
        except Exception:
            pass
        return (0, 0)
