import math
import time
from typing import Any

from shared.models import (
    MouseButton,
    MouseClickAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
)

from .constants import DRAG_THRESHOLD, _calculate_duration


class MouseHandlerMixin:
    @staticmethod
    def _resolve_button(button: Any) -> str:
        button_str = str(button).lower()
        if "right" in button_str:
            return "RIGHT"
        elif "middle" in button_str:
            return "MIDDLE"
        return "LEFT"

    def _add_move_to(self, x: int, y: int) -> None:
        prev_x, prev_y = self._last_recorded_pos
        dx = x - prev_x
        dy = y - prev_y
        distance = math.sqrt(dx * dx + dy * dy)
        if distance < 3:
            return
        duration = _calculate_duration(distance)
        self._actions.append(MouseMoveAction(x=x, y=y, is_relative=False, duration_ms=duration))
        self._last_recorded_pos = (x, y)

    def _on_mouse_move(self, x: int, y: int) -> None:
        """드래그 추적용으로만 사용. 일반 이동은 기록하지 않는다."""
        if not self._is_recording:
            return
        self._mouse_current_pos = (x, y)

    def _on_mouse_click(self, x: int, y: int, button: Any, pressed: bool) -> None:
        if not self._is_recording:
            return

        button_name = self._resolve_button(button)

        if pressed:
            self._mouse_down = True
            self._mouse_down_pos = (x, y)
            self._mouse_down_button = button_name
            self._mouse_current_pos = (x, y)
        else:
            if self._mouse_down:
                self._mouse_down = False
                dx = x - self._mouse_down_pos[0]
                dy = y - self._mouse_down_pos[1]
                distance = math.sqrt(dx * dx + dy * dy)

                if distance >= DRAG_THRESHOLD:
                    self._add_delay()
                    self._actions.append(
                        MouseDragAction(
                            start_x=self._mouse_down_pos[0],
                            start_y=self._mouse_down_pos[1],
                            end_x=x,
                            end_y=y,
                            duration_ms=_calculate_duration(distance),
                        )
                    )
                    self._last_recorded_pos = (x, y)
                    self._last_click_time = 0.0
                else:
                    now = time.monotonic()
                    click_x, click_y = self._mouse_down_pos
                    is_double = (
                        hasattr(self, "_last_click_time")
                        and (now - self._last_click_time) < 0.3
                        and hasattr(self, "_last_click_pos")
                        and abs(click_x - self._last_click_pos[0]) < 5
                        and abs(click_y - self._last_click_pos[1]) < 5
                        and hasattr(self, "_last_click_button")
                        and self._last_click_button == button_name
                    )

                    if is_double and self._actions:
                        last = self._actions[-1]
                        if isinstance(last, MouseClickAction) and last.count < 5:
                            self._actions[-1] = MouseClickAction(
                                button=MouseButton(button_name),
                                count=last.count + 1,
                            )
                            self._last_click_time = now
                            self._last_click_pos = (click_x, click_y)
                            return

                    self._add_delay()
                    self._add_move_to(click_x, click_y)
                    self._actions.append(MouseClickAction(button=MouseButton(button_name), count=1))
                    self._last_recorded_pos = (click_x, click_y)
                    self._last_click_time = now
                    self._last_click_pos = (click_x, click_y)
                    self._last_click_button = button_name

    def _on_mouse_scroll(self, x: int, y: int, dx: int, dy: int) -> None:
        if not self._is_recording:
            return
        self._add_delay()
        self._add_move_to(x, y)
        direction = "up" if dy > 0 else "down"
        amount = max(1, min(10, abs(dy)))
        self._actions.append(MouseScrollAction(amount=amount, direction=direction))
        self._last_recorded_pos = (x, y)
