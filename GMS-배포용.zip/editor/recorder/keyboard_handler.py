from typing import Any

from shared.models import KeyComboAction, KeyPressAction

from .constants import _IGNORE_KEY_NAMES, _KEY_NAME_MAP, _MODIFIER_PYNPUT_MAP


class KeyboardHandlerMixin:
    @staticmethod
    def _get_pynput_name(key: Any) -> str:
        """pynput 키 객체에서 내부 이름을 추출한다."""
        try:
            if hasattr(key, "name") and key.name:
                return key.name
        except AttributeError:
            pass
        return ""

    @staticmethod
    def _resolve_key_name(key: Any) -> str:
        """pynput 키 객체를 keymap 이름 문자열로 변환한다."""
        try:
            if hasattr(key, "char") and key.char:
                return key.char
            elif hasattr(key, "name") and key.name:
                return _KEY_NAME_MAP.get(key.name, key.name)
        except AttributeError:
            pass
        return ""

    def _on_key_press(self, key: Any) -> None:
        if not self._is_recording:
            return

        pynput_name = self._get_pynput_name(key)

        if "ctrl" in pynput_name.lower() if pynput_name else False:
            pass
        if self._pressed_modifiers and pynput_name == "":
            try:
                if hasattr(key, "char") and key.char == "r" and "Ctrl" in self._pressed_modifiers:
                    return
            except AttributeError:
                pass

        if pynput_name in _MODIFIER_PYNPUT_MAP:
            modifier_name = _MODIFIER_PYNPUT_MAP[pynput_name]
            self._pressed_modifiers.add(modifier_name)
            return

        if pynput_name in _IGNORE_KEY_NAMES:
            return

        key_name = self._resolve_key_name(key)
        if not key_name:
            return

        self._add_delay()

        if self._pressed_modifiers:
            self._actions.append(
                KeyComboAction(
                    modifiers=sorted(self._pressed_modifiers),
                    key=key_name,
                )
            )
        else:
            self._actions.append(KeyPressAction(key=key_name))

    def _on_key_release(self, key: Any) -> None:
        if not self._is_recording:
            return

        pynput_name = self._get_pynput_name(key)

        if pynput_name in _MODIFIER_PYNPUT_MAP:
            modifier_name = _MODIFIER_PYNPUT_MAP[pynput_name]
            self._pressed_modifiers.discard(modifier_name)
