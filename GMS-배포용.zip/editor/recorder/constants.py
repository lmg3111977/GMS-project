MIN_DELAY_MS: int = 30
DRAG_THRESHOLD: int = 10  # 이 거리 이상 이동해야 드래그로 판정

_IGNORE_KEY_NAMES: set[str] = {
    "f5",
    "f6",
    "f7",
}

_MODIFIER_PYNPUT_MAP: dict[str, str] = {
    "ctrl_l": "Ctrl",
    "ctrl_r": "Ctrl",
    "shift": "Shift",
    "shift_r": "Shift",
    "alt_l": "Alt",
    "alt_r": "Alt",
    "cmd": "Win",
    "cmd_r": "Win",
}

_KEY_NAME_MAP: dict[str, str] = {
    **_MODIFIER_PYNPUT_MAP,
    "enter": "Enter",
    "return": "Enter",
    "space": "Space",
    "tab": "Tab",
    "backspace": "Backspace",
    "delete": "Delete",
    "escape": "Esc",
    "esc": "Esc",
    "up": "Up",
    "down": "Down",
    "left": "Left",
    "right": "Right",
    "home": "Home",
    "end": "End",
    "page_up": "PageUp",
    "page_down": "PageDown",
    "insert": "Insert",
    "caps_lock": "CapsLock",
    "f1": "F1",
    "f2": "F2",
    "f3": "F3",
    "f4": "F4",
    "f5": "F5",
    "f6": "F6",
    "f7": "F7",
    "f8": "F8",
    "f9": "F9",
    "f10": "F10",
    "f11": "F11",
    "f12": "F12",
}


def _calculate_duration(distance: float) -> int:
    """이동 거리에 따른 자연스러운 이동 시간(ms)을 계산한다."""
    if distance <= 0:
        return 0
    ms = int(40 + distance * 0.35)
    return max(80, min(600, ms))
