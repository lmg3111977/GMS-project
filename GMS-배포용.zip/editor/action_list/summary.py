"""액션 요약 문자열 생성 유틸."""

from __future__ import annotations

import re
from html import escape

from shared.models import (
    Action,
    ActionType,
    CommentAction,
    DelayAction,
    ElseAction,
    EndIfAction,
    FunctionCallAction,
    FunctionDefAction,
    FunctionEndAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    KeyComboAction,
    KeyDownAction,
    KeyPressAction,
    KeyUpAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    MouseClickAction,
    MouseDownAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
    MouseUpAction,
    OCRReadAction,
    OCRWaitAction,
    PixelWaitAction,
    ReturnAction,
    SubMacroCallAction,
    TypeTextAction,
    VariableSetAction,
)


def get_action_summary(action: Action) -> str:
    """액션의 한 줄 요약 텍스트를 생성한다."""
    if isinstance(action, MouseMoveAction):
        mode = "상대" if action.is_relative else "절대"
        if (action.xy_expression or "").strip():
            return f"MouseMove XY식='{action.xy_expression}' [{mode}] {action.duration_ms}ms"
        x_expr = (action.x_expression or "").strip()
        y_expr = (action.y_expression or "").strip()
        if x_expr or y_expr:
            x_part = x_expr or str(action.x)
            y_part = y_expr or str(action.y)
            return f"MouseMove 식=({x_part}, {y_part}) [{mode}] {action.duration_ms}ms"
        return f"MouseMove ({action.x}, {action.y}) [{mode}] {action.duration_ms}ms"
    if isinstance(action, MouseClickAction):
        return f"MouseClick {action.button} x{action.count}"
    if isinstance(action, MouseScrollAction):
        return f"Scroll {action.direction} x{action.amount}"
    if isinstance(action, KeyPressAction):
        return f"KeyPress '{action.key}'"
    if isinstance(action, KeyComboAction):
        mods = "+".join(action.modifiers)
        return f"KeyCombo {mods}+{action.key}"
    if isinstance(action, TypeTextAction):
        preview = action.text[:20] + ("..." if len(action.text) > 20 else "")
        return f'TypeText "{preview}"'
    if isinstance(action, DelayAction):
        if action.random_min is not None and action.random_max is not None:
            return f"Delay {action.random_min}~{action.random_max}ms (기본 {action.ms}ms)"
        return f"Delay {action.ms}ms"
    if isinstance(action, CommentAction):
        text = (action.comment or "").strip()
        if not text:
            return "-------- 구간 메모 --------"
        if text.startswith("-"):
            return text
        return f"-------- {text} --------"
    if isinstance(action, LoopStartAction):
        if (
            action.range_start_expression is not None
            and action.range_start_expression.strip()
            and action.range_end_expression is not None
            and action.range_end_expression.strip()
        ):
            start_s = action.range_start_expression.strip()
            end_s = action.range_end_expression.strip()
            op = "<=" if action.range_end_inclusive else "<"
            count_part = f"범위: {start_s}..{end_s} ({op})"
        elif (raw_expr := action.count_expression) is not None and raw_expr.strip():
            e = raw_expr.strip()
            short = e[:28] + ("…" if len(e) > 28 else "")
            count_part = f"식: {short}"
        else:
            count_part = "무한 반복" if action.count == -1 else f"{action.count}회"
        label_str = f" '{action.label}'" if action.label else ""
        return f"Loop Start{label_str} ({count_part})"
    if isinstance(action, LoopEndAction):
        return "Loop End"
    if action.type == ActionType.BREAK:
        return "Break"
    if isinstance(action, ElseAction):
        return "Else"
    if isinstance(action, EndIfAction):
        return "EndIf"
    if isinstance(action, LabelAction):
        return f"Label: {action.name}"
    if isinstance(action, GotoAction):
        return f"Goto -> {action.target}"
    if isinstance(action, IfPixelAction):
        mode = "변화" if action.detect_change else "일치"
        if (action.xy_expression or "").strip():
            return f"IfPixel[{mode}] XY식={action.xy_expression} {action.color}"
        if (action.x_expression or "").strip() or (action.y_expression or "").strip():
            x_part = (action.x_expression or "").strip() or str(action.x)
            y_part = (action.y_expression or "").strip() or str(action.y)
            return f"IfPixel[{mode}] ({x_part},{y_part}) {action.color}"
        return f"IfPixel[{mode}] ({action.x},{action.y}) {action.color}"
    if isinstance(action, PixelWaitAction):
        if action.detect_change:
            mode = "변화대기/시작색" if action.change_reference == "runtime" else "변화대기/입력색"
        else:
            mode = "일치대기"
        if (action.xy_expression or "").strip():
            return f"PixelWait[{mode}] XY식={action.xy_expression} {action.timeout_ms}ms"
        if (action.x_expression or "").strip() or (action.y_expression or "").strip():
            x_part = (action.x_expression or "").strip() or str(action.x)
            y_part = (action.y_expression or "").strip() or str(action.y)
            return f"PixelWait[{mode}] ({x_part},{y_part}) {action.timeout_ms}ms"
        return f"PixelWait[{mode}] ({action.x},{action.y}) {action.timeout_ms}ms"
    if isinstance(action, ImageSearchAction):
        name = action.template_path.split("/")[-1] if action.template_path else "(미지정)"
        extra = []
        if action.grayscale:
            extra.append("GS")
        if action.click_on_found:
            extra.append("클릭")
        if action.move_on_found:
            extra.append("이동")
        if action.max_retry > 1:
            extra.append(f"{action.max_retry}회")
        extra_str = f" [{','.join(extra)}]" if extra else ""
        return f"ImgSearch '{name}' conf≥{action.confidence:.2f}{extra_str}"
    if isinstance(action, VariableSetAction):
        if action.expression:
            return f"Set {action.var_name} = {action.expression}"
        return f"Set {action.var_name} = {action.value}"
    if isinstance(action, IfVariableAction):
        return f"If {action.var_name} {action.operator} {action.compare_value}"
    if isinstance(action, ImageWaitAction):
        name = action.template_path.split("/")[-1] if action.template_path else "(미지정)"
        return f"ImgWait '{name}' {action.timeout_ms}ms"
    if isinstance(action, ImageClickAction):
        name = action.template_path.split("/")[-1] if action.template_path else "(미지정)"
        return f"ImgClick '{name}' {action.click_button}"
    if isinstance(action, OCRReadAction):
        return f"OCRRead ({action.region_x},{action.region_y}) → {action.store_var}"
    if isinstance(action, OCRWaitAction):
        pattern_preview = action.pattern[:15] + ("..." if len(action.pattern) > 15 else "")
        mode = "정규식" if action.use_regex else "텍스트"
        return f"OCRWait '{pattern_preview}' [{mode}] {action.timeout_ms}ms"
    if isinstance(action, MouseDownAction):
        return f"MouseDown {action.button}"
    if isinstance(action, MouseUpAction):
        return f"MouseUp {action.button}"
    if isinstance(action, MouseDragAction):
        if (action.start_xy_expression or "").strip() or (action.end_xy_expression or "").strip():
            s = (action.start_xy_expression or "").strip() or f"{action.start_x},{action.start_y}"
            e = (action.end_xy_expression or "").strip() or f"{action.end_x},{action.end_y}"
            return f"Drag {s}→{e} {action.duration_ms}ms"
        return (
            f"Drag ({action.start_x},{action.start_y})→"
            f"({action.end_x},{action.end_y}) {action.duration_ms}ms"
        )
    if isinstance(action, KeyDownAction):
        return f"KeyDown '{action.key}'"
    if isinstance(action, KeyUpAction):
        return f"KeyUp '{action.key}'"
    if isinstance(action, SubMacroCallAction):
        name = action.macro_path.split("/")[-1] if action.macro_path else "(미지정)"
        return f"SubMacro '{name}'"
    if isinstance(action, FunctionDefAction):
        params_str = ", ".join(action.params) if action.params else ""
        return f"함수 정의 {action.name}({params_str})"
    if isinstance(action, FunctionEndAction):
        return "함수 끝"
    if isinstance(action, FunctionCallAction):
        args_str = ", ".join(action.args) if action.args else ""
        ret = f" → 반환:{action.return_var}" if action.return_var else ""
        return f"함수 호출 {action.target}({args_str}){ret}"
    if isinstance(action, ReturnAction):
        return f"반환 {action.expression}" if action.expression else "반환"
    return str(action.type)


_HL_COLOR = "#4f46e5"
_PARAM_PATTERN = re.compile(
    r"\d+ms\b"  # 300ms
    r"|\bx\d+\b"  # x3
    r"|\d+회"  # 10회
    r"|conf≥[\d.]+"  # conf≥0.85
    r"|'[^']*'"  # 'Enter'
    r"|\"[^\"]*\""  # "hello"
    r"|\([\d,.\s]+\)",  # (150, 200)
)


def highlight_params(text: str) -> str:
    """요약 텍스트에서 핵심 파라미터를 볼드+인디고 색상으로 강조한 HTML을 반환한다."""
    safe = escape(text, quote=False)

    def _wrap(match: re.Match[str]) -> str:
        return f"<b style='color:{_HL_COLOR}'>{match.group(0)}</b>"

    return _PARAM_PATTERN.sub(_wrap, safe)
