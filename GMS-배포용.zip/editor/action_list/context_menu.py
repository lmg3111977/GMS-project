"""우클릭 메뉴/브레이크포인트/구조형 변환 mixin."""

from __future__ import annotations

from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QMenu

from shared.models import (
    Action,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    OCRWaitAction,
    PixelWaitAction,
)

from .structure import is_struct_if_action, struct_if_with_shared_field_copy


class ContextMenuMixin:
    """컨텍스트 메뉴 관련 동작."""

    def _show_context_menu(self, position: object) -> None:
        menu = QMenu(self)
        pos = position
        item = self.itemAt(pos)  # type: ignore[arg-type]
        if item is not None:
            self.setCurrentItem(item)
            self._context_menu_row = self.row(item)
        else:
            self._context_menu_row = self.currentRow()

        if self.currentRow() >= 0:
            current = self._actions[self.currentRow()]
            dup = QAction("복제 (Ctrl+D, 다중 선택 시 각 행)", self)
            dup.triggered.connect(self.duplicate_selected)
            menu.addAction(dup)

            delete = QAction("삭제 (Delete)", self)
            delete.triggered.connect(self.remove_selected)
            menu.addAction(delete)

            if is_struct_if_action(current):
                convert_menu = menu.addMenu("조건 타입 변환")
                convert_items: list[tuple[str, type[Action]]] = [
                    ("IfPixel", IfPixelAction),
                    ("IfVar", IfVariableAction),
                    ("PixWait", PixelWaitAction),
                    ("ImgSearch", ImageSearchAction),
                    ("ImgWait", ImageWaitAction),
                    ("ImgClick", ImageClickAction),
                    ("OCRWait", OCRWaitAction),
                ]
                for label, action_cls in convert_items:
                    act = QAction(label, self)
                    act.triggered.connect(
                        lambda checked=False, cls=action_cls: self._convert_current_struct_if(cls)
                    )
                    convert_menu.addAction(act)

            toggle = QAction("활성/비활성 토글", self)
            toggle.triggered.connect(self.toggle_selected_enabled)
            menu.addAction(toggle)

            menu.addSeparator()
            bp_action = QAction("브레이크포인트 토글", self)
            bp_action.triggered.connect(self._toggle_breakpoint_current)
            menu.addAction(bp_action)

            linked_rows = self.get_linked_if_rows(self.currentRow())
            if len(linked_rows) > 1:
                menu.addSeparator()
                select_linked = QAction("연결된 블록 모두 선택", self)
                select_linked.triggered.connect(self._select_current_linked_if_rows)
                menu.addAction(select_linked)
                next_linked = QAction("연결 블록 다음 위치로 이동", self)
                next_linked.triggered.connect(self._jump_to_next_linked_if_row)
                menu.addAction(next_linked)

        menu.exec(self.mapToGlobal(position))  # type: ignore[arg-type]

    def _toggle_breakpoint_current(self) -> None:
        """현재 선택 액션의 브레이크포인트를 토글한다."""
        row = self.currentRow()
        if not (0 <= row < len(self._actions)):
            return
        self.action_list_about_to_modify.emit()
        action_id = self._actions[row].action_id
        if action_id in self._breakpoint_action_ids:
            self._breakpoint_action_ids.remove(action_id)
        else:
            self._breakpoint_action_ids.add(action_id)
        self._apply_debug_visuals()
        self.breakpoints_changed.emit(sorted(self.get_breakpoint_indices()))

    def _convert_current_struct_if(self, action_cls: type[Action]) -> None:
        """현재 선택된 구조형 if 헤더 액션을 다른 타입으로 교체한다."""
        row = self.currentRow()
        self.convert_struct_if_row(row, action_cls)

    def convert_struct_if_row(self, row: int, action_cls: type[Action]) -> bool:
        """지정 행의 구조형 if 헤더 액션을 다른 타입으로 교체한다."""
        if not (0 <= row < len(self._actions)):
            return False
        current = self._actions[row]
        if not is_struct_if_action(current):
            return False
        if isinstance(current, action_cls):
            return False

        converted = struct_if_with_shared_field_copy(current, action_cls)
        self.action_list_about_to_modify.emit()
        self._actions[row] = converted
        self._rebuild_list()
        self.setCurrentRow(row)
        self.action_selected.emit(row)
        self.action_list_modified.emit()
        return True
