"""선택/활성 상태 관련 mixin."""

from __future__ import annotations

from PyQt6.QtCore import QItemSelectionModel
from PyQt6.QtWidgets import QAbstractItemView


class SelectionMixin:
    """행 선택, 연결 블록 선택/이동 관련 동작."""

    def _hover_group_rows(self, row: int) -> set[int]:
        if row < 0:
            return set()
        if row in self._if_group_rows_by_row:
            return set(self._if_group_rows_by_row[row])
        return {row}

    def set_hover_row(self, row: int) -> None:
        """마우스 오버 행(및 연결 블록)을 하이라이트한다."""
        if row == self._hover_row:
            return
        prev_rows = self._hover_group_rows(self._hover_row)
        self._hover_row = row
        next_rows = self._hover_group_rows(self._hover_row)
        for idx in prev_rows.union(next_rows):
            if 0 <= idx < self.count():
                self._apply_row_background(idx)

    def get_linked_if_rows(self, row: int) -> list[int]:
        """주어진 행과 연결된 구조형 if/else/end 행 목록을 반환한다."""
        if row < 0:
            return []
        if row in self._if_group_rows_by_row:
            return sorted(self._if_group_rows_by_row[row])
        return [row] if row < len(self._actions) else []

    def _on_row_changed(self, current_row: int) -> None:
        prev_selected = self._selected_row
        self._selected_row = current_row
        for idx in self._hover_group_rows(prev_selected).union(self._hover_group_rows(current_row)):
            if 0 <= idx < self.count():
                self._apply_row_background(idx)
        if 0 <= current_row < len(self._actions):
            current_action = self._actions[current_row]
            if (
                self._recent_action_id is not None
                and current_action.action_id != self._recent_action_id
            ):
                self._recent_action_id = None
                self._apply_debug_visuals()
        if 0 <= current_row < len(self._actions):
            self.action_selected.emit(current_row)

    def _select_current_linked_if_rows(self) -> None:
        """현재 행과 연결된 If/Else/End 행을 모두 선택한다."""
        row = self._context_menu_row if self._context_menu_row >= 0 else self.currentRow()
        linked = self.get_linked_if_rows(row)
        if len(linked) <= 1:
            return
        self.clearSelection()
        sm = self.selectionModel()
        if sm is None:
            return
        for idx in linked:
            it = self.item(idx)
            if it is None:
                continue
            sm.select(self.indexFromItem(it), QItemSelectionModel.SelectionFlag.Select)

        current_item = self.item(row)
        if current_item is not None:
            sm.setCurrentIndex(
                self.indexFromItem(current_item),
                QItemSelectionModel.SelectionFlag.Current
                | QItemSelectionModel.SelectionFlag.NoUpdate,
            )

    def _jump_to_next_linked_if_row(self) -> None:
        """현재 연결 블록의 다음 행(If→Else→End)을 순환 이동한다."""
        row = self.currentRow()
        linked = self.get_linked_if_rows(row)
        if len(linked) <= 1:
            return
        try:
            pos = linked.index(row)
        except ValueError:
            pos = 0
        next_row = linked[(pos + 1) % len(linked)]
        self.setCurrentRow(next_row)
        item = self.item(next_row)
        if item is not None:
            self.scrollToItem(item, QAbstractItemView.ScrollHint.PositionAtCenter)
