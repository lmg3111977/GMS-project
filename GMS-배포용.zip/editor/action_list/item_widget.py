"""액션 리스트 개별 행 위젯."""

from __future__ import annotations

from html import escape
from typing import TYPE_CHECKING

from PyQt6.QtCore import QItemSelectionModel, QRect, Qt
from PyQt6.QtGui import QFont, QFontMetrics, QMouseEvent, QResizeEvent
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QToolButton,
    QWidget,
)

from shared.models import Action, CommentAction, ElseAction, EndIfAction

from .constants import _INDENT_PX, ACTION_CATEGORY, ACTION_COLORS
from .summary import get_action_summary, highlight_params

if TYPE_CHECKING:
    from .core import ActionListWidget


def _is_separator_action(action: Action) -> bool:
    """Comment 액션은 항상 구분선 형태로 표시한다."""
    return isinstance(action, CommentAction)


def _extract_separator_title(action: Action) -> str:
    """구분줄 주석에서 제목 텍스트를 추출한다."""
    comment = (action.comment or "").strip()
    if not isinstance(action, CommentAction):
        return comment.strip("-").strip() or "구간 메모"
    if not comment:
        return "구간 메모"
    return comment.strip("-").strip() or comment


class ActionItemWidget(QWidget):
    """액션 리스트의 개별 항목 위젯."""

    def __init__(
        self,
        action: Action,
        index: int,
        indent_level: int = 0,
        list_widget: ActionListWidget | None = None,
        is_collapsible: bool = False,
        is_collapsed: bool = False,
        block_tag: str | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self._action = action
        self._index = index
        self._list_widget = list_widget
        self._is_collapsible = is_collapsible
        self._is_collapsed = is_collapsed
        self._separator_title_label: QLabel | None = None
        self._separator_title_full: str | None = None
        self._row_kind: str = "normal"

        # ── 구분줄 전용 레이아웃 ──
        if _is_separator_action(action):
            self._row_kind = "separator"
            layout_sep = QHBoxLayout(self)
            layout_sep.setContentsMargins(4, 2, 4, 2)
            layout_sep.setSpacing(6)
            self._build_separator_layout(layout_sep, action)
            self.setStyleSheet("ActionItemWidget { border-bottom: 1px solid #f0f0f0; }")
            return

        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 2, 4, 2)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        # ── 왼쪽 카테고리 컬러 바 ──
        category = ACTION_CATEGORY.get(action.type, "variable")
        color = ACTION_COLORS.get(category, "#888")

        _transparent = Qt.WidgetAttribute.WA_TransparentForMouseEvents

        left_gutter = QLabel("", self)
        left_gutter.setFixedWidth(12)
        left_gutter.setAttribute(_transparent)
        layout.addWidget(left_gutter)

        color_bar = QFrame(self)
        color_bar.setFixedWidth(3)
        color_bar.setStyleSheet(f"background-color: {color}; border-radius: 1px;")
        color_bar.setAttribute(_transparent)
        layout.addWidget(color_bar)

        if is_collapsible:
            fold_btn = QToolButton(self)
            fold_btn.setText("▸" if is_collapsed else "▾")
            fold_btn.setFixedWidth(18)
            fold_btn.setStyleSheet("border: none; color: #9e9a96;")
            fold_font = QFont(fold_btn.font())
            fold_font.setPointSize(9)
            fold_btn.setFont(fold_font)
            fold_btn.clicked.connect(self._on_fold_clicked)
            layout.addWidget(fold_btn)
        else:
            spacer = QLabel("")
            spacer.setFixedWidth(18)
            spacer.setAttribute(_transparent)
            layout.addWidget(spacer)

        idx_label = QLabel(f"#{index:02d}")
        idx_label.setFixedWidth(32)
        idx_label.setStyleSheet("color: #9e9a96; font-size: 11px;")
        idx_label.setAttribute(_transparent)
        layout.addWidget(idx_label)

        # ── 배지 (60px → 80px, 12자까지 표시) ──
        type_short = action.type.value.replace("_", " ").title()[:12]
        badge = QLabel(type_short)
        badge.setFixedWidth(80)
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setStyleSheet(
            f"background-color: {color}; color: white; "
            f"border-radius: 3px; font-size: 10px; font-weight: bold; padding: 2px;"
        )
        badge.setAttribute(_transparent)
        layout.addWidget(badge)

        # ── 요약 텍스트 (파라미터 하이라이트) ──
        summary_text = get_action_summary(action)
        if block_tag:
            summary_text = f"{summary_text}  [{block_tag}]"

        comment_display = ""
        if action.comment:
            ct = action.comment.strip()
            if not ct.startswith("--------"):
                comment_display = ct

        self._combined_plain = (
            f"{summary_text}  ·  {comment_display}" if comment_display else summary_text
        )

        self._summary_label = QLabel()
        self._summary_label.setAttribute(_transparent)
        self._summary_label.setWordWrap(True)
        self._summary_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self._summary_label.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred
        )
        summary_style = f"font-size: 12px; padding-left: {max(0, indent_level) * _INDENT_PX}px;"

        if not action.enabled:
            self._summary_label.setTextFormat(Qt.TextFormat.PlainText)
            self._summary_label.setText(self._combined_plain)
            self._summary_label.setStyleSheet(
                summary_style + " color: #c4b8aa; text-decoration: line-through;"
            )
        elif isinstance(action, (ElseAction, EndIfAction)):
            self._summary_label.setTextFormat(Qt.TextFormat.PlainText)
            self._summary_label.setText(self._combined_plain)
            self._summary_label.setStyleSheet(summary_style + " color: #6b6360;")
        else:
            self._summary_label.setTextFormat(Qt.TextFormat.RichText)
            if comment_display:
                body = (
                    highlight_params(summary_text)
                    + '<span style="color:#5a524a;font-size:11px;font-style:italic;'
                    'font-weight:500">&nbsp;·&nbsp;'
                    f"{escape(comment_display)}</span>"
                )
            else:
                body = highlight_params(summary_text)
            self._summary_label.setText(body)
            self._summary_label.setStyleSheet(summary_style)

        if comment_display:
            self._summary_label.setToolTip(f"{summary_text}\n{comment_display}")
        elif len(self._combined_plain) > 120:
            self._summary_label.setToolTip(self._combined_plain)

        layout.addWidget(self._summary_label, stretch=1, alignment=Qt.AlignmentFlag.AlignTop)

        if indent_level > 0:
            depth = min(indent_level, 8)
            bg = min(252, 232 + min(depth * 2, 20))
            g = min(252, bg - 4)
            b = min(242, bg - 14)
            alpha = min(70 + depth * 8, 160)
            self.setStyleSheet(
                f"ActionItemWidget {{ background-color: rgba({bg},{g},{b}, {alpha}); "
                f"border-radius: 4px; border-bottom: 1px solid #e8e8e8; }}"
            )
            self.setToolTip(
                f"루프·조건·함수 정의 블록 안쪽 (깊이 {indent_level}). "
                "Else/EndIf는 목록에서 자동으로 맞춰집니다."
            )
        else:
            self.setStyleSheet("ActionItemWidget { border-bottom: 1px solid #efefef; }")

    def _build_separator_layout(self, layout: QHBoxLayout, action: Action) -> None:
        """주석 구분줄: 한 줄(길면 말줄임, 툴팁 전체)."""
        _transparent = Qt.WidgetAttribute.WA_TransparentForMouseEvents
        title = _extract_separator_title(action)

        left_line = QFrame(self)
        left_line.setFrameShape(QFrame.Shape.HLine)
        left_line.setStyleSheet("color: #8b8177;")
        left_line.setFixedHeight(2)
        left_line.setAttribute(_transparent)

        label = QLabel(title)
        label.setStyleSheet(
            "color: #3f3a36; font-size: 12px; font-weight: 700; "
            "padding: 0 8px; letter-spacing: 0.5px;"
        )
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setAttribute(_transparent)
        self._separator_title_label = label
        self._separator_title_full = title
        label.setToolTip(title)

        right_line = QFrame(self)
        right_line.setFrameShape(QFrame.Shape.HLine)
        right_line.setStyleSheet("color: #8b8177;")
        right_line.setFixedHeight(2)
        right_line.setAttribute(_transparent)

        layout.addWidget(left_line, stretch=1)
        layout.addWidget(label)
        layout.addWidget(right_line, stretch=1)

    def _apply_compact_text_height(self) -> None:
        """요약+주석을 한 덩어리로 보고, 한 줄에 안 들어가면 함께 최대 2줄."""
        if self.width() < 48:
            return
        lay = self.layout()
        if lay is None:
            return
        lay.activate()

        fm = QFontMetrics(self._summary_label.font())
        line_h = fm.lineSpacing() + 2
        one_line_cap = line_h + 4
        two_line_cap = line_h * 2 + 6

        w_body = self._summary_label.width()
        if w_body < 24:
            return

        br = fm.boundingRect(
            QRect(0, 0, w_body, 10_000),
            int(Qt.AlignmentFlag.AlignLeft | Qt.TextFlag.TextWordWrap),
            self._combined_plain,
        )
        need_lines = max(1, (br.height() + fm.lineSpacing() - 1) // max(1, fm.lineSpacing()))
        if need_lines <= 1:
            self._summary_label.setMaximumHeight(one_line_cap)
        else:
            self._summary_label.setMaximumHeight(two_line_cap)

    def _sync_separator_elide(self) -> None:
        if self._separator_title_label is None or not self._separator_title_full:
            return
        if self.width() < 48:
            return
        lay = self.layout()
        if lay is not None:
            lay.activate()
        label = self._separator_title_label
        w = label.width()
        if w < 8:
            return
        fm = QFontMetrics(label.font())
        label.setText(
            fm.elidedText(
                self._separator_title_full,
                Qt.TextElideMode.ElideMiddle,
                w,
            )
        )

    def _sync_list_item_size(self) -> None:
        """행 sizeHint를 뷰포트 너비·줄바꿈 높이와 맞춘다(행마다 가로가 달라지지 않게)."""
        lw = self._list_widget
        if lw is None or self.width() < 24:
            return
        item = lw.item(self._index)
        if item is None:
            return
        lay = self.layout()
        if lay is None:
            return
        lay.activate()
        h = lay.sizeHint().height()
        mode = getattr(lw, "_row_height_mode", "기본")
        extra = {"컴팩트": -4, "기본": 0, "넓게": 8}.get(mode, 0)
        target = max(22, h + extra)
        row_w = lw.item_row_viewport_width()
        if row_w < 8:
            return
        sh = item.sizeHint()
        if abs(sh.height() - target) <= 1 and sh.width() == row_w:
            return
        sh.setWidth(row_w)
        sh.setHeight(target)
        item.setSizeHint(sh)

    def resizeEvent(self, event: QResizeEvent) -> None:  # noqa: N802
        super().resizeEvent(event)
        if self._row_kind == "separator":
            self._sync_separator_elide()
        else:
            self._apply_compact_text_height()
        self._sync_list_item_size()

    def enterEvent(self, event: object) -> None:  # noqa: N802
        if self._list_widget is not None and not (
            QApplication.mouseButtons() & Qt.MouseButton.LeftButton
        ):
            self._list_widget.set_hover_row(self._index)
        super().enterEvent(event)  # type: ignore[arg-type]

    def leaveEvent(self, event: object) -> None:  # noqa: N802
        if self._list_widget is not None and not (
            QApplication.mouseButtons() & Qt.MouseButton.LeftButton
        ):
            self._list_widget.set_hover_row(-1)
        super().leaveEvent(event)  # type: ignore[arg-type]

    def _on_fold_clicked(self) -> None:
        if self._list_widget is not None:
            self._list_widget.toggle_fold_row(self._index)

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """리스트 기본 선택 동작(Shift/Ctrl 다중 선택)을 우선 보장한다."""
        if self._list_widget is not None and event.button() == Qt.MouseButton.LeftButton:
            mods = event.modifiers()
            item = self._list_widget.item(self._index)
            is_selected_row = bool(item is not None and item.isSelected())
            multi_selected = len(self._list_widget.selectedIndexes()) > 1
            preserve_multi_selection_drag = (
                multi_selected
                and is_selected_row
                and not (mods & Qt.KeyboardModifier.ShiftModifier)
                and not (mods & Qt.KeyboardModifier.ControlModifier)
            )

            if self._is_collapsible and self._is_collapsed:
                linked_rows = self._list_widget.get_linked_if_rows(self._index)
                sm = self._list_widget.selectionModel()
                if sm is not None and linked_rows:
                    self._list_widget.clearSelection()
                    for row in linked_rows:
                        it = self._list_widget.item(row)
                        if it is None:
                            continue
                        sm.select(
                            self._list_widget.indexFromItem(it),
                            QItemSelectionModel.SelectionFlag.Select,
                        )
                    self._list_widget.setCurrentRow(self._index)
            anchor = self.mapTo(self._list_widget.viewport(), event.position().toPoint())
            self._list_widget.begin_row_drag(self._index, anchor)
            if (
                not multi_selected
                or not is_selected_row
                or (mods & Qt.KeyboardModifier.ShiftModifier)
                or (mods & Qt.KeyboardModifier.ControlModifier)
            ):
                self._list_widget.setCurrentRow(self._index)
            if preserve_multi_selection_drag:
                # 이미 다중선택된 행 드래그는 기본 선택 갱신을 막아 그룹 이동을 보장한다.
                event.accept()
                return
        event.ignore()  # QListWidget가 선택/드래그를 처리하도록 전달

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """행 위젯에서 누른 뒤 이동할 때도 리스트와 동일하게 드래그를 시작한다."""
        if self._list_widget is not None and event.buttons() & Qt.MouseButton.LeftButton:
            vp = self._list_widget.viewport()
            vp_pos = vp.mapFromGlobal(event.globalPosition().toPoint())
            if self._list_widget._maybe_start_row_drag(vp_pos):
                event.accept()
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if self._list_widget is not None:
            self._list_widget.clear_row_drag_prep()
        super().mouseReleaseEvent(event)
