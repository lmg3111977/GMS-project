"""드래그앤드롭 정렬 관련 mixin."""

from __future__ import annotations

from PyQt6.QtCore import QItemSelectionModel, QTimer
from PyQt6.QtGui import QDropEvent
from PyQt6.QtWidgets import QAbstractItemView


def _reorder_actions_by_ids(
    actions: list,
    moving_ids: list[str],
    drop_row: int,
) -> list:
    """moving_ids 순서를 유지한 채 drop_row 기준으로 재배치한다."""
    moving_set = set(moving_ids)
    id_to_action = {action.action_id: action for action in actions}
    block_actions = [
        id_to_action[action_id] for action_id in moving_ids if action_id in id_to_action
    ]
    if not block_actions:
        return list(actions)

    target_row = max(0, min(drop_row, len(actions)))
    insert_at = sum(1 for idx in range(target_row) if actions[idx].action_id not in moving_set)
    remaining = [action for action in actions if action.action_id not in moving_set]
    return remaining[:insert_at] + block_actions + remaining[insert_at:]


class DragDropMixin:
    """행 이동 후 내부 액션 동기화 동작."""

    def dropEvent(self, event: QDropEvent) -> None:  # noqa: N802
        """선택/접힘 상태와 무관하게 액션 묶음을 안정적으로 이동한다."""
        if not self._actions:
            event.ignore()
            return

        pending_ids = list(getattr(self, "_pending_block_move_action_ids", []) or [])
        if pending_ids:
            moving_ids = pending_ids
        else:
            selected_rows = sorted({idx.row() for idx in self.selectedIndexes() if idx.row() >= 0})
            if len(selected_rows) > 1:
                moving_ids = [
                    self._actions[row].action_id
                    for row in selected_rows
                    if 0 <= row < len(self._actions)
                ]
            else:
                row = self.currentRow()
                moving_ids = [self._actions[row].action_id] if 0 <= row < len(self._actions) else []

        if not moving_ids:
            event.ignore()
            self._pending_block_move_action_ids = None
            return

        point = event.position().toPoint()
        index = self.indexAt(point)
        drop_row = index.row()
        if drop_row >= 0:
            rect = self.visualRect(index)
            if point.y() > rect.center().y():
                drop_row += 1
        else:
            drop_row = len(self._actions)

        new_actions = _reorder_actions_by_ids(self._actions, moving_ids, drop_row)

        if [action.action_id for action in new_actions] == [
            action.action_id for action in self._actions
        ]:
            event.ignore()
            self._pending_block_move_action_ids = None
            return

        self.action_list_about_to_modify.emit()
        self._actions = new_actions
        # 부분 선택 이동으로 구조형 if/else/end 균형이 깨질 수 있으므로 즉시 복원한다.
        self._repair_if_structure_after_delete()
        valid_ids = {action.action_id for action in self._actions}
        self._collapsed_if_action_ids.intersection_update(valid_ids)
        self._pending_block_move_action_ids = None
        # _rebuild_list()·선택 복원은 _post_drop_sync에서 1회만 수행 (이중 호출 방지)

        # Qt 내부 드래그 상태 정리가 끝난 직후 한 번 더 동기화해서
        # "다음 행동을 해야 반영되는" 지연 표시를 방지한다.
        QTimer.singleShot(0, lambda ids=list(moving_ids): self._post_drop_sync(ids))

        event.acceptProposedAction()
        self.action_order_changed.emit()
        self.action_list_modified.emit()

    def _post_drop_sync(self, moving_ids: list[str]) -> None:
        """드롭 직후 1틱 뒤 UI/선택 상태를 다시 고정한다."""
        valid_ids = {action.action_id for action in self._actions}
        self._collapsed_if_action_ids.intersection_update(valid_ids)
        self._rebuild_list()

        moving_set = set(moving_ids)
        sm = self.selectionModel()
        if sm is None:
            return
        self.clearSelection()
        first_row = -1
        for idx, action in enumerate(self._actions):
            if action.action_id not in moving_set:
                continue
            item = self.item(idx)
            if item is None:
                continue
            sm.select(self.indexFromItem(item), QItemSelectionModel.SelectionFlag.Select)
            if first_row < 0:
                first_row = idx
        if first_row >= 0:
            self.setCurrentRow(first_row)
            item = self.item(first_row)
            if item is not None:
                self.scrollToItem(item, QAbstractItemView.ScrollHint.PositionAtCenter)
        self.doItemsLayout()
        self.viewport().update()
