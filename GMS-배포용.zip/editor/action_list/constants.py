"""action_list 패키지 공용 상수/색상 정의."""

from __future__ import annotations

import logging

from PyQt6.QtGui import QColor

from shared.models import ActionType

logger = logging.getLogger(__name__)
_INDENT_PX = 16

# 액션 리스트 행 배경색 (상태별).
# 배경 우선순위(낮음 → 높음): 기본/제브라 < 호버(연결) < 브레이크포인트
# < 선택(연결) < 선택(현재) < 실행중
# 최근 추가(recent)는 배경을 덮지 않고 "보조 강조(좌측 보더)"로만 표현한다.
_ROW_BG_DEFAULT = QColor(255, 255, 255)  # 기본(매우 연함)
_ROW_BG_ZEBRA = QColor(251, 251, 251)  # 제브라(기본과 미세 차이)
_ROW_BG_HOVER_LINKED = QColor(242, 245, 255)  # 연한 인디고 (호버 연결)
_ROW_BG_BREAKPOINT = QColor(255, 237, 237)  # 연한 빨강 (브레이크포인트)
_ROW_BG_EXECUTING = QColor(220, 252, 231)  # 연한 초록 (실행 중)
# 선택 색은 "현재 선택된 1개"와 "연결된 나머지"를 확실히 구분한다.
_ROW_BG_SELECTED_PRIMARY = QColor(210, 225, 255)  # 현재 선택(더 뚜렷한 대비)
_ROW_BG_SELECTED_LINKED = QColor(226, 237, 255)  # 연결 선택(명확 구분)
_ROW_BORDER_RECENT = QColor(245, 181, 90)  # recent 보조 강조(좌측 보더)

ACTION_COLORS: dict[str, str] = {
    "mouse": "#3b7dd8",
    "keyboard": "#16a34a",
    "flow": "#7c3aed",
    "delay": "#d97706",
    "screen": "#dc2626",
    "variable": "#64748b",
    "function": "#0891b2",
}

UI_COLORS: dict[str, str] = {
    "error": "#dc2626",
    "warning": "#d97706",
    "success": "#16a34a",
}

ACTION_CATEGORY: dict[ActionType, str] = {
    ActionType.MOUSE_MOVE: "mouse",
    ActionType.MOUSE_CLICK: "mouse",
    ActionType.MOUSE_DOWN: "mouse",
    ActionType.MOUSE_UP: "mouse",
    ActionType.MOUSE_DRAG: "mouse",
    ActionType.MOUSE_SCROLL: "mouse",
    ActionType.KEY_PRESS: "keyboard",
    ActionType.KEY_DOWN: "keyboard",
    ActionType.KEY_UP: "keyboard",
    ActionType.KEY_COMBO: "keyboard",
    ActionType.TYPE_TEXT: "keyboard",
    ActionType.DELAY: "delay",
    ActionType.COMMENT: "variable",
    ActionType.LOOP_START: "flow",
    ActionType.LOOP_END: "flow",
    ActionType.BREAK: "flow",
    ActionType.ELSE: "flow",
    ActionType.END_IF: "flow",
    ActionType.LABEL: "flow",
    ActionType.GOTO: "flow",
    ActionType.IF_PIXEL: "screen",
    ActionType.PIXEL_WAIT: "screen",
    ActionType.IMAGE_SEARCH: "screen",
    ActionType.SUB_MACRO_CALL: "flow",
    ActionType.VARIABLE_SET: "variable",
    ActionType.IF_VARIABLE: "variable",
    ActionType.IMAGE_WAIT: "screen",
    ActionType.IMAGE_CLICK: "screen",
    ActionType.OCR_READ: "screen",
    ActionType.OCR_WAIT: "screen",
    ActionType.FUNCTION_DEF: "function",
    ActionType.FUNCTION_END: "function",
    ActionType.FUNCTION_CALL: "function",
    ActionType.RETURN: "function",
}
