"""if/else/end + loop 구조 계산 유틸."""

from __future__ import annotations

from shared.models import (
    Action,
    ElseAction,
    EndIfAction,
    FunctionDefAction,
    FunctionEndAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    OCRWaitAction,
    PixelWaitAction,
)


def struct_if_with_shared_field_copy(current: Action, target_cls: type[Action]) -> Action:
    """구조형 if 헤더를 다른 타입으로 바꿀 때, 양쪽 모델에 **동일한 이름**의 필드만 이전 값으로 채운다.

    - ``type``(리터럴 구분자)은 대상 클래스 기본값을 쓴다.
    - 이름이 겹치지 않으면(예: IfPixel → ImageSearch) 이월되는 값은 거의 없다.
    """
    src = current.model_dump(mode="python")
    target_names = frozenset(target_cls.model_fields) - {"type"}
    payload = {k: src[k] for k in target_names if k in src}
    return target_cls.model_validate(payload)


def param_edit_requires_full_list_rebuild(prev: Action, new: Action) -> bool:
    """파라미터만 바뀐 뒤 리스트 행을 갱신할 때 전체 재빌드가 필요한지.

    연결 태그(if/loop/함수/label↔goto)가 다른 행까지 바뀔 수 있으면 True.
    대부분의 필드 편집(이미지 검색 수치 등)은 False로 단일 행 교체로 충분하다.
    """
    return (
        type(prev) is not type(new)
        or prev.action_id != new.action_id
        or (
            isinstance(prev, LabelAction)
            and isinstance(new, LabelAction)
            and (prev.name or "").strip() != (new.name or "").strip()
        )
        or (
            isinstance(prev, GotoAction)
            and isinstance(new, GotoAction)
            and (prev.target or "").strip() != (new.target or "").strip()
        )
    )


def is_struct_if_action(action: Action) -> bool:
    """if/else/end 구조형 분기 액션인지 판단한다."""
    return isinstance(
        action,
        (
            IfPixelAction,
            IfVariableAction,
            PixelWaitAction,
            ImageSearchAction,
            ImageWaitAction,
            ImageClickAction,
            OCRWaitAction,
        ),
    )


def compute_indent_levels(actions: list[Action]) -> list[int]:
    """if/else/end + loop + 함수 정의/끝 구조를 기준으로 행 들여쓰기 깊이를 계산한다."""
    depth = 0
    levels: list[int] = []
    for action in actions:
        if isinstance(action, (LoopEndAction, FunctionEndAction)):
            depth = max(0, depth - 1)
            levels.append(depth)
            continue
        if isinstance(action, EndIfAction):
            depth = max(0, depth - 1)
            levels.append(depth)
            continue
        if isinstance(action, ElseAction):
            levels.append(max(0, depth - 1))
            depth = max(0, depth - 1) + 1
            continue
        levels.append(depth)
        if isinstance(action, (LoopStartAction, FunctionDefAction)):
            depth += 1
            continue
        if is_struct_if_action(action):
            depth += 1
    return levels


def compute_if_block_metadata(
    actions: list[Action],
) -> tuple[dict[int, str], dict[int, set[int]]]:
    """구조 연결 블록(if/else/end, loop, 함수 정의/끝, label-goto)의 라벨/연결 행을 계산한다."""
    label_by_row: dict[int, str] = {}
    group_rows_by_row: dict[int, set[int]] = {}
    stack: list[dict[str, int | None | str]] = []
    seq_stack: list[int] = []
    seq_counters_by_depth: dict[int, int] = {}
    loop_stack: list[tuple[int, str]] = []
    loop_seq = 0
    func_stack: list[tuple[int, str]] = []
    func_seq = 0
    label_rows_by_name: dict[str, int] = {}
    goto_rows_by_target: dict[str, list[int]] = {}

    for idx, action in enumerate(actions):
        if isinstance(action, LabelAction):
            name = action.name.strip()
            if name:
                label_rows_by_name.setdefault(name, idx)
            continue

        if isinstance(action, GotoAction):
            target = action.target.strip()
            if target:
                goto_rows_by_target.setdefault(target, []).append(idx)
            continue

        if isinstance(action, LoopStartAction):
            loop_seq += 1
            loop_stack.append((idx, f"L{loop_seq:02d}"))
            continue

        if isinstance(action, LoopEndAction):
            if not loop_stack:
                continue
            start_idx, tag = loop_stack.pop()
            rows = {start_idx, idx}
            for row in rows:
                label_by_row[row] = tag
                group_rows_by_row[row] = set(rows)
            continue

        if isinstance(action, FunctionDefAction):
            func_seq += 1
            func_stack.append((idx, f"F{func_seq:02d}"))
            continue

        if isinstance(action, FunctionEndAction):
            if not func_stack:
                continue
            start_idx, tag = func_stack.pop()
            rows = {start_idx, idx}
            for row in rows:
                label_by_row[row] = tag
                group_rows_by_row[row] = set(rows)
            continue

        if is_struct_if_action(action):
            depth = len(seq_stack) + 1
            seq_no = seq_counters_by_depth.get(depth, 0) + 1
            seq_counters_by_depth[depth] = seq_no
            seq_stack.append(seq_no)
            tag = "B" + ".".join(f"{n:02d}" for n in seq_stack)
            stack.append({"if": idx, "else": None, "tag": tag})
            continue

        if isinstance(action, ElseAction):
            if stack:
                stack[-1]["else"] = idx
            continue

        if isinstance(action, EndIfAction):
            if not stack:
                continue
            frame = stack.pop()
            if_idx = frame["if"]
            else_idx = frame["else"]
            tag = frame["tag"]
            if if_idx is None or not isinstance(tag, str):
                continue

            rows = {if_idx, idx}
            if else_idx is not None:
                rows.add(else_idx)

            for row in rows:
                label_by_row[row] = tag
                group_rows_by_row[row] = set(rows)
            if seq_stack:
                seq_stack.pop()

    jump_seq = 0
    for label_name, label_row in label_rows_by_name.items():
        goto_rows = goto_rows_by_target.get(label_name, [])
        if not goto_rows:
            continue
        jump_seq += 1
        tag = f"J{jump_seq:02d}"
        rows = {label_row, *goto_rows}
        for row in rows:
            label_by_row[row] = tag
            group_rows_by_row[row] = set(rows)

    return label_by_row, group_rows_by_row
