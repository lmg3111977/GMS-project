"""ActionListWidget 핵심 구현."""

from __future__ import annotations

from enum import IntEnum

from PyQt6.QtCore import QPoint, QSize, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QMouseEvent, QResizeEvent
from PyQt6.QtWidgets import QAbstractItemView, QApplication, QListWidget, QListWidgetItem, QWidget

from shared.models import Action, ElseAction, EndIfAction

from .constants import (
    _ROW_BG_BREAKPOINT,
    _ROW_BG_DEFAULT,
    _ROW_BG_EXECUTING,
    _ROW_BG_HOVER_LINKED,
    _ROW_BG_SELECTED_LINKED,
    _ROW_BG_SELECTED_PRIMARY,
    _ROW_BG_ZEBRA,
    _ROW_BORDER_RECENT,
    logger,
)
from .context_menu import ContextMenuMixin
from .drag_drop import DragDropMixin
from .item_widget import ActionItemWidget
from .selection import SelectionMixin
from .structure import (
    compute_if_block_metadata,
    compute_indent_levels,
    is_struct_if_action,
    param_edit_requires_full_list_rebuild,
)


class _RowBgPriority(IntEnum):
    """행 배경 우선순위. 값이 클수록 우선순위가 높다."""

    BASE = 0
    HOVER_LINKED = 1
    BREAKPOINT = 2
    SELECTED_LINKED = 3
    SELECTED_PRIMARY = 4
    EXECUTING = 5


def _resolve_row_background_color(
    idx: int,
    *,
    in_hover_group: bool,
    has_breakpoint: bool,
    is_selected_primary: bool,
    is_selected_linked: bool,
    is_executing: bool,
) -> QColor:
    """상태 우선순위를 기반으로 행 배경색을 결정한다.

    단일 진실 원천:
    기본/제브라 < 호버(연결) < 브레이크포인트 < 선택(연결) < 선택(현재) < 실행중
    """
    priority = _RowBgPriority.BASE
    color = _ROW_BG_DEFAULT if idx % 2 == 0 else _ROW_BG_ZEBRA

    if in_hover_group and priority < _RowBgPriority.HOVER_LINKED:
        priority = _RowBgPriority.HOVER_LINKED
        color = _ROW_BG_HOVER_LINKED
    if has_breakpoint and priority < _RowBgPriority.BREAKPOINT:
        priority = _RowBgPriority.BREAKPOINT
        color = _ROW_BG_BREAKPOINT
    if is_selected_linked and priority < _RowBgPriority.SELECTED_LINKED:
        priority = _RowBgPriority.SELECTED_LINKED
        color = _ROW_BG_SELECTED_LINKED
    if is_selected_primary and priority < _RowBgPriority.SELECTED_PRIMARY:
        priority = _RowBgPriority.SELECTED_PRIMARY
        color = _ROW_BG_SELECTED_PRIMARY
    if is_executing and priority < _RowBgPriority.EXECUTING:
        color = _ROW_BG_EXECUTING

    return color


class ActionListWidget(SelectionMixin, ContextMenuMixin, DragDropMixin, QListWidget):
    """드래그 정렬 가능한 액션 리스트."""

    action_selected = pyqtSignal(int)
    action_list_about_to_modify = pyqtSignal()
    action_order_changed = pyqtSignal()
    action_list_modified = pyqtSignal()
    breakpoints_changed = pyqtSignal(object)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._actions: list[Action] = []
        self._collapsed_if_action_ids: set[str] = set()
        self._breakpoint_action_ids: set[str] = set()
        self._recent_action_id: str | None = None
        self._execution_row: int = -1
        self._row_height_mode: str = "기본"
        self._hover_row: int = -1
        self._selected_row: int = -1
        self._context_menu_row: int = -1
        self._if_block_tag_by_row: dict[int, str] = {}
        self._if_group_rows_by_row: dict[int, set[int]] = {}
        self._drag_start_point: QPoint | None = None
        self._drag_start_row: int = -1
        self._pending_block_move_action_ids: list[str] | None = None
        # mousePress 시점 다중 선택(드래그 직전 Qt가 선택을 줄이는 경우 대비)
        self._multi_drag_action_ids_snapshot: list[str] | None = None
        self._left_gutter_drag_guard_px: int = 14

        self.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setSelectionRectVisible(False)
        # 기본 영역은 다중선택 드래그를 우선하고, 이동은 행 내부 핸들에서만 시작한다.
        self.setDragEnabled(False)
        self.setAcceptDrops(True)
        self.viewport().setAcceptDrops(True)
        self.setViewportMargins(0, 0, 0, 0)
        self.setStyleSheet(
            "QListWidget {"
            "padding: 0px 2px 0px 2px;"
            "background: #ffffff;"
            "}"
            "QRubberBand {"
            "border: 0px;"
            "background: transparent;"
            "}"
        )

        self._resize_debounce_timer = QTimer(self)
        self._resize_debounce_timer.setSingleShot(True)
        self._resize_debounce_timer.setInterval(50)
        self._resize_debounce_timer.timeout.connect(self._sync_all_item_size_hint_widths)

        self.currentRowChanged.connect(self._on_row_changed)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)

    def item_row_viewport_width(self) -> int:
        """각 행 sizeHint·위젯에 쓸 가로 길이. 내용 길이에 따라 행마다 달라지면 안 된다."""
        vw = int(self.viewport().width())
        if vw >= 8:
            return vw
        fw = int(self.frameWidth())
        outer = int(self.width()) - 2 * fw
        return max(outer, 8)

    def resizeEvent(self, event: QResizeEvent) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._resize_debounce_timer.start()

    def _sync_all_item_size_hint_widths(self) -> None:
        w = self.item_row_viewport_width()
        if w < 8:
            return
        for i in range(self.count()):
            it = self.item(i)
            if it is None:
                continue
            sh = it.sizeHint()
            if sh.width() != w:
                sh.setWidth(w)
                it.setSizeHint(sh)
            iw = self.itemWidget(it)
            if iw is not None and hasattr(iw, "_sync_list_item_size"):
                iw._sync_list_item_size()  # type: ignore[attr-defined]

    def _prepare_pending_block_move_for_drag_row(self, row: int) -> None:
        """startDrag 직전에 호출: 다중 이동은 mousePress 시 스냅샷을 우선한다."""
        self._pending_block_move_action_ids = None
        if not (0 <= row < len(self._actions)):
            return
        snap = self._multi_drag_action_ids_snapshot
        row_id = self._actions[row].action_id
        if snap is not None and row_id in snap:
            self._pending_block_move_action_ids = list(snap)
        else:
            selected_rows = sorted({idx.row() for idx in self.selectedIndexes() if idx.row() >= 0})
            if len(selected_rows) > 1 and row in selected_rows:
                self._pending_block_move_action_ids = [
                    self._actions[idx].action_id
                    for idx in selected_rows
                    if 0 <= idx < len(self._actions)
                ]
        if self.is_struct_if_row(row):
            header_action = self._actions[row]
            if header_action.action_id in self._collapsed_if_action_ids:
                linked_rows = self._get_if_block_range_rows(row)
                self._pending_block_move_action_ids = [
                    self._actions[idx].action_id
                    for idx in linked_rows
                    if 0 <= idx < len(self._actions)
                ]

    def begin_row_drag(self, row: int, anchor_pos: QPoint) -> None:
        """행 핸들에서 이동 드래그를 시작할 준비를 한다."""
        self._multi_drag_action_ids_snapshot = None
        if not (0 <= row < len(self._actions)):
            return
        if not (0 <= row < self.count()):
            return
        if anchor_pos.x() <= self._left_gutter_drag_guard_px:
            # 좌측 여백에서는 행 이동 드래그를 시작하지 않고 다중선택 드래그를 우선한다.
            return
        item = self.item(row)
        if item is None:
            return
        self._drag_start_row = row
        self._drag_start_point = anchor_pos
        self._pending_block_move_action_ids = None
        selected_rows = sorted({idx.row() for idx in self.selectedIndexes() if idx.row() >= 0})
        if len(selected_rows) > 1 and row in selected_rows:
            self._multi_drag_action_ids_snapshot = [
                self._actions[i].action_id for i in selected_rows if 0 <= i < len(self._actions)
            ]
        selected_rows_set = set(selected_rows)
        multi_group_drag = len(selected_rows_set) > 1 and row in selected_rows_set
        if not multi_group_drag and not item.isSelected():
            self.setCurrentRow(row)

    def _viewport_pos_from_global(self, global_pos: QPoint) -> QPoint:
        return self.viewport().mapFromGlobal(global_pos)

    def _maybe_start_row_drag(self, viewport_pos: QPoint) -> bool:
        """뷰포트 좌표 기준으로 행 이동 드래그를 시작하면 True."""
        if (
            self._drag_start_point is not None
            and self._drag_start_row >= 0
            and (viewport_pos - self._drag_start_point).manhattanLength()
            >= QApplication.startDragDistance()
        ):
            self._prepare_pending_block_move_for_drag_row(self._drag_start_row)
            self.startDrag(Qt.DropAction.MoveAction)
            self.clear_row_drag_prep()
            return True
        return False

    def clear_row_drag_prep(self) -> None:
        """행 드래그가 시작되지 않은 채 마우스가 떨어졌을 때 상태를 초기화한다."""
        self._drag_start_point = None
        self._drag_start_row = -1
        self._multi_drag_action_ids_snapshot = None

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.buttons() & Qt.MouseButton.LeftButton:
            vp = self._viewport_pos_from_global(event.globalPosition().toPoint())
            if self._maybe_start_row_drag(vp):
                event.accept()
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        self.clear_row_drag_prep()
        super().mouseReleaseEvent(event)

    def set_actions(self, actions: list[Action]) -> None:
        self._actions = list(actions)
        valid_ids = {action.action_id for action in self._actions}
        self._collapsed_if_action_ids.intersection_update(valid_ids)
        self._breakpoint_action_ids.intersection_update(valid_ids)
        self._rebuild_list()

    def restore_full_state(
        self,
        actions: list[Action],
        collapsed_if_action_ids: set[str],
        breakpoint_action_ids: set[str],
    ) -> None:
        """액션 목록 + 접기 + 브레이크포인트를 한 번에 복원한다(Undo/Redo용)."""
        self._actions = list(actions)
        valid_ids = {action.action_id for action in self._actions}
        self._collapsed_if_action_ids = set(collapsed_if_action_ids) & valid_ids
        self._breakpoint_action_ids = set(breakpoint_action_ids) & valid_ids
        self._rebuild_list()
        self.breakpoints_changed.emit(sorted(self.get_breakpoint_indices()))

    def get_all_actions(self) -> list[Action]:
        return list(self._actions)

    def is_struct_if_row(self, row: int) -> bool:
        return 0 <= row < len(self._actions) and is_struct_if_action(self._actions[row])

    def get_breakpoint_indices(self) -> set[int]:
        result: set[int] = set()
        for idx, action in enumerate(self._actions):
            if action.action_id in self._breakpoint_action_ids:
                result.add(idx)
        return result

    def set_execution_row(self, row: int) -> None:
        prev_row = self._execution_row
        self._execution_row = row
        if prev_row != row and 0 <= prev_row < self.count():
            self._apply_row_background(prev_row)
        if 0 <= row < self.count():
            self._apply_row_background(row)
            item = self.item(row)
            if item is not None:
                self.scrollToItem(item, QAbstractItemView.ScrollHint.PositionAtCenter)

    def toggle_breakpoint_current(self) -> None:
        self._toggle_breakpoint_current()

    def set_row_height_mode(self, mode: str) -> None:
        if mode not in ("컴팩트", "기본", "넓게"):
            mode = "기본"
        self._row_height_mode = mode
        self._rebuild_list()

    def add_action(self, action: Action, index: int | None = None) -> None:
        self.action_list_about_to_modify.emit()
        if index is None:
            current_row = self.currentRow()
            if 0 <= current_row < len(self._actions):
                insert_at = current_row + 1
                self._actions.insert(insert_at, action)
            else:
                insert_at = len(self._actions)
                self._actions.append(action)
        else:
            insert_at = index
            self._actions.insert(index, action)

        self._recent_action_id = action.action_id
        self._insert_single_row(insert_at, action)
        self.setCurrentRow(insert_at)
        self.action_selected.emit(insert_at)
        self.action_list_modified.emit()

    def remove_selected(self) -> None:
        rows = sorted([idx.row() for idx in self.selectedIndexes()], reverse=True)
        if not rows:
            return
        self.action_list_about_to_modify.emit()
        for row in rows:
            if 0 <= row < len(self._actions):
                self._actions.pop(row)
        valid_ids = {action.action_id for action in self._actions}
        self._collapsed_if_action_ids.intersection_update(valid_ids)
        self._repair_if_structure_after_delete()
        self._rebuild_list()
        if self._actions:
            self.setCurrentRow(min(rows[-1], len(self._actions) - 1))
        self.action_list_modified.emit()

    def duplicate_selected(self) -> None:
        selected_rows = sorted({idx.row() for idx in self.selectedIndexes() if idx.row() >= 0})
        valid = [r for r in selected_rows if 0 <= r < len(self._actions)]
        if not valid:
            return
        self.action_list_about_to_modify.emit()
        from shared.models import _generate_action_id

        for row in reversed(valid):
            original = self._actions[row]
            copy = original.model_copy(deep=True)
            copy.action_id = _generate_action_id()  # type: ignore[attr-defined]
            self._actions.insert(row + 1, copy)

        self._rebuild_list()
        if self._actions:
            first = valid[0]
            self.setCurrentRow(first + 1)
        self.action_list_modified.emit()

    def toggle_selected_enabled(self) -> None:
        current_row = self.currentRow()
        if 0 <= current_row < len(self._actions):
            self.action_list_about_to_modify.emit()
            action = self._actions[current_row]
            data = action.model_dump()
            data["enabled"] = not action.enabled
            updated = type(action).model_validate(data)
            self._actions[current_row] = updated
            self._refresh_single_row_widget(current_row)
            self.setCurrentRow(current_row)
            self.action_list_modified.emit()

    def _refresh_single_row_widget(self, index: int) -> None:
        """메타데이터(_if_block_tag_by_row 등)는 그대로 두고 한 행의 위젯만 교체한다."""
        if not (0 <= index < len(self._actions)):
            return
        item = self.item(index)
        if item is None:
            return
        action = self._actions[index]
        indent_levels = compute_indent_levels(self._actions)
        indent = indent_levels[index] if index < len(indent_levels) else 0
        new_widget = ActionItemWidget(
            action,
            index,
            indent_level=indent,
            list_widget=self,
            is_collapsible=is_struct_if_action(action),
            is_collapsed=action.action_id in self._collapsed_if_action_ids,
            block_tag=self._if_block_tag_by_row.get(index),
        )
        row_w = self.item_row_viewport_width()
        hint = new_widget.sizeHint()
        extra_height = {"컴팩트": -4, "기본": 0, "넓게": 8}.get(self._row_height_mode, 0)
        hint.setHeight(max(22, hint.height() + extra_height))
        hint.setWidth(row_w)
        item.setSizeHint(hint)
        self.setItemWidget(item, new_widget)
        self._apply_row_background(index)

    def update_action(self, index: int, action: Action) -> None:
        if 0 <= index < len(self._actions):
            prev = self._actions[index]
            self._actions[index] = action
            if param_edit_requires_full_list_rebuild(prev, action):
                self._rebuild_list()
            else:
                self._refresh_single_row_widget(index)
            self.setCurrentRow(index)
            self.action_list_modified.emit()

    def _rebuild_list(self) -> None:
        self.clear()
        indent_levels = compute_indent_levels(self._actions)
        self._if_block_tag_by_row, self._if_group_rows_by_row = compute_if_block_metadata(
            self._actions
        )
        extra_height = {"컴팩트": -4, "기본": 0, "넓게": 8}.get(self._row_height_mode, 0)
        for idx, action in enumerate(self._actions):
            item = QListWidgetItem(self)
            indent = indent_levels[idx] if idx < len(indent_levels) else 0
            is_collapsible = is_struct_if_action(action)
            is_collapsed = action.action_id in self._collapsed_if_action_ids
            widget = ActionItemWidget(
                action,
                idx,
                indent_level=indent,
                list_widget=self,
                is_collapsible=is_collapsible,
                is_collapsed=is_collapsed,
                block_tag=self._if_block_tag_by_row.get(idx),
            )
            row_w = self.item_row_viewport_width()
            hint = widget.sizeHint()
            target_height = max(22, hint.height() + extra_height)
            item.setSizeHint(QSize(row_w, target_height))
            self.addItem(item)
            self.setItemWidget(item, widget)
        self._apply_fold_visibility()
        self._apply_debug_visuals()
        QTimer.singleShot(0, self._deferred_sync_action_item_heights)

    def _deferred_sync_action_item_heights(self) -> None:
        """줄바꿈 행 높이를 뷰 너비 기준으로 한 번 더 맞춘다."""
        self._sync_all_item_size_hint_widths()

    def _find_matching_endif_index(self, header_row: int) -> int | None:
        if not (0 <= header_row < len(self._actions)):
            return None
        if not is_struct_if_action(self._actions[header_row]):
            return None
        depth = 1
        for idx in range(header_row + 1, len(self._actions)):
            action = self._actions[idx]
            if is_struct_if_action(action):
                depth += 1
                continue
            if isinstance(action, EndIfAction):
                depth -= 1
                if depth == 0:
                    return idx
        return None

    def _apply_fold_visibility(self) -> None:
        for row in range(self.count()):
            self.setRowHidden(row, False)
        for row, action in enumerate(self._actions):
            if action.action_id not in self._collapsed_if_action_ids:
                continue
            end_row = self._find_matching_endif_index(row)
            if end_row is None:
                continue
            for child_row in range(row + 1, end_row + 1):
                self.setRowHidden(child_row, True)

    def toggle_fold_row(self, row: int) -> None:
        if not (0 <= row < len(self._actions)):
            return
        action = self._actions[row]
        if not is_struct_if_action(action):
            return
        self.action_list_about_to_modify.emit()
        if action.action_id in self._collapsed_if_action_ids:
            self._collapsed_if_action_ids.remove(action.action_id)
        else:
            self._collapsed_if_action_ids.add(action.action_id)
        self._rebuild_list()
        self.setCurrentRow(row)

    def _get_if_block_range_rows(self, header_row: int) -> list[int]:
        """if 헤더부터 EndIf까지의 블록 행 범위를 반환한다."""
        if not (0 <= header_row < len(self._actions)):
            return []
        end_row = self._find_matching_endif_index(header_row)
        if end_row is None or end_row < header_row:
            return [header_row]
        return list(range(header_row, end_row + 1))

    def _insert_single_row(self, index: int, action: Action) -> None:
        _ = index
        _ = action
        self._rebuild_list()

    def _apply_debug_visuals(self) -> None:
        for idx in range(self.count()):
            self._apply_row_background(idx)

    def _apply_row_background(self, idx: int) -> None:
        item = self.item(idx)
        if item is None:
            return
        hover_rows = self._hover_group_rows(self._hover_row)
        selected_rows = self._hover_group_rows(self._selected_row)
        action = self._actions[idx] if 0 <= idx < len(self._actions) else None

        is_selected_primary = idx == self._selected_row
        is_selected_linked = not is_selected_primary and idx in selected_rows
        bg_color = _resolve_row_background_color(
            idx,
            in_hover_group=idx in hover_rows,
            has_breakpoint=(action is not None and action.action_id in self._breakpoint_action_ids),
            is_selected_primary=is_selected_primary,
            is_selected_linked=is_selected_linked,
            is_executing=idx == self._execution_row,
        )
        item.setBackground(bg_color)

        is_recent = action is not None and action.action_id == self._recent_action_id
        self._apply_recent_indicator(item, is_recent)

    def _apply_recent_indicator(self, item: QListWidgetItem, is_recent: bool) -> None:
        """최근 추가 행을 배경이 아닌 좌측 보더로 보조 강조한다."""
        widget = self.itemWidget(item)
        if widget is None:
            return
        base_style = widget.property("_base_row_style")
        if not isinstance(base_style, str):
            base_style = widget.styleSheet()
            widget.setProperty("_base_row_style", base_style)
        if not is_recent:
            widget.setStyleSheet(base_style)
            return
        recent_rule = (
            f"\nActionItemWidget {{ border-left: 2px solid {_ROW_BORDER_RECENT.name()}; }}"
        )
        widget.setStyleSheet(base_style + recent_rule)

    def _repair_if_structure_after_delete(self) -> None:
        frames: list[dict[str, bool]] = []
        i = 0
        repaired = False
        while i < len(self._actions):
            action = self._actions[i]
            if is_struct_if_action(action):
                frames.append({"has_else": False})
                i += 1
                continue
            if isinstance(action, ElseAction):
                if frames:
                    if frames[-1]["has_else"]:
                        self._actions.pop(i)
                        repaired = True
                        continue
                    frames[-1]["has_else"] = True
                i += 1
                continue
            if isinstance(action, EndIfAction):
                if not frames:
                    i += 1
                    continue
                if not frames[-1]["has_else"]:
                    self._actions.insert(i, ElseAction())
                    frames[-1]["has_else"] = True
                    repaired = True
                    i += 1
                frames.pop()
                i += 1
                continue
            i += 1

        while frames:
            frame = frames.pop()
            if not frame["has_else"]:
                self._actions.append(ElseAction())
                repaired = True
            self._actions.append(EndIfAction())
            repaired = True

        if repaired:
            logger.info("구조형 if/else/end 블록 자동 복구를 수행했습니다.")
