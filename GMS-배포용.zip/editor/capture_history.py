"""F8 캡처 히스토리 저장소."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)

MAX_HISTORY = 10


@dataclass
class CaptureEntry:
    x: int
    y: int
    color: str
    captured_at: datetime = field(default_factory=datetime.now)
    label: str = ""

    def to_clipboard_text(self) -> str:
        return f"{self.x},{self.y},{self.color}"

    def display_label(self) -> str:
        """콤보 등 목록용 짧은 라벨(색은 아이콘 스와치로 표시)."""
        ts = self.captured_at.strftime("%H:%M:%S")
        base = f"[{ts}] ({self.x},{self.y})"
        return f"{base}  ({self.label})" if self.label else base


class CaptureHistory:
    """F8 캡처 항목을 메모리에 누적 관리하는 저장소."""

    def __init__(self, max_size: int = MAX_HISTORY) -> None:
        self._max = max_size
        self._entries: list[CaptureEntry] = []
        self._active_index: int = -1

    def push(self, x: int, y: int, color: str) -> CaptureEntry:
        """캡처 항목 추가. 직전 항목과 동일하면 중복 저장하지 않는다."""
        if self._entries:
            prev = self._entries[-1]
            if prev.x == x and prev.y == y and prev.color == color:
                logger.debug("CaptureHistory: duplicate skip (%d,%d,%s)", x, y, color)
                return prev

        entry = CaptureEntry(x=x, y=y, color=color)
        self._entries.append(entry)
        if len(self._entries) > self._max:
            self._entries.pop(0)
        self._active_index = len(self._entries) - 1
        logger.debug(
            "CaptureHistory: push #%d -> %s", self._active_index, entry.to_clipboard_text()
        )
        return entry

    @property
    def active(self) -> CaptureEntry | None:
        if 0 <= self._active_index < len(self._entries):
            return self._entries[self._active_index]
        return None

    @property
    def entries(self) -> list[CaptureEntry]:
        return list(self._entries)

    @property
    def active_index(self) -> int:
        return self._active_index

    def select(self, index: int) -> None:
        if 0 <= index < len(self._entries):
            self._active_index = index
            return
        logger.warning("CaptureHistory: invalid index %d (size=%d)", index, len(self._entries))

    def clear(self) -> None:
        self._entries.clear()
        self._active_index = -1
