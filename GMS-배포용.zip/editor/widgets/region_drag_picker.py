"""화면에서 드래그로 직사각형 영역(검색 영역 등)을 선택하는 위젯."""

from __future__ import annotations

from contextlib import suppress

from PyQt6.QtCore import QPoint, QRect, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QGuiApplication, QMouseEvent, QPainter, QPen
from PyQt6.QtWidgets import QApplication, QPushButton, QWidget


class RegionDragPickerButton(QPushButton):
    """전체 화면 오버레이에서 드래그하여 (X1,Y1)~(X2,Y2) 영역을 잡는 버튼.

    Signals:
        region_picked(int, int, int, int): 화면 좌표계에서 x1, y1, x2, y2 (포함 경계)
    """

    region_picked = pyqtSignal(int, int, int, int)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__("화면에서 드래그로 영역 선택", parent)
        self.setToolTip(
            "버튼을 누른 뒤 화면에서 드래그하여 검색 영역을 지정합니다.\n" "ESC로 취소합니다."
        )
        self.clicked.connect(self._start_picking)
        # 부모 없는 QWidget은 Python 참조가 없으면 즉시 GC되어 창이 안 뜰 수 있음
        self._overlay_ref: _RegionDragOverlay | None = None

    def _start_picking(self) -> None:
        # close()만 하면 기본적으로 위젯이 파괴되지 않아 destroyed가 안 나고,
        # 두 번째 클릭이 보이지 않는 예전 창에만 raise 되어 무반응처럼 보인다.
        if self._overlay_ref is not None:
            old = self._overlay_ref
            self._overlay_ref = None
            with suppress(RuntimeError):
                old.close()
            old.deleteLater()

        overlay = _RegionDragOverlay()
        self._overlay_ref = overlay
        overlay.region_picked.connect(self.region_picked.emit)
        overlay.destroyed.connect(lambda *a, ow=overlay: self._clear_if_same_overlay(ow))
        overlay.show()
        overlay.raise_()
        overlay.activateWindow()
        QApplication.processEvents()

    def _clear_if_same_overlay(self, ow: QWidget) -> None:
        if self._overlay_ref is ow:
            self._overlay_ref = None


class _RegionDragOverlay(QWidget):
    """전역 좌표계에서 드래그 직사각형을 그리고 좌표를 반환한다."""

    region_picked = pyqtSignal(int, int, int, int)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(None)
        # Tool만 쓰면 일부 환경에서 최상위 창이 안 뜨거나 바로 사라질 수 있어 Window 플래그를 명시한다.
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        # close() 시 실제로 파괴되어 destroyed가 나가고, 다음에 새 오버레이를 띄울 수 있음
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        screen = QGuiApplication.primaryScreen()
        if screen is not None:
            geo = screen.virtualGeometry()
            self.setGeometry(geo)
            if geo.width() <= 1 or geo.height() <= 1:
                self.showFullScreen()
        else:
            self.showFullScreen()

        self._dragging = False
        self._origin = QPoint()
        self._current = QPoint()

    def showEvent(self, event: object) -> None:  # noqa: N802
        super().showEvent(event)
        self.raise_()
        self.activateWindow()
        QTimer.singleShot(0, self._take_focus)

    def _take_focus(self) -> None:
        self.setFocus(Qt.FocusReason.PopupFocusReason)

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() != Qt.MouseButton.LeftButton:
            return
        self._dragging = True
        self._origin = event.globalPosition().toPoint()
        self._current = self._origin
        self.grabMouse()
        self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if not self._dragging:
            return
        self._current = event.globalPosition().toPoint()
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() != Qt.MouseButton.LeftButton or not self._dragging:
            return
        self._dragging = False
        self.releaseMouse()
        end = event.globalPosition().toPoint()
        x1 = min(self._origin.x(), end.x())
        y1 = min(self._origin.y(), end.y())
        x2 = max(self._origin.x(), end.x())
        y2 = max(self._origin.y(), end.y())
        self.region_picked.emit(x1, y1, x2, y2)
        self.close()

    def keyPressEvent(self, event: object) -> None:  # noqa: N802
        if hasattr(event, "key") and event.key() == Qt.Key.Key_Escape:  # type: ignore[union-attr]
            self._dragging = False
            self.releaseMouse()
            self.close()
        else:
            super().keyPressEvent(event)

    def paintEvent(self, event: object) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        full = self.rect()
        dim = QColor(0, 0, 0, 110)

        if not self._dragging:
            painter.fillRect(full, dim)
            painter.setPen(QPen(QColor(255, 255, 255)))
            painter.setFont(QFont("Malgun Gothic", 14))
            painter.drawText(
                full,
                Qt.AlignmentFlag.AlignCenter,
                "왼쪽 버튼을 누른 채 드래그하여 영역 지정 (ESC 취소)",
            )
            painter.end()
            return

        g0 = self.mapFromGlobal(self._origin)
        g1 = self.mapFromGlobal(self._current)
        sel = QRect(g0, g1).normalized()

        fl, ft = full.left(), full.top()
        fr, fb = full.right(), full.bottom()
        x, y, w, h = sel.x(), sel.y(), sel.width(), sel.height()
        painter.fillRect(fl, ft, full.width(), max(0, y - ft), dim)
        painter.fillRect(fl, y + h, full.width(), max(0, fb - (y + h) + 1), dim)
        painter.fillRect(fl, y, max(0, x - fl), h, dim)
        painter.fillRect(x + w, y, max(0, fr - (x + w) + 1), h, dim)

        painter.setPen(QPen(QColor(0, 200, 120), 2))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(sel.adjusted(0, 0, -1, -1))

        painter.setPen(QPen(QColor(255, 255, 255)))
        painter.setFont(QFont("Malgun Gothic", 11))
        br = sel.bottomRight()
        painter.drawText(min(br.x() + 8, fr - 120), min(br.y() + 18, fb - 4), f"{w} × {h}")
        painter.end()
