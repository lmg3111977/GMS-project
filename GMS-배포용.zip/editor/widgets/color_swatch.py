"""#RRGGBB 색상 미리보기(스와치) 유틸."""

from __future__ import annotations

import re

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import QLabel

_HEX6 = re.compile(r"^#[0-9A-Fa-f]{6}$")


def is_valid_hex_color(text: str) -> bool:
    return bool(_HEX6.match((text or "").strip()))


def normalized_hex_or_default(text: str, default: str = "#000000") -> str:
    s = (text or "").strip()
    return s if is_valid_hex_color(s) else default


def capture_color_swatch_icon(hex_color: str, size: int = 20) -> QIcon:
    """#RRGGBB 문자열로 작은 색상 스와치 아이콘을 만든다."""
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    qcolor = QColor(normalized_hex_or_default(hex_color))
    painter = QPainter(pm)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setBrush(qcolor)
    painter.setPen(QPen(QColor("#888888"), 1))
    painter.drawRoundedRect(1, 1, size - 2, size - 2, 3, 3)
    painter.end()
    return QIcon(pm)


def apply_color_swatch_label(label: QLabel, hex_text: str) -> None:
    """QLabel을 스와치처럼 스타일한다. 잘못된 형식이면 회색으로 표시."""
    raw = (hex_text or "").strip()
    if is_valid_hex_color(raw):
        label.setToolTip(f"미리보기 색상\nHEX: {raw}")
        label.setStyleSheet(
            f"background: {raw}; border: 1px solid #9e9e9e; border-radius: 5px; min-width: 36px;"
        )
    else:
        label.setToolTip("올바른 #RRGGBB 형식이 아닙니다 (예: #FF0000)")
        label.setStyleSheet(
            "background: #e0e0e0; border: 1px dashed #9e9e9e; border-radius: 5px; min-width: 36px;"
        )
