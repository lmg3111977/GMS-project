"""도움말·힌트 라벨 공통 스타일 (가독성·대비·줄간격 통일)."""

from __future__ import annotations

from PyQt6.QtWidgets import QLabel


def style_form_hint_label(lab: QLabel) -> None:
    """폼 안 작은 안내(좌표식 규칙 등)."""
    lab.setStyleSheet(STYLE_FORM_HINT)
    lab.setWordWrap(True)


def style_panel_action_desc_label(lab: QLabel) -> None:
    """파라미터 패널 상단 액션 타입 설명 박스."""
    lab.setStyleSheet(STYLE_PANEL_ACTION_DESC)
    lab.setWordWrap(True)


# 본문: 최소 12px 권장, 대비 확보
STYLE_FORM_HINT = (
    "color: #3d3835; font-size: 12px; line-height: 1.5; margin-bottom: 4px;"
)

STYLE_PANEL_ACTION_DESC = (
    "background-color: #eef2ff; color: #1e1b4b; "
    "padding: 10px 12px; border-radius: 8px; "
    "font-size: 12px; line-height: 1.55; margin-bottom: 6px; "
    "border: 1px solid #c7d2fe;"
)

# 이미지/OCR 영역 힌트 (base.region_hint_label)
REGION_HINT_STYLE = (
    "color: #3d3835; font-size: 12px; line-height: 1.5; margin-bottom: 6px;"
)

# Loop 등 그룹 상단 안내
STYLE_SECTION_HINT = "color: #3d3835; font-size: 12px; line-height: 1.5;"

# 그룹 하단 작은 팁
STYLE_SECTION_NOTE = "color: #5c5652; font-size: 11px; line-height: 1.5;"

# 좌측 사이드바 보조 문구 (스케줄 요약 등)
STYLE_SIDEBAR_SECONDARY = "color: #4a4540; font-size: 11px; line-height: 1.5;"
