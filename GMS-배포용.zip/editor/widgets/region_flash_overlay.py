"""화면 좌표계에서 직사각형 영역을 잠시 강조 표시하는 오버레이."""

from __future__ import annotations

from contextlib import suppress

from PyQt6.QtCore import QPoint, QRect, Qt, QTimer
from PyQt6.QtGui import QColor, QGuiApplication, QPainter, QPen
from PyQt6.QtWidgets import QApplication, QWidget


class RegionFlashOverlay(QWidget):
    """전역 좌표 (x1,y1)-(x2,y2) 직사각형을 반투명으로 강조한 뒤 자동으로 닫는다."""

    def __init__(
        self,
        gx1: int,
        gy1: int,
        gx2: int,
        gy2: int,
        *,
        duration_ms: int = 1500,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        xa, xb = sorted((gx1, gx2))
        ya, yb = sorted((gy1, gy2))
        self._gx1 = xa
        self._gy1 = ya
        self._gx2 = xb
        self._gy2 = yb

        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setCursor(Qt.CursorShape.ArrowCursor)

        screen = QGuiApplication.primaryScreen()
        if screen is not None:
            geo = screen.virtualGeometry()
            self.setGeometry(geo)
            if geo.width() <= 1 or geo.height() <= 1:
                self.showFullScreen()
        else:
            self.showFullScreen()

        QTimer.singleShot(max(200, duration_ms), self.close)

    def showEvent(self, event: object) -> None:  # noqa: N802
        super().showEvent(event)
        self.raise_()
        self.activateWindow()
        QApplication.processEvents()

    def paintEvent(self, event: object) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        full = self.rect()
        dim = QColor(0, 0, 0, 100)
        painter.fillRect(full, dim)

        p0 = self.mapFromGlobal(QPoint(self._gx1, self._gy1))
        p1 = self.mapFromGlobal(QPoint(self._gx2, self._gy2))
        sel = QRect(p0, p1).normalized()
        if sel.width() < 2 and sel.height() < 2:
            sel.adjust(-2, -2, 2, 2)

        painter.fillRect(sel, QColor(0, 220, 120, 55))
        painter.setPen(QPen(QColor(0, 255, 140), 3))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(sel.adjusted(0, 0, -1, -1))
        painter.end()

    def keyPressEvent(self, event: object) -> None:  # noqa: N802
        if hasattr(event, "key") and event.key() == Qt.Key.Key_Escape:  # type: ignore[union-attr]
            self.close()
        else:
            super().keyPressEvent(event)


def flash_screen_rect(
    gx1: int,
    gy1: int,
    gx2: int,
    gy2: int,
    *,
    duration_ms: int = 1500,
) -> RegionFlashOverlay:
    """영역을 화면에 잠시 표시하고 오버레이 위젯을 반환한다 (참조 유지 필요 시 보관)."""
    overlay = RegionFlashOverlay(gx1, gy1, gx2, gy2, duration_ms=duration_ms)
    overlay.show()
    overlay.raise_()
    with suppress(RuntimeError):
        overlay.activateWindow()
    QApplication.processEvents()
    return overlay
