"""에디터 독립 스케줄러 서비스.

UI 스레드의 QTimer로 동작하며, 매크로 실행 엔진과 분리된 트리거 역할만 담당한다.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

from PyQt6.QtCore import QObject, QTimer

from shared.models import Macro, ScheduleRule


class EditorScheduleService(QObject):
    """현재 에디터 매크로 설정을 감시해 예약 트리거를 발생시킨다."""

    def __init__(
        self,
        macro_supplier: Callable[[], Macro | None],
        on_fire: Callable[[ScheduleRule], None],
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._macro_supplier = macro_supplier
        self._on_fire = on_fire
        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)
        self._last_fired_keys: set[str] = set()

    def start(self) -> None:
        self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    def _tick(self) -> None:
        macro = self._macro_supplier()
        if macro is None:
            return

        now = datetime.now()
        for rule in macro.settings.schedule_rules:
            if not rule.enabled:
                continue
            if not rule.macro_path.strip():
                continue
            if len(rule.time_hhmm) != 5 or ":" not in rule.time_hhmm:
                continue
            hh_text, mm_text = rule.time_hhmm.split(":", 1)
            try:
                target_hh = int(hh_text)
                target_mm = int(mm_text)
            except ValueError:
                continue
            if now.hour != target_hh or now.minute != target_mm:
                continue

            # 동일 규칙(rule_id) + 동일 분(date,time) 중복 트리거 방지
            fire_key = f"{now.date().isoformat()}|{target_hh:02d}:{target_mm:02d}|{rule.rule_id}"
            if fire_key in self._last_fired_keys:
                continue
            self._last_fired_keys.add(fire_key)
            self._on_fire(rule)
