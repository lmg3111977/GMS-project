"""현재 매크로 액션에서 변수명 후보를 모아 콤보 제안에 쓴다."""

from __future__ import annotations

from collections.abc import Iterable

from PyQt6.QtWidgets import QComboBox, QWidget

from engine.variables import MAX_VAR_NAME_LENGTH, VAR_NAME_PATTERN, VAR_REF_PATTERN
from shared.models import (
    Action,
    IfVariableAction,
    ImageSearchAction,
    ImageWaitAction,
    LoopStartAction,
    OCRReadAction,
    OCRWaitAction,
    VariableSetAction,
)


def create_editable_var_combo(parent: QWidget | None = None) -> QComboBox:
    c = QComboBox(parent)
    c.setEditable(True)
    c.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
    return c


def refill_var_combo_items(combo: QComboBox, names: list[str]) -> None:
    """드롭다운 항목만 갱신하고, 현재 입력 텍스트는 유지한다."""
    current = combo.currentText()
    combo.blockSignals(True)
    try:
        combo.clear()
        for n in names:
            combo.addItem(n)
        combo.setCurrentText(current)
    finally:
        combo.blockSignals(False)


def _add_literal(name: str, bag: set[str]) -> None:
    t = (name or "").strip()
    if not t or len(t) > MAX_VAR_NAME_LENGTH:
        return
    if VAR_NAME_PATTERN.match(t):
        bag.add(t)


def _add_refs(text: str | None, bag: set[str]) -> None:
    if not text:
        return
    for m in VAR_REF_PATTERN.finditer(text):
        n = m.group(1)
        if len(n) <= MAX_VAR_NAME_LENGTH and VAR_NAME_PATTERN.match(n):
            bag.add(n)


def _walk(action: Action, bag: set[str]) -> None:
    if isinstance(action, VariableSetAction):
        _add_literal(action.var_name, bag)
        _add_refs(action.expression, bag)
    elif isinstance(action, IfVariableAction):
        _add_literal(action.var_name, bag)
        _add_refs(action.compare_value, bag)
    elif isinstance(action, ImageSearchAction):
        _add_literal(action.store_x_var, bag)
        _add_literal(action.store_y_var, bag)
        _add_literal(action.store_xy_combined_var, bag)
        _add_literal(action.store_found_var, bag)
        _add_literal(action.store_confidence_var, bag)
    elif isinstance(action, ImageWaitAction):
        _add_literal(action.store_x_var, bag)
        _add_literal(action.store_y_var, bag)
    elif isinstance(action, (OCRReadAction, OCRWaitAction)):
        _add_literal(action.store_var, bag)
    elif isinstance(action, LoopStartAction):
        _add_refs(action.count_expression, bag)
        _add_refs(action.range_start_expression, bag)
        _add_refs(action.range_end_expression, bag)


def collect_suggested_var_names(actions: Iterable[Action]) -> list[str]:
    bag: set[str] = set()
    for a in actions:
        _walk(a, bag)
    return sorted(bag)
