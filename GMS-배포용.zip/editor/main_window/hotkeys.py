"""핫키/단축키 관련 믹스인."""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import TYPE_CHECKING

from PyQt6.QtGui import QAction, QKeySequence

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow

logger = logging.getLogger(__name__)


class HotkeysMixin:
    """핫키/단축키 관련 메서드를 제공하는 믹스인."""

    def _setup_shortcuts(self: MacroEditorWindow) -> None:
        """FIX #1: 앱 포커스 상태에서 동작하는 단축키 설정."""
        shortcuts = [
            (QKeySequence("Ctrl+Z"), self._undo_from_shortcut, "실행 취소"),
            (QKeySequence("Ctrl+Y"), self._redo_from_shortcut, "다시 실행"),
            (QKeySequence("Ctrl+R"), self._toggle_recording, "녹화 시작/정지"),
            (QKeySequence("F8"), self._capture_mouse_clipboard, "좌표/색상 클립보드 캡처"),
            (
                QKeySequence("F9"),
                self._action_list.toggle_breakpoint_current,
                "브레이크포인트 토글",
            ),
            (QKeySequence("F10"), self._step_macro, "디버그 1스텝 실행"),
            (QKeySequence("Delete"), self._delete_from_shortcut, "삭제"),
            (QKeySequence("Backspace"), self._delete_from_shortcut, "삭제(Backspace)"),
            (QKeySequence("Ctrl+D"), self._duplicate_from_shortcut, "복제"),
        ]
        for key_seq, callback, desc in shortcuts:
            action = QAction(desc, self)
            action.setShortcut(key_seq)
            action.triggered.connect(callback)
            self.addAction(action)

    def _is_action_list_focus_context(self: MacroEditorWindow) -> bool:
        """포커스가 중앙 액션 리스트(또는 그 자식)에 있는지 확인한다."""
        focused = self.focusWidget()
        return bool(
            focused is self._action_list
            or (focused is not None and self._action_list.isAncestorOf(focused))
        )

    def _undo_from_shortcut(self: MacroEditorWindow) -> None:
        """Ctrl+Z는 액션 리스트 포커스일 때만 동작시킨다."""
        if self._is_action_list_focus_context():
            self._undo()

    def _redo_from_shortcut(self: MacroEditorWindow) -> None:
        """Ctrl+Y는 액션 리스트 포커스일 때만 동작시킨다."""
        if self._is_action_list_focus_context():
            self._redo()

    def _delete_from_shortcut(self: MacroEditorWindow) -> None:
        """Delete는 액션 리스트 포커스일 때만 선택 액션을 삭제한다."""
        if self._is_action_list_focus_context():
            self._action_list.remove_selected()

    def _duplicate_from_shortcut(self: MacroEditorWindow) -> None:
        """Ctrl+D는 액션 리스트 포커스일 때만 선택 액션을 복제한다."""
        if self._is_action_list_focus_context():
            self._action_list.duplicate_selected()

    def _setup_global_hotkeys(self: MacroEditorWindow) -> None:
        """게임/다른 프로그램이 활성화된 상태에서도 동작하는 전역 핫키를 등록한다.

        pynput의 GlobalHotKeys(SetWindowsHookEx 기반)는 관리자 권한 게임이나
        DirectInput 독점 모드에서 이벤트를 받지 못한다.

        Windows에서는 RegisterHotKey API를 사용한다 (Ctrl+F5/F6/F7).
        이 API는 OS 커널 레벨에서 동작하므로 게임 프로세스의 입력 독점과
        무관하게 핫키를 수신할 수 있다.

        비-Windows 환경에서는 pynput 폴백을 사용한다.
        """
        import sys

        if sys.platform.startswith("win"):
            success = self._setup_win32_hotkeys()
            if success:
                return
            self.log_message("WARNING", "Win32 핫키 등록 실패. pynput 폴백 시도합니다.")

        self._setup_pynput_hotkeys()

    def _setup_win32_hotkeys(self: MacroEditorWindow) -> bool:
        """Win32 RegisterHotKey API로 전역 핫키를 등록한다.

        별도 데몬 스레드에서 GetMessage 루프를 돌며 WM_HOTKEY를 수신하고,
        Qt signal emit으로 UI 스레드에 전달한다.

        Returns:
            등록 성공 여부
        """
        import ctypes
        import ctypes.wintypes
        import threading

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        # RegisterHotKey 상수
        mod_control = 0x0002
        mod_norepeat = 0x4000  # 키 반복 방지
        hotkey_mods = mod_control | mod_norepeat
        error_hotkey_already_registered = 1409

        # VK 코드: F5=0x74, F6=0x75, F7=0x76 (항상 Ctrl 동시 누름)
        hotkey_defs: list[tuple[int, int, str, object]] = [
            (1, 0x74, "run", self.hotkey_run_requested.emit),
            (2, 0x75, "pause", self.hotkey_pause_requested.emit),
            (3, 0x76, "stop", self.hotkey_stop_requested.emit),
        ]
        vk_label = {0x74: "Ctrl+F5", 0x75: "Ctrl+F6", 0x76: "Ctrl+F7"}

        self._win32_hotkey_thread_running = False
        self._win32_hotkey_thread_id: int | None = None
        self._win32_hotkey_registered_labels: list[str] = []
        self._win32_hotkey_failed: list[tuple[str, int]] = []

        def _win32_hotkey_error_text(code: int) -> str:
            if code == error_hotkey_already_registered:
                return "다른 프로그램이 동일 키를 이미 등록함(ERROR_HOTKEY_ALREADY_REGISTERED)"
            if code == 87:
                return "잘못된 매개변수(ERROR_INVALID_PARAMETER)"
            if code == 0:
                return "GetLastError=0 (원인 불명 — 다른 프로그램이 동일 키를 쓰는지 확인)"
            return f"Win32 오류 {code}"

        def _try_register(hotkey_id: int, vk: int, fs_modifiers: int) -> bool:
            kernel32.SetLastError(0)
            return bool(user32.RegisterHotKey(None, hotkey_id, fs_modifiers, vk))

        def _hotkey_thread() -> None:
            """RegisterHotKey + GetMessage 루프를 실행하는 데몬 스레드."""
            # RegisterHotKey는 호출한 스레드에 바인딩된다.
            registered_ids: list[int] = []
            registered_labels: list[str] = []
            failed: list[tuple[str, int]] = []

            for hk_id, vk_code, _name, _callback in hotkey_defs:
                label = vk_label.get(vk_code, f"VK{vk_code:02X}")
                ok = _try_register(hk_id, vk_code, hotkey_mods)
                if ok:
                    registered_ids.append(hk_id)
                    registered_labels.append(label)
                    continue
                err = int(kernel32.GetLastError())
                failed.append((label, err))
                logger.warning(
                    "RegisterHotKey 실패: %s (id=%d vk=0x%02X) — %s",
                    label,
                    hk_id,
                    vk_code,
                    _win32_hotkey_error_text(err),
                )

            self._win32_hotkey_registered_labels = registered_labels
            self._win32_hotkey_failed = failed

            if not registered_ids:
                return

            self._win32_hotkey_thread_id = ctypes.windll.kernel32.GetCurrentThreadId()
            self._win32_hotkey_thread_running = True

            # 콜백 매핑
            callback_map = {hk_id: (name, callback) for hk_id, _vk, name, callback in hotkey_defs}

            msg = ctypes.wintypes.MSG()
            sleep_event = threading.Event()
            while self._win32_hotkey_thread_running:
                # PeekMessage로 0.05초마다 폴링 (GetMessage는 블로킹이라 종료 신호를 받기 어려움)
                result = user32.PeekMessageW(
                    ctypes.byref(msg),
                    None,
                    0x0312,
                    0x0312,
                    0x0001,  # WM_HOTKEY=0x0312, PM_REMOVE=0x0001
                )
                if result:
                    hk_id = msg.wParam
                    entry = callback_map.get(hk_id)
                    if entry:
                        name, callback = entry
                        now = time.monotonic()
                        prev = self._last_hotkey_trigger_at.get(name, 0.0)
                        if now - prev >= 0.2:
                            self._last_hotkey_trigger_at[name] = now
                            try:
                                callback()
                            except Exception as exc:
                                logger.warning("Win32 핫키 콜백 에러 (%s): %s", name, exc)
                else:
                    # 헌법 8조: time.sleep 직접 호출 금지 — Event.wait로 대체
                    sleep_event.wait(timeout=0.05)

            # 해제
            for hk_id in registered_ids:
                user32.UnregisterHotKey(None, hk_id)
            logger.debug("Win32 핫키 해제 완료: %s", registered_ids)

        thread = threading.Thread(target=_hotkey_thread, daemon=True, name="Win32HotkeyThread")
        thread.start()

        # 스레드가 RegisterHotKey를 완료할 시간 확보
        # 헌법 8조: time.sleep 직접 호출 금지 — QThread.msleep로 대체
        from PyQt6.QtCore import QThread

        QThread.msleep(100)
        if self._win32_hotkey_thread_running:
            self._global_hotkeys = thread  # closeEvent에서 정리용
            joined = "/".join(self._win32_hotkey_registered_labels)
            self.log_message("INFO", f"전역 핫키 활성화 (Win32): {joined}")
            for lbl, err in self._win32_hotkey_failed:
                self.log_message(
                    "WARNING",
                    f"{lbl} 전역 등록 실패: {_win32_hotkey_error_text(err)}",
                )
            return True

        self.log_message("WARNING", "Win32 RegisterHotKey 등록된 핫키 없음")
        return False

    def _setup_pynput_hotkeys(self: MacroEditorWindow) -> None:
        """pynput GlobalHotKeys 폴백 (비-Windows 또는 Win32 실패 시)."""
        try:
            from pynput import keyboard
        except ImportError:
            self.log_message("WARNING", "전역 핫키 비활성화: `pynput` 미설치")
            return

        def _trigger(name: str, callback: Callable[[], None]) -> None:
            now = time.monotonic()
            prev = self._last_hotkey_trigger_at.get(name, 0.0)
            if now - prev < 0.2:
                return
            self._last_hotkey_trigger_at[name] = now
            callback()

        # pynput 콜백은 별도 스레드에서 실행되므로 Qt signal emit만 호출한다.
        self._global_hotkeys = keyboard.GlobalHotKeys(
            {
                "<ctrl>+<f5>": lambda: _trigger("run", self.hotkey_run_requested.emit),
                "<ctrl>+<f6>": lambda: _trigger("pause", self.hotkey_pause_requested.emit),
                "<ctrl>+<f7>": lambda: _trigger("stop", self.hotkey_stop_requested.emit),
            }
        )
        try:
            self._global_hotkeys.start()
            self.log_message(
                "INFO",
                "전역 핫키 활성화 (pynput 폴백): Ctrl+F5 / Ctrl+F6 / Ctrl+F7",
            )
        except Exception as exc:
            self._global_hotkeys = None
            self.log_message("WARNING", f"전역 핫키 시작 실패: {exc}")
