"""스케줄 UI 관련 믹스인."""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from editor.action_list import get_action_summary
from shared.models import Macro, ScheduleRule
from shared.schema import load_macro

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow


class ScheduleUIMixin:
    """스케줄 UI 관련 메서드를 제공하는 믹스인."""

    def _refresh_schedule_list(self: MacroEditorWindow) -> None:
        rules = self._macro.settings.schedule_rules
        if hasattr(self, "_schedule_manage_button"):
            self._schedule_manage_button.setText(f"스케줄 관리 ({len(rules)})")
        if not hasattr(self, "_schedule_summary_label"):
            return
        if not rules:
            self._schedule_summary_label.setText("등록된 스케줄 없음")
            return
        enabled_rules = [r for r in rules if r.enabled]
        if not enabled_rules:
            self._schedule_summary_label.setText(f"총 {len(rules)}개 (모두 비활성)")
            return
        next_text = min(self._format_next_schedule_run(r.time_hhmm) for r in enabled_rules)
        self._schedule_summary_label.setText(
            f"총 {len(rules)}개 / 활성 {len(enabled_rules)}개\n다음 실행: {next_text}"
        )

    def _open_schedule_manager(self: MacroEditorWindow) -> None:
        self._edit_schedule_rules_dialog()

    def _edit_schedule_rules_dialog(self: MacroEditorWindow) -> None:
        from PyQt6.QtWidgets import QDialog, QDialogButtonBox

        dialog = QDialog(self)
        dialog.setWindowTitle("스케줄 관리")
        dialog.setMinimumWidth(560)
        layout = QFormLayout(dialog)

        schedule_table = QTableWidget(0, 5)
        schedule_table.setHorizontalHeaderLabels(
            ["사용", "시각(HH:MM)", "실행 중 맞물릴 때", "호출할 매크로(JSON)", "rule_id"]
        )
        schedule_table.horizontalHeader().setStretchLastSection(True)
        schedule_table.verticalHeader().setVisible(False)
        schedule_table.setMinimumHeight(260)
        schedule_table.setColumnHidden(4, True)

        def _append_schedule_row(rule: ScheduleRule | None = None) -> None:
            row = schedule_table.rowCount()
            schedule_table.insertRow(row)
            enabled_item = QTableWidgetItem()
            enabled_item.setFlags(
                Qt.ItemFlag.ItemIsEnabled
                | Qt.ItemFlag.ItemIsSelectable
                | Qt.ItemFlag.ItemIsUserCheckable
            )
            enabled_item.setCheckState(
                Qt.CheckState.Checked
                if (rule.enabled if rule is not None else True)
                else Qt.CheckState.Unchecked
            )
            schedule_table.setItem(row, 0, enabled_item)
            time_item = QTableWidgetItem(rule.time_hhmm if rule is not None else "20:00")
            path_item = QTableWidgetItem(rule.macro_path if rule is not None else "")
            rule_id_item = QTableWidgetItem(rule.rule_id if rule is not None else "")
            mode_combo = QComboBox()
            mode_combo.addItem("이어서", "resume")
            mode_combo.addItem("처음부터", "restart")
            mode_combo.addItem("중단", "stop")
            default_mode = "resume" if (rule is None) else rule.on_trigger_during_run
            if default_mode == "resume":
                mode_combo.setCurrentIndex(0)
            elif default_mode == "restart":
                mode_combo.setCurrentIndex(1)
            else:
                mode_combo.setCurrentIndex(2)
            schedule_table.setItem(row, 1, time_item)
            schedule_table.setCellWidget(row, 2, mode_combo)
            schedule_table.setItem(row, 3, path_item)
            schedule_table.setItem(row, 4, rule_id_item)

        for existing_rule in self._macro.settings.schedule_rules:
            _append_schedule_row(existing_rule)

        row_btn_widget = QWidget()
        row_btn_layout = QHBoxLayout(row_btn_widget)
        row_btn_layout.setContentsMargins(0, 0, 0, 0)
        btn_add_rule = QPushButton("규칙 추가")
        btn_remove_rule = QPushButton("규칙 삭제")
        btn_pick_path = QPushButton("경로 선택")
        btn_view_code = QPushButton("코드 보기")
        row_btn_layout.addWidget(btn_add_rule)
        row_btn_layout.addWidget(btn_remove_rule)
        row_btn_layout.addWidget(btn_view_code)
        row_btn_layout.addWidget(btn_pick_path)
        row_btn_layout.addStretch()
        btn_add_rule.clicked.connect(lambda: _append_schedule_row(None))
        btn_remove_rule.clicked.connect(
            lambda: (
                schedule_table.removeRow(schedule_table.currentRow())
                if schedule_table.currentRow() >= 0
                else None
            )
        )

        def _pick_schedule_path() -> None:
            row = schedule_table.currentRow()
            if row < 0:
                return
            selected, _ = QFileDialog.getOpenFileName(
                dialog,
                "스케줄 SubCall 매크로 선택",
                "macros/",
                "매크로 (*.json);;전체 (*)",
            )
            if selected:
                item = schedule_table.item(row, 3)
                if item is None:
                    item = QTableWidgetItem()
                    schedule_table.setItem(row, 3, item)
                item.setText(selected)

        def _view_schedule_code() -> None:
            row = schedule_table.currentRow()
            if row < 0:
                self.log_message("WARNING", "코드 보기를 할 스케줄 규칙을 먼저 선택하세요.")
                return
            path_item = schedule_table.item(row, 3)
            macro_path_text = path_item.text().strip() if path_item is not None else ""
            self._open_schedule_code_viewer(macro_path_text)

        btn_pick_path.clicked.connect(_pick_schedule_path)
        btn_view_code.clicked.connect(_view_schedule_code)
        sched_intro = QLabel(
            "저장된 시각마다 아래 경로의 매크로를 SubCall처럼 호출합니다. "
            "규칙은 지금 편집 중인 매크로 파일에 함께 저장됩니다."
        )
        sched_intro.setWordWrap(True)
        sched_intro.setStyleSheet("color: #555; font-size: 11px;")
        layout.addRow(sched_intro)
        layout.addRow(schedule_table)
        layout.addRow(row_btn_widget)
        schedule_help = QLabel(
            "「실행 중 맞물릴 때」 열 설명:\n"
            "- 이어서: 스케줄로 부른 매크로가 끝난 뒤, 원래 매크로를 멈췄던 다음 줄부터 이어서 갑니다.\n"
            "- 처음부터: 스케줄 매크로 후 원래 매크로를 처음부터 다시 돌립니다.\n"
            "- 중단: 스케줄 매크로만 실행하고 원래 매크로는 다시 이어서 돌리지 않습니다."
        )
        schedule_help.setWordWrap(True)
        schedule_help.setStyleSheet("color: #666; font-size: 10px;")
        layout.addRow(schedule_help)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            new_rules: list[ScheduleRule] = []
            for row in range(schedule_table.rowCount()):
                enabled_item = schedule_table.item(row, 0)
                time_item = schedule_table.item(row, 1)
                mode_widget = schedule_table.cellWidget(row, 2)
                path_item = schedule_table.item(row, 3)
                rule_id_item = schedule_table.item(row, 4)
                if time_item is None or path_item is None:
                    continue
                mode_value = "resume"
                if isinstance(mode_widget, QComboBox):
                    mode_value = str(mode_widget.currentData() or "resume")
                existing_rule_id = rule_id_item.text().strip() if rule_id_item is not None else ""
                base_kwargs = {
                    "enabled": (
                        enabled_item is None or enabled_item.checkState() == Qt.CheckState.Checked
                    ),
                    "time_hhmm": (time_item.text().strip() or "20:00"),
                    "macro_path": path_item.text().strip(),
                    "on_trigger_during_run": (
                        "stop"
                        if mode_value == "stop"
                        else ("restart" if mode_value == "restart" else "resume")
                    ),
                }
                if existing_rule_id:
                    new_rules.append(ScheduleRule(rule_id=existing_rule_id, **base_kwargs))
                else:
                    new_rules.append(ScheduleRule(**base_kwargs))
            self._macro.settings.schedule_rules = new_rules
        except Exception as exc:
            self._show_message("스케줄 관리", f"스케줄 규칙 값이 올바르지 않습니다: {exc}")
            return
        self._is_modified = True
        self._update_title()
        self._refresh_schedule_list()
        self.log_message(
            "INFO", f"스케줄 규칙 변경 완료: 총 {len(self._macro.settings.schedule_rules)}개"
        )

    def _open_schedule_code_viewer(self: MacroEditorWindow, macro_path_text: str) -> None:
        macro_path_text = macro_path_text.strip()
        if not macro_path_text:
            self.log_message("WARNING", "선택한 스케줄 규칙에 매크로 경로가 없습니다.")
            return
        path = Path(macro_path_text)
        try:
            loaded_macro = load_macro(path)
        except Exception as exc:
            self._show_message("스케줄 코드 보기", f"매크로를 불러오지 못했습니다:\n{exc}")
            return
        preview_text = self._build_schedule_action_preview_text(loaded_macro)
        self._show_schedule_code_dialog(path, preview_text)

    def _build_schedule_action_preview_text(self: MacroEditorWindow, macro: Macro) -> str:
        lines: list[str] = []
        lines.append(f"매크로 이름: {macro.name}")
        lines.append(f"액션 수: {len(macro.actions)}")
        lines.append("")
        if macro.settings.schedule_rules:
            lines.append("=== 스케줄 규칙 ===")
            for idx, rule in enumerate(macro.settings.schedule_rules, start=1):
                if rule.on_trigger_during_run == "resume":
                    mode_text = "이어서"
                elif rule.on_trigger_during_run == "restart":
                    mode_text = "처음부터"
                else:
                    mode_text = "중단"
                lines.append(
                    f"규칙#{idx}: {rule.time_hhmm} / {mode_text} / {Path(rule.macro_path).name}"
                )
            lines.append("")
        if not macro.actions:
            lines.append("(액션 없음)")
            return "\n".join(lines)
        lines.append("=== 액션 리스트 미리보기 ===")
        for idx, action in enumerate(macro.actions, start=1):
            summary = get_action_summary(action)
            suffix_parts: list[str] = []
            if not action.enabled:
                suffix_parts.append("비활성")
            if action.comment and action.comment.strip():
                suffix_parts.append(f"메모: {action.comment.strip()}")
            suffix = f"  ({' / '.join(suffix_parts)})" if suffix_parts else ""
            lines.append(f"#{idx:02d}  {summary}{suffix}")
        return "\n".join(lines).rstrip()

    def _show_schedule_code_dialog(self: MacroEditorWindow, path: Path, text: str) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle(f"스케줄 코드 보기 - {path.name}")
        dialog.setMinimumSize(760, 520)
        layout = QVBoxLayout(dialog)
        view = QTextEdit()
        view.setReadOnly(True)
        view.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        view.setPlainText(text)
        layout.addWidget(view)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        buttons.button(QDialogButtonBox.StandardButton.Close).clicked.connect(dialog.close)
        layout.addWidget(buttons)
        dialog.exec()

    def _format_next_schedule_run(self: MacroEditorWindow, time_hhmm: str) -> str:
        if len(time_hhmm) != 5 or ":" not in time_hhmm:
            return "다음시각-오류"
        hh_text, mm_text = time_hhmm.split(":", 1)
        try:
            hh = int(hh_text)
            mm = int(mm_text)
        except ValueError:
            return "다음시각-오류"
        now = datetime.now()
        candidate = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if candidate <= now:
            candidate = candidate + timedelta(days=1)
        return candidate.strftime("%m-%d %H:%M")

    def update_schedule_runtime(self: MacroEditorWindow, rule_id: str, success: bool) -> None:
        self.schedule_runtime_changed.emit(
            rule_id,
            success,
            datetime.now().strftime("%H:%M:%S"),
        )

    def _apply_schedule_runtime(
        self: MacroEditorWindow, rule_id: str, success: bool, at_text: str
    ) -> None:
        self._schedule_runtime[rule_id] = (at_text, success)
        self._refresh_schedule_list()
