"""러너 동기화 관련 믹스인."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from PyQt6.QtCore import QByteArray, Qt, pyqtSlot
from PyQt6.QtGui import QBrush, QColor, QImage, QPixmap
from PyQt6.QtWidgets import QLabel, QTableWidgetItem

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow

# 엔진 썸네일은 30×30 PNG. 독 패널에는 약 2.5배 확대해 표시(가독성, 이전 15×5와 비슷한 크기).
_DEBUG_THUMB_DISPLAY_PX = 75


class RunnerSyncMixin:
    """러너 동기화 관련 메서드를 제공하는 믹스인."""

    def update_variable_display(self: MacroEditorWindow, variables: dict[str, str]) -> None:
        """변수 모니터를 갱신한다(워커 스레드에서도 안전 — 시그널로 메인 스레드에 전달).

        update_execution_row와 동일한 100ms 쓰로틀링 적용.
        """
        now = time.monotonic()
        if now - self._last_variable_display_time < 0.1:
            self._pending_variables = variables
            return
        self._last_variable_display_time = now
        self._pending_variables = None
        self.variables_snapshot_changed.emit(variables)

    def flush_pending_variable_display(self: MacroEditorWindow) -> None:
        """쓰로틀링으로 밀린 변수 스냅샷을 반영한다."""
        if self._pending_variables is not None:
            self.variables_snapshot_changed.emit(self._pending_variables)
            self._pending_variables = None

    def _apply_variable_display(self: MacroEditorWindow, variables: object) -> None:
        """변수 모니터 테이블을 실제로 갱신한다(UI 스레드 전용)."""
        if not isinstance(variables, dict):
            return
        var_map: dict[str, str] = {str(k): str(v) for k, v in variables.items()}
        changed_names = {
            name for name, value in var_map.items() if self._last_variables.get(name) != value
        }

        sorted_items = sorted(var_map.items())
        highlight = QColor(255, 241, 168)
        clear_brush = QBrush()

        # 키 집합·행 수가 같으면 셀 텍스트만 갱신 (변수가 많을 때 전체 재구성 비용 절감)
        if (
            sorted_items
            and len(var_map) == len(self._last_variables)
            and set(var_map) == set(self._last_variables)
            and self._var_table.rowCount() == len(sorted_items)
        ):
            fast_path_ok = True
            for row, (name, value) in enumerate(sorted_items):
                name_item = self._var_table.item(row, 0)
                value_item = self._var_table.item(row, 1)
                if name_item is None or value_item is None:
                    fast_path_ok = False
                    break
                if name_item.text() != name:
                    fast_path_ok = False
                    break
                value_item.setText(value)
                if name in changed_names:
                    name_item.setBackground(highlight)
                    value_item.setBackground(highlight)
                else:
                    name_item.setBackground(clear_brush)
                    value_item.setBackground(clear_brush)
            if fast_path_ok:
                self._last_variables = dict(var_map)
                return

        self._var_table.setRowCount(len(var_map))
        for row, (name, value) in enumerate(sorted_items):
            name_item = QTableWidgetItem(name)
            value_item = QTableWidgetItem(value)
            name_font = name_item.font()
            name_font.setBold(True)
            name_item.setFont(name_font)
            if name in changed_names:
                name_item.setBackground(highlight)
                value_item.setBackground(highlight)
            self._var_table.setItem(row, 0, name_item)
            self._var_table.setItem(row, 1, value_item)

        self._last_variables = dict(var_map)

    @pyqtSlot(bool, str)
    def update_arduino_status(self: MacroEditorWindow, connected: bool, port: str = "") -> None:
        """Arduino 연결 상태를 갱신한다(워커 스레드에서도 안전 — 시그널로 메인 스레드에 전달)."""
        self.arduino_status_changed.emit(connected, port)

    def _apply_arduino_status(self: MacroEditorWindow, connected: bool, port: str = "") -> None:
        """실제 Arduino 상태 위젯을 갱신한다(UI 스레드 전용)."""
        if connected:
            self._status_arduino.set_full_text(f"Arduino  {port} 연결됨")
            self._status_arduino.setStyleSheet(
                "color: #15803d; background: #dcfce7; border: 1px solid #86efac; "
                "border-radius: 5px; font-size: 13px; font-weight: 700; padding: 4px 7px;"
            )
        else:
            self._status_arduino.set_full_text("Arduino  미연결")
            self._status_arduino.setStyleSheet(
                "color: #dc2626; background: #fee2e2; border: 1px solid #fca5a5; "
                "border-radius: 5px; font-size: 13px; font-weight: 700; padding: 4px 7px;"
            )
        self._status_strip_sync()

    def update_runner_state(self: MacroEditorWindow, state: str) -> None:
        """실행 상태 배지를 갱신한다(워커 스레드에서도 안전 — 시그널로 메인 스레드에 전달)."""
        self.runner_state_changed.emit(state)

    def _apply_runner_state(self: MacroEditorWindow, state: str) -> None:
        self._runner_state = state
        self._update_pause_button_label()
        state_display = {
            "IDLE": "○ 대기",
            "RUNNING": "▶ 실행 중",
            "PAUSED": "⏸ 일시정지",
            "STOPPED": "■ 정지됨",
            "COMPLETED": "✓ 매크로 종료",
        }.get(state, state)
        state_icon = {
            "IDLE": "○",
            "RUNNING": "▶",
            "PAUSED": "⏸",
            "STOPPED": "■",
            "COMPLETED": "✓",
        }.get(state, "•")
        self._status_state_full = f" {state_display} "
        self._status_state_icon = state_icon
        state_style = {
            "IDLE": "color: #6b6360; background: #f0ede8; font-size: 14px; font-weight: 700; padding: 4px 8px; border-radius: 5px;",
            "RUNNING": "color: #FFF; background: #15803d; font-size: 14px; font-weight: 700; padding: 4px 8px; border-radius: 5px;",
            "PAUSED": "color: #FFF; background: #d97706; font-size: 14px; font-weight: 700; padding: 4px 8px; border-radius: 5px;",
            "STOPPED": "color: #FFF; background: #dc2626; font-size: 14px; font-weight: 700; padding: 4px 8px; border-radius: 5px;",
            "COMPLETED": "color: #FFF; background: #4f46e5; font-size: 14px; font-weight: 700; padding: 4px 8px; border-radius: 5px;",
        }.get(state, "")
        self._status_state.setStyleSheet(state_style)
        self._status_strip_sync()

        busy = state in ("RUNNING", "PAUSED")
        block_tip = "실행 중에는 사용할 수 없습니다. Ctrl+F7로 정지 후 사용하세요."
        for act in (
            getattr(self, "_act_file_new", None),
            getattr(self, "_act_file_open", None),
            getattr(self, "_act_file_save", None),
            getattr(self, "_act_file_save_as", None),
        ):
            if act is not None:
                act.setEnabled(not busy)
                act.setToolTip(block_tip if busy else "")
        pm = getattr(self, "_btn_player_mode", None)
        if pm is not None:
            pm.setEnabled(not busy)
            pm.setToolTip(
                block_tip
                if busy
                else "경량 플레이어 모드로 전환합니다 (에디터 UI를 숨기고 미니 패널 표시)"
            )
        sm = getattr(self, "_schedule_manage_button", None)
        if sm is not None:
            sm.setEnabled(not busy)
            sm.setToolTip(block_tip if busy else "")

        if state == "RUNNING":
            self._clear_visual_debug_panel()
        if state in ("STOPPED", "IDLE", "COMPLETED"):
            self.flush_pending_execution_row()
            self.flush_pending_variable_display()
            self._action_list.set_execution_row(-1)
        if state in ("STOPPED", "IDLE"):
            self._clear_visual_debug_panel()

    def update_visual_debug(
        self: MacroEditorWindow,
        kind: str,
        ref_png: bytes | None,
        screen_png: bytes | None,
        show_found_thumb: bool,
    ) -> None:
        """워커 스레드에서 호출해도 안전 — 시그널로 UI 스레드에 전달."""
        r = QByteArray(ref_png) if ref_png else QByteArray()
        s = QByteArray(screen_png) if screen_png else QByteArray()
        self.visual_debug_changed.emit(kind, r, s, show_found_thumb)

    def _debug_placeholder_pixmap(self: MacroEditorWindow) -> QPixmap:
        pm = QPixmap(_DEBUG_THUMB_DISPLAY_PX, _DEBUG_THUMB_DISPLAY_PX)
        pm.fill(QColor("#f0ede8"))
        return pm

    def _debug_black_pixmap(self: MacroEditorWindow) -> QPixmap:
        pm = QPixmap(_DEBUG_THUMB_DISPLAY_PX, _DEBUG_THUMB_DISPLAY_PX)
        pm.fill(QColor("#000000"))
        return pm

    def _set_debug_label_png(
        self: MacroEditorWindow, label: QLabel, png_data: bytes | None
    ) -> None:
        disp = _DEBUG_THUMB_DISPLAY_PX
        if png_data:
            img = QImage.fromData(png_data, "PNG")
            if not img.isNull():
                pm = QPixmap.fromImage(img).scaled(
                    disp,
                    disp,
                    Qt.AspectRatioMode.IgnoreAspectRatio,
                    Qt.TransformationMode.FastTransformation,
                )
                label.setPixmap(pm)
                return
        label.setPixmap(self._debug_placeholder_pixmap())

    def _apply_visual_debug(
        self: MacroEditorWindow,
        kind: str,
        ref_ba: QByteArray,
        screen_ba: QByteArray,
        show_found_thumb: bool,
    ) -> None:
        labels_ko = {
            "image_search": "이미지 캡처 · ImageSearch",
            "image_wait": "이미지 캡처 · ImageWait",
            "image_click": "이미지 캡처 · ImageClick",
            "if_pixel": "픽셀 캡처 · IfPixel",
            "pixel_wait": "픽셀 캡처 · PixelWait",
        }
        self._debug_kind_lbl.setText(labels_ko.get(kind, kind))
        ref_png = bytes(ref_ba) if ref_ba.length() > 0 else None
        scr_png = bytes(screen_ba) if screen_ba.length() > 0 else None
        is_image_kind = kind.startswith("image_")

        if ref_png:
            self._set_debug_label_png(self._debug_ref_lbl, ref_png)
        elif is_image_kind and not show_found_thumb:
            self._debug_ref_lbl.setPixmap(self._debug_black_pixmap())
        else:
            self._debug_ref_lbl.setPixmap(self._debug_placeholder_pixmap())

        if show_found_thumb and scr_png:
            self._set_debug_label_png(self._debug_screen_lbl, scr_png)
        elif show_found_thumb:
            self._debug_screen_lbl.setPixmap(self._debug_placeholder_pixmap())
        else:
            self._debug_screen_lbl.setPixmap(self._debug_black_pixmap())

    def _clear_visual_debug_panel(self: MacroEditorWindow) -> None:
        self._debug_kind_lbl.setText("—")
        self._debug_ref_lbl.setPixmap(self._debug_placeholder_pixmap())
        self._debug_screen_lbl.setPixmap(self._debug_placeholder_pixmap())

    def update_execution_row(self: MacroEditorWindow, row: int) -> None:
        """현재 실행 액션 위치를 리스트에 표시한다(워커 스레드에서도 안전).

        100ms 쓰로틀링을 적용하여 UI repaint 부하를 제한한다.
        매 스텝(~5-20ms)마다 호출되지만 실제 UI 갱신은 초당 10회로 제한.
        """
        now = time.monotonic()
        if now - self._last_execution_row_time < 0.1:
            self._pending_execution_row = row
            return
        self._last_execution_row_time = now
        self._pending_execution_row = -1
        self.execution_row_changed.emit(row)

    def flush_pending_execution_row(self: MacroEditorWindow) -> None:
        """쓰로틀링으로 밀린 마지막 실행 행을 반영한다.

        매크로 정지/완료 시 호출하여 최종 위치를 보여준다.
        """
        if self._pending_execution_row >= 0:
            self.execution_row_changed.emit(self._pending_execution_row)
            self._pending_execution_row = -1

    def _apply_execution_row(self: MacroEditorWindow, row: int) -> None:
        self._action_list.set_execution_row(row)

    def get_breakpoint_indices(self: MacroEditorWindow) -> set[int]:
        """현재 설정된 브레이크포인트 인덱스를 반환한다."""
        return self._action_list.get_breakpoint_indices()
