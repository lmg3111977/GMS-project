"""Undo/Redo 관련 믹스인."""

from __future__ import annotations

import copy
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow


class UndoRedoMixin:
    """Undo/Redo 관련 메서드를 제공하는 믹스인."""

    _UNDO_STACK_MAX = 50

    @staticmethod
    def _split_undo_entry(
        item: Any,
    ) -> tuple[list[Any], set[str] | None, set[str] | None]:
        """스택 항목: (액션 목록, 접기 id 집합, 브레이크포인트 id 집합) 또는 레거시 [액션…]."""
        if isinstance(item, tuple) and len(item) == 3:
            return item[0], item[1], item[2]
        if isinstance(item, list):
            return item, None, None
        raise TypeError(f"지원하지 않는 undo 스택 항목: {type(item)!r}")

    def _save_undo_state(self: MacroEditorWindow) -> None:
        current = self._action_list.get_all_actions()
        entry = (
            copy.deepcopy(current),
            set(self._action_list._collapsed_if_action_ids),
            set(self._action_list._breakpoint_action_ids),
        )
        self._undo_stack.append(entry)
        if len(self._undo_stack) > self._UNDO_STACK_MAX:
            self._undo_stack.pop(0)
        self._redo_stack.clear()

    def _undo(self: MacroEditorWindow) -> None:
        if not self._undo_stack:
            self.log_message("WARNING", "실행 취소할 작업이 없습니다")
            return

        current_row = self._action_list.currentRow()
        current = self._action_list.get_all_actions()
        redo_entry = (
            copy.deepcopy(current),
            set(self._action_list._collapsed_if_action_ids),
            set(self._action_list._breakpoint_action_ids),
        )
        self._redo_stack.append(redo_entry)
        if len(self._redo_stack) > self._UNDO_STACK_MAX:
            self._redo_stack.pop(0)

        prev = self._undo_stack.pop()
        prev_actions, prev_collapsed, prev_breakpoints = self._split_undo_entry(prev)
        if prev_collapsed is not None and hasattr(self._action_list, "restore_full_state"):
            self._action_list.restore_full_state(prev_actions, prev_collapsed, prev_breakpoints)
        else:
            self._action_list.set_actions(prev_actions)
        restored = self._action_list.get_all_actions()
        if restored:
            row = max(0, min(current_row, len(restored) - 1))
            self._action_list.setCurrentRow(row)
            self._param_panel.set_action(restored[row])
            self._update_param_header(restored[row], row)
        else:
            self._param_panel.clear_panel()
            self._update_param_header(None)
        self._is_modified = True
        self._update_title()
        self._refresh_variable_suggestions()
        self.log_message("INFO", "실행 취소 완료")
        self._param_undo_snapshot_taken = False

    def _redo(self: MacroEditorWindow) -> None:
        if not self._redo_stack:
            self.log_message("WARNING", "다시 실행할 작업이 없습니다")
            return

        current_row = self._action_list.currentRow()
        current = self._action_list.get_all_actions()
        self._undo_stack.append(
            (
                copy.deepcopy(current),
                set(self._action_list._collapsed_if_action_ids),
                set(self._action_list._breakpoint_action_ids),
            )
        )
        if len(self._undo_stack) > self._UNDO_STACK_MAX:
            self._undo_stack.pop(0)

        nxt = self._redo_stack.pop()
        next_actions, next_collapsed, next_breakpoints = self._split_undo_entry(nxt)
        if next_collapsed is not None and hasattr(self._action_list, "restore_full_state"):
            self._action_list.restore_full_state(next_actions, next_collapsed, next_breakpoints)
        else:
            self._action_list.set_actions(next_actions)
        restored = self._action_list.get_all_actions()
        if restored:
            row = max(0, min(current_row, len(restored) - 1))
            self._action_list.setCurrentRow(row)
            self._param_panel.set_action(restored[row])
            self._update_param_header(restored[row], row)
        else:
            self._param_panel.clear_panel()
            self._update_param_header(None)
        self._is_modified = True
        self._update_title()
        self._refresh_variable_suggestions()
        self.log_message("INFO", "다시 실행 완료")
        self._param_undo_snapshot_taken = False
