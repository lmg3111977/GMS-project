"""실행 제어 관련 믹스인."""

from __future__ import annotations

from typing import TYPE_CHECKING

from PyQt6.QtCore import QSettings
from PyQt6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QTextEdit,
    QVBoxLayout,
)

from shared.macro_run_summary import format_run_summary_text

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow


class RunControlMixin:
    """실행 제어 관련 메서드를 제공하는 믹스인."""

    def _run_macro(self: MacroEditorWindow) -> None:
        if self._recorder.is_recording:
            self.log_message("WARNING", "녹화 중에는 실행할 수 없습니다. 녹화를 먼저 정지하세요.")
            return
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message("WARNING", "이미 실행 중입니다")
            return
        self._macro.actions = self._action_list.get_all_actions()
        if not self._macro.actions:
            self.log_message("WARNING", "실행할 액션이 없습니다")
            return

        self._pending_rehearsal_run = False
        settings = QSettings("GameMacroStudio", "Editor")
        skip_dialog = settings.value("run_confirm_dialog/skip", False, bool)
        if not skip_dialog:
            dlg = QDialog(self)
            dlg.setWindowTitle("실행 전 확인")
            layout = QVBoxLayout(dlg)
            layout.addWidget(
                QLabel(
                    "아래 요약을 확인한 뒤 실행하세요.\n"
                    "막히면 도움말 → 사용 가이드 또는 단축키 안내를 먼저 보세요. "
                    "(소스 트리를 쓰는 경우 docs/user/troubleshooting.md)"
                )
            )
            summary = QTextEdit()
            summary.setReadOnly(True)
            summary.setPlainText(format_run_summary_text(self._macro))
            summary.setMinimumHeight(220)
            layout.addWidget(summary)
            cb_skip = QCheckBox("다음부터 이 대화상자 생략")
            layout.addWidget(cb_skip)
            ctx = getattr(self, "_app_ctx", None)
            dry_run_app = bool(getattr(ctx, "dry_run", False)) if ctx is not None else False
            cb_rehearsal = QCheckBox(
                "리허설 (HID 미전송, Stub 로그만 — Arduino에 입력 보내지 않음)"
            )
            cb_rehearsal.setEnabled(not dry_run_app)
            if dry_run_app:
                cb_rehearsal.setToolTip("앱이 이미 --dry-run 모드입니다.")
            layout.addWidget(cb_rehearsal)
            buttons = QDialogButtonBox(
                QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
            )
            buttons.accepted.connect(dlg.accept)
            buttons.rejected.connect(dlg.reject)
            layout.addWidget(buttons)
            if dlg.exec() != QDialog.DialogCode.Accepted:
                return
            if cb_skip.isChecked():
                settings.setValue("run_confirm_dialog/skip", True)
            self._pending_rehearsal_run = cb_rehearsal.isChecked() and not dry_run_app

        self.macro_run_requested.emit(self._macro)
        self._status_state_full = " ▶ 실행 중 "
        self._status_state_icon = "▶"
        self._status_state.setStyleSheet(
            "color: #FFF; background: #15803d; font-size: 14px; font-weight: 700; "
            "padding: 4px 8px; border-radius: 5px;"
        )
        self._status_strip_sync()
        self.log_message("INFO", "실행 요청: 매크로")

    def _pause_macro(self: MacroEditorWindow) -> None:
        # 실행 중에는 일시정지, 일시정지 중에는 재개로 토글한다.
        if self._runner_state == "PAUSED":
            self.macro_resume_requested.emit()
            self.log_message("INFO", "실행 요청: 매크로 재개")
            return

        self.macro_pause_requested.emit()
        self.log_message("INFO", "실행 요청: 매크로 일시정지")

    def _update_pause_button_label(self: MacroEditorWindow) -> None:
        """현재 실행 상태에 맞춰 일시정지/재개 버튼 라벨을 갱신한다."""
        if self._runner_state == "PAUSED":
            self._btn_pause.setText("▶ 재개 (Ctrl+F6)")
        else:
            self._btn_pause.setText("⏸ 일시정지 (Ctrl+F6)")

    def _stop_macro(self: MacroEditorWindow) -> None:
        self.macro_stop_requested.emit()
        self._status_state_full = " ■ 정지됨 "
        self._status_state_icon = "■"
        self._status_state.setStyleSheet(
            "color: #FFF; background: #dc2626; font-size: 14px; font-weight: 700; "
            "padding: 4px 8px; border-radius: 5px;"
        )
        self._status_strip_sync()
        self._action_list.set_execution_row(-1)

    def _step_macro(self: MacroEditorWindow) -> None:
        """디버그 1스텝 실행 요청."""
        self.macro_step_requested.emit()
        self.log_message("DEBUG", "실행 요청: 스텝")

    def _on_switch_to_player(self: MacroEditorWindow) -> None:
        """플레이어 모드로 전환을 요청한다.

        매크로가 실행 중이면 전환을 차단한다.
        """
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message("WARNING", "매크로 실행 중에는 모드를 전환할 수 없습니다.")
            return
        self.switch_to_player_requested.emit()

    def _toggle_recording(self: MacroEditorWindow) -> None:
        """녹화 시작/정지를 토글한다."""
        if self._recorder.is_recording:
            recorded_actions = self._recorder.stop_recording()
            if recorded_actions:
                # 녹화 전체를 하나의 undo 단위로 처리한다.
                self._save_undo_state()
                self._action_list.blockSignals(True)
                for act in recorded_actions:
                    self._action_list.add_action(act)
                self._action_list._rebuild_list()
                self._action_list.blockSignals(False)
                self._is_modified = True
                self._update_title()
                self._refresh_variable_suggestions()
                self.log_message(
                    "INFO",
                    f"녹화 완료: {len(recorded_actions)}개 액션 추가됨",
                )
            else:
                self.log_message("WARNING", "녹화 결과 없음: 액션 0개")
            self._btn_record.setText("● 녹화 (Ctrl+R)")
        else:
            if self._runner_state in ("RUNNING", "PAUSED"):
                self.log_message("WARNING", "녹화 시작 실패: 매크로 실행/일시정지 중 상태")
                return
            self._recorder.start_recording()
            self.log_message("INFO", "녹화 시작 완료: Ctrl+R로 정지")
            self._btn_record.setText("■ 녹화 정지 (Ctrl+R)")
