"""매크로 에디터 메인 윈도우 패키지."""

from editor.main_window.window import MacroEditorWindow

__all__ = ["MacroEditorWindow"]
