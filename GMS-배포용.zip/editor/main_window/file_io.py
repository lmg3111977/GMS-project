"""파일 입출력 관련 믹스인."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from PyQt6.QtWidgets import QFileDialog

from shared.models import Macro
from shared.schema import MacroValidationError, load_macro, save_macro

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow


class FileIOMixin:
    """파일 입출력 관련 메서드를 제공하는 믹스인."""

    def _new_macro(self: MacroEditorWindow) -> None:
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message("WARNING", "매크로 실행 중에는 새로 만들기를 사용할 수 없습니다.")
            return
        if self._is_modified and not self._confirm_discard():
            return
        self._macro = Macro()
        self._current_file = None
        self._action_list.set_actions([])
        self._param_undo_snapshot_taken = False
        self._param_panel.clear_panel()
        self._update_param_header(None)
        self._is_modified = False
        self._update_title()
        self._refresh_variable_suggestions()
        self._refresh_schedule_list()
        self.log_message("INFO", "매크로 생성 완료")

    def _open_macro(self: MacroEditorWindow) -> None:
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message("WARNING", "매크로 실행 중에는 파일 열기를 사용할 수 없습니다.")
            return
        if self._is_modified and not self._confirm_discard():
            return
        file_path, _ = QFileDialog.getOpenFileName(
            self, "매크로 열기", "macros/", "매크로 (*.json);;전체 (*)"
        )
        if not file_path:
            return
        self._open_macro_from_path(Path(file_path), ask_discard=False)

    def _save_macro(self: MacroEditorWindow) -> None:
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message(
                "WARNING",
                "매크로 실행 중에는 저장할 수 없습니다. 먼저 정지(Ctrl+F7)하세요.",
            )
            return
        if self._current_file is None:
            self._save_macro_as()
            return
        self._do_save(self._current_file)

    def _save_macro_as(self: MacroEditorWindow) -> None:
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message(
                "WARNING",
                "매크로 실행 중에는 저장할 수 없습니다. 먼저 정지(Ctrl+F7)하세요.",
            )
            return
        file_path, _ = QFileDialog.getSaveFileName(
            self, "매크로 저장", "macros/", "매크로 (*.json)"
        )
        if not file_path:
            return
        if not file_path.endswith(".json"):
            file_path += ".json"
        self._do_save(Path(file_path))

    def _do_save(self: MacroEditorWindow, path: Path) -> None:
        self._macro.actions = self._action_list.get_all_actions()
        try:
            save_macro(self._macro, path)
            self._current_file = path
            self._is_modified = False
            self._update_title()
            self.log_message("INFO", f"매크로 저장 완료: {path}")
        except MacroValidationError as exc:
            self._show_message("저장 실패", f"검증 오류:\n{exc}")

    def _open_macro_from_path(
        self: MacroEditorWindow, path: Path, *, ask_discard: bool = True
    ) -> None:
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message("WARNING", "매크로 실행 중에는 파일 열기를 사용할 수 없습니다.")
            return
        if ask_discard and self._is_modified and not self._confirm_discard():
            return
        try:
            loaded = load_macro(path)
        except (MacroValidationError, FileNotFoundError) as exc:
            self._show_message("열기 실패", str(exc))
            return

        self._macro = loaded
        self._current_file = path
        self._action_list.set_actions(self._macro.actions)
        self._param_undo_snapshot_taken = False
        self._param_panel.clear_panel()
        self._update_param_header(None)
        self._is_modified = False
        self._update_title()
        self._refresh_variable_suggestions()
        self._refresh_schedule_list()
        self.log_message("INFO", f"매크로 열기 완료: {path}")
        self.file_opened.emit(str(path))
