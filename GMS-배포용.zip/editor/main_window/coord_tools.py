"""좌표 도구 관련 믹스인."""

from __future__ import annotations

from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QCursor, QGuiApplication
from PyQt6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QSpinBox,
)

from editor.widgets.color_swatch import capture_color_swatch_icon
from shared.models import (
    Action,
    IfPixelAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    MouseDragAction,
    MouseMoveAction,
    OCRReadAction,
    OCRWaitAction,
    PixelWaitAction,
)

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow


class CoordToolsMixin:
    """좌표 도구 관련 메서드를 제공하는 믹스인."""

    def _update_capture_status_badge(
        self: MacroEditorWindow,
        x: int,
        y: int,
        hex_color: str,
    ) -> None:
        """상태바 F8 캡처 배지를 갱신한다."""
        self._status_capture_x.setText(f"X {x}")
        self._status_capture_y.setText(f"Y {y}")
        self._status_capture_color.setText("")
        self._status_capture_color.setMinimumSize(52, 26)
        self._status_capture_color.setMaximumHeight(28)
        self._status_capture_color.setToolTip(
            f"캡처 픽셀 색 미리보기\nHEX: {hex_color}\n클립보드: {x},{y},{hex_color}"
        )
        self._status_capture_color.setStyleSheet(
            f"background: {hex_color}; border: 1px solid #9e9e9e; "
            "border-radius: 5px; padding: 0;"
        )
        self._status_capture_box.setStyleSheet(
            "background: #F1F1F1; border: 1px solid #BDBDBD; border-radius: 5px;"
        )
        self._status_capture_x.setStyleSheet("color: #0D47A1; font-size: 15px; font-weight: 800;")
        self._status_capture_y.setStyleSheet("color: #0D47A1; font-size: 15px; font-weight: 800;")
        if hasattr(self, "_status_capture_xy_compact_label"):
            self._status_capture_xy_compact_label.setStyleSheet(
                "color: #0D47A1; font-size: 15px; font-weight: 800;"
            )
        self._status_strip_sync()

    def _refresh_capture_history_selector(self: MacroEditorWindow) -> None:
        """상태바 캡처 히스토리 콤보를 최신 상태로 갱신한다."""
        if not hasattr(self, "_status_capture_history_combo"):
            return
        history = getattr(self, "_capture_history", None)
        combo = self._status_capture_history_combo
        combo.blockSignals(True)
        try:
            combo.clear()
            if history is None or not history.entries:
                combo.addItem("최근 캡처 없음")
                combo.setEnabled(False)
                return

            combo.setEnabled(True)
            for entry in history.entries:
                icon = capture_color_swatch_icon(entry.color)
                combo.addItem(icon, entry.display_label())
                idx = combo.count() - 1
                combo.setItemData(
                    idx,
                    (
                        f"좌표 ({entry.x}, {entry.y})\n"
                        f"HEX {entry.color}\n"
                        f"클립보드: {entry.to_clipboard_text()}"
                    ),
                    Qt.ItemDataRole.ToolTipRole,
                )

            active_index = history.active_index
            if 0 <= active_index < combo.count():
                combo.setCurrentIndex(active_index)
        finally:
            combo.blockSignals(False)

    def _on_capture_history_selected(self: MacroEditorWindow, index: int) -> None:
        """상태바 콤보 선택 항목을 활성 캡처로 반영한다."""
        history = getattr(self, "_capture_history", None)
        if history is None:
            return
        if index < 0 or index >= len(history.entries):
            return
        history.select(index)
        entry = history.active
        if entry is None:
            return
        QGuiApplication.clipboard().setText(entry.to_clipboard_text())
        self._update_capture_status_badge(entry.x, entry.y, entry.color)

    def _open_coordinate_offset_dialog(self: MacroEditorWindow) -> None:
        """현재 매크로의 좌표 필드에 DX/DY를 일괄 적용한다."""
        if self._runner_state in ("RUNNING", "PAUSED"):
            self.log_message("WARNING", "매크로 실행 중에는 좌표 오프셋을 적용할 수 없습니다.")
            return

        actions = self._action_list.get_all_actions()
        if not actions:
            self.log_message("WARNING", "오프셋을 적용할 액션이 없습니다.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("좌표 오프셋 적용")
        dialog.setMinimumWidth(420)
        layout = QFormLayout(dialog)

        spin_dx = QSpinBox()
        spin_dx.setRange(-7680, 7680)
        spin_dx.setValue(0)
        spin_dx.setToolTip("오른쪽은 +, 왼쪽은 -\n예) 오른쪽으로 300px 이동: 300")
        layout.addRow("가로 이동값 (DX):", spin_dx)

        spin_dy = QSpinBox()
        spin_dy.setRange(-4320, 4320)
        spin_dy.setValue(0)
        spin_dy.setToolTip("아래는 +, 위는 -\n예) 위로 120px 이동: -120")
        layout.addRow("세로 이동값 (DY):", spin_dy)

        include_relative = QCheckBox("상대 이동값(MouseMove)에도 같이 적용")
        include_relative.setChecked(False)
        include_relative.setToolTip(
            "기본 권장: 해제\n체크하면 상대 이동(dx, dy) 값도 함께 바뀝니다."
        )
        layout.addRow(include_relative)
        relative_help = QLabel(
            "설명: 보통은 끄는 것을 권장합니다.\n"
            "이 옵션을 켜면 '현재 위치에서 얼마나 이동할지' 값도 함께 변경됩니다."
        )
        relative_help.setWordWrap(True)
        relative_help.setStyleSheet("color: #666; font-size: 11px;")
        layout.addRow(relative_help)

        include_click_offsets = QCheckBox("이미지 클릭 보정값(click_offset)도 같이 적용")
        include_click_offsets.setChecked(False)
        include_click_offsets.setToolTip(
            "이미지 중심에서 추가로 이동해 클릭하는 보정값까지 변경합니다."
        )
        layout.addRow(include_click_offsets)
        click_offset_help = QLabel(
            "설명: 이미지를 찾은 뒤 중심점에서 추가로 이동해 클릭하는 보정값입니다.\n"
            "정밀하게 클릭 위치를 맞춰둔 매크로라면 함께 이동이 필요할 수 있습니다."
        )
        click_offset_help.setWordWrap(True)
        click_offset_help.setStyleSheet("color: #666; font-size: 11px;")
        layout.addRow(click_offset_help)

        clamp_to_screen = QCheckBox("실제 화면 범위로 안전 보정(권장)")
        clamp_to_screen.setChecked(False)
        clamp_to_screen.setToolTip("체크 시 현재 모니터 범위를 넘어가는 좌표를 자동 보정합니다.")
        layout.addRow(clamp_to_screen)
        clamp_help = QLabel(
            "설명: 오프셋 후 좌표가 화면 밖으로 나가면 자동으로 안전한 범위로 줄여줍니다.\n"
            "멀티 모니터/해상도 변경 환경에서 오류를 줄일 때 유용합니다."
        )
        clamp_help.setWordWrap(True)
        clamp_help.setStyleSheet("color: #666; font-size: 11px;")
        layout.addRow(clamp_help)

        help_label = QLabel(
            "이 기능은 현재 매크로 파일의 좌표를 한 번에 이동합니다.\n"
            "예) 다른 게임 창으로 옮길 때 DX/DY만 입력하면 됩니다."
        )
        help_label.setWordWrap(True)
        help_label.setStyleSheet("color: #666; font-size: 11px;")
        layout.addRow(help_label)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        dx = spin_dx.value()
        dy = spin_dy.value()
        if dx == 0 and dy == 0:
            self.log_message("INFO", "적용 취소: 이동값(DX/DY)이 0입니다.")
            return

        include_relative_move = include_relative.isChecked()
        include_click_offset_xy = include_click_offsets.isChecked()
        use_screen_bounds_clamp = clamp_to_screen.isChecked()

        _, changed_count, clamped_count, screen_out_count = self._apply_coordinate_offset(
            actions,
            dx=dx,
            dy=dy,
            include_relative_move=include_relative_move,
            include_click_offsets=include_click_offset_xy,
            use_screen_bounds_clamp=use_screen_bounds_clamp,
            dry_run=True,
        )
        if changed_count == 0:
            self.log_message("INFO", "적용할 좌표 변경이 없습니다.")
            return

        confirm_text = (
            f"이동값: DX={dx}, DY={dy}\n\n"
            f"변경되는 액션: {changed_count}/{len(actions)}\n"
            f"자동 보정(클램프): {clamped_count}건\n"
            f"화면 밖 예상 좌표/영역: {screen_out_count}건\n\n"
            "이대로 적용할까요?"
        )
        if not self._ask_yes_no("좌표 오프셋 확인", confirm_text, default_yes=True):
            self.log_message("INFO", "좌표 오프셋 적용이 취소되었습니다.")
            return

        updated_actions, changed_count, clamped_count, screen_out_count = (
            self._apply_coordinate_offset(
                actions,
                dx=dx,
                dy=dy,
                include_relative_move=include_relative_move,
                include_click_offsets=include_click_offset_xy,
                use_screen_bounds_clamp=use_screen_bounds_clamp,
            )
        )

        current_row = self._action_list.currentRow()
        self._save_undo_state()
        self._action_list.set_actions(updated_actions)
        self._param_undo_snapshot_taken = False
        if updated_actions:
            row = max(0, min(current_row, len(updated_actions) - 1))
            self._action_list.setCurrentRow(row)
            self._param_panel.set_action(updated_actions[row])
            self._update_param_header(updated_actions[row], row)
        else:
            self._param_panel.clear_panel()
            self._update_param_header(None)

        self._is_modified = True
        self._update_title()
        self._refresh_variable_suggestions()
        self.log_message(
            "INFO",
            (
                f"좌표 오프셋 적용 완료: DX={dx}, DY={dy}, "
                f"변경 액션 {changed_count}/{len(updated_actions)}, "
                f"클램프 {clamped_count}건, "
                f"실화면 경계 초과 {screen_out_count}건"
            ),
        )

    def _virtual_screen_bounds(self: MacroEditorWindow) -> tuple[int, int, int, int] | None:
        """현재 시스템의 가상 데스크톱 경계를 반환한다."""
        screens = QGuiApplication.screens()
        if not screens:
            return None
        first = screens[0].geometry()
        left = first.left()
        top = first.top()
        right = first.right()
        bottom = first.bottom()
        for screen in screens[1:]:
            geo = screen.geometry()
            left = min(left, geo.left())
            top = min(top, geo.top())
            right = max(right, geo.right())
            bottom = max(bottom, geo.bottom())
        return left, top, right, bottom

    def _apply_coordinate_offset(
        self: MacroEditorWindow,
        actions: list[Action],
        *,
        dx: int,
        dy: int,
        include_relative_move: bool,
        include_click_offsets: bool,
        use_screen_bounds_clamp: bool,
        dry_run: bool = False,
    ) -> tuple[list[Action], int, int, int]:
        """좌표 기반 액션에 DX/DY를 적용한다."""
        schema_x_min, schema_x_max = 0, 7680
        schema_y_min, schema_y_max = 0, 4320
        screen_bounds = self._virtual_screen_bounds()
        x_min, x_max = schema_x_min, schema_x_max
        y_min, y_max = schema_y_min, schema_y_max
        if use_screen_bounds_clamp and screen_bounds is not None:
            left, top, right, bottom = screen_bounds
            x_min = max(schema_x_min, left)
            x_max = min(schema_x_max, right)
            y_min = max(schema_y_min, top)
            y_max = min(schema_y_max, bottom)
            if x_min > x_max:
                x_min, x_max = schema_x_min, schema_x_max
            if y_min > y_max:
                y_min, y_max = schema_y_min, schema_y_max

        def _clamp(value: int, low: int, high: int) -> tuple[int, bool]:
            clamped = max(low, min(high, value))
            return clamped, clamped != value

        # dry_run에서도 동일 로직으로 계산하되, 원본 액션은 절대 변경하지 않는다.
        # (기존에는 dry_run 시 원본을 직접 수정해 오프셋이 2번 누적되는 문제가 있었다.)
        updated_actions = [a.model_copy(deep=True) for a in actions]
        changed_count = 0
        clamped_count = 0
        screen_out_count = 0

        def _track_screen_out(x_val: int, y_val: int) -> None:
            nonlocal screen_out_count
            if screen_bounds is None:
                return
            left, top, right, bottom = screen_bounds
            if x_val < left or x_val > right or y_val < top or y_val > bottom:
                screen_out_count += 1

        def _track_region_out(x_val: int, y_val: int, width: int, height: int) -> None:
            nonlocal screen_out_count
            if screen_bounds is None:
                return
            left, top, right, bottom = screen_bounds
            region_right = x_val + max(1, width) - 1
            region_bottom = y_val + max(1, height) - 1
            if x_val < left or y_val < top or region_right > right or region_bottom > bottom:
                screen_out_count += 1

        for action in updated_actions:
            changed = False

            if isinstance(action, MouseMoveAction):
                if action.is_relative and not include_relative_move:
                    continue
                if action.is_relative:
                    new_x = action.x + dx
                    new_y = action.y + dy
                    x_clamped = False
                    y_clamped = False
                else:
                    new_x, x_clamped = _clamp(action.x + dx, x_min, x_max)
                    new_y, y_clamped = _clamp(action.y + dy, y_min, y_max)
                changed = (new_x != action.x) or (new_y != action.y)
                action.x = new_x
                action.y = new_y
                clamped_count += int(x_clamped) + int(y_clamped)
                if changed and not action.is_relative:
                    _track_screen_out(action.x, action.y)

            elif isinstance(action, MouseDragAction):
                new_sx, sx_clamped = _clamp(action.start_x + dx, x_min, x_max)
                new_sy, sy_clamped = _clamp(action.start_y + dy, y_min, y_max)
                new_ex, ex_clamped = _clamp(action.end_x + dx, x_min, x_max)
                new_ey, ey_clamped = _clamp(action.end_y + dy, y_min, y_max)
                changed = (
                    new_sx != action.start_x
                    or new_sy != action.start_y
                    or new_ex != action.end_x
                    or new_ey != action.end_y
                )
                action.start_x = new_sx
                action.start_y = new_sy
                action.end_x = new_ex
                action.end_y = new_ey
                clamped_count += (
                    int(sx_clamped) + int(sy_clamped) + int(ex_clamped) + int(ey_clamped)
                )
                if changed:
                    _track_screen_out(action.start_x, action.start_y)
                    _track_screen_out(action.end_x, action.end_y)

            elif isinstance(action, (IfPixelAction, PixelWaitAction)):
                new_x, x_clamped = _clamp(action.x + dx, x_min, x_max)
                new_y, y_clamped = _clamp(action.y + dy, y_min, y_max)
                changed = (new_x != action.x) or (new_y != action.y)
                action.x = new_x
                action.y = new_y
                clamped_count += int(x_clamped) + int(y_clamped)
                if changed:
                    _track_screen_out(action.x, action.y)

            elif isinstance(
                action,
                (
                    ImageSearchAction,
                    ImageWaitAction,
                    ImageClickAction,
                    OCRReadAction,
                    OCRWaitAction,
                ),
            ):
                new_rx, rx_clamped = _clamp(action.region_x + dx, x_min, x_max)
                new_ry, ry_clamped = _clamp(action.region_y + dy, y_min, y_max)
                changed = (new_rx != action.region_x) or (new_ry != action.region_y)
                action.region_x = new_rx
                action.region_y = new_ry
                clamped_count += int(rx_clamped) + int(ry_clamped)
                if changed:
                    _track_region_out(
                        action.region_x,
                        action.region_y,
                        action.region_width,
                        action.region_height,
                    )
                if include_click_offsets and isinstance(
                    action, (ImageSearchAction, ImageClickAction)
                ):
                    new_cx = action.click_offset_x + dx
                    new_cy = action.click_offset_y + dy
                    if new_cx != action.click_offset_x or new_cy != action.click_offset_y:
                        changed = True
                        action.click_offset_x = new_cx
                        action.click_offset_y = new_cy

            if changed:
                changed_count += 1

        return updated_actions, changed_count, clamped_count, screen_out_count

    def _capture_mouse_clipboard(self: MacroEditorWindow) -> None:
        """F8: 현재 마우스 좌표와 픽셀 색상을 클립보드에 저장한다.

        포맷: "x,y,#RRGGBB" — 파라미터 패널에서 쉽게 붙여넣어 사용할 수 있다.
        """
        pos = QCursor.pos()
        x, y = pos.x(), pos.y()

        hex_color = "#000000"
        color_ok = False
        screen = QGuiApplication.primaryScreen()
        if screen is not None:
            try:
                pixmap = screen.grabWindow(0, x, y, 1, 1)
                img = pixmap.toImage()
                if not img.isNull():
                    c = img.pixelColor(0, 0)
                    hex_color = f"#{c.red():02X}{c.green():02X}{c.blue():02X}"
                    color_ok = True
            except Exception:
                color_ok = False

        text = f"{x},{y},{hex_color}"
        clipboard = QGuiApplication.clipboard()
        clipboard.setText(text)
        if hasattr(self, "_capture_history"):
            self._capture_history.push(x, y, hex_color)
            self._refresh_capture_history_selector()
        if color_ok:
            self.log_message("INFO", f"F8 캡처 완료: {text}")
        else:
            self.log_message(
                "WARNING",
                f"F8 캡처 실패(픽셀색상): {x},{y} (기본 #000000 사용)",
            )

        # 상태바 통합 배지(F8 상태/좌표/색상)를 갱신한다.
        self._update_capture_status_badge(x, y, hex_color)
