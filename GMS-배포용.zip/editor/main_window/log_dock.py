"""로그 독 패널 관련 믹스인."""

from __future__ import annotations

from datetime import datetime
from html import escape
from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt, pyqtSlot
from PyQt6.QtGui import QTextCursor
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDockWidget,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

if TYPE_CHECKING:
    from editor.main_window.window import MacroEditorWindow

# 엔진 썸네일은 30×30 PNG. 독 패널에는 약 2.5배 확대해 표시(가독성, 이전 15×5와 비슷한 크기).
_DEBUG_THUMB_SOURCE_PX = 30
_DEBUG_THUMB_DISPLAY_PX = 75


class LogDockMixin:
    """로그 독 패널 관련 메서드를 제공하는 믹스인."""

    def _setup_bottom_panel_dock(self: MacroEditorWindow) -> None:
        """하단 독: 좌측 실행 로그, 우측 이미지·픽셀 캡처(QSplitter로 폭 조절)."""
        dock = QDockWidget("실행 로그 · 이미지/픽셀", self)
        dock.setToolTip(
            "왼쪽: 실행 로그 필터·삭제. 오른쪽: 디버그용 캡처 미리보기. "
            "Ctrl+L로 이 패널을 숨기거나 다시 표시합니다."
        )
        self._log_dock = dock
        dock.setAllowedAreas(
            Qt.DockWidgetArea.BottomDockWidgetArea | Qt.DockWidgetArea.TopDockWidgetArea
        )

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(8)
        splitter.setStyleSheet(
            "QSplitter::handle:horizontal {"
            "background: #efebe6;"
            "border-left: 1px solid #cdc5bb;"
            "border-right: 1px solid #cdc5bb;"
            "}"
            "QSplitter::handle:horizontal:hover {"
            "background: #e6e0d8;"
            "border-left: 1px solid #b5ac9f;"
            "border-right: 1px solid #b5ac9f;"
            "}"
        )

        log_container = QWidget()
        log_layout = QVBoxLayout(log_container)
        log_layout.setContentsMargins(0, 0, 0, 0)
        log_layout.setSpacing(2)

        # FIX #6: 로그 삭제 버튼
        log_toolbar = QHBoxLayout()
        self._log_filter_preset = QComboBox()
        self._log_filter_preset.addItems(["전체", "경고+오류", "오류만"])
        self._log_filter_preset.setToolTip("자주 쓰는 로그 보기 프리셋입니다. 아래 체크박스로 세부 조합도 바꿀 수 있습니다.")
        self._log_filter_preset.currentTextChanged.connect(self._on_log_filter_preset_changed)
        self._log_filter_preset.setFixedWidth(110)
        log_toolbar.addWidget(self._log_filter_preset)
        log_toolbar.addWidget(QLabel("필터:"))
        self._log_filter_info = QCheckBox("INFO")
        self._log_filter_info.setChecked(True)
        self._log_filter_info.stateChanged.connect(self._on_log_filter_changed)
        log_toolbar.addWidget(self._log_filter_info)

        self._log_filter_warning = QCheckBox("WARN")
        self._log_filter_warning.setChecked(True)
        self._log_filter_warning.stateChanged.connect(self._on_log_filter_changed)
        log_toolbar.addWidget(self._log_filter_warning)

        self._log_filter_error = QCheckBox("ERROR")
        self._log_filter_error.setChecked(True)
        self._log_filter_error.stateChanged.connect(self._on_log_filter_changed)
        log_toolbar.addWidget(self._log_filter_error)
        self._log_filter_info.setStyleSheet(
            "background: transparent; color: #1f1b16; font-weight: bold;"
            "QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #d4c9bc; border-radius: 3px; background: #ffffff; }"
            "QCheckBox::indicator:checked { border: 1px solid #9e9a96; background: #f5f1ec; }"
        )
        self._log_filter_warning.setStyleSheet(
            "background: transparent; color: #b45309; font-weight: bold;"
            "QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #d4c9bc; border-radius: 3px; background: #ffffff; }"
            "QCheckBox::indicator:checked { border: 1px solid #9e9a96; background: #f5f1ec; }"
        )
        self._log_filter_error.setStyleSheet(
            "background: transparent; color: #dc2626; font-weight: bold;"
            "QCheckBox::indicator { width: 14px; height: 14px; border: 1px solid #d4c9bc; border-radius: 3px; background: #ffffff; }"
            "QCheckBox::indicator:checked { border: 1px solid #9e9a96; background: #f5f1ec; }"
        )
        log_toolbar.addStretch()
        btn_clear_log = QPushButton("로그 삭제")
        btn_clear_log.setFixedHeight(22)
        btn_clear_log.setStyleSheet("font-size: 11px; padding: 2px 10px;")
        btn_clear_log.clicked.connect(self._clear_log)
        log_toolbar.addWidget(btn_clear_log)
        self._log_filter_preset.setStyleSheet(self._log_combo_style())
        log_toolbar_widget = QWidget()
        log_toolbar_widget.setObjectName("logFilterBar")
        log_toolbar_widget.setLayout(log_toolbar)
        log_toolbar_widget.setStyleSheet(self._log_toolbar_style())
        # 필터 줄은 세로로 늘리지 않음 (독 리사이즈 시 여유 공간은 로그 본문으로만)
        log_toolbar_widget.setSizePolicy(
            QSizePolicy.Policy.Preferred,
            QSizePolicy.Policy.Fixed,
        )
        log_toolbar_widget.setFixedHeight(35)
        log_layout.addWidget(log_toolbar_widget, stretch=0)

        self._log_text = QTextEdit()
        self._log_text.setReadOnly(True)
        # 독 높이에 맞춰 로그 영역이 늘어나도록 Expanding + stretch(아래)
        self._log_text.setMinimumHeight(24)
        self._log_text.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding,
        )
        # QTextEdit의 block 수를 제한해서 오래된 로그가 자동으로 잘리도록 한다.
        self._log_text.document().setMaximumBlockCount(500)
        self._log_text.setStyleSheet(self._log_text_style("보통"))
        log_layout.addWidget(self._log_text, stretch=1)

        density_row = QHBoxLayout()
        density_row.setContentsMargins(0, 0, 0, 0)
        density_row.addWidget(QLabel("로그 크기"))
        self._log_font_size_preset = QComboBox()
        self._log_font_size_preset.addItems(["작게", "보통", "크게"])
        self._log_font_size_preset.setCurrentText("보통")
        self._log_font_size_preset.currentTextChanged.connect(self._on_log_font_size_changed)
        self._log_font_size_preset.setStyleSheet(self._log_combo_style())
        density_row.addWidget(self._log_font_size_preset)
        density_row.addStretch()
        density_widget = QWidget()
        density_widget.setLayout(density_row)
        density_widget.setSizePolicy(
            QSizePolicy.Policy.Preferred,
            QSizePolicy.Policy.Fixed,
        )
        density_widget.setFixedHeight(28)
        log_layout.addWidget(density_widget, stretch=0)

        capture_root = QWidget()
        cap_layout = QHBoxLayout(capture_root)
        cap_layout.setContentsMargins(8, 6, 8, 6)
        cap_layout.setSpacing(12)

        info_col = QVBoxLayout()
        cap_title = QLabel(
            "이미지·픽셀 캡처\n" "ImageSearch / ImageWait / ImageClick / IfPixel / PixelWait"
        )
        cap_title.setStyleSheet("font-weight: bold; font-size: 11px; color: #1f1b16;")
        cap_title.setWordWrap(True)
        info_col.addWidget(cap_title)
        self._debug_kind_lbl = QLabel("—")
        self._debug_kind_lbl.setStyleSheet("color: #6b6360; font-size: 10px;")
        self._debug_kind_lbl.setWordWrap(True)
        info_col.addWidget(self._debug_kind_lbl)
        cap_hint = QLabel(
            f"원본 {_DEBUG_THUMB_SOURCE_PX}×{_DEBUG_THUMB_SOURCE_PX} → "
            f"표시 {_DEBUG_THUMB_DISPLAY_PX}×{_DEBUG_THUMB_DISPLAY_PX}. "
            "이미지 매칭 실패 시: 찾을 이미지=템플릿, 찾은 이미지=검정(화면 캡처 생략)."
        )
        cap_hint.setStyleSheet("color: #9e9a96; font-size: 9px;")
        cap_hint.setWordWrap(True)
        info_col.addWidget(cap_hint)
        info_col.addStretch()
        cap_layout.addLayout(info_col, stretch=1)

        ref_col = QVBoxLayout()
        ref_col.addWidget(QLabel("찾을 이미지"))
        self._debug_ref_lbl = QLabel()
        self._debug_ref_lbl.setFixedSize(_DEBUG_THUMB_DISPLAY_PX, _DEBUG_THUMB_DISPLAY_PX)
        self._debug_ref_lbl.setStyleSheet("border: 2px solid #4f46e5; background: #eef2ff;")
        self._debug_ref_lbl.setScaledContents(True)
        ref_col.addWidget(self._debug_ref_lbl)
        ref_col.addStretch()
        cap_layout.addLayout(ref_col)

        scr_col = QVBoxLayout()
        scr_col.addWidget(QLabel("찾은 이미지"))
        self._debug_screen_lbl = QLabel()
        self._debug_screen_lbl.setFixedSize(_DEBUG_THUMB_DISPLAY_PX, _DEBUG_THUMB_DISPLAY_PX)
        self._debug_screen_lbl.setStyleSheet("border: 2px solid #16a34a; background: #dcfce7;")
        self._debug_screen_lbl.setScaledContents(True)
        scr_col.addWidget(self._debug_screen_lbl)
        scr_col.addStretch()
        cap_layout.addLayout(scr_col)

        log_container.setMinimumWidth(220)
        capture_root.setMinimumWidth(280)

        splitter.addWidget(log_container)
        splitter.addWidget(capture_root)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([700, 700])

        resize_hint_bar = QWidget()
        resize_hint_bar.setFixedHeight(10)
        resize_hint_bar.setCursor(Qt.CursorShape.SizeVerCursor)
        resize_hint_bar.setToolTip("이 경계를 위/아래로 드래그해 실행 로그 패널 높이를 조절합니다.")
        resize_hint_bar.setStyleSheet(
            "background: #f6f3ef;"
            "border-top: 1px solid #ddd6cd;"
            "border-bottom: 1px solid #ddd6cd;"
        )
        resize_hint_layout = QHBoxLayout(resize_hint_bar)
        resize_hint_layout.setContentsMargins(0, 0, 0, 0)
        resize_hint_layout.setSpacing(0)
        grip_label = QLabel("=====")
        grip_label.setStyleSheet("color: #b8aea2; font-size: 9px; font-weight: bold;")
        resize_hint_layout.addStretch()
        resize_hint_layout.addWidget(grip_label)
        resize_hint_layout.addStretch()

        dock_container = QWidget()
        dock_layout = QVBoxLayout(dock_container)
        dock_layout.setContentsMargins(0, 0, 0, 0)
        dock_layout.setSpacing(0)
        dock_layout.addWidget(resize_hint_bar, stretch=0)
        dock_layout.addWidget(splitter, stretch=1)

        dock.setWidget(dock_container)
        dock.setMinimumHeight(100)
        dock.setMinimumWidth(520)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)

        self._clear_visual_debug_panel()

        if hasattr(self, "_tool_menu_ref"):
            self._tool_menu_ref.addSeparator()
            toggle = dock.toggleViewAction()
            toggle.setText("하단 패널 (로그 · 캡처)")
            toggle.setShortcut("Ctrl+L")
            self._tool_menu_ref.addAction(toggle)

    # -------------------------------------------------------------------
    # FIX #6: 로그 삭제
    # -------------------------------------------------------------------

    def _clear_log(self: MacroEditorWindow) -> None:
        """로그 내용을 모두 삭제한다."""
        self._log_entries.clear()
        self._log_text.clear()

    def _on_log_filter_changed(self: MacroEditorWindow, _state: int) -> None:
        self._log_level_filters["INFO"] = self._log_filter_info.isChecked()
        self._log_level_filters["WARNING"] = self._log_filter_warning.isChecked()
        self._log_level_filters["ERROR"] = self._log_filter_error.isChecked()
        self._sync_log_filter_preset_from_checkboxes()
        self._refresh_log_view()

    def _on_log_font_size_changed(self: MacroEditorWindow, mode: str) -> None:
        self._log_text.setStyleSheet(self._log_text_style(mode))

    def _is_dark_mode(self: MacroEditorWindow) -> bool:
        window_color = self.palette().window().color()
        return window_color.lightness() < 128

    def _log_toolbar_style(self: MacroEditorWindow) -> str:
        if self._is_dark_mode():
            return (
                "QWidget#logFilterBar { "
                "background: #2B2B2B; border: 1px solid #444; border-radius: 4px; "
                "}"
            )
        return (
            "QWidget#logFilterBar { "
            "background: #faf8f5; border: 1px solid #e8e0d5; border-radius: 4px; "
            "}"
        )

    def _log_text_style(self: MacroEditorWindow, mode: str) -> str:
        font_size = {"작게": "10px", "보통": "11px", "크게": "13px"}.get(mode, "11px")
        if self._is_dark_mode():
            return (
                f"font-family: Consolas, monospace; font-size: {font_size}; "
                "border: 1px solid #444; border-radius: 4px; padding: 6px; "
                "background: #1F1F1F; color: #E8E8E8;"
            )
        return (
            f"font-family: Consolas, monospace; font-size: {font_size}; "
            "border: 1px solid #e8e0d5; border-radius: 4px; padding: 6px;"
        )

    def _log_combo_style(self: MacroEditorWindow) -> str:
        if self._is_dark_mode():
            return (
                "QComboBox {"
                "background: #242424; color: #EAEAEA; border: 1px solid #4A4A4A; "
                "border-radius: 4px; padding: 2px 8px; min-height: 22px;"
                "}"
                "QComboBox QAbstractItemView {"
                "background: #2A2A2A; color: #EAEAEA; selection-background-color: #3A3A3A;"
                "}"
            )
        return (
            "QComboBox {"
            "background: #ffffff; color: #1f1b16; border: 1px solid #d4c9bc; "
            "border-radius: 4px; padding: 2px 8px; min-height: 22px;"
            "}"
            "QComboBox QAbstractItemView {"
            "background: #ffffff; color: #1f1b16; selection-background-color: #eef2ff;"
            "}"
        )

    def _on_log_filter_preset_changed(self: MacroEditorWindow, preset: str) -> None:
        if preset == "전체":
            states = (True, True, True)
        elif preset == "경고+오류":
            states = (False, True, True)
        else:  # "오류만"
            states = (False, False, True)

        widgets = (
            (self._log_filter_info, states[0]),
            (self._log_filter_warning, states[1]),
            (self._log_filter_error, states[2]),
        )
        for widget, checked in widgets:
            blocked = widget.blockSignals(True)
            try:
                widget.setChecked(checked)
            finally:
                widget.blockSignals(blocked)

        self._log_level_filters["INFO"] = states[0]
        self._log_level_filters["WARNING"] = states[1]
        self._log_level_filters["ERROR"] = states[2]
        self._refresh_log_view()

    def _sync_log_filter_preset_from_checkboxes(self: MacroEditorWindow) -> None:
        states = (
            self._log_level_filters["INFO"],
            self._log_level_filters["WARNING"],
            self._log_level_filters["ERROR"],
        )
        preset = "전체"
        if states == (False, True, True):
            preset = "경고+오류"
        elif states == (False, False, True):
            preset = "오류만"

        blocked = self._log_filter_preset.blockSignals(True)
        try:
            self._log_filter_preset.setCurrentText(preset)
        finally:
            self._log_filter_preset.blockSignals(blocked)

    def _is_log_visible(self: MacroEditorWindow, level: str) -> bool:
        if level == "INFO":
            return self._log_level_filters["INFO"]
        if level == "WARNING":
            return self._log_level_filters["WARNING"]
        # ERROR + CRITICAL + 기타 레벨은 ERROR 필터에 묶어서 표시한다.
        return self._log_level_filters["ERROR"]

    def _append_log_line(
        self: MacroEditorWindow, level: str, timestamp: str, message: str, repeat_count: int = 1
    ) -> None:
        color = {
            "INFO": "#1f1b16",
            "WARNING": "#b45309",
            "ERROR": "#dc2626",
            "CRITICAL": "#dc2626",
            "DEBUG": "#9e9a96",
        }.get(level, "#1f1b16")
        safe_message = escape(message)
        repeat_suffix = f" (x{repeat_count})" if repeat_count > 1 else ""
        self._log_text.append(
            f'<span style="color:{color}">[{level}] {timestamp} {safe_message}{repeat_suffix}</span>'
        )

    def _refresh_log_view(self: MacroEditorWindow) -> None:
        self._log_text.clear()
        for level, timestamp, message, repeat_count in self._log_entries:
            if self._is_log_visible(level):
                self._append_log_line(level, timestamp, message, repeat_count)

    @pyqtSlot(str, str)
    def log_message(self: MacroEditorWindow, level: str, message: str) -> None:
        """로그를 UI에 추가한다(스레드 안전)."""
        self.log_received.emit(level, message)

    def _append_log_ui(self: MacroEditorWindow, level: str, message: str) -> None:
        """실제 QTextEdit 갱신(UI 스레드 전용)."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        if self._log_entries:
            prev_level, prev_ts, prev_msg, prev_count = self._log_entries[-1]
            if prev_level == level and prev_msg == message:
                self._log_entries[-1] = (prev_level, prev_ts, prev_msg, prev_count + 1)
                if self._is_log_visible(level):
                    self._refresh_log_view()
                return

        self._log_entries.append((level, timestamp, message, 1))
        if len(self._log_entries) > 1000:
            self._log_entries.pop(0)

        if self._is_log_visible(level):
            self._append_log_line(level, timestamp, message, 1)

        # 항상 최신 로그가 화면에 보이도록 강제 스크롤
        cursor = self._log_text.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        self._log_text.setTextCursor(cursor)
        self._log_text.ensureCursorVisible()
