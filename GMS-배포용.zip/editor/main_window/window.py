"""매크로 에디터 메인 윈도우.

FIX #1: 단축키 (Ctrl+F5=실행, Ctrl+F6=일시정지, Ctrl+F7=정지, Delete=삭제, Ctrl+D=복제)
FIX #2: 드롭다운 대신 카테고리별 그리드 버튼으로 액션 추가
FIX #6: 로그 삭제 버튼
FIX #7: 액션 카테고리 설명 라벨
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from PyQt6.QtCore import QByteArray, QSize, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (
    QAction,
    QKeySequence,
)
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTextEdit,
    QToolBar,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from editor.action_list import ActionListWidget
from editor.action_palette import ACTION_BUTTON_TOOLTIPS, ACTION_BUTTONS
from editor.capture_history import CaptureHistory
from editor.main_window.coord_tools import CoordToolsMixin
from editor.main_window.file_io import FileIOMixin
from editor.main_window.hotkeys import HotkeysMixin
from editor.main_window.log_dock import LogDockMixin
from editor.main_window.run_control import RunControlMixin
from editor.main_window.runner_sync import RunnerSyncMixin
from editor.main_window.schedule_ui import ScheduleUIMixin
from editor.main_window.undo_redo import UndoRedoMixin
from editor.param_panel import ParamPanel
from editor.recorder import MacroRecorder
from editor.validator import MacroValidator
from editor.widgets.help_text import STYLE_SIDEBAR_SECONDARY
from shared.models import (
    Action,
    BreakAction,
    CommentAction,
    DelayAction,
    ElseAction,
    EndIfAction,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    KeyPressAction,
    LoopEndAction,
    LoopStartAction,
    Macro,
    MacroSettings,
    MouseClickAction,
    OCRWaitAction,
    PixelWaitAction,
    VariableSetAction,
)

logger = logging.getLogger(__name__)

IF_TRIO_ACTION_TYPES: tuple[type[Action], ...] = (
    IfPixelAction,
    IfVariableAction,
    PixelWaitAction,
    ImageSearchAction,
    ImageWaitAction,
    ImageClickAction,
    OCRWaitAction,
)


def _default_block_comment(action: Action) -> str:
    """구조형 블록 헤더에 붙일 기본 주석 구분선을 생성한다."""
    if isinstance(action, IfVariableAction):
        title = "조건 블록"
    elif isinstance(action, PixelWaitAction):
        title = "픽셀 대기 블록"
    elif isinstance(action, ImageSearchAction):
        title = "이미지 검색 블록"
    elif isinstance(action, ImageWaitAction):
        title = "이미지 대기 블록"
    elif isinstance(action, ImageClickAction):
        title = "이미지 클릭 블록"
    elif isinstance(action, OCRWaitAction):
        title = "OCR 대기 블록"
    else:
        title = "분기 블록"
    return f"-------- {title} --------"


STRUCT_IF_TYPE_OPTIONS: tuple[tuple[str, type[Action]], ...] = (
    ("IfPixel", IfPixelAction),
    ("IfVar", IfVariableAction),
    ("PixWait", PixelWaitAction),
    ("ImgSearch", ImageSearchAction),
    ("ImgWait", ImageWaitAction),
    ("ImgClick", ImageClickAction),
    ("OCRWait", OCRWaitAction),
)

# 엔진 썸네일은 30×30 PNG. 독 패널에는 약 2.5배 확대해 표시(가독성, 이전 15×5와 비슷한 크기).
_DEBUG_THUMB_SOURCE_PX = 30
_DEBUG_THUMB_DISPLAY_PX = 75

# 상태바 단축키 콤보 — 목록에서 한 줄씩 온전히 표시(말줄임 없음).
_STATUS_SHORTCUT_HELP_LINES: tuple[str, ...] = (
    "Ctrl+F5 실행",
    "Ctrl+F6 일시정지",
    "Ctrl+F7 정지",
    "F8 좌표·색 캡처(히스토리·클립보드)",
    "Ctrl+L 하단패널",
)


class StatusBarAdaptiveLabel(QLabel):
    """상태바 칩 — 넉넉할 땐 전체 문구, 좁을 땐 아이콘만(전체는 툴팁). 말줄임으로 글자 잘림 없음."""

    def __init__(
        self,
        full_text: str = "",
        *,
        icon: str = "•",
        min_text_width: int = 36,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._full_text = full_text
        self._icon = icon
        self._icon_mode = False
        self._min_text_width = min_text_width
        self.setWordWrap(False)
        self.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Preferred)
        self._sync_visible()

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        sh = super().minimumSizeHint()
        return QSize(max(self._min_text_width, 1), sh.height())

    def set_full_text(self, text: str) -> None:
        self._full_text = text
        self._sync_visible()

    def set_icon_mode(self, on: bool) -> None:
        if self._icon_mode == on:
            return
        self._icon_mode = on
        self._sync_visible()
        self.updateGeometry()

    def _sync_visible(self) -> None:
        if not self._full_text:
            super().setText("")
            self.setToolTip("")
            return
        if self._icon_mode:
            super().setText(self._icon)
            self.setToolTip(self._full_text)
        else:
            super().setText(self._full_text)
            self.setToolTip("")


def _status_strip_level(strip_inner_width: int) -> int:
    """0=전체 … 8=최대 압축.

    우선순위(먼저 줄어듦): 하단 우측 단축키 콤보 폭 → 매크로 → 재연결 → Arduino → 실행상태
    → (가장 나중) F8 제목 아이콘 → 콤보(클립보드) 폭 → 좌표(X/Y)⌖ (L9).
    """
    w = strip_inner_width
    if w >= 1000:
        return 0
    if w >= 880:
        return 1
    if w >= 760:
        return 2
    if w >= 640:
        return 3
    if w >= 500:
        return 4
    if w >= 400:
        return 5
    if w >= 330:
        return 6
    if w >= 260:
        return 7
    if w >= 200:
        return 8
    return 9


class _EditorStatusStrip(QWidget):
    """하단 상태 한 줄 — 셀 간 빈 stretch 없이 붙이고, 폭에 따라 단계적으로 아이콘 모드."""

    def __init__(
        self,
        editor: QWidget,
        arduino: StatusBarAdaptiveLabel,
        reconnect: QPushButton,
        macro: StatusBarAdaptiveLabel,
        state: QLabel,
        capture_row: QWidget,
        shortcut: QComboBox,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._editor = editor
        self._arduino = arduino
        self._reconnect = reconnect
        self._macro = macro
        self._state = state
        self._capture_row = capture_row
        self._shortcut = shortcut
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(arduino, 0)
        lay.addWidget(reconnect, 0)
        lay.addWidget(macro, 0)
        lay.addWidget(state, 0)
        lay.addWidget(capture_row, 0)
        # permanent 영역이 아니라 한 줄 레이아웃에 넣어 F8 캡처·콤보와 밀착 (중간 빈 stretch 제거)
        lay.addWidget(shortcut, 0)
        lay.addStretch(1)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.setMinimumWidth(0)

    def sync_compact(self) -> None:
        ed = self._editor
        w = self.width()
        if w < 40:
            return
        lvl = _status_strip_level(w)
        # L1: 우측 단축키 콤보 폭 축소 → L2~L5: 매크로·재연결·Arduino·상태 → L6: F8 제목 → L7~8: 캡처 콤보 → L9: 좌표·구분선
        sc = self._shortcut
        if lvl >= 1:
            sc.setMinimumWidth(88)
            sc.setMaximumWidth(132)
        else:
            sc.setMinimumWidth(132)
            sc.setMaximumWidth(380)

        self._macro.set_icon_mode(lvl >= 2)
        if lvl >= 4:
            rtxt = "🔌"
        elif lvl >= 3:
            rtxt = "재연결"
        else:
            rtxt = "🔌 재연결"
        if self._reconnect.text() != rtxt:
            self._reconnect.setText(rtxt)
        self._arduino.set_icon_mode(lvl >= 4)
        if lvl >= 5:
            self._state.setText(f" {getattr(ed, '_status_state_icon', '○')} ")
            self._state.setFixedWidth(getattr(ed, "_status_state_w_icon", 40))
        else:
            self._state.setText(getattr(ed, "_status_state_full", " ○ 대기 "))
            self._state.setFixedWidth(getattr(ed, "_status_state_w_full", 120))

        cap_title = getattr(ed, "_status_capture_title", None)
        if cap_title is not None:
            cap_title.setText("📷" if lvl >= 6 else "F8 캡처")

        combo = getattr(ed, "_status_capture_history_combo", None)
        if combo is not None:
            if lvl >= 8:
                combo.setMinimumWidth(64)
                combo.setMaximumWidth(88)
            elif lvl >= 7:
                combo.setMinimumWidth(88)
                combo.setMaximumWidth(130)
            else:
                combo.setMinimumWidth(120)
                combo.setMaximumWidth(190)

        compact_xy = lvl >= 9
        for cw in getattr(ed, "_status_capture_xy_compact_widgets", ()):
            cw.setVisible(not compact_xy)
        ph = getattr(ed, "_status_capture_xy_compact_label", None)
        if ph is not None:
            ph.setVisible(compact_xy)
            if compact_xy:
                x_txt = getattr(ed, "_status_capture_x", None)
                y_txt = getattr(ed, "_status_capture_y", None)
                xs = x_txt.text() if x_txt is not None else ""
                ys = y_txt.text() if y_txt is not None else ""
                ph.setText("⌖")
                ph.setToolTip(f"F8 좌표 {xs} {ys}".strip())

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self.sync_compact()


class MacroEditorWindow(
    FileIOMixin,
    RunControlMixin,
    LogDockMixin,
    HotkeysMixin,
    ScheduleUIMixin,
    CoordToolsMixin,
    UndoRedoMixin,
    RunnerSyncMixin,
    QMainWindow,
):
    """매크로 에디터 메인 윈도우."""

    macro_run_requested = pyqtSignal(object)
    macro_stop_requested = pyqtSignal()
    macro_pause_requested = pyqtSignal()
    macro_resume_requested = pyqtSignal()
    macro_step_requested = pyqtSignal()
    breakpoints_changed = pyqtSignal(object)
    hotkey_run_requested = pyqtSignal()
    hotkey_pause_requested = pyqtSignal()
    hotkey_stop_requested = pyqtSignal()
    switch_to_player_requested = pyqtSignal()
    reconnect_requested = pyqtSignal()
    file_opened = pyqtSignal(str)  # 매크로 파일 경로
    # 엔진/워커 스레드에서 호출될 수 있으므로 UI 변경은 메인 스레드에서 수행한다.
    log_received = pyqtSignal(str, str)
    runner_state_changed = pyqtSignal(str)
    execution_row_changed = pyqtSignal(int)
    variables_snapshot_changed = pyqtSignal(object)
    arduino_status_changed = pyqtSignal(bool, str)
    visual_debug_changed = pyqtSignal(str, QByteArray, QByteArray, bool)
    schedule_runtime_changed = pyqtSignal(str, bool, str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("GameMacroStudio")
        self.setMinimumSize(950, 650)
        self.resize(1150, 750)
        self._ui_ready = False

        self._current_file: Path | None = None
        self._macro = Macro()
        self._validator = MacroValidator()
        self._recorder = MacroRecorder()
        self._is_modified: bool = False
        self._pending_rehearsal_run: bool = False
        self._global_hotkeys = None
        self._last_hotkey_trigger_at: dict[str, float] = {}
        self._runner_state: str = "IDLE"
        self._last_variables: dict[str, str] = {}
        self._last_execution_row_time: float = 0.0
        self._pending_execution_row: int = -1
        self._last_variable_display_time: float = 0.0
        self._pending_variables: dict[str, str] | None = None
        self._undo_stack: list[object] = []
        self._redo_stack: list[object] = []
        self._param_undo_snapshot_taken: bool = False
        self._suppress_param_panel_reload: bool = False
        self._log_entries: list[tuple[str, str, str, int]] = []
        self._log_level_filters: dict[str, bool] = {
            "INFO": True,
            "WARNING": True,
            "ERROR": True,
        }
        self._schedule_runtime: dict[str, tuple[str, bool]] = {}
        self._capture_history = CaptureHistory()

        # 무거운 UI 빌드를 이벤트 루프 진입 후로 지연 — 윈도우 프레임 즉시 표시
        QTimer.singleShot(0, self._build_ui)

    def _build_ui(self) -> None:
        """이벤트 루프 진입 후 호출 — 무거운 UI 위젯을 빌드한다."""
        self._setup_central_widget()
        self._setup_menu_bar()
        self._setup_toolbar()
        self._setup_bottom_panel_dock()
        self.log_received.connect(self._append_log_ui)
        self.runner_state_changed.connect(self._apply_runner_state)
        self.execution_row_changed.connect(self._apply_execution_row)
        self.variables_snapshot_changed.connect(self._apply_variable_display)
        self.arduino_status_changed.connect(self._apply_arduino_status)
        self.visual_debug_changed.connect(self._apply_visual_debug)
        self.schedule_runtime_changed.connect(self._apply_schedule_runtime)
        self._setup_status_bar()
        self._setup_shortcuts()  # FIX #1
        self._setup_global_hotkeys()
        self.hotkey_run_requested.connect(self._run_macro)
        self.hotkey_pause_requested.connect(self._pause_macro)
        self.hotkey_stop_requested.connect(self._stop_macro)

        self._schedule_ui_timer = QTimer(self)
        self._schedule_ui_timer.setInterval(30000)
        self._schedule_ui_timer.timeout.connect(self._refresh_schedule_list)
        self._schedule_ui_timer.start()

        self._ui_ready = True
        self._update_title()
        self.log_message(
            "INFO",
            "에디터 시작: 단축키(Ctrl+F5 실행, Ctrl+F6 일시정지, Ctrl+F7 정지)",
        )
        QTimer.singleShot(0, self._maybe_show_startup_checklist)

    def _maybe_show_startup_checklist(self) -> None:
        """첫 실행 시 온보딩 체크리스트(한 번만 또는 '다시 표시 안 함')."""
        from PyQt6.QtCore import QSettings
        from PyQt6.QtWidgets import QCheckBox, QDialog, QDialogButtonBox, QLabel, QVBoxLayout

        s = QSettings("GameMacroStudio", "Editor")
        if s.value("startup_checklist/done", False, bool):
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("시작 체크리스트")
        lay = QVBoxLayout(dlg)
        lay.addWidget(
            QLabel(
                "1) 예제 열기: 파일 → 열기 → macros/examples/example_click_loop.json\n"
                "2) 안전: 실행 전 확인에서 리허설 선택 또는 python main.py --dry-run\n"
                "3) 화면 안내: 도움말 → 사용 가이드 (상세 절차는 소스의 docs/onboarding/editor-walkthrough.md)\n"
                "4) 긴급 정지: Ctrl+F7"
            )
        )
        cb = QCheckBox("다시 표시하지 않음")
        lay.addWidget(cb)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok)
        bb.accepted.connect(dlg.accept)
        lay.addWidget(bb)
        dlg.exec()
        if cb.isChecked():
            s.setValue("startup_checklist/done", True)

    def _setup_central_widget(self) -> None:
        """좌측: 액션 추가 버튼 + 변수 표시 / 중앙: 액션 리스트 / 우측: 파라미터 패널."""

        # ── 좌측 패널: 버튼 + 변수 모니터 ──
        left_widget = QWidget()
        left_root_layout = QHBoxLayout(left_widget)
        left_root_layout.setContentsMargins(4, 4, 4, 4)
        left_root_layout.setSpacing(6)

        # 버튼 패널 (왼쪽 세로 + 스크롤)
        button_inner = QWidget()
        button_layout = QVBoxLayout(button_inner)
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.setSpacing(4)

        for category_name, actions in ACTION_BUTTONS.items():
            group = QGroupBox(category_name)
            group.setStyleSheet(
                "QGroupBox { font-size: 11px; font-weight: bold; padding-top: 14px; margin-top: 2px; "
                "color: #1f1b16; border: 1px solid #e8e0d5; border-radius: 4px; } "
                "QGroupBox::title { color: #6b6360; }"
            )
            grid = QGridLayout(group)
            grid.setSpacing(4)
            grid.setContentsMargins(4, 4, 4, 4)

            for i, (btn_text, action_class, color) in enumerate(actions):
                btn = QPushButton(btn_text)
                btn.setFixedHeight(26)
                btn.setMinimumWidth(72)
                btn.setStyleSheet(
                    f"QPushButton {{ background-color: {color}; color: white; "
                    f"border: none; border-radius: 3px; font-size: 11px; font-weight: bold; padding: 2px 6px; }}"
                )
                tooltip = ACTION_BUTTON_TOOLTIPS.get(action_class)
                if tooltip:
                    btn.setToolTip(tooltip)
                btn.clicked.connect(lambda checked, ac=action_class: self._add_action_type(ac))
                grid.addWidget(btn, i // 2, i % 2)

            button_layout.addWidget(group)

        combo_group = QGroupBox("추천 조합")
        combo_group.setStyleSheet(
            "QGroupBox { font-size: 11px; font-weight: bold; padding-top: 14px; margin-top: 2px; "
            "color: #1f1b16; border: 1px solid #e8e0d5; border-radius: 4px; } "
            "QGroupBox::title { color: #6b6360; }"
        )
        combo_grid = QGridLayout(combo_group)
        combo_grid.setSpacing(4)
        combo_grid.setContentsMargins(4, 4, 4, 4)
        combo_buttons: list[tuple[str, object]] = [
            ("클릭+딜레이", self._quick_insert_click_delay),
            ("키입력+딜레이", self._quick_insert_key_delay),
            ("픽셀대기+클릭", self._quick_insert_pixel_wait_click),
            ("재시도+실패분기", self._quick_insert_retry_with_fallback),
        ]
        for i, (label, slot) in enumerate(combo_buttons):
            combo_btn = QPushButton(label)
            combo_btn.setFixedHeight(26)
            combo_btn.setStyleSheet(
                "QPushButton { background-color: #4f46e5; color: white; border: none; "
                "border-radius: 3px; font-size: 11px; font-weight: bold; padding: 2px 6px; }"
            )
            combo_btn.clicked.connect(slot)  # type: ignore[arg-type]
            combo_grid.addWidget(combo_btn, i // 2, i % 2)
        button_layout.addWidget(combo_group)

        # ── 변수 모니터 패널 ──
        var_group = QGroupBox("변수 모니터")
        var_group.setStyleSheet(
            "QGroupBox { font-size: 11px; font-weight: bold; padding-top: 14px; margin-top: 2px; }"
        )
        var_inner = QVBoxLayout(var_group)
        var_inner.setContentsMargins(4, 4, 4, 4)
        var_inner.setSpacing(2)

        self._var_table = QTableWidget(0, 2)
        self._var_table.setHorizontalHeaderLabels(["변수", "값"])
        self._var_table.horizontalHeader().setStretchLastSection(True)
        self._var_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self._var_table.verticalHeader().setVisible(False)
        self._var_table.setMaximumHeight(160)
        self._var_table.setStyleSheet(
            "font-size: 11px; gridline-color: #e8e0d5;"
            "QHeaderView::section { background: #f5f1ec; font-weight: bold; padding: 4px 6px; }"
            "QTableWidget::item { padding: 3px 4px; }"
        )
        self._var_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        var_inner.addWidget(self._var_table)

        button_layout.addWidget(var_group)

        schedule_group = QGroupBox("스케줄")
        schedule_group.setStyleSheet(
            "QGroupBox { font-size: 11px; font-weight: bold; padding-top: 14px; margin-top: 2px; }"
        )
        schedule_inner = QVBoxLayout(schedule_group)
        schedule_inner.setContentsMargins(4, 4, 4, 4)
        schedule_inner.setSpacing(4)
        self._schedule_manage_button = QPushButton("스케줄 관리 열기")
        self._schedule_manage_button.setFixedHeight(28)
        self._schedule_manage_button.clicked.connect(self._open_schedule_manager)
        self._schedule_summary_label = QLabel("")
        self._schedule_summary_label.setWordWrap(True)
        self._schedule_summary_label.setStyleSheet(STYLE_SIDEBAR_SECONDARY)
        schedule_inner.addWidget(self._schedule_manage_button)
        schedule_inner.addWidget(self._schedule_summary_label)
        button_layout.addWidget(schedule_group)
        button_layout.addStretch()

        # 스크롤 영역으로 감싸기
        scroll = QScrollArea()
        scroll.setWidget(button_inner)
        scroll.setWidgetResizable(True)
        # 2열 액션 버튼·한글 라벨 최소 폭이 ~210px을 넘어서면 가로 스크롤이 생김 — 여유 폭 확보
        scroll.setMinimumWidth(280)
        scroll.setMaximumWidth(360)
        scroll.setStyleSheet("QScrollArea { border: none; }")

        # 액션 리스트 패널 (오른쪽, 넓게)
        list_panel = QWidget()
        list_layout = QVBoxLayout(list_panel)
        list_layout.setContentsMargins(6, 0, 0, 0)
        list_layout.setSpacing(6)

        list_label = QLabel("액션 리스트 (드래그로 순서 변경 가능)")
        list_label.setStyleSheet("font-size: 11px; color: #6b6360; font-weight: bold;")
        list_layout.addWidget(list_label)

        self._action_list = ActionListWidget()
        list_layout.addWidget(self._action_list, stretch=1)

        left_root_layout.addWidget(scroll)
        left_root_layout.addWidget(list_panel, stretch=1)

        # ── 우측 패널: 파라미터 편집 ──
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(4, 4, 4, 4)

        self._param_title = QLabel("파라미터 편집 (선택 없음)")
        self._param_title.setStyleSheet("font-size: 13px; font-weight: bold; margin-bottom: 4px;")
        param_header = QWidget()
        param_header_layout = QHBoxLayout(param_header)
        param_header_layout.setContentsMargins(0, 0, 0, 0)
        param_header_layout.setSpacing(8)
        param_header_layout.addWidget(self._param_title, stretch=1)
        self._param_type_combo = QComboBox()
        self._param_type_combo.setToolTip(
            "조건형 블록(IfPixel·PixWait·ImgSearch 등)의 맨 위 헤더 종류만 바꿉니다.\n"
            "Else·EndIf와 안쪽에 넣어 둔 액션은 그대로 둡니다."
        )
        for label, _action_cls in STRUCT_IF_TYPE_OPTIONS:
            self._param_type_combo.addItem(label)
        self._param_type_combo.currentIndexChanged.connect(self._on_param_type_changed)
        self._param_type_combo.hide()
        param_header_layout.addWidget(self._param_type_combo)
        right_layout.addWidget(param_header)

        # 파라미터 패널도 스크롤 가능하게
        param_scroll = QScrollArea()
        self._param_panel = ParamPanel(capture_history=self._capture_history)
        param_scroll.setWidget(self._param_panel)
        param_scroll.setWidgetResizable(True)
        param_scroll.setStyleSheet("QScrollArea { border: none; }")
        right_layout.addWidget(param_scroll, stretch=1)

        # 스플리터
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(10)
        splitter.setStyleSheet(
            "QSplitter::handle:horizontal {"
            "background: #efebe6;"
            "border-left: 1px solid #cdc5bb;"
            "border-right: 1px solid #cdc5bb;"
            "}"
            "QSplitter::handle:horizontal:hover {"
            "background: #e6e0d8;"
            "border-left: 1px solid #b5ac9f;"
            "border-right: 1px solid #b5ac9f;"
            "}"
        )
        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setSizes([660, 360])

        self.setCentralWidget(splitter)

        # 시그널 연결
        self._action_list.action_selected.connect(self._on_action_selected)
        self._action_list.action_list_about_to_modify.connect(self._save_undo_state)
        self._action_list.action_list_modified.connect(self._on_modified)
        self._action_list.action_order_changed.connect(self._refresh_variable_suggestions)
        self._action_list.breakpoints_changed.connect(self.breakpoints_changed.emit)
        self._param_panel.action_modified.connect(self._on_param_changed)
        self._refresh_variable_suggestions()
        self._refresh_schedule_list()

    def _refresh_variable_suggestions(self) -> None:
        """액션 목록에서 변수명 후보를 모아 파라미터 패널 콤보에 반영한다."""
        from editor.variable_suggestions import collect_suggested_var_names

        names = collect_suggested_var_names(self._action_list.get_all_actions())
        self._param_panel.set_variable_suggestions(names)

    def _setup_menu_bar(self) -> None:
        menubar = self.menuBar()

        def _make_action(text: str, slot: object, shortcut: str = "") -> QAction:
            act = QAction(text, self)
            if shortcut:
                act.setShortcut(QKeySequence(shortcut))
            act.triggered.connect(slot)
            return act

        file_menu = menubar.addMenu("파일(&F)")
        self._act_file_new = _make_action("새로 만들기", self._new_macro, "Ctrl+N")
        self._act_file_open = _make_action("열기", self._open_macro, "Ctrl+O")
        self._act_file_save = _make_action("저장", self._save_macro, "Ctrl+S")
        self._act_file_save_as = _make_action("다른이름 저장", self._save_macro_as, "Ctrl+Shift+S")
        file_menu.addAction(self._act_file_new)
        file_menu.addAction(self._act_file_open)
        file_menu.addAction(self._act_file_save)
        file_menu.addAction(self._act_file_save_as)
        file_menu.addSeparator()
        self._recent_menu = file_menu.addMenu("최근 파일")
        self._recent_menu.aboutToShow.connect(self._populate_recent_menu)
        file_menu.addSeparator()
        file_menu.addAction(_make_action("종료", self.close, "Alt+F4"))

        tool_menu = menubar.addMenu("도구(&T)")
        tool_menu.addAction(_make_action("매크로 속성", self._edit_macro_properties))
        tool_menu.addAction(_make_action("좌표 오프셋 적용", self._open_coordinate_offset_dialog))
        tool_menu.addAction(_make_action("매크로 검증", self._validate_macro, "Ctrl+Shift+V"))
        tool_menu.addSeparator()
        tool_menu.addAction(_make_action("Arduino 재연결", lambda: self.reconnect_requested.emit()))
        tool_menu.addSeparator()
        tool_menu.addAction(_make_action("AI 매크로 생성", self._open_ai_gen_dialog))
        self._tool_menu_ref = tool_menu

        # 도움말 메뉴: 단축키 설명
        help_menu = menubar.addMenu("도움말(&H)")
        help_menu.addAction(_make_action("사용 가이드", self._show_user_guide))
        help_menu.addAction(_make_action("단축키 안내", self._show_shortcuts_help))

        self._menu_expiry_label = QLabel("사용만료일: -")
        self._menu_expiry_label.setStyleSheet(
            "color: #6b6360; font-size: 12px; font-weight: bold; padding: 0 8px;"
        )
        menubar.setCornerWidget(self._menu_expiry_label, Qt.Corner.TopRightCorner)

    def _setup_toolbar(self) -> None:
        toolbar = QToolBar("메인")
        toolbar.setMovable(False)
        toolbar.setStyleSheet("QToolBar { spacing: 4px; }")
        self.addToolBar(toolbar)

        self._btn_record = toolbar.addAction("● 녹화 (Ctrl+R)", self._toggle_recording)
        toolbar.addSeparator()

        # FIX #1: 단축키 표시
        self._btn_run = toolbar.addAction("▶ 실행 (Ctrl+F5)", self._run_macro)
        self._btn_pause = toolbar.addAction("⏸ 일시정지 (Ctrl+F6)", self._pause_macro)
        self._btn_step = toolbar.addAction("⏭ 스텝 (F10)", self._step_macro)
        toolbar.addSeparator()  # 위험 동작(정지)과 실행 동작을 시각적으로 분리
        self._btn_stop = toolbar.addAction("⏹ 정지 (Ctrl+F7)", self._stop_macro)
        self._btn_run.setToolTip("매크로 실행 시작 (Ctrl+F5)")
        self._btn_pause.setToolTip("실행 중 일시정지 / 일시정지 중 재개 (Ctrl+F6)")
        self._btn_step.setToolTip("일시정지 상태에서 1스텝 실행 (F10)")
        self._btn_stop.setToolTip("매크로 즉시 정지 (Ctrl+F7)")
        self._style_toolbar_action_button(toolbar, self._btn_run, "#2E7D32")
        self._style_toolbar_action_button(toolbar, self._btn_pause, "#F57C00")
        self._style_toolbar_action_button(toolbar, self._btn_step, "#1565C0")
        self._style_toolbar_action_button(toolbar, self._btn_stop, "#C62828")
        toolbar.addSeparator()

        row_height_menu = QMenu(toolbar)
        row_height_menu.addAction("컴팩트", lambda: self._set_row_height_mode("컴팩트"))
        row_height_menu.addAction("기본", lambda: self._set_row_height_mode("기본"))
        row_height_menu.addAction("넓게", lambda: self._set_row_height_mode("넓게"))
        row_height_button = QToolButton()
        row_height_button.setText("행 높이")
        row_height_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        row_height_button.setMenu(row_height_menu)
        row_height_button.setToolTip("액션 리스트 행 높이를 변경합니다")
        row_height_button.setStyleSheet(
            "QToolButton { background: #f5f1ec; border: 1px solid #e8e0d5; "
            "border-radius: 4px; padding: 3px 8px; color: #1f1b16; }"
        )
        toolbar.addWidget(row_height_button)

        # 모드 전환 버튼 — 에디터 → 플레이어
        toolbar.addSeparator()
        self._btn_player_mode = QToolButton()
        self._btn_player_mode.setText("🎮 플레이어 모드")
        self._btn_player_mode.setToolTip(
            "경량 플레이어 모드로 전환합니다 (에디터 UI를 숨기고 미니 패널 표시)"
        )
        self._btn_player_mode.setStyleSheet(
            "QToolButton { background: #4f46e5; color: #FFFFFF; border: none; "
            "border-radius: 4px; padding: 4px 10px; font-weight: bold; }"
            "QToolButton:pressed { padding-top: 5px; padding-left: 11px; }"
        )
        self._btn_player_mode.clicked.connect(self._on_switch_to_player)
        toolbar.addWidget(self._btn_player_mode)

    def set_license_expiry(self, expires_at: str) -> None:
        """메뉴바 우측(도구 오른쪽 영역)에 사용 만료일을 표시한다."""
        text = self._format_expiry_korean(expires_at)
        if hasattr(self, "_menu_expiry_label"):
            self._menu_expiry_label.setText(f"사용만료일: {text or '-'}")

    def _format_expiry_korean(self, expires_at: str) -> str:
        """서버/엑셀에서 내려준 시각 문자열을 그대로 한국어 포맷으로 표시한다."""
        if not isinstance(expires_at, str):
            return ""
        raw = expires_at.strip()
        if not raw:
            return ""
        try:
            # 서버가 KST 문자열(+09:00)을 내려주므로 UI에서 별도 타임존 변환하지 않는다.
            normalized = raw.replace("Z", "+00:00")
            dt = datetime.fromisoformat(normalized)
            return dt.strftime("%Y년 %m월 %d일 %H시 %M분")
        except ValueError:
            # 형식이 다를 경우 원문을 그대로 보여준다.
            return raw

    def _style_toolbar_action_button(
        self, toolbar: QToolBar, action: QAction, bg_color: str
    ) -> None:
        """실행 제어 QAction을 색상 버튼으로 표시한다."""
        widget = toolbar.widgetForAction(action)
        if not isinstance(widget, QToolButton):
            return
        widget.setStyleSheet(
            "QToolButton {"
            f"background-color: {bg_color}; color: #FFFFFF; border: none; "
            "border-radius: 4px; padding: 4px 8px; font-weight: bold;"
            "}"
            "QToolButton:pressed { padding-top: 5px; padding-left: 9px; }"
        )

    def _set_row_height_mode(self, mode: str) -> None:
        self._action_list.set_row_height_mode(mode)
        self.log_message("INFO", f"행 높이 변경: {mode}")

    def _setup_status_bar(self) -> None:
        self._status_arduino = StatusBarAdaptiveLabel(
            "Arduino  미연결",
            icon="🔌",
            min_text_width=40,
        )
        self._status_macro = StatusBarAdaptiveLabel(
            "매크로명: 없음",
            icon="📄",
            min_text_width=44,
        )
        self._status_macro.setSizePolicy(
            QSizePolicy.Policy.Minimum,
            QSizePolicy.Policy.Preferred,
        )
        self._status_state_full = " ○ 대기 "
        self._status_state_icon = "○"
        self._status_state = QLabel(self._status_state_full)
        self._status_state.setStyleSheet(
            "color: #6b6360; background: #f0ede8; font-weight: bold; "
            "font-size: 14px; padding: 4px 8px; border-radius: 5px;"
        )
        self._status_state.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._status_state.setSizePolicy(
            QSizePolicy.Policy.Fixed,
            QSizePolicy.Policy.Fixed,
        )
        self._status_state.setText(" ✓ 매크로 종료 ")
        self._status_state_w_full = self._status_state.sizeHint().width()
        _icon_w = 0
        for _glyph in (" ○ ", " ▶ ", " ⏸ ", " ■ ", " ✓ "):
            self._status_state.setText(_glyph)
            _icon_w = max(_icon_w, self._status_state.sizeHint().width())
        self._status_state_w_icon = _icon_w
        self._status_state.setText(self._status_state_full)
        self._status_state.setFixedWidth(self._status_state_w_full)

        # FIX #1: 단축키 안내 — 콤보 목록에서 각 줄 전체 표시(드롭다운 폭은 최장 줄 기준).
        self._status_shortcut = QComboBox()
        self._status_shortcut.setEditable(False)
        self._status_shortcut.addItem("단축키 안내")
        self._status_shortcut.addItems(list(_STATUS_SHORTCUT_HELP_LINES))
        self._status_shortcut.setCurrentIndex(0)
        self._status_shortcut.setSizeAdjustPolicy(
            QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
        )
        fm = self._status_shortcut.fontMetrics()
        _pop_w = (
            max(fm.horizontalAdvance(s) for s in ("단축키 안내", *_STATUS_SHORTCUT_HELP_LINES)) + 48
        )
        self._status_shortcut.view().setMinimumWidth(max(_pop_w, 300))
        self._status_shortcut.view().setTextElideMode(Qt.TextElideMode.ElideNone)
        self._status_shortcut.setMinimumWidth(132)
        self._status_shortcut.setMaximumWidth(380)
        self._status_shortcut.setSizePolicy(
            QSizePolicy.Policy.Minimum,
            QSizePolicy.Policy.Fixed,
        )
        self._status_shortcut.setToolTip(
            "목록을 펼치면 단축키를 한 줄씩 잘리지 않고 볼 수 있습니다."
        )
        self._status_shortcut.setStyleSheet(
            "QComboBox { color: #6b6360; font-size: 13px; font-weight: 600; padding: 2px 4px; "
            "background: #f5f1ec; border: 1px solid #e8e0d5; border-radius: 4px; min-height: 20px; }"
            "QComboBox::drop-down { width: 18px; border: none; }"
        )
        self._status_shortcut.activated.connect(self._on_status_shortcut_combo_activated)

        # F8 캡처 상태/좌표/색상(테두리 박스) + 히스토리 콤보는 박스 밖에 둬 이중 테두리를 피한다.
        self._status_capture_box = QWidget()
        capture_layout = QHBoxLayout(self._status_capture_box)
        capture_layout.setContentsMargins(3, 2, 3, 2)
        capture_layout.setSpacing(2)
        self._status_capture_title = QLabel("F8 캡처")
        self._status_capture_x = QLabel("X -")
        self._status_capture_y = QLabel("Y -")
        self._status_capture_color = QLabel("")
        self._status_capture_color.setMinimumSize(52, 26)
        self._status_capture_color.setMaximumHeight(28)
        self._status_capture_color.setSizePolicy(
            QSizePolicy.Policy.Fixed,
            QSizePolicy.Policy.Fixed,
        )
        self._status_capture_color.setToolTip(
            "F8 캡처 픽셀 색 미리보기 — 마우스를 올리면 HEX·클립보드 문자열"
        )
        self._status_capture_history_combo = QComboBox()
        self._status_capture_history_combo.setMinimumWidth(120)
        self._status_capture_history_combo.setMaximumWidth(190)
        self._status_capture_history_combo.setSizeAdjustPolicy(
            QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
        )
        self._status_capture_history_combo.setIconSize(QSize(18, 18))
        self._status_capture_history_combo.setToolTip(
            "F8로 찍은 좌표·색 기록(최근 10개). 펼쳐서 고르면 활성 캡처로 바뀝니다."
        )
        # 드롭다운은 OS 기본 스타일 유지(QSS로 QAbstractItemView/drop-down 꾸미면 Windows에서 깨지기 쉬움).
        self._status_capture_history_combo.view().setMinimumWidth(280)
        self._status_capture_history_combo.currentIndexChanged.connect(
            self._on_capture_history_selected
        )
        self._status_capture_title.setStyleSheet(
            "color: #1f1b16; font-size: 14px; font-weight: 700;"
        )
        self._status_capture_x.setStyleSheet("color: #4f46e5; font-size: 15px; font-weight: 800;")
        self._status_capture_y.setStyleSheet("color: #4f46e5; font-size: 15px; font-weight: 800;")
        self._status_capture_color.setStyleSheet(
            "background: #e0e0e0; border: 1px solid #9e9e9e; border-radius: 5px; padding: 0;"
        )
        sep0 = QFrame()
        sep0.setFrameShape(QFrame.Shape.VLine)
        sep0.setFrameShadow(QFrame.Shadow.Plain)
        sep0.setFixedWidth(1)
        sep0.setStyleSheet("color: #c7d2fe; max-width: 1px;")
        sep1 = QFrame()
        sep1.setFrameShape(QFrame.Shape.VLine)
        sep1.setFrameShadow(QFrame.Shadow.Plain)
        sep1.setFixedWidth(1)
        sep1.setStyleSheet("color: #c7d2fe; max-width: 1px;")
        sep2 = QFrame()
        sep2.setFrameShape(QFrame.Shape.VLine)
        sep2.setFrameShadow(QFrame.Shadow.Plain)
        sep2.setFixedWidth(1)
        sep2.setStyleSheet("color: #c7d2fe; max-width: 1px;")
        capture_layout.addWidget(self._status_capture_title)
        self._status_capture_xy_compact_label = QLabel("⌖")
        self._status_capture_xy_compact_label.setVisible(False)
        self._status_capture_xy_compact_label.setStyleSheet(
            "color: #4f46e5; font-size: 15px; font-weight: 800;"
        )
        self._status_capture_xy_compact_label.setToolTip("")
        capture_layout.addWidget(self._status_capture_xy_compact_label)
        capture_layout.addWidget(sep0)
        capture_layout.addWidget(self._status_capture_x)
        capture_layout.addWidget(sep1)
        capture_layout.addWidget(self._status_capture_y)
        capture_layout.addWidget(sep2)
        capture_layout.addWidget(self._status_capture_color)
        self._status_capture_xy_compact_widgets = (
            sep0,
            self._status_capture_x,
            sep1,
            self._status_capture_y,
            sep2,
        )
        self._status_capture_box.setStyleSheet(
            "background: #f5f1ec; border: 1px solid #d4c9bc; border-radius: 5px;"
        )

        self._status_capture_row = QWidget()
        capture_row_layout = QHBoxLayout(self._status_capture_row)
        capture_row_layout.setContentsMargins(0, 0, 0, 0)
        capture_row_layout.setSpacing(0)
        capture_row_layout.addWidget(self._status_capture_box)
        capture_row_layout.addWidget(self._status_capture_history_combo)
        self._status_arduino.setStyleSheet(
            "color: #1f1b16; background: #f5f1ec; border: 1px solid #e8e0d5; "
            "border-radius: 5px; font-size: 13px; font-weight: 700; padding: 4px 7px;"
        )
        self._status_macro.setStyleSheet(
            "color: #1f1b16; background: #f5f1ec; border: 1px solid #e8e0d5; "
            "border-radius: 5px; font-size: 13px; font-weight: 700; padding: 4px 7px;"
        )

        statusbar = self.statusBar()
        statusbar.setStyleSheet(
            "QStatusBar { margin: 0px; padding: 0px; }" "QStatusBar::item { border: none; }"
        )
        _sb_lay = statusbar.layout()
        if _sb_lay is not None:
            _sb_lay.setSpacing(0)
            _sb_lay.setContentsMargins(2, 0, 2, 0)
        statusbar.setContentsMargins(2, 0, 2, 0)
        statusbar.setFixedHeight(64)

        # 재연결 버튼 (Arduino 상태·매크로명과 함께 한 줄에서 폭에 따라 압축)
        self._btn_reconnect = QPushButton("🔌 재연결")
        self._btn_reconnect.setToolTip("Arduino에 수동으로 재연결을 시도합니다")
        self._btn_reconnect.setStyleSheet(
            "QPushButton { background: #c2410c; color: #FFFFFF; border: none; "
            "border-radius: 4px; font-size: 12px; font-weight: bold; padding: 3px 7px; }"
            "QPushButton:pressed { padding-top: 4px; }"
        )
        self._btn_reconnect.setMinimumWidth(36)
        self._btn_reconnect.setSizePolicy(
            QSizePolicy.Policy.Minimum,
            QSizePolicy.Policy.Fixed,
        )
        self._btn_reconnect.clicked.connect(self.reconnect_requested.emit)
        self._status_strip = _EditorStatusStrip(
            self,
            self._status_arduino,
            self._btn_reconnect,
            self._status_macro,
            self._status_state,
            self._status_capture_row,
            self._status_shortcut,
        )
        statusbar.addWidget(self._status_strip, stretch=1)
        self._refresh_capture_history_selector()
        self._status_strip_sync()
        QTimer.singleShot(0, self._status_strip_sync)

        # 스크롤바 가시성 강화: 폭/색 대비를 높여 즉시 인식 가능하게 한다.
        self.setStyleSheet(
            "QScrollBar:vertical { width: 14px; background: #f0ede8; margin: 2px; border-radius: 6px; }"
            "QScrollBar::handle:vertical { background: #c4b8aa; min-height: 28px; border-radius: 6px; }"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }"
            "QScrollBar:horizontal { height: 14px; background: #f0ede8; margin: 2px; border-radius: 6px; }"
            "QScrollBar::handle:horizontal { background: #c4b8aa; min-width: 28px; border-radius: 6px; }"
            "QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }"
        )

    def _status_strip_sync(self) -> None:
        strip = getattr(self, "_status_strip", None)
        if strip is not None:
            strip.sync_compact()

    def _on_status_shortcut_combo_activated(self, index: int) -> None:
        """안내용 콤보 — 항목을 고르면 읽은 뒤 표시줄은 다시 '단축키 안내'로 둔다."""
        if index <= 0:
            return
        QTimer.singleShot(0, self._reset_status_shortcut_combo)

    def _reset_status_shortcut_combo(self) -> None:
        cb = getattr(self, "_status_shortcut", None)
        if cb is None:
            return
        cb.blockSignals(True)
        try:
            cb.setCurrentIndex(0)
        finally:
            cb.blockSignals(False)

    # -------------------------------------------------------------------
    # FIX #2: 그리드 버튼으로 액션 추가
    # -------------------------------------------------------------------

    def _add_action_type(self, action_class: type[Action]) -> None:
        """지정된 타입의 기본 액션을 리스트에 추가한다."""
        if action_class in IF_TRIO_ACTION_TYPES:
            current_row = self._action_list.currentRow()
            insert_at = current_row + 1 if current_row >= 0 else None
            header = action_class()
            if not (header.comment or "").strip():
                header.comment = _default_block_comment(header)
            trio: list[Action] = [header, ElseAction(), EndIfAction()]
            for act in trio:
                self._action_list.add_action(act, insert_at)
                if insert_at is not None:
                    insert_at += 1
            action = trio[0]
        else:
            action = action_class()
            self._action_list.add_action(action)
        # 버튼으로 액션을 추가할 때 파라미터 패널이 비워진 상태로 남는 문제를 방어
        try:
            actions = self._action_list.get_all_actions()
            row = self._action_list.currentRow()
            if 0 <= row < len(actions):
                self._param_panel.set_action(actions[row])
            elif actions:
                self._param_panel.set_action(actions[-1])
        except Exception:
            self._param_panel.set_action(action)
        self.log_message("INFO", f"액션 추가 완료: {action.type}")

    def _insert_quick_actions(self, name: str, actions: list[Action]) -> None:
        """자주 쓰는 액션 묶음을 한 번에 추가한다."""
        for action in actions:
            self._action_list.add_action(action)
        self.log_message("INFO", f"퀵 삽입 완료: {name} ({len(actions)}개)")

    def _quick_insert_click_delay(self) -> None:
        self._insert_quick_actions(
            "클릭+딜레이",
            [
                MouseClickAction(),
                DelayAction(ms=300),
            ],
        )

    def _quick_insert_key_delay(self) -> None:
        self._insert_quick_actions(
            "키입력+딜레이",
            [
                KeyPressAction(key="1"),
                DelayAction(ms=300),
            ],
        )

    def _quick_insert_pixel_wait_click(self) -> None:
        self._insert_quick_actions(
            "픽셀대기+클릭",
            [
                PixelWaitAction(timeout_ms=3000),
                MouseClickAction(),
                ElseAction(),
                EndIfAction(),
            ],
        )

    def _quick_insert_retry_with_fallback(self) -> None:
        """최대 N회 시도 후 실패 시 후처리하는 추천 구조를 삽입한다."""
        self._insert_quick_actions(
            "재시도+실패분기",
            [
                VariableSetAction(
                    var_name="success",
                    value="",
                    expression="0",
                    comment="성공 플래그 초기화(0=실패, 1=성공)",
                ),
                LoopStartAction(
                    count=5,
                    comment="최대 5회 시도",
                ),
                ImageSearchAction(
                    store_found_var="found",
                    max_retry=1,
                    retry_interval_ms=300,
                    comment="TODO: 템플릿/영역 설정 · 발견 시 아래 성공 처리, 미발견 시 else",
                ),
                VariableSetAction(
                    var_name="success",
                    value="",
                    expression="1",
                    comment="발견(then) — 루프 탈출",
                ),
                BreakAction(),
                ElseAction(
                    comment="미발견(else) — 루프 재시도",
                ),
                DelayAction(ms=200, comment="다음 시도 전 짧은 대기"),
                EndIfAction(),
                LoopEndAction(),
                IfVariableAction(
                    var_name="success",
                    operator="==",
                    compare_value="0",
                    comment="모든 시도 실패 시 fallback 실행",
                ),
                KeyPressAction(
                    key="esc",
                    comment="fallback 예시: ESC 입력",
                ),
                ElseAction(),
                EndIfAction(),
            ],
        )

    def _open_ai_gen_dialog(self) -> None:
        """AI 매크로 생성 도우미 다이얼로그를 열고 결과를 삽입한다."""
        from editor.ai_gen_dialog import AI_INSERT_EMPTY_COMMENT_HINT, AIGenDialog

        # 모달 다이얼로그 동안 포커스가 바뀌어도, 연 시점의 선택 행 기준으로 삽입한다.
        action_count_before = len(self._action_list.get_all_actions())
        anchor_row = self._action_list.currentRow()

        dlg = AIGenDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            actions = dlg.get_actions()
            if actions:
                self._save_undo_state()
                user_note = dlg.get_user_request_text()
                hint = AI_INSERT_EMPTY_COMMENT_HINT

                to_insert: list[Action] = []
                if user_note:
                    to_insert.append(CommentAction(comment=f"[AI 자연어 요청]\n{user_note}"))
                for action in actions:
                    if user_note and not (action.comment or "").strip():
                        action = action.model_copy(update={"comment": hint})
                    to_insert.append(action)

                if 0 <= anchor_row < action_count_before:
                    insert_at = anchor_row + 1
                    for offset, action in enumerate(to_insert):
                        self._action_list.add_action(action, index=insert_at + offset)
                else:
                    for action in to_insert:
                        self._action_list.add_action(action)

                self._is_modified = True
                self._update_title()
                log_suffix = (
                    f"동작 {len(actions)}개 (자연어 요약 주석 포함)"
                    if user_note
                    else f"동작 {len(actions)}개"
                )
                self.log_message("INFO", f"AI 매크로 삽입 완료: {log_suffix}")

    # -------------------------------------------------------------------
    # 액션 편집
    # -------------------------------------------------------------------

    def _on_action_selected(self, index: int) -> None:
        if self._suppress_param_panel_reload:
            return
        self._param_undo_snapshot_taken = False
        actions = self._action_list.get_all_actions()
        if 0 <= index < len(actions):
            self._param_panel.set_action(actions[index])
            self._update_param_header(actions[index], index)
        else:
            self._param_panel.clear_panel()
            self._update_param_header(None)

    def _on_param_changed(self, action: Action) -> None:
        """FIX #4,#5: 파라미터 변경 → 리스트 즉시 갱신."""
        if not self._param_undo_snapshot_taken:
            self._save_undo_state()
            self._param_undo_snapshot_taken = True
        current_row = self._action_list.currentRow()
        if current_row >= 0:
            self._suppress_param_panel_reload = True
            try:
                self._action_list.update_action(current_row, action)
            finally:
                self._suppress_param_panel_reload = False
            self._is_modified = True
            self._update_title()

    def _on_modified(self) -> None:
        self._is_modified = True
        self._update_title()
        self._refresh_variable_suggestions()

    def _edit_macro_properties(self) -> None:
        """매크로 이름/설정을 편집하는 대화상자를 표시한다."""
        from PyQt6.QtWidgets import QDialog, QDialogButtonBox

        dialog = QDialog(self)
        dialog.setWindowTitle("매크로 속성")
        dialog.setMinimumWidth(350)
        layout = QFormLayout(dialog)

        name_edit = QLineEdit(self._macro.name)
        name_edit.setPlaceholderText("매크로 이름")
        layout.addRow("이름:", name_edit)

        humanize_check = QCheckBox("휴머나이저 활성화")
        humanize_check.setChecked(self._macro.settings.humanize)
        humanize_check.setToolTip(
            "켜면: 액션 사이에 짧은 대기를 무작위로 넣어 패턴이 덜 눈에 띄게 합니다.\n"
            "끄면: 그런 추가 대기를 넣지 않습니다."
        )
        layout.addRow(humanize_check)

        base_delay_spin = QSpinBox()
        base_delay_spin.setRange(0, 5000)
        base_delay_spin.setSuffix(" ms")
        base_delay_spin.setValue(self._macro.settings.base_delay_ms)
        base_delay_spin.setToolTip(
            "휴머나이저가 켜져 있을 때, 액션 사이 대기 시간의 기준(ms)입니다.\n"
            "항상 같은 값이 아니라 이 값을 중심으로 무작위로 흔들립니다."
        )
        layout.addRow("기본 딜레이:", base_delay_spin)

        micro_afk_check = QCheckBox("마이크로 AFK 활성화")
        micro_afk_check.setChecked(self._macro.settings.micro_afk_enabled)
        micro_afk_check.setToolTip(
            "낮은 확률로 긴 추가 대기(멈칫)를 넣습니다.\n" "체감 속도가 느려질 수 있습니다."
        )
        layout.addRow(micro_afk_check)

        micro_afk_chance_spin = QSpinBox()
        micro_afk_chance_spin.setRange(0, 100)
        micro_afk_chance_spin.setSuffix(" %")
        micro_afk_chance_spin.setValue(self._macro.settings.micro_afk_chance_percent)
        micro_afk_chance_spin.setToolTip("마이크로 AFK가 발생할 확률(%)입니다.")
        layout.addRow("마이크로 AFK 확률:", micro_afk_chance_spin)

        micro_afk_min_spin = QSpinBox()
        micro_afk_min_spin.setRange(0, 10000)
        micro_afk_min_spin.setSuffix(" ms")
        micro_afk_min_spin.setValue(self._macro.settings.micro_afk_min_ms)
        micro_afk_min_spin.setToolTip("마이크로 AFK 최소 추가 대기(ms)입니다.")
        layout.addRow("마이크로 AFK 최소:", micro_afk_min_spin)

        micro_afk_max_spin = QSpinBox()
        micro_afk_max_spin.setRange(0, 10000)
        micro_afk_max_spin.setSuffix(" ms")
        micro_afk_max_spin.setValue(self._macro.settings.micro_afk_max_ms)
        micro_afk_max_spin.setToolTip("마이크로 AFK 최대 추가 대기(ms)입니다.")
        layout.addRow("마이크로 AFK 최대:", micro_afk_max_spin)

        humanizer_help = QLabel(
            "안내: 휴머나이저는 액션마다 짧은 무작위 대기를 더합니다.\n"
            "마이크로 AFK를 켜면 정한 확률로 최소~최대(ms)만큼 한 번 더 멈춥니다."
        )
        humanizer_help.setStyleSheet("color: #6b6360; font-size: 11px;")
        humanizer_help.setWordWrap(True)
        layout.addRow(humanizer_help)

        def _sync_micro_afk_controls() -> None:
            enabled = micro_afk_check.isChecked()
            micro_afk_chance_spin.setEnabled(enabled)
            micro_afk_min_spin.setEnabled(enabled)
            micro_afk_max_spin.setEnabled(enabled)

        micro_afk_check.toggled.connect(_sync_micro_afk_controls)
        _sync_micro_afk_controls()
        schedule_help = QLabel("스케줄 편집은 좌측 하단의 '스케줄 관리' 버튼에서 진행하세요.")
        schedule_help.setStyleSheet("color: #6b6360; font-size: 11px;")
        schedule_help.setWordWrap(True)
        layout.addRow(schedule_help)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._macro.name = name_edit.text().strip() or self._macro.name
            prev = self._macro.settings
            self._macro.settings = MacroSettings(
                humanize=humanize_check.isChecked(),
                base_delay_ms=base_delay_spin.value(),
                micro_afk_enabled=micro_afk_check.isChecked(),
                micro_afk_chance_percent=micro_afk_chance_spin.value(),
                micro_afk_min_ms=min(micro_afk_min_spin.value(), micro_afk_max_spin.value()),
                micro_afk_max_ms=max(micro_afk_min_spin.value(), micro_afk_max_spin.value()),
                schedule_rules=prev.schedule_rules,
            )
            self._is_modified = True
            self._update_title()
            self._refresh_schedule_list()
            self.log_message("INFO", f"매크로 속성 변경 완료: 이름='{self._macro.name}'")

    def _validate_macro(self) -> None:
        self._macro.actions = self._action_list.get_all_actions()
        issues = self._validator.validate(self._macro)
        if not issues:
            self._show_message("검증", "문제 없음!")
            self.log_message("INFO", "매크로 검증 완료: 문제 없음")
        else:
            report = self._validator.format_issues(issues)
            self._show_message("검증 결과", report)
            self.log_message("WARNING", f"매크로 검증 완료: 이슈 {len(issues)}개")

    def _update_param_header(self, action: Action | None, index: int | None = None) -> None:
        if action is None:
            self._param_title.setText("파라미터 편집 (선택 없음)")
            self._param_type_combo.blockSignals(True)
            try:
                self._param_type_combo.hide()
            finally:
                self._param_type_combo.blockSignals(False)
            return

        row = index if index is not None else self._action_list.currentRow()
        action_name = action.type.value
        self._param_title.setText(f"파라미터 편집 · #{row + 1:02d} {action_name}")
        if self._action_list.is_struct_if_row(row):
            self._param_type_combo.blockSignals(True)
            try:
                self._param_type_combo.show()
                for i, (_label, action_cls) in enumerate(STRUCT_IF_TYPE_OPTIONS):
                    if isinstance(action, action_cls):
                        self._param_type_combo.setCurrentIndex(i)
                        break
            finally:
                self._param_type_combo.blockSignals(False)
        else:
            self._param_type_combo.blockSignals(True)
            try:
                self._param_type_combo.hide()
            finally:
                self._param_type_combo.blockSignals(False)

    def _on_param_type_changed(self, index: int) -> None:
        row = self._action_list.currentRow()
        if not self._action_list.is_struct_if_row(row):
            return
        if not (0 <= index < len(STRUCT_IF_TYPE_OPTIONS)):
            return
        _label, action_cls = STRUCT_IF_TYPE_OPTIONS[index]
        changed = self._action_list.convert_struct_if_row(row, action_cls)
        if not changed:
            return
        actions = self._action_list.get_all_actions()
        if 0 <= row < len(actions):
            self._param_panel.set_action(actions[row])
            self._update_param_header(actions[row], row)

    def _show_shortcuts_help(self) -> None:
        """단축키 설명 다이얼로그를 표시한다."""
        lines = [
            "[파일/도구]",
            "Ctrl+N  : 새로 만들기",
            "Ctrl+O  : 열기",
            "Ctrl+S  : 저장",
            "Ctrl+Shift+S : 다른이름 저장",
            "Ctrl+Shift+V : 매크로 검증",
            "Alt+F4  : 종료",
            "",
            "[실행/디버그]",
            "Ctrl+F5  : 매크로 실행",
            "Ctrl+F6  : 매크로 일시정지 / 재개 토글",
            "Ctrl+F7  : 매크로 정지",
            "Ctrl+R : 녹화 시작/정지",
            "F8  : 좌표·픽셀 색 캡처 → 클립보드 갱신, 최근 10개 히스토리(상태바·중복 생략)",
            "F9  : 현재 액션 브레이크포인트 토글",
            "F10 : 1스텝 실행",
            "",
            "[편집/뷰]",
            "Ctrl+Z : 실행 취소 (Undo, 액션 리스트 포커스 · 접기·브레이크포인트 포함)",
            "Ctrl+Y : 다시 실행 (Redo, 액션 리스트 포커스)",
            "Delete / Backspace : 선택된 액션 삭제 (액션 리스트 포커스)",
            "Ctrl+D : 선택 행 복제 (액션 리스트 포커스, 다중 선택 시 각 행)",
            "Ctrl+L : 하단 패널(로그 · 캡처) 표시/숨김",
            "",
            "조건 블록 타입 변경:",
            "- 우측 파라미터 패널 상단 드롭다운(구조형 if 헤더 선택 시 표시)",
        ]
        text = "\n".join(lines)
        self._show_message("단축키 안내", text)

    def _show_user_guide(self) -> None:
        """버튼/기능 중심 사용 가이드를 다이얼로그로 표시한다."""
        dialog = QDialog(self)
        dialog.setWindowTitle("GameMacroStudio 사용 가이드")
        dialog.setMinimumSize(760, 560)

        layout = QVBoxLayout(dialog)
        guide_view = QTextEdit()
        guide_view.setReadOnly(True)
        guide_view.setStyleSheet("font-size: 12px; line-height: 1.5;")
        guide_view.setPlainText(
            "GameMacroStudio 사용 가이드 (요약)\n"
            "\n"
            "1) 기본 흐름\n"
            "- 새로 만들기(Ctrl+N) → 액션 추가·편집 → 저장(Ctrl+S) → 실행(Ctrl+F5)\n"
            "- 실행 전 확인에서 요약을 읽고, 필요하면 리허설(HID 미전송)을 선택할 수 있습니다.\n"
            "- 일시정지(Ctrl+F6), 스텝(F10), 정지(Ctrl+F7)\n"
            "- 녹화: 툴바 또는 Ctrl+R (실행 중·일시정지 중에는 녹화 시작 불가)\n"
            "\n"
            "2) 주요 영역\n"
            "- 좌측: 액션 추가 버튼·추천 조합, 변수 모니터(실행 중 이름·값 표만), 스케줄 관리\n"
            "- 중앙: 액션 리스트(드래그로 순서 변경, Delete 삭제, Ctrl+D 복제·다중 선택 시 각 행)\n"
            "- 우측: 선택한 액션의 파라미터 편집(맨 위 보라색 박스에 액션 요약·VarSet·IfVar 변수 규칙 포함)\n"
            "- 하단: 실행 로그(좌) + 이미지·픽셀 캡처(우), 가운데 구분선 드래그로 폭 조절\n"
            "- 휴머나이저·기본 딜레이·마이크로 AFK: 도구 → 매크로 속성에서 설정합니다. "
            "액션 사이 간격을 사람처럼 무작위로 흔들어 줍니다.\n"
            "\n"
            "2-1) 스케줄\n"
            "- 좌측 「스케줄 관리」에서 시각(HH:MM)과 실행할 다른 매크로(SubCall) 경로를 등록합니다.\n"
            "- 규칙은 현재 열린 매크로 JSON(settings)에 저장됩니다. "
            "정해진 시각에 서브 매크로를 돌리는 용도로 생각하면 됩니다.\n"
            "\n"
            "2-2) 도구: AI 매크로 생성\n"
            "- 도구 → AI 매크로 생성: 왼쪽에 동작을 자연어로 적고 [클립보드 복사]로 "
            "프롬프트를 외부 AI에 붙여넣습니다.\n"
            '- 오른쪽에 액션 JSON(배열 또는 {"actions": [...]})을 붙여 [검증 및 삽입]하면 '
            "선택 행 아래(없으면 맨 아래)에 한 덩어리로 들어갑니다.\n"
            "- 왼쪽 자연어는 [AI 자연어 요청] 메모 행·비어 있던 액션 메모(comment)에 남아 맥락 파악에 도움이 됩니다.\n"
            "\n"
            "2-3) 도구: 좌표 오프셋\n"
            "- 도구 → 좌표 오프셋 적용: 마우스·화면 좌표가 들어 있는 액션 일괄 이동에 사용합니다.\n"
            "\n"
            "3) 액션 카테고리 (좌측 버튼 이름과 동일)\n"
            "- 마우스 입력: Delay, Move, Click, Down, Up, Drag, Scroll\n"
            "- 키보드 입력: Press, Down, Up, Combo, Text\n"
            "- 화면 감지/조건: IfPixel, IfVar, VarSet, PixWait, ImgSearch, ImgWait, ImgClick, "
            "OCR읽기(한 번 읽기), OCR대기(글자 나올 때까지 대기·분기)\n"
            "- 반복/분기: Comment, For(Loop+), EndFor(Loop-), Else, EndIf, Break\n"
            "  ※ For(Loop+)와 EndFor(Loop-)는 한 쌍입니다. 예전 문서의 Loop+/Loop-와 같은 뜻입니다.\n"
            "- 점프/서브매크로: Label, Goto, SubCall\n"
            "- 함수: 함수 정의, 함수 끝, 함수 호출, 반환\n"
            "- 추천 조합: 클릭+딜레이, 키입력+딜레이, 픽셀대기+클릭, 재시도+실패분기\n"
            "\n"
            "4) 조건/대기 블록(구조형 If·Else·EndIf)\n"
            "- IfPixel, IfVar, PixWait, ImgSearch, ImgWait, ImgClick, OCR대기를 추가하면 "
            "조건 헤더 + Else + EndIf가 함께 만들어집니다.\n"
            "- 성공·일치면 then 쪽, 실패·타임아웃이면 else 쪽으로 갑니다.\n"
            "- Else/EndIf를 지워도 리스트에서 자동으로 복구됩니다.\n"
            "- 조건 헤더 행을 선택하면 우측 상단 콤보로 종류만 바꿀 수 있습니다(내부 액션은 유지).\n"
            "- OCR읽기는 구조형 블록이 아니라, 한 번 읽고 변수에 넣는 단발 액션입니다.\n"
            "- Label/Goto는 조건 없이 위치만 옮길 때 쓰는 고급 흐름입니다.\n"
            "\n"
            "5) 주요 화면·텍스트 액션 요약\n"
            "- ImgSearch: 영역에서 이미지를 찾아 img_x/img_y 등에 저장\n"
            "- ImgWait: 이미지가 나타날 때까지 대기 후 분기\n"
            "- ImgClick: 찾은 위치 클릭(오프셋·버튼 설정 가능)\n"
            "- OCR읽기: 영역 글자를 한 번 읽어 변수에 저장\n"
            "- OCR대기: 패턴(또는 정규식)이 보일 때까지 대기 후 분기\n"
            "- SubCall: 다른 JSON 매크로 파일 실행(깊이 제한 있음)\n"
            "\n"
            "6) 디버깅 팁\n"
            "- F9: 브레이크포인트 토글\n"
            "- F10: 일시정지 중 한 액션만 실행 후 다시 멈춤\n"
            "- F8: 좌표·색 캡처(클립보드 + 최근 히스토리, 파라미터의 F8 자동 입력)\n"
            "- Ctrl+L: 하단 패널(로그·캡처) 표시/숨김\n"
            "- 흐름 오류 시 Label/Goto 이름 중복·철자부터 확인\n"
            "\n"
            "7) 권장 체크\n"
            "- 실행 전: For(Loop+)/EndFor(Loop-) 짝, Label 이름 확인\n"
            "- 실행 중: 저장·새로 만들기·열기는 불가 — 먼저 정지(Ctrl+F7)\n"
            "- 로그의 WARNING/ERROR를 우선 확인\n"
            "- 위험 시: 툴바 정지(Ctrl+F7) 또는 창을 닫기 전 매크로 정지"
        )
        layout.addWidget(guide_view)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        buttons.button(QDialogButtonBox.StandardButton.Close).clicked.connect(dialog.close)
        layout.addWidget(buttons)

        dialog.exec()

    # -------------------------------------------------------------------
    # 유틸리티
    # -------------------------------------------------------------------

    def _update_title(self) -> None:
        name = self._current_file.name if self._current_file else "새 매크로"
        modified = " *" if self._is_modified else ""
        self.setWindowTitle(f"GameMacroStudio — {name}{modified}")
        self._status_macro.set_full_text(f"매크로명: {name}{modified}")
        self._status_strip_sync()

    def _confirm_discard(self) -> bool:
        return self._ask_yes_no(
            "저장 안 됨",
            "저장되지 않은 변경이 있습니다. 계속할까요?",
            default_yes=False,
        )

    def _show_message(self, title: str, text: str) -> None:
        """시스템 경고음을 내지 않는 메시지 박스를 표시한다."""
        msg = QMessageBox(self)
        msg.setWindowTitle(title)
        msg.setText(text)
        msg.setIcon(QMessageBox.Icon.NoIcon)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()

    def _ask_yes_no(self, title: str, text: str, default_yes: bool = False) -> bool:
        """시스템 경고음 없이 Yes/No 확인 박스를 표시한다."""
        msg = QMessageBox(self)
        msg.setWindowTitle(title)
        msg.setText(text)
        msg.setIcon(QMessageBox.Icon.NoIcon)
        msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        default_button = (
            QMessageBox.StandardButton.Yes if default_yes else QMessageBox.StandardButton.No
        )
        msg.setDefaultButton(default_button)
        return msg.exec() == QMessageBox.StandardButton.Yes

    def _populate_recent_menu(self) -> None:
        """최근 파일 서브메뉴를 현재 config 기준으로 갱신한다."""
        self._recent_menu.clear()
        ctx = getattr(self, "_app_ctx", None)
        recent: list[str] = []
        if ctx is not None:
            recent = ctx.app_config.get("recent_files", [])
        if not recent:
            empty = QAction("(없음)", self)
            empty.setEnabled(False)
            self._recent_menu.addAction(empty)
            return
        for file_path in recent:
            p = Path(file_path)
            act = QAction(p.name, self)
            act.setToolTip(str(p))
            if not p.exists():
                act.setEnabled(False)
                act.setText(f"{p.name}  (파일 없음)")
            else:
                act.triggered.connect(
                    lambda checked=False, path=p: self._open_macro_from_path(path)
                )
            self._recent_menu.addAction(act)

    def _save_window_geometry(self) -> None:
        """현재 창 위치/크기를 config에 기록한다."""
        ctx = getattr(self, "_app_ctx", None)
        if ctx is None:
            return
        from shared.config import save_config

        geo = self.geometry()
        ctx.app_config["window_x"] = geo.x()
        ctx.app_config["window_y"] = geo.y()
        ctx.app_config["window_width"] = geo.width()
        ctx.app_config["window_height"] = geo.height()
        save_config(ctx.app_config)

    def closeEvent(self, event: object) -> None:  # noqa: N802
        """윈도우 종료 시 핫키 스레드, 녹화, 실행기를 정리한다."""
        if self._recorder.is_recording:
            self._recorder.stop_recording()
            self.log_message("INFO", "녹화 정지 완료")

        if self._global_hotkeys is not None:
            try:
                # Win32 RegisterHotKey 스레드인 경우
                if hasattr(self, "_win32_hotkey_thread_running"):
                    self._win32_hotkey_thread_running = False
                    if hasattr(self._global_hotkeys, "join"):
                        self._global_hotkeys.join(timeout=1.0)
                        if self._global_hotkeys.is_alive():
                            logger.warning("Win32 핫키 스레드가 1초 내 종료되지 않음")
                else:
                    # pynput GlobalHotKeys인 경우
                    self._global_hotkeys.stop()
            except Exception as exc:
                logger.debug("핫키 스레드 정리 중 에러: %s", exc)

        switching = getattr(self, "_closing_for_mode_switch", False)
        if switching:
            self._closing_for_mode_switch = False
        elif self._is_modified and not self._confirm_discard():
            event.ignore()  # type: ignore[union-attr]
            return

        # 종료 시 실행 중이었을 가능성을 방어적으로 처리한다.
        # runner.stop_macro()는 IDLE 상태에서는 아무 일도 하지 않으므로 안전하다.
        self.macro_stop_requested.emit()

        self._save_window_geometry()
        event.accept()  # type: ignore[union-attr]
