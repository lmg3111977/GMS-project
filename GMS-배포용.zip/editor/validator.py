"""매크로 논리 검증기.

매크로의 Action 리스트가 논리적으로 올바른지 검증한다.
shared/schema.py의 validate_macro_logic()을 UI 레벨에서 래핑하여
ValidationIssue 객체로 결과를 제공한다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import StrEnum

from shared.models import Macro
from shared.schema import validate_macro_logic

logger = logging.getLogger(__name__)


class IssueLevel(StrEnum):
    """검증 이슈 심각도."""

    ERROR = "error"
    WARNING = "warning"


@dataclass
class ValidationIssue:
    """검증 이슈 데이터.

    Attributes:
        level: 심각도 (error / warning)
        action_index: 문제가 있는 액션의 인덱스 (-1이면 매크로 전체)
        message: 이슈 설명
    """

    level: IssueLevel
    action_index: int = -1
    message: str = ""


class MacroValidator:
    """매크로 논리 검증기.

    shared/schema.py의 검증 결과를 파싱하여
    UI에서 사용하기 편한 ValidationIssue 리스트로 변환한다.
    """

    def validate(self, macro: Macro) -> list[ValidationIssue]:
        """매크로를 검증하고 이슈 목록을 반환한다.

        Args:
            macro: 검증할 Macro 인스턴스

        Returns:
            ValidationIssue 리스트. 빈 리스트면 유효함.
        """
        raw_issues = validate_macro_logic(macro)
        issues: list[ValidationIssue] = []

        for raw in raw_issues:
            level = IssueLevel.ERROR if "[ERROR]" in raw else IssueLevel.WARNING
            message = raw.replace("[ERROR] ", "").replace("[WARNING] ", "")

            # 액션 인덱스 추출 (예: "#5: ...")
            action_index = -1
            if message.startswith("#"):
                try:
                    idx_str = message.split(":")[0].lstrip("#")
                    action_index = int(idx_str)
                    message = ":".join(message.split(":")[1:]).strip()
                except (ValueError, IndexError):
                    pass

            issues.append(
                ValidationIssue(
                    level=level,
                    action_index=action_index,
                    message=message,
                )
            )

        if issues:
            error_count = sum(1 for i in issues if i.level == IssueLevel.ERROR)
            warn_count = sum(1 for i in issues if i.level == IssueLevel.WARNING)
            logger.info(
                "매크로 검증 완료: %d개 에러, %d개 경고",
                error_count,
                warn_count,
            )
        else:
            logger.debug("매크로 검증 통과")

        return issues

    def has_errors(self, issues: list[ValidationIssue]) -> bool:
        """에러 레벨 이슈가 있는지 확인한다."""
        return any(i.level == IssueLevel.ERROR for i in issues)

    def format_issues(self, issues: list[ValidationIssue]) -> str:
        """이슈 목록을 사람이 읽을 수 있는 문자열로 포맷한다."""
        if not issues:
            return "검증 통과: 문제 없음"

        lines: list[str] = []
        for issue in issues:
            prefix = "ERROR" if issue.level == IssueLevel.ERROR else "WARN"
            location = f"#{issue.action_index}" if issue.action_index >= 0 else "전체"
            lines.append(f"[{prefix}] {location}: {issue.message}")

        return "\n".join(lines)
