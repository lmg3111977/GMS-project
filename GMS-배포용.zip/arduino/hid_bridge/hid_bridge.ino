/*
 * GameMacroStudio — Arduino Leonardo HID Bridge
 *
 * PC에서 시리얼(USB CDC, 115200 baud)로 수신한 명령을
 * HID(마우스/키보드) 출력으로 변환하는 브릿지.
 *
 * 패킷: [STX 0x02][CMD 1B][LENGTH 1B][PAYLOAD 0~60B][CHECKSUM 1B][ETX 0x03]
 * 체크섬: CMD XOR LENGTH XOR (각 PAYLOAD 바이트)
 *
 * 안전 장치:
 *   - 부팅 후 5초 대기 (리프로그래밍 여유)
 *   - 킬 스위치 D2 (LOW = HID 비활성)
 *   - EMERGENCY_STOP (0xFF) → 모든 키/마우스 해제
 *   - 3초 시리얼 무응답 → 자동 해제
 */

#include <Keyboard.h>
#include <Mouse.h>

// ── 패킷 상수 ──
#define PACKET_STX        0x02
#define PACKET_ETX        0x03
#define MAX_PAYLOAD       60

// ── 명령 코드 (shared/protocol.py와 동일) ──
#define CMD_MOUSE_MOVE    0x01
#define CMD_MOUSE_CLICK   0x02
#define CMD_MOUSE_DOWN    0x03
#define CMD_MOUSE_UP      0x04
#define CMD_MOUSE_SCROLL  0x05
#define CMD_KEY_PRESS     0x10
#define CMD_KEY_DOWN      0x11
#define CMD_KEY_UP        0x12
#define CMD_KEY_RELEASE   0x13
#define CMD_TYPE_CHAR     0x20
#define CMD_HANDSHAKE     0xF0
#define CMD_ACK           0xF1
#define CMD_EMERGENCY     0xFF

// ── ACK 상태 코드 ──
#define ACK_OK            0x00
#define ACK_BAD_CHECKSUM  0x01
#define ACK_UNKNOWN_CMD   0x02
#define ACK_EXEC_FAIL     0x03

// ── 하드웨어 핀 ──
#define PIN_KILL_SWITCH   2
#define PIN_LED           13

// ── 타이밍 ──
#define BOOT_DELAY_MS     5000
#define SAFETY_TIMEOUT_MS 3000
#define KEY_PRESS_HOLD_MS 10

// ── 프로토콜 버전 ──
#define FIRMWARE_VERSION  1

// ── 패킷 파서 상태 ──
enum ParserState {
  WAIT_STX,
  READ_CMD,
  READ_LENGTH,
  READ_PAYLOAD,
  READ_CHECKSUM,
  WAIT_ETX
};

// ── 전역 변수 (constitution: g_ 접두사) ──
static uint8_t g_packetBuffer[MAX_PAYLOAD];
static uint8_t g_bufferIndex = 0;
static uint8_t g_cmd = 0;
static uint8_t g_payloadLength = 0;
static uint8_t g_receivedChecksum = 0;
static ParserState g_parserState = WAIT_STX;
static unsigned long g_lastDataTime = 0;
static bool g_hidEnabled = false;
static unsigned long g_parserStartTime = 0;

// ── 함수 프로トタイプ ──
void parseSerialByte(uint8_t byte);
void executeCommand(uint8_t cmd, uint8_t* payload, uint8_t length);
void sendAck(uint8_t status);
void releaseAll(void);
void resetParser(void);
uint8_t calculateChecksum(uint8_t cmd, uint8_t* payload, uint8_t length);

// ═══════════════════════════════════════════════
// setup
// ═══════════════════════════════════════════════

void setup() {
  pinMode(PIN_KILL_SWITCH, INPUT_PULLUP);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  Serial.begin(115200);
  while (!Serial) {
    ;  // Leonardo: USB CDC 연결 대기
  }

  // 부팅 대기 (리프로그래밍 여유 시간)
  // LED 깜빡임으로 대기 중 표시
  for (int i = 0; i < 10; i++) {
    digitalWrite(PIN_LED, (i % 2 == 0) ? HIGH : LOW);
    delay(BOOT_DELAY_MS / 10);
  }

  Keyboard.begin();
  Mouse.begin();

  g_lastDataTime = millis();
  g_hidEnabled = (digitalRead(PIN_KILL_SWITCH) == HIGH);
  digitalWrite(PIN_LED, g_hidEnabled ? HIGH : LOW);
}

// ═══════════════════════════════════════════════
// loop (논블로킹 — delay() 사용 금지)
// ═══════════════════════════════════════════════

void loop() {
  // 킬 스위치 확인
  bool switchState = (digitalRead(PIN_KILL_SWITCH) == HIGH);
  if (switchState != g_hidEnabled) {
    g_hidEnabled = switchState;
    digitalWrite(PIN_LED, g_hidEnabled ? HIGH : LOW);
    if (!g_hidEnabled) {
      releaseAll();
    }
  }

  // 안전 타이머: 3초 무응답 시 모든 입력 해제
  if (millis() - g_lastDataTime > SAFETY_TIMEOUT_MS) {
    releaseAll();
    g_lastDataTime = millis();  // 반복 해제 방지
  }

  // 패킷 파서 타임아웃 (수신 시작 후 100ms 이내 완료되지 않으면 리셋)
  if (g_parserState != WAIT_STX) {
    if (millis() - g_parserStartTime > 100) {
      resetParser();
    }
  }

  // 시리얼 데이터 처리
  while (Serial.available() > 0) {
    g_lastDataTime = millis();
    parseSerialByte((uint8_t)Serial.read());
  }
}

// ═══════════════════════════════════════════════
// 패킷 파서 (상태 머신)
// ═══════════════════════════════════════════════

void parseSerialByte(uint8_t byte) {
  switch (g_parserState) {
    case WAIT_STX:
      if (byte == PACKET_STX) {
        g_parserState = READ_CMD;
        g_parserStartTime = millis();
      }
      break;

    case READ_CMD:
      g_cmd = byte;
      g_parserState = READ_LENGTH;
      break;

    case READ_LENGTH:
      g_payloadLength = byte;
      g_bufferIndex = 0;
      if (g_payloadLength > MAX_PAYLOAD) {
        resetParser();
      } else if (g_payloadLength == 0) {
        g_parserState = READ_CHECKSUM;
      } else {
        g_parserState = READ_PAYLOAD;
      }
      break;

    case READ_PAYLOAD:
      g_packetBuffer[g_bufferIndex++] = byte;
      if (g_bufferIndex >= g_payloadLength) {
        g_parserState = READ_CHECKSUM;
      }
      break;

    case READ_CHECKSUM:
      g_receivedChecksum = byte;
      g_parserState = WAIT_ETX;
      break;

    case WAIT_ETX:
      if (byte == PACKET_ETX) {
        uint8_t expected = calculateChecksum(g_cmd, g_packetBuffer, g_payloadLength);
        if (g_receivedChecksum == expected) {
          executeCommand(g_cmd, g_packetBuffer, g_payloadLength);
        } else {
          sendAck(ACK_BAD_CHECKSUM);
        }
      }
      resetParser();
      break;
  }
}

void resetParser(void) {
  g_parserState = WAIT_STX;
  g_bufferIndex = 0;
  g_cmd = 0;
  g_payloadLength = 0;
}

uint8_t calculateChecksum(uint8_t cmd, uint8_t* payload, uint8_t length) {
  uint8_t cs = cmd ^ length;
  for (uint8_t i = 0; i < length; i++) {
    cs ^= payload[i];
  }
  return cs;
}

// ═══════════════════════════════════════════════
// 명령 실행
// ═══════════════════════════════════════════════

void executeCommand(uint8_t cmd, uint8_t* payload, uint8_t length) {
  // EMERGENCY_STOP은 킬 스위치 상태와 무관하게 항상 실행
  if (cmd == CMD_EMERGENCY) {
    releaseAll();
    sendAck(ACK_OK);
    return;
  }

  // HANDSHAKE도 항상 응답
  if (cmd == CMD_HANDSHAKE) {
    sendAck(ACK_OK);
    return;
  }

  // HID 비활성 상태면 실행 거부
  if (!g_hidEnabled) {
    sendAck(ACK_EXEC_FAIL);
    return;
  }

  switch (cmd) {
    case CMD_MOUSE_MOVE: {
      if (length >= 4) {
        int16_t dx = (int16_t)(payload[0] | (payload[1] << 8));
        int16_t dy = (int16_t)(payload[2] | (payload[3] << 8));
        // Mouse.move()는 signed char 범위이므로 클램핑
        int8_t mx = (dx > 127) ? 127 : (dx < -128) ? -128 : (int8_t)dx;
        int8_t my = (dy > 127) ? 127 : (dy < -128) ? -128 : (int8_t)dy;
        Mouse.move(mx, my, 0);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_MOUSE_CLICK: {
      if (length >= 2) {
        uint8_t button = payload[0];
        uint8_t count = payload[1];
        for (uint8_t i = 0; i < count; i++) {
          Mouse.click(button);
          if (i < count - 1 && count > 1) {
            // 더블클릭 간 짧은 딜레이 (millis 기반은 복잡해지므로 예외 허용)
            delay(50);
          }
        }
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_MOUSE_DOWN: {
      if (length >= 1) {
        Mouse.press(payload[0]);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_MOUSE_UP: {
      if (length >= 1) {
        Mouse.release(payload[0]);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_MOUSE_SCROLL: {
      if (length >= 1) {
        int8_t amount = (int8_t)payload[0];
        Mouse.move(0, 0, amount);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_KEY_PRESS: {
      if (length >= 1) {
        Keyboard.press(payload[0]);
        delay(KEY_PRESS_HOLD_MS);
        Keyboard.release(payload[0]);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_KEY_DOWN: {
      if (length >= 1) {
        Keyboard.press(payload[0]);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_KEY_UP: {
      if (length >= 1) {
        Keyboard.release(payload[0]);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    case CMD_KEY_RELEASE: {
      Keyboard.releaseAll();
      sendAck(ACK_OK);
      break;
    }

    case CMD_TYPE_CHAR: {
      if (length >= 1) {
        Keyboard.write(payload[0]);
        sendAck(ACK_OK);
      } else {
        sendAck(ACK_EXEC_FAIL);
      }
      break;
    }

    default:
      sendAck(ACK_UNKNOWN_CMD);
      break;
  }
}

// ═══════════════════════════════════════════════
// ACK 응답
// ═══════════════════════════════════════════════

void sendAck(uint8_t status) {
  uint8_t payload[1] = { status };
  uint8_t cs = CMD_ACK ^ 1 ^ status;

  Serial.write(PACKET_STX);
  Serial.write(CMD_ACK);
  Serial.write((uint8_t)1);  // length
  Serial.write(status);
  Serial.write(cs);
  Serial.write(PACKET_ETX);
}

// ═══════════════════════════════════════════════
// 안전 해제
// ═══════════════════════════════════════════════

void releaseAll(void) {
  Keyboard.releaseAll();
  Mouse.release(MOUSE_LEFT);
  Mouse.release(MOUSE_RIGHT);
  Mouse.release(MOUSE_MIDDLE);
}
