# QUICKSTART (약 15분)

이 문서가 **첫 실행의 단일 진입점**입니다. 런타임은 루트의 `shared/`, `engine/`, `editor/`, `player/` 패키지입니다. 매크로 포맷은 **`version`: `"1.0"`** ([`shared/schema.py`](shared/schema.py)의 `CURRENT_SCHEMA_VERSION`).

## 1. 준비

- Python 3.11 이상
- (선택) Arduino Leonardo — 실제 HID까지 쓸 때만 필요. **`python main.py --dry-run`** 으로 시작하면 Stub(로그만)입니다.

## 2. 설치

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## 3. 첫 실행 — 헤드리스 샘플

```bash
python main.py --run macros/examples/example_click_loop.json
```

콘솔에 실행 로그가 보이면 성공입니다.

## 4. 에디터 GUI

```bash
python main.py
```

- **열기**: `macros/` 아래 JSON (예: `macros/examples/example_click_loop.json`)
- **실행**: Ctrl+F5 (실행 전 요약 대화상자에서 **리허설**로 HID 없이 테스트 가능)
- **도움말**: 메뉴 **도움말 → 사용 가이드**에서 화면별 요약 확인
- **스케줄**: 좌측 **스케줄 관리**로 시각·다른 매크로 경로 등록(현재 JSON 설정에 저장)
- **자주 쓰는 단축키**: Ctrl+F6(일시정지/재개), Ctrl+F7(정지), F8(좌표·색 캡처·히스토리), Ctrl+L(하단 패널 토글)
- **전체 목록**: [`docs/user/shortcut-guide.md`](docs/user/shortcut-guide.md)

## 5. 다음 단계

- 에디터로 첫 매크로: [`docs/onboarding/first-macro.md`](docs/onboarding/first-macro.md)
- 화면별 절차: [`docs/onboarding/editor-walkthrough.md`](docs/onboarding/editor-walkthrough.md)
- 막히면: [`docs/user/troubleshooting.md`](docs/user/troubleshooting.md)

## AI 협업 5줄 체크리스트

- Claude Code는 탐색/수정 명세/검증만 수행하고, Cursor Agent가 코드 수정을 담당한다.
- 기본 검증은 빠른 검증(변경 파일 중심 린트 + 관련 테스트)부터 실행한다.
- 전체 검증([Quality Gates](docs/governance/quality-gates.md) 명령 전부)은 머지 전/릴리즈 전/핵심 로직 변경 시에만 실행한다.
- 성능 검증은 전체 검증 조건일 때만 전/후 3회 평균으로 비교하고, 악화율 1.0% 초과 시 실패 처리한다.
- 실패 시 원인 1줄 요약 → 수정 프롬프트 재생성 → 재수정으로 최대 2회까지 반복한다.

## 완료 기준

- [ ] `pip install` 성공
- [ ] `example_click_loop.json` 헤드리스 실행 성공
- [ ] (선택) GUI에서 샘플 열기·실행
