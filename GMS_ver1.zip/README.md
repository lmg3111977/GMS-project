# GameMacroStudio

Arduino HID 기반 매크로를 **에디터**에서 만들고 **플레이어**로 실행합니다.

## 빠른 시작

1. [`QUICKSTART.md`](QUICKSTART.md)
2. 헌법: [`docs/governance/constitution.md`](docs/governance/constitution.md)
3. AI 협업: [`docs/README.md`](docs/README.md) (ai-collaboration 섹션)

## 실행

```bash
python main.py
python main.py --run macros/examples/example_click_loop.json
python main.py --dry-run
```

## 구조

| 경로 | 내용 |
|------|------|
| `shared/` | 모델, 스키마(`schema.py`), 프로토콜 |
| `engine/` | 러너, 스케줄러, 시리얼, 화면 분석 |
| `editor/` | PyQt6 에디터 UI |
| `player/` | 트레이·경량 실행 UI |
| `macros/` | 사용자·예제 매크로 JSON (`version`: `"1.0"`) |
| `tests/` | pytest |

## 품질 게이트

검증 방법은 [Quality Gates](docs/governance/quality-gates.md) 참조.

Cursor에서 작업할 때는 에이전트가 [`docs/governance/quality-gates.md`](docs/governance/quality-gates.md)에 따라 **터미널에서 검증을 직접** 돌린다. 아래 스크립트는 로컬에서 수동으로 돌릴 때만 쓰면 된다(선택).

```powershell
# 빠른 게이트 (기본)
powershell -ExecutionPolicy Bypass -File scripts/quality-gate.ps1

# 전체 게이트
powershell -ExecutionPolicy Bypass -File scripts/quality-gate.ps1 -Mode full
```

CMD/더블클릭 환경에서는 배치 파일 래퍼를 사용할 수 있습니다.

```bat
scripts\quality-gate.bat
scripts\quality-gate.bat full
```

## AI 협업 운영 요약

- 역할 분리: Claude Code는 탐색/수정 명세/검증, Cursor Agent는 코드 수정 담당
- 검증 순서: 기본은 빠른 검증(변경 파일 중심), 전체 검증은 머지 전/릴리즈 전/핵심 로직 변경 시 실행
- 성능 정책: 전체 검증 조건일 때 전/후 3회 평균으로 회귀 확인, 악화율 1.0% 초과 시 실패 처리
- 자세한 규칙: [`docs/governance/constitution.md`](docs/governance/constitution.md), [`CLAUDE.md`](CLAUDE.md), [`docs/ai-collaboration/ai-workflow.md`](docs/ai-collaboration/ai-workflow.md)

## 문서 트리

분류 기준 인덱스: [`docs/README.md`](docs/README.md)

### 사용자/운영 핵심

| 문서 | 설명 |
|------|------|
| [`docs/governance/constitution.md`](docs/governance/constitution.md) | 최상위 규범 |
| [`docs/onboarding/first-macro.md`](docs/onboarding/first-macro.md) | 첫 매크로 |
| [`docs/onboarding/editor-walkthrough.md`](docs/onboarding/editor-walkthrough.md) | 에디터 절차 |
| [`docs/user/shortcut-guide.md`](docs/user/shortcut-guide.md) | 단축키 전체 |
| [`docs/user/action-reference.md`](docs/user/action-reference.md) | 액션 타입 요약 |
| [`docs/user/troubleshooting.md`](docs/user/troubleshooting.md) | 문제 해결 |
| [`docs/README.md`](docs/README.md) | 전체 분류 트리 |
