/**
 * GAS 로그인 API (아이디·비밀번호)
 * - 시트: licenses
 * - 입력: userId, password
 * - 출력: ok / code / message / expiresAt
 * - 비밀번호: 시트에는 password_hash 권장 (v1$솔트$반복$해시). 레거시 평문(password)은
 *   로그인 성공 시 자동으로 해시로 덮어씀.
 */

const SHEET_NAME = "licenses";
/** PBKDF2 단일 블록 반복 횟수. GAS/네트워크 타임아웃 균형값. */
const PBKDF2_ITERATIONS = 10000;
const HASH_SCHEME = "v1";
const RATE_LIMIT_MAX_ATTEMPTS = 6;
const RATE_LIMIT_WINDOW_SEC = 60;
const RATE_LIMIT_BLOCK_SEC = 120;
const SERVER_TIMEZONE = "Asia/Seoul";
/**
 * 로그인 성공 시 평문→해시 저장 및, 저장된 PBKDF2 반복 횟수가 PBKDF2_ITERATIONS와 다르면 리해시.
 * 평문 없이 해시만으로는 오프라인 리해시 불가 → 로그인 시 마이그레이션이 필요.
 */
const AUTO_MIGRATE_ON_LOGIN = true;

function doPost(e) {
  try {
    logInfo_("doPost: 요청 수신");
    const body = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    const userId = String(body.userId || "").trim();
    const password = String(body.password || "");

    if (!userId || !password) {
      return jsonResponse_(false, "BAD_REQUEST", "아이디와 비밀번호가 필요합니다.", "");
    }

    if (isRateLimited_(userId)) {
      return jsonResponse_(
        false,
        "TOO_MANY_REQUESTS",
        "요청이 너무 많습니다. 잠시 후 다시 시도하세요.",
        ""
      );
    }

    const ctx = loadAuthContext_();
    const row = findUserRow_(ctx, userId);
    if (!row) {
      registerFailedAttempt_(userId);
      return jsonResponse_(
        false,
        "INVALID_CREDENTIALS",
        "아이디 또는 비밀번호가 올바르지 않습니다.",
        ""
      );
    }
    if (row.duplicate) {
      return jsonResponse_(
        false,
        "DUPLICATE_USER",
        "같은 user_id가 여러 행에 존재합니다. 관리자에게 문의하세요.",
        ""
      );
    }

    if (!verifyPassword_(password, row.storedCredential)) {
      registerFailedAttempt_(userId);
      return jsonResponse_(
        false,
        "INVALID_CREDENTIALS",
        "아이디 또는 비밀번호가 올바르지 않습니다.",
        ""
      );
    }

    const statusCell = row.status;
    const status =
      statusCell === undefined ||
      statusCell === null ||
      String(statusCell).trim() === ""
        ? "active"
        : String(statusCell).trim().toLowerCase();
    if (status !== "active") {
      const code =
        status === "suspended"
          ? "ACCOUNT_SUSPENDED"
          : status === "revoked"
            ? "ACCOUNT_REVOKED"
            : "ACCOUNT_DISABLED";
      const msg =
        status === "suspended"
          ? "정지된 계정입니다."
          : status === "revoked"
            ? "폐기된 계정입니다."
            : "비활성 계정입니다.";
      return jsonResponse_(false, code, msg, toKstIsoString_(row.expires_at));
    }

    if (!isNotExpired_(row.expires_at)) {
      return jsonResponse_(false, "ACCOUNT_EXPIRED", "만료된 계정입니다.", toKstIsoString_(row.expires_at));
    }

    clearFailedAttempts_(userId);
    if (AUTO_MIGRATE_ON_LOGIN) {
      let needsMigrate = !isHashedCredential_(row.storedCredential);
      if (!needsMigrate) {
        const parts = String(row.storedCredential).split("$");
        needsMigrate = parts.length === 4 && parseInt(parts[2], 10) !== PBKDF2_ITERATIONS;
      }
      if (needsMigrate) {
        tryMigratePasswordToHash_(ctx, row.rowNumber, password);
      }
    }

    tryUpdateLastSeen_(ctx, row.rowNumber, userId);
    logInfo_("doPost: 로그인 성공 userId=" + userId + ", row=" + row.rowNumber);
    return jsonResponse_(true, "OK", "로그인 성공", toKstIsoString_(row.expires_at));
  } catch (err) {
    logInfo_("doPost failed: " + (err && err.stack ? err.stack : err));
    return jsonResponse_(false, "SERVER_ERROR", "서버 오류", "");
  }
}

function loadAuthContext_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) throw new Error("Missing sheet: " + SHEET_NAME);
  const lastRow = sheet.getLastRow();
  const lastColumn = sheet.getLastColumn();
  if (lastColumn < 1 || lastRow < 1) throw new Error("Missing header row");
  // 헤더+데이터 한 번에 읽기 (getValues 1회)
  const allData = sheet.getRange(1, 1, lastRow, lastColumn).getValues();
  const headerRow = allData[0];
  const headerIndex = buildHeaderIndex_(headerRow);
  const cols = {
    user: columnIndexIgnoreCase_(headerIndex, "user_id"),
    hash: columnIndexIgnoreCase_(headerIndex, "password_hash"),
    pass: columnIndexIgnoreCase_(headerIndex, "password"),
    status: columnIndexIgnoreCase_(headerIndex, "status"),
    exp: columnIndexIgnoreCase_(headerIndex, "expires_at"),
    lastSeen: columnIndexIgnoreCase_(headerIndex, "last_seen_at"),
  };
  if (cols.user === undefined) throw new Error("Missing user_id column");
  return { sheet: sheet, cols: cols, lastColumn: lastColumn, rows: allData };
}

function findUserRow_(ctx, userId) {
  const targetUserId = String(userId || "").trim();
  if (!targetUserId) return null;

  const cols = ctx.cols;
  const rows = ctx.rows;
  if (rows.length < 2) return null;

  // 대소문자 구분 + 셀 값 trim 후 비교(TextFinder와 동일한 의미)
  var matchIndex = -1;
  var duplicate = false;
  for (var i = 1; i < rows.length; i += 1) {
    var cellValue = String(rows[i][cols.user] || "").trim();
    if (cellValue === targetUserId) {
      if (matchIndex !== -1) {
        duplicate = true;
        break;
      }
      matchIndex = i;
    }
  }

  if (matchIndex === -1) return null;
  if (duplicate) return { duplicate: true };

  var rowNumber = matchIndex + 1;
  var row = rows[matchIndex];
  return {
    rowNumber: rowNumber,
    storedCredential: getStoredCredential_(row, cols.hash, cols.pass),
    status: cols.status !== undefined ? row[cols.status] : undefined,
    expires_at: cols.exp !== undefined ? row[cols.exp] : "",
  };
}

function getStoredCredential_(row, idxHash, idxPass) {
  if (idxHash !== undefined) {
    const h = String(row[idxHash] || "").trim();
    if (h) return h;
  }
  if (idxPass === undefined) return "";
  const p = row[idxPass];
  if (p === undefined || p === null) return "";
  return String(p);
}

function isHashedCredential_(stored) {
  const s = String(stored);
  if (s.indexOf(HASH_SCHEME + "$") !== 0) return false;
  return s.split("$").length === 4;
}

function verifyPassword_(plain, stored) {
  const s = String(stored).trim();
  if (!s) return false;
  if (isHashedCredential_(s)) {
    return verifyPasswordHash_(plain, s);
  }
  return legacyPlainEqual_(plain, s);
}

function legacyPlainEqual_(plain, stored) {
  const a = String(plain);
  const b = String(stored);
  if (a.length !== b.length) return false;
  return constantTimeEqualStr_(a, b);
}

function verifyPasswordHash_(plain, stored) {
  const parts = String(stored).split("$");
  if (parts.length !== 4 || parts[0] !== HASH_SCHEME) return false;
  const saltB64 = parts[1];
  const iterations = parseInt(parts[2], 10);
  const wantB64 = parts[3];
  if (!saltB64 || !iterations || iterations < 1 || !wantB64) return false;
  const got = pbkdf2Sha256_(plain, saltB64, iterations);
  if (!got || got.length === 0) return false;
  const gotB64 = Utilities.base64EncodeWebSafe(got);
  return constantTimeEqualStr_(gotB64, wantB64);
}

function hashPassword_(plain) {
  const saltB64 = randomSaltB64_();
  const hashBytes = pbkdf2Sha256_(plain, saltB64, PBKDF2_ITERATIONS);
  const hashB64 = Utilities.base64EncodeWebSafe(hashBytes);
  return HASH_SCHEME + "$" + saltB64 + "$" + PBKDF2_ITERATIONS + "$" + hashB64;
}

function randomSaltB64_() {
  const raw = [];
  for (let i = 0; i < 16; i += 1) raw.push(Math.floor(Math.random() * 256));
  return Utilities.base64EncodeWebSafe(raw);
}

function pbkdf2Sha256_(password, saltB64, iterations) {
  let saltStr;
  try {
    saltStr = bytesToString_(Utilities.base64DecodeWebSafe(saltB64));
  } catch (err) {
    return [];
  }
  const block = "\x00\x00\x00\x01";
  let u = normalizeDigest_(Utilities.computeHmacSha256Signature(saltStr + block, password));
  const t = u.slice();
  for (let j = 1; j < iterations; j += 1) {
    u = normalizeDigest_(
      Utilities.computeHmacSha256Signature(bytesToString_(u), password)
    );
    for (let k = 0; k < t.length; k += 1) t[k] ^= u[k];
  }
  return t;
}

function normalizeDigest_(u) {
  if (!u || u.length === undefined) return [];
  const arr = [];
  for (let i = 0; i < u.length; i += 1) arr.push((u[i] + 256) % 256);
  return arr;
}

function bytesToString_(bytes) {
  if (typeof bytes === "string") return bytes;
  const out = [];
  for (let i = 0; i < bytes.length; i += 1) out.push((bytes[i] + 256) % 256);
  return String.fromCharCode.apply(null, out);
}

function constantTimeEqualStr_(a, b) {
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i += 1) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}

function rateLimitKey_(prefix, userId) {
  return "auth_rl:" + prefix + ":" + encodeURIComponent(String(userId).trim());
}

function isRateLimited_(userId) {
  const cache = CacheService.getScriptCache();
  const blocked = cache.get(rateLimitKey_("block", userId));
  return blocked === "1";
}

function registerFailedAttempt_(userId) {
  const cache = CacheService.getScriptCache();
  const keyFail = rateLimitKey_("fail", userId);
  const raw = cache.get(keyFail);
  const next = (parseInt(raw || "0", 10) || 0) + 1;
  cache.put(keyFail, String(next), RATE_LIMIT_WINDOW_SEC);
  if (next >= RATE_LIMIT_MAX_ATTEMPTS) {
    cache.put(rateLimitKey_("block", userId), "1", RATE_LIMIT_BLOCK_SEC);
    cache.remove(keyFail);
  }
}

function clearFailedAttempts_(userId) {
  const cache = CacheService.getScriptCache();
  cache.remove(rateLimitKey_("fail", userId));
  cache.remove(rateLimitKey_("block", userId));
}

function migratePasswordToHash_(ctx, rowNumber, plain) {
  const sheet = ctx.sheet;
  const colHash = ctx.cols.hash;
  const colPass = ctx.cols.pass;
  const newHash = hashPassword_(plain);
  if (colHash !== undefined) {
    sheet.getRange(rowNumber, colHash + 1).setValue(newHash);
    if (colPass !== undefined) {
      sheet.getRange(rowNumber, colPass + 1).setValue("");
    }
  } else if (colPass !== undefined) {
    sheet.getRange(rowNumber, colPass + 1).setValue(newHash);
  }
}

/**
 * 로그인 성공 경로를 보호하기 위해, 마이그레이션 쓰기 실패는 삼키고 로깅만 한다.
 */
function tryMigratePasswordToHash_(ctx, rowNumber, plain) {
  try {
    migratePasswordToHash_(ctx, rowNumber, plain);
  } catch (err) {
    logInfo_(
      "migratePasswordToHash_ failed (row=" +
        rowNumber +
        "): " +
        (err && err.stack ? err.stack : err)
    );
  }
}

function buildHeaderIndex_(headerRow) {
  const index = {};
  for (let i = 0; i < headerRow.length; i += 1) {
    index[String(headerRow[i]).trim()] = i;
  }
  return index;
}

/** 헤더명 대소문자 무시 (Status / status 동일 처리). */
function columnIndexIgnoreCase_(headerIndex, name) {
  const want = String(name).toLowerCase();
  for (const key in headerIndex) {
    if (String(key).trim().toLowerCase() === want) {
      return headerIndex[key];
    }
  }
  return undefined;
}

function isNotExpired_(expiresAt) {
  const value = String(expiresAt || "").trim();
  if (!value) return true; // 비어 있으면 영구 라이선스
  const expires = new Date(value);
  if (Number.isNaN(expires.getTime())) return true; // 파싱 불가 → 허용
  return expires.getTime() >= Date.now();
}

function updateLastSeen_(ctx, rowNumber) {
  const col = ctx.cols.lastSeen;
  if (col === undefined) return;
  ctx.sheet.getRange(rowNumber, col + 1).setValue(nowKstIsoString_());
}

function normalizeExpiresAt_(ctx, rowNumber, currentValue) {
  const col = ctx.cols.exp;
  if (col === undefined) return;
  const normalized = toKstIsoString_(currentValue);
  if (!normalized) return;
  const current = String(currentValue || "").trim();
  if (current === normalized) return;
  ctx.sheet.getRange(rowNumber, col + 1).setValue(normalized);
}

function nowKstIsoString_() {
  return Utilities.formatDate(new Date(), SERVER_TIMEZONE, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function toKstIsoString_(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  const dt = new Date(raw);
  if (Number.isNaN(dt.getTime())) return raw;
  return Utilities.formatDate(dt, SERVER_TIMEZONE, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

/**
 * 로그인 성공 경로를 보호하기 위해, last_seen 갱신 실패는 삼키고 로깅만 한다.
 * CacheService로 동일 userId는 5분에 한 번만 시트 쓰기.
 */
function tryUpdateLastSeen_(ctx, rowNumber, userId) {
  try {
    const cache = CacheService.getScriptCache();
    const key = "last_seen:" + encodeURIComponent(String(userId).toLowerCase());
    if (cache.get(key)) return;
    updateLastSeen_(ctx, rowNumber);
    cache.put(key, "1", 300);
  } catch (err) {
    logInfo_("updateLastSeen_ failed: " + err);
  }
}

function tryNormalizeExpiresAt_(ctx, rowNumber, currentValue) {
  try {
    normalizeExpiresAt_(ctx, rowNumber, currentValue);
  } catch (err) {
    logInfo_(
      "normalizeExpiresAt_ failed (row=" +
        rowNumber +
        "): " +
        (err && err.stack ? err.stack : err)
    );
  }
}

function jsonResponse_(ok, code, message, expiresAt) {
  const payload = {
    ok: ok,
    code: code,
    message: message,
    expiresAt: expiresAt || "",
  };
  return ContentService.createTextOutput(JSON.stringify(payload)).setMimeType(
    ContentService.MimeType.JSON
  );
}

function logInfo_(message) {
  const msg = String(message);
  console.log(msg);
  Logger.log(msg);
}

/**
 * licenses 시트의 expires_at / last_seen_at 값을 KST(+09:00) ISO 문자열로 일괄 정규화한다.
 * - 실행 방법: Apps Script 편집기에서 normalizeLicenseTimesToKst_() 수동 실행
 * - 파싱 불가 값은 원문 유지(데이터 손실 방지)
 */
function normalizeLicenseTimesToKst_() {
  const ctx = loadAuthContext_();
  const sheet = ctx.sheet;
  const cols = ctx.cols;
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) {
    logInfo_("normalizeLicenseTimesToKst_: 데이터 행 없음");
    return;
  }

  let normalizedCount = 0;
  if (cols.exp !== undefined) {
    normalizedCount += normalizeColumnToKst_(sheet, cols.exp + 1, lastRow);
  }
  if (cols.lastSeen !== undefined) {
    normalizedCount += normalizeColumnToKst_(sheet, cols.lastSeen + 1, lastRow);
  }
  logInfo_(
    "normalizeLicenseTimesToKst_: 완료 (rows=" +
      (lastRow - 1) +
      ", changed=" +
      normalizedCount +
      ")"
  );
}

function normalizeColumnToKst_(sheet, columnNumber, lastRow) {
  const range = sheet.getRange(2, columnNumber, lastRow - 1, 1);
  const values = range.getValues();
  const out = [];
  let changed = 0;
  for (let i = 0; i < values.length; i += 1) {
    const raw = values[i][0];
    if (raw === undefined || raw === null || String(raw).trim() === "") {
      out.push([""]);
      continue;
    }
    const normalized = toKstIsoString_(raw);
    out.push([normalized]);
    if (String(raw).trim() !== String(normalized).trim()) {
      changed += 1;
    }
  }
  range.setValues(out);
  return changed;
}

/**
 * 평문 비밀번호를 password_hash로 일괄 마이그레이션한다.
 * - 이미 해시가 있는 행은 건너뜀
 * - user_id 또는 password가 비어 있으면 건너뜀
 * - 완료 후 password 컬럼은 빈 문자열로 정리
 */
function migrateAllPlainPasswordsToHash_() {
  const ctx = loadAuthContext_();
  const sheet = ctx.sheet;
  const cols = ctx.cols;
  if (cols.hash === undefined || cols.pass === undefined) {
    throw new Error("password_hash 또는 password 컬럼이 없습니다.");
  }
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) {
    logInfo_("migrateAllPlainPasswordsToHash_: 데이터 행 없음");
    return;
  }

  const range = sheet.getRange(2, 1, lastRow - 1, ctx.lastColumn);
  const values = range.getValues();
  let changed = 0;
  for (let i = 0; i < values.length; i += 1) {
    const row = values[i];
    const uid = String(row[cols.user] || "").trim();
    const hashValue = String(row[cols.hash] || "").trim();
    const passValue = row[cols.pass];
    const plain = passValue === undefined || passValue === null ? "" : String(passValue);
    if (!uid || !plain) continue;
    if (isHashedCredential_(hashValue)) continue;

    row[cols.hash] = hashPassword_(plain);
    row[cols.pass] = "";
    changed += 1;
  }
  if (changed > 0) {
    range.setValues(values);
  }
  logInfo_(
    "migrateAllPlainPasswordsToHash_: 완료 (rows=" +
      (lastRow - 1) +
      ", changed=" +
      changed +
      ")"
  );
}

/**
 * 기존 해시의 반복 횟수를 현재 PBKDF2_ITERATIONS로 갱신하려면:
 * 1) AUTO_MIGRATE_ON_LOGIN = true 로 둔다 (기본값).
 * 2) 사용자가 로그인하면 평문→새 해시로 자동 교체하거나, 저장 반복 횟수가 다르면 리해시한다.
 *
 * 평문 없이는 해시→해시 변환 불가하므로 오프라인 일괄 리해시는 불가, 로그인 시 마이그레이션만 가능.
 */
