@echo off
setlocal

set "MODE=%~1"
if "%MODE%"=="" set "MODE=quick"

if /I not "%MODE%"=="quick" if /I not "%MODE%"=="full" (
  echo Usage: scripts\quality-gate.bat [quick^|full]
  exit /b 2
)

powershell -ExecutionPolicy Bypass -File "%~dp0quality-gate.ps1" -Mode %MODE%
exit /b %ERRORLEVEL%
