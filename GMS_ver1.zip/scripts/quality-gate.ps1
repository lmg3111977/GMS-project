param(
    [ValidateSet("quick", "full")]
    [string]$Mode = "quick"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Invoke-Step {
    param(
        [string]$Name,
        [string]$Command
    )
    Write-Host "==> $Name"
    Invoke-Expression $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE"
    }
}

$targets = "shared engine editor player tests"

if ($Mode -eq "quick") {
    Invoke-Step "ruff (full scope)" "ruff check $targets"
    Invoke-Step "targeted tests" "pytest -q tests/test_action_list_row_priority.py"
    Write-Host "Quick gate passed."
    exit 0
}

Invoke-Step "ruff (full scope)" "ruff check $targets"
Invoke-Step "black --check (full scope)" "black --check $targets"
Invoke-Step "pytest (full suite)" "pytest -q tests"
Write-Host "Full gate passed."
