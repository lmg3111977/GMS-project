"""action_list.structure — 들여쓰기·연결 메타데이터 단위 테스트."""

from __future__ import annotations

from editor.action_list.structure import (
    compute_if_block_metadata,
    compute_indent_levels,
    param_edit_requires_full_list_rebuild,
    struct_if_with_shared_field_copy,
)
from shared.models import (
    DelayAction,
    FunctionCallAction,
    FunctionDefAction,
    FunctionEndAction,
    GotoAction,
    IfPixelAction,
    ImageSearchAction,
    LabelAction,
    LoopEndAction,
    PixelWaitAction,
    ReturnAction,
)


def test_function_indent_def_body_end() -> None:
    actions = [
        FunctionDefAction(name="f"),
        DelayAction(ms=10),
        ReturnAction(expression="1"),
        FunctionEndAction(),
    ]
    levels = compute_indent_levels(actions)
    assert levels == [0, 1, 1, 0]


def test_function_pair_metadata_tag_and_group() -> None:
    actions = [
        FunctionDefAction(name="g"),
        ReturnAction(expression="0"),
        FunctionEndAction(),
    ]
    labels, groups = compute_if_block_metadata(actions)
    assert labels.get(0) == "F01"
    assert labels.get(2) == "F01"
    assert groups[0] == {0, 2}
    assert groups[2] == {0, 2}


def test_nested_functions_separate_tags() -> None:
    actions = [
        FunctionDefAction(name="outer"),
        FunctionDefAction(name="inner"),
        FunctionEndAction(),
        FunctionEndAction(),
    ]
    assert compute_indent_levels(actions) == [0, 1, 1, 0]
    labels, groups = compute_if_block_metadata(actions)
    assert labels.get(1) == "F02"
    assert labels.get(2) == "F02"
    assert labels.get(0) == "F01"
    assert labels.get(3) == "F01"
    assert groups[0] == {0, 3}
    assert groups[1] == {1, 2}


def test_function_call_not_in_function_pair_group() -> None:
    actions = [
        FunctionDefAction(name="x"),
        FunctionEndAction(),
        FunctionCallAction(target="x"),
    ]
    _labels, groups = compute_if_block_metadata(actions)
    assert 2 not in groups


def test_struct_if_shared_fields_ifpixel_to_pixel_wait() -> None:
    src = IfPixelAction(
        x=12,
        y=34,
        color="#aabbcc",
        tolerance=20,
        detect_change=True,
        comment="hdr",
        enabled=False,
    )
    out = struct_if_with_shared_field_copy(src, PixelWaitAction)
    assert isinstance(out, PixelWaitAction)
    assert out.x == 12 and out.y == 34
    assert out.color == "#aabbcc"
    assert out.tolerance == 20
    assert out.detect_change is True
    assert out.comment == "hdr"
    assert out.enabled is False
    assert out.action_id == src.action_id
    assert out.timeout_ms == 5000
    assert out.change_reference == "target"


def test_struct_if_shared_fields_ifpixel_to_image_search_minimal_overlap() -> None:
    src = IfPixelAction(x=99, y=88, color="#112233")
    out = struct_if_with_shared_field_copy(src, ImageSearchAction)
    assert isinstance(out, ImageSearchAction)
    assert out.action_id == src.action_id
    assert out.template_path == ""
    assert out.region_x == 0


def test_param_edit_requires_full_list_rebuild_heuristics() -> None:
    d1 = DelayAction(ms=10)
    d2 = d1.model_copy(update={"ms": 99})
    assert not param_edit_requires_full_list_rebuild(d1, d2)

    g1 = GotoAction(target="a")
    g2 = g1.model_copy(update={"target": "b"})
    assert param_edit_requires_full_list_rebuild(g1, g2)

    l1 = LabelAction(name="x")
    l2 = l1.model_copy(update={"name": "y"})
    assert param_edit_requires_full_list_rebuild(l1, l2)

    assert param_edit_requires_full_list_rebuild(DelayAction(ms=1), LoopEndAction())
