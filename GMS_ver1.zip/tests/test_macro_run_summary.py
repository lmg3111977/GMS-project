"""macro_run_summary 모듈 테스트."""

from shared.macro_run_summary import format_run_summary_text, summarize_macro_run
from shared.models import DelayAction, Macro, MacroSettings, MouseClickAction


def test_summarize_counts_clicks_and_delays() -> None:
    m = Macro(
        name="t",
        version="1.0",
        settings=MacroSettings(),
        actions=[
            MouseClickAction(count=2),
            DelayAction(ms=100),
        ],
    )
    s = summarize_macro_run(m)
    assert s["action_count"] == 2
    assert s["click_actions"] == 2
    assert s["delay_ms_static_sum"] == 100


def test_format_run_summary_text_non_empty() -> None:
    m = Macro(name="t", version="1.0", settings=MacroSettings(), actions=[DelayAction(ms=1)])
    text = format_run_summary_text(m)
    assert "액션 개수" in text
    assert "HID" in text
