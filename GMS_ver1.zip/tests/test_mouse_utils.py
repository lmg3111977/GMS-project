"""shared/mouse_utils.py 단위 테스트."""

from __future__ import annotations

from shared.mouse_utils import (
    calculate_move_duration,
    calculate_relative_move,
    clamp,
    generate_bezier_path,
    generate_linear_path,
    path_to_relative_steps,
    split_mouse_move,
)


class TestClamp:
    """clamp() 테스트."""

    def test_within_range(self) -> None:
        assert clamp(50, 0, 100) == 50

    def test_below_min(self) -> None:
        assert clamp(-10, 0, 100) == 0

    def test_above_max(self) -> None:
        assert clamp(200, 0, 100) == 100

    def test_at_boundary(self) -> None:
        assert clamp(0, 0, 100) == 0
        assert clamp(100, 0, 100) == 100


class TestCalculateRelativeMove:
    """calculate_relative_move() 테스트."""

    def test_positive_move(self) -> None:
        dx, dy = calculate_relative_move(100, 200, 300, 500)
        assert dx == 200
        assert dy == 300

    def test_negative_move(self) -> None:
        dx, dy = calculate_relative_move(500, 500, 100, 200)
        assert dx == -400
        assert dy == -300

    def test_zero_move(self) -> None:
        dx, dy = calculate_relative_move(100, 200, 100, 200)
        assert dx == 0
        assert dy == 0


class TestSplitMouseMove:
    """split_mouse_move() 테스트."""

    def test_small_move_no_split(self) -> None:
        """127 이하 이동은 분할 불필요."""
        steps = split_mouse_move(50, 30)
        assert steps == [(50, 30)]

    def test_exact_boundary(self) -> None:
        """정확히 127은 분할 불필요."""
        steps = split_mouse_move(127, -128)
        assert steps == [(127, -128)]

    def test_large_positive_x(self) -> None:
        """큰 양수 dx 분할."""
        steps = split_mouse_move(300, 0)
        total_dx = sum(s[0] for s in steps)
        assert total_dx == 300
        for step_dx, _ in steps:
            assert -128 <= step_dx <= 127

    def test_large_negative_y(self) -> None:
        """큰 음수 dy 분할."""
        steps = split_mouse_move(0, -300)
        total_dy = sum(s[1] for s in steps)
        assert total_dy == -300
        for _, step_dy in steps:
            assert -128 <= step_dy <= 127

    def test_both_axes_large(self) -> None:
        """양쪽 축 모두 큰 이동."""
        steps = split_mouse_move(500, -400)
        total_dx = sum(s[0] for s in steps)
        total_dy = sum(s[1] for s in steps)
        assert total_dx == 500
        assert total_dy == -400

    def test_zero_move(self) -> None:
        steps = split_mouse_move(0, 0)
        assert steps == [(0, 0)]

    def test_single_pixel(self) -> None:
        steps = split_mouse_move(1, -1)
        assert steps == [(1, -1)]


class TestGenerateLinearPath:
    """generate_linear_path() 테스트."""

    def test_start_and_end_points(self) -> None:
        path = generate_linear_path(0, 0, 100, 100, num_points=5)
        assert path[0] == (0, 0)
        assert path[-1] == (100, 100)

    def test_correct_num_points(self) -> None:
        path = generate_linear_path(0, 0, 100, 100, num_points=10)
        assert len(path) == 10

    def test_minimum_two_points(self) -> None:
        path = generate_linear_path(0, 0, 100, 100, num_points=1)
        assert len(path) == 2  # 최소 2점

    def test_horizontal_line(self) -> None:
        path = generate_linear_path(0, 50, 200, 50, num_points=5)
        for _, y in path:
            assert y == 50


class TestGenerateBezierPath:
    """generate_bezier_path() 테스트."""

    def test_start_and_end_points(self) -> None:
        path = generate_bezier_path(0, 0, 500, 300, num_points=20)
        assert path[0] == (0, 0)
        assert path[-1] == (500, 300)

    def test_correct_num_points(self) -> None:
        path = generate_bezier_path(0, 0, 500, 300, num_points=15)
        assert len(path) == 15

    def test_auto_num_points(self) -> None:
        """num_points=None이면 거리에 비례하여 자동 결정."""
        path = generate_bezier_path(0, 0, 500, 0)
        assert len(path) >= 5  # 500/5 = 100

    def test_short_distance(self) -> None:
        """짧은 거리에서도 최소 점 수."""
        path = generate_bezier_path(0, 0, 5, 5)
        assert len(path) >= 2

    def test_all_integer_coordinates(self) -> None:
        """모든 좌표가 정수인지 확인."""
        path = generate_bezier_path(100, 200, 500, 400, num_points=10)
        for x, y in path:
            assert isinstance(x, int)
            assert isinstance(y, int)


class TestPathToRelativeSteps:
    """path_to_relative_steps() 테스트."""

    def test_basic_conversion(self) -> None:
        path = [(0, 0), (10, 5), (30, 15)]
        steps = path_to_relative_steps(path)
        assert steps == [(10, 5), (20, 10)]

    def test_sum_equals_total_move(self) -> None:
        path = generate_linear_path(100, 200, 500, 600, num_points=10)
        steps = path_to_relative_steps(path)
        total_dx = sum(s[0] for s in steps)
        total_dy = sum(s[1] for s in steps)
        assert total_dx == 400
        assert total_dy == 400

    def test_empty_path(self) -> None:
        steps = path_to_relative_steps([])
        assert steps == []

    def test_single_point(self) -> None:
        steps = path_to_relative_steps([(100, 200)])
        assert steps == []


class TestCalculateMoveDuration:
    """calculate_move_duration() 테스트."""

    def test_normal_speed(self) -> None:
        ms = calculate_move_duration(500, "normal")
        assert ms > 0

    def test_slow_longer_than_fast(self) -> None:
        slow = calculate_move_duration(500, "slow")
        fast = calculate_move_duration(500, "fast")
        assert slow > fast

    def test_zero_distance(self) -> None:
        ms = calculate_move_duration(0, "normal")
        assert ms >= 10  # 최소값

    def test_minimum_duration(self) -> None:
        ms = calculate_move_duration(1, "fast")
        assert ms >= 10
