"""editor.variable_suggestions — 매크로에서 변수명 후보 수집."""

from editor.variable_suggestions import collect_suggested_var_names
from shared.models import (
    DelayAction,
    IfVariableAction,
    ImageSearchAction,
    LoopStartAction,
    VariableSetAction,
)


def test_collect_from_variable_set_and_refs() -> None:
    actions = [
        VariableSetAction(var_name="a", value="1"),
        VariableSetAction(var_name="b", expression="{a} + 1"),
        LoopStartAction(count=1, count_expression="{b}"),
    ]
    names = collect_suggested_var_names(actions)
    assert "a" in names
    assert "b" in names


def test_collect_if_variable_name() -> None:
    cond = IfVariableAction(
        var_name="flag",
        operator="==",
        compare_value="1",
    )
    names = collect_suggested_var_names([cond, DelayAction(ms=1)])
    assert "flag" in names


def test_collect_image_search_stores() -> None:
    img = ImageSearchAction(
        store_x_var="sx",
        store_y_var="sy",
        store_found_var="found",
    )
    assert "sx" in collect_suggested_var_names([img])
    assert "found" in collect_suggested_var_names([img])
