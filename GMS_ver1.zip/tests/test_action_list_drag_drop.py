"""action_list 드래그 재배치 순수 로직 테스트."""

from __future__ import annotations

from dataclasses import dataclass

from editor.action_list.drag_drop import _reorder_actions_by_ids


@dataclass
class _DummyAction:
    action_id: str


def _ids(actions: list[_DummyAction]) -> list[str]:
    return [a.action_id for a in actions]


def test_multi_selection_moves_as_group_to_bottom() -> None:
    actions = [_DummyAction("a"), _DummyAction("b"), _DummyAction("c"), _DummyAction("d")]
    moved = _reorder_actions_by_ids(actions, ["b", "c"], drop_row=len(actions))
    assert _ids(moved) == ["a", "d", "b", "c"]


def test_bottom_half_drop_moves_after_target_row() -> None:
    actions = [_DummyAction("a"), _DummyAction("b"), _DummyAction("c"), _DummyAction("d")]
    moved = _reorder_actions_by_ids(actions, ["a"], drop_row=4)
    assert _ids(moved) == ["b", "c", "d", "a"]


def test_collapsed_block_like_range_moves_together() -> None:
    actions = [
        _DummyAction("if"),
        _DummyAction("inner1"),
        _DummyAction("inner2"),
        _DummyAction("else"),
        _DummyAction("endif"),
        _DummyAction("tail"),
    ]
    moved = _reorder_actions_by_ids(
        actions,
        ["if", "inner1", "inner2", "else", "endif"],
        drop_row=len(actions),
    )
    assert _ids(moved) == ["tail", "if", "inner1", "inner2", "else", "endif"]
