"""다중 선택 시 `duplicate_selected`가 각 행을 복제하는지 검증."""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PyQt6")

from PyQt6.QtCore import QItemSelectionModel
from PyQt6.QtWidgets import QApplication

from editor.action_list import ActionListWidget
from shared.models import DelayAction


@pytest.fixture()
def app() -> QApplication:
    qapp = QApplication.instance()
    if qapp is None:
        qapp = QApplication([])
    return qapp


def test_duplicate_selected_copies_each_selected_row(app: QApplication) -> None:
    _ = app
    w = ActionListWidget()
    w.set_actions([DelayAction(ms=1), DelayAction(ms=2), DelayAction(ms=3)])
    sm = w.selectionModel()
    assert sm is not None
    w.clearSelection()
    for row in (0, 2):
        it = w.item(row)
        assert it is not None
        sm.select(w.indexFromItem(it), QItemSelectionModel.SelectionFlag.Select)
    w.duplicate_selected()
    actions = w.get_all_actions()
    assert len(actions) == 5
    assert [a.ms for a in actions] == [1, 1, 2, 3, 3]
