"""액션 리스트 관련 단축키 바인딩/동작 검증 테스트.

문서: `docs/user/shortcut-guide.md` — 편집/실행 항목과 동일한 정책을 코드로 고정한다.
단일 진실 소스: `editor/main_window/hotkeys.py`의 `_setup_shortcuts()` 목록.
"""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PyQt6")

from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget

from editor.main_window.hotkeys import HotkeysMixin
from editor.main_window.undo_redo import UndoRedoMixin


class _DummyActionList(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.breakpoint_toggled = 0
        self.removed = 0
        self.duplicated = 0

    def toggle_breakpoint_current(self) -> None:
        self.breakpoint_toggled += 1

    def remove_selected(self) -> None:
        self.removed += 1

    def duplicate_selected(self) -> None:
        self.duplicated += 1


class _TestWindow(HotkeysMixin, QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self._action_list = _DummyActionList()
        self.setCentralWidget(self._action_list)
        self.undo_called = 0
        self.redo_called = 0
        self.record_called = 0
        self.capture_called = 0
        self.step_called = 0

    def _undo(self) -> None:
        self.undo_called += 1

    def _redo(self) -> None:
        self.redo_called += 1

    def _toggle_recording(self) -> None:
        self.record_called += 1

    def _capture_mouse_clipboard(self) -> None:
        self.capture_called += 1

    def _step_macro(self) -> None:
        self.step_called += 1


class _SimpleList:
    def __init__(self, actions: list[int]) -> None:
        self._actions = list(actions)
        self._row = 0
        self._collapsed_if_action_ids: set[str] = set()
        self._breakpoint_action_ids: set[str] = set()

    def get_all_actions(self) -> list[int]:
        return list(self._actions)

    def set_actions(self, actions: list[int]) -> None:
        self._actions = list(actions)

    def restore_full_state(
        self,
        actions: list[int],
        collapsed: set[str],
        breakpoints: set[str],
    ) -> None:
        self._actions = list(actions)
        self._collapsed_if_action_ids = set(collapsed)
        self._breakpoint_action_ids = set(breakpoints)

    def currentRow(self) -> int:  # noqa: N802
        return self._row

    def setCurrentRow(self, row: int) -> None:  # noqa: N802
        self._row = row


class _SimplePanel:
    def set_action(self, _action: object) -> None:
        return

    def clear_panel(self) -> None:
        return


class _UndoHarness(UndoRedoMixin):
    def __init__(self) -> None:
        self._action_list = _SimpleList([1])
        self._param_panel = _SimplePanel()
        self._undo_stack: list[object] = []
        self._redo_stack: list[object] = []
        self._is_modified = False
        self._param_undo_snapshot_taken = False

    def _update_param_header(self, _action: object, _row: int | None = None) -> None:
        return

    def _update_title(self) -> None:
        return

    def _refresh_variable_suggestions(self) -> None:
        return

    def log_message(self, _level: str, _message: str) -> None:
        return


@pytest.fixture()
def app() -> QApplication:
    qapp = QApplication.instance()
    if qapp is None:
        qapp = QApplication([])
    return qapp


def _trigger(window: _TestWindow, key: str) -> None:
    aliases = {"Delete": "Del"}
    target = aliases.get(key, key)
    for action in window.actions():
        if action.shortcut().toString() == target:
            action.trigger()
            return
    raise AssertionError(f"단축키를 찾지 못했습니다: {key}")


def test_action_list_shortcuts_registered_and_triggered(app: QApplication) -> None:
    _ = app
    window = _TestWindow()
    window._setup_shortcuts()

    expected = {
        "Ctrl+Z",
        "Ctrl+Y",
        "Ctrl+R",
        "F8",
        "F9",
        "F10",
        "Del",
        "Backspace",
        "Ctrl+D",
    }
    actual = {action.shortcut().toString() for action in window.actions()}
    assert expected.issubset(actual)

    # 액션 리스트 포커스 컨텍스트가 아닐 때는 편집 단축키가 무시되어야 한다.
    _trigger(window, "Delete")
    _trigger(window, "Backspace")
    _trigger(window, "Ctrl+D")
    _trigger(window, "Ctrl+Z")
    _trigger(window, "Ctrl+Y")
    assert window._action_list.removed == 0
    assert window._action_list.duplicated == 0
    assert window.undo_called == 0
    assert window.redo_called == 0

    # 컨텍스트가 맞으면 편집 단축키가 동작해야 한다.
    original_checker = window._is_action_list_focus_context
    window._is_action_list_focus_context = lambda: True  # type: ignore[method-assign]
    _trigger(window, "Delete")
    _trigger(window, "Backspace")
    _trigger(window, "Ctrl+D")
    _trigger(window, "Ctrl+Z")
    _trigger(window, "Ctrl+Y")
    assert window._action_list.removed == 2
    assert window._action_list.duplicated == 1
    assert window.undo_called == 1
    assert window.redo_called == 1
    window._is_action_list_focus_context = original_checker  # type: ignore[method-assign]

    # 비포커스 조건과 무관한 단축키는 항상 동작한다.
    _trigger(window, "Ctrl+R")
    _trigger(window, "F8")
    _trigger(window, "F9")
    _trigger(window, "F10")
    assert window.record_called == 1
    assert window.capture_called == 1
    assert window._action_list.breakpoint_toggled == 1
    assert window.step_called == 1


def test_undo_works_with_pre_modify_snapshot() -> None:
    harness = _UndoHarness()
    harness._save_undo_state()  # action_list_about_to_modify 시점
    harness._action_list.set_actions([1, 2])  # 실제 변경 반영

    harness._undo()
    assert harness._action_list.get_all_actions() == [1]
