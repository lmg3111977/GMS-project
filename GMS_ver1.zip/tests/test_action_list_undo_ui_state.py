"""접기·브레이크포인트가 Undo 스냅샷에 포함되는지 검증."""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PyQt6")

from PyQt6.QtWidgets import QApplication

from editor.action_list import ActionListWidget
from editor.main_window.undo_redo import UndoRedoMixin
from shared.models import (
    DelayAction,
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
)


class _Panel:
    def set_action(self, _a: object) -> None:
        return

    def clear_panel(self) -> None:
        return


class _Harness(UndoRedoMixin):
    def __init__(self, widget: ActionListWidget) -> None:
        self._action_list = widget
        self._param_panel = _Panel()
        self._undo_stack: list[object] = []
        self._redo_stack: list[object] = []
        self._is_modified = False
        self._param_undo_snapshot_taken = False

    def _update_param_header(self, _a: object, _i: int | None = None) -> None:
        return

    def _update_title(self) -> None:
        return

    def _refresh_variable_suggestions(self) -> None:
        return

    def log_message(self, _l: str, _m: str) -> None:
        return


@pytest.fixture()
def app() -> QApplication:
    qapp = QApplication.instance()
    if qapp is None:
        qapp = QApplication([])
    return qapp


def test_undo_restores_breakpoint_toggle(app: QApplication) -> None:
    _ = app
    w = ActionListWidget()
    w.set_actions([DelayAction(ms=1)])
    w.setCurrentRow(0)
    h = _Harness(w)
    w.action_list_about_to_modify.connect(h._save_undo_state)
    row = w.currentRow()
    assert row == 0
    w.toggle_breakpoint_current()
    assert w.get_breakpoint_indices() == {0}
    h._undo()
    assert w.get_breakpoint_indices() == set()


def test_undo_restores_if_fold_toggle(app: QApplication) -> None:
    _ = app
    w = ActionListWidget()
    w.set_actions(
        [
            IfPixelAction(x=0, y=0, color="#000000", tolerance=0),
            ElseAction(),
            EndIfAction(),
        ]
    )
    w.setCurrentRow(0)
    h = _Harness(w)
    w.action_list_about_to_modify.connect(h._save_undo_state)
    w.toggle_fold_row(0)
    assert w.isRowHidden(1)
    h._undo()
    assert not w.isRowHidden(1)


def test_label_goto_link_color_group_updates_immediately(app: QApplication) -> None:
    _ = app
    w = ActionListWidget()
    w.set_actions(
        [
            LabelAction(name="start"),
            DelayAction(ms=10),
            GotoAction(target="other"),
        ]
    )

    # 초기에는 label/goto 이름이 달라 연결 그룹이 없다.
    assert w.get_linked_if_rows(0) == [0]
    assert w.get_linked_if_rows(2) == [2]

    # Goto 대상을 맞추면 즉시 연결 그룹/태그가 생겨야 한다.
    w.update_action(2, GotoAction(target="start"))
    linked_after_target_update = set(w.get_linked_if_rows(0))
    assert linked_after_target_update == {0, 2}
    assert w._if_block_tag_by_row[0].startswith("J")
    assert w._if_block_tag_by_row[2] == w._if_block_tag_by_row[0]

    # Label 이름을 바꿔 불일치가 되면 연결이 즉시 해제되어야 한다.
    w.update_action(0, LabelAction(name="renamed"))
    assert w.get_linked_if_rows(0) == [0]
    assert w.get_linked_if_rows(2) == [2]


def test_loop_link_color_group_updates_immediately(app: QApplication) -> None:
    _ = app
    w = ActionListWidget()
    w.set_actions(
        [
            LoopStartAction(count=2),
            DelayAction(ms=5),
            LoopEndAction(),
        ]
    )

    linked_initial = set(w.get_linked_if_rows(0))
    assert linked_initial == {0, 2}
    assert w._if_block_tag_by_row[0].startswith("L")
    assert w._if_block_tag_by_row[2] == w._if_block_tag_by_row[0]

    # LoopEnd를 Delay로 바꾸면 즉시 연결이 해제되어야 한다.
    w.update_action(2, DelayAction(ms=7))
    assert w.get_linked_if_rows(0) == [0]
    assert w.get_linked_if_rows(2) == [2]
