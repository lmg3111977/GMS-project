"""CaptureHistory 단위 테스트."""

from editor.capture_history import CaptureHistory
from editor.param_panel.base import get_active_capture_text


def test_push_single() -> None:
    history = CaptureHistory()
    entry = history.push(100, 200, "#FF0000")
    assert history.active is entry
    assert history.active is not None
    assert history.active.x == 100


def test_push_accumulates() -> None:
    history = CaptureHistory()
    history.push(1, 2, "#000000")
    history.push(3, 4, "#FFFFFF")
    assert len(history.entries) == 2
    assert history.active is not None
    assert history.active.x == 3


def test_max_size_respected() -> None:
    history = CaptureHistory(max_size=3)
    for i in range(5):
        history.push(i, i, "#000000")
    assert len(history.entries) == 3
    assert history.entries[0].x == 2


def test_duplicate_skip() -> None:
    history = CaptureHistory()
    entry1 = history.push(10, 20, "#AABBCC")
    entry2 = history.push(10, 20, "#AABBCC")
    assert entry1 is entry2
    assert len(history.entries) == 1


def test_select_changes_active() -> None:
    history = CaptureHistory()
    history.push(1, 1, "#111111")
    history.push(2, 2, "#222222")
    history.select(0)
    assert history.active is not None
    assert history.active.x == 1


def test_select_invalid_index_no_crash() -> None:
    history = CaptureHistory()
    history.push(1, 1, "#111111")
    history.select(99)
    assert history.active is not None
    assert history.active.x == 1


def test_active_none_when_empty() -> None:
    history = CaptureHistory()
    assert history.active is None


def test_clipboard_fallback_via_get_active_capture_text() -> None:
    assert get_active_capture_text(None) is None
    history = CaptureHistory()
    assert get_active_capture_text(history) is None
    history.push(5, 6, "#001122")
    assert get_active_capture_text(history) == "5,6,#001122"
