"""함수 액션(FUNCTION_DEF/CALL/RETURN/END) 테스트."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from engine.scheduler import ActionScheduler, SchedulerError
from engine.variables import VariableStore
from shared.models import (
    ElseAction,
    EndIfAction,
    FunctionCallAction,
    FunctionDefAction,
    FunctionEndAction,
    IfVariableAction,
    LoopEndAction,
    LoopStartAction,
    ReturnAction,
    VariableSetAction,
)
from tests.test_scheduler import make_scheduler


def test_basic_function_call() -> None:
    scheduler = make_scheduler(
        [
            FunctionDefAction(name="hp_check", params=[]),
            ReturnAction(expression="777"),
            FunctionEndAction(),
            FunctionCallAction(target="hp_check", args=[], return_var="hp"),
        ]
    )
    while scheduler.execute_next():
        pass
    assert scheduler.variables.get("hp") == "777"


def test_function_with_args() -> None:
    scheduler = make_scheduler(
        [
            FunctionDefAction(name="plus_one", params=["n"]),
            ReturnAction(expression="{n} + 1"),
            FunctionEndAction(),
            FunctionCallAction(target="plus_one", args=["41"], return_var="ans"),
        ]
    )
    while scheduler.execute_next():
        pass
    assert scheduler.variables.get("ans") == "42"


def test_return_var_with_if_variable() -> None:
    scheduler = make_scheduler(
        [
            FunctionDefAction(name="is_ready", params=[]),
            ReturnAction(expression="1"),
            FunctionEndAction(),
            FunctionCallAction(target="is_ready", args=[], return_var="ready"),
            IfVariableAction(var_name="ready", operator="==", compare_value="1"),
            VariableSetAction(var_name="result", value="ok"),
            ElseAction(),
            VariableSetAction(var_name="result", value="fail"),
            EndIfAction(),
        ]
    )
    while scheduler.execute_next():
        pass
    assert scheduler.variables.get("result") == "ok"


def test_local_scope_isolation() -> None:
    scheduler = make_scheduler(
        [
            FunctionDefAction(name="set_local", params=[]),
            VariableSetAction(var_name="tmp", value="123"),
            ReturnAction(expression="{tmp}"),
            FunctionEndAction(),
            FunctionCallAction(target="set_local", args=[], return_var="out"),
        ]
    )
    while scheduler.execute_next():
        pass
    assert scheduler.variables.get("out") == "123"
    assert scheduler.variables.has("tmp") is False


def test_global_fallback() -> None:
    scheduler = make_scheduler(
        [
            VariableSetAction(var_name="g", value="5"),
            FunctionDefAction(name="read_global", params=[]),
            ReturnAction(expression="{g}"),
            FunctionEndAction(),
            FunctionCallAction(target="read_global", args=[], return_var="out"),
        ]
    )
    while scheduler.execute_next():
        pass
    assert scheduler.variables.get("out") == "5"


def test_implicit_return() -> None:
    scheduler = make_scheduler(
        [
            FunctionDefAction(name="f", params=[]),
            FunctionEndAction(),
            FunctionCallAction(target="f", args=[], return_var="rv"),
        ]
    )
    while scheduler.execute_next():
        pass
    assert scheduler.variables.get("rv") == ""


def test_undefined_function_error() -> None:
    scheduler = make_scheduler([FunctionCallAction(target="missing", args=[], return_var="x")])
    with pytest.raises(SchedulerError, match="찾을 수 없음"):
        scheduler.execute_next()


def test_arg_count_mismatch_error() -> None:
    scheduler = make_scheduler(
        [
            FunctionDefAction(name="f", params=["a", "b"]),
            ReturnAction(expression="{a}"),
            FunctionEndAction(),
            FunctionCallAction(target="f", args=["1"], return_var="x"),
        ]
    )
    with pytest.raises(SchedulerError, match="인자 1개"):
        while scheduler.execute_next():
            pass


def test_return_outside_function_error() -> None:
    scheduler = make_scheduler([ReturnAction(expression="1")])
    with pytest.raises(SchedulerError, match="함수 안에서만"):
        scheduler.execute_next()


def test_recursion_depth_limit() -> None:
    scheduler = make_scheduler(
        [
            FunctionDefAction(name="recur", params=[]),
            FunctionCallAction(target="recur", args=[], return_var=""),
            FunctionEndAction(),
            FunctionCallAction(target="recur", args=[], return_var=""),
        ]
    )
    with pytest.raises(SchedulerError, match="호출 깊이 제한"):
        while scheduler.execute_next():
            pass


def test_duplicate_function_name_error() -> None:
    with pytest.raises(SchedulerError, match="중복 정의"):
        make_scheduler(
            [
                FunctionDefAction(name="dup", params=[]),
                FunctionEndAction(),
                FunctionDefAction(name="dup", params=[]),
                FunctionEndAction(),
            ]
        )


def test_existing_macro_no_regression() -> None:
    serial_mock = MagicMock()
    serial_mock.send_action.return_value = True
    scheduler = ActionScheduler(serial_commander=serial_mock, variable_store=VariableStore())
    scheduler.load_actions(
        [
            VariableSetAction(var_name="n", value="2"),
            LoopStartAction(count=2),
            VariableSetAction(var_name="n", expression="{n} + 1"),
            LoopEndAction(),
        ]
    )
    while scheduler.execute_next():
        pass
    assert scheduler.variables.get("n") == "4"
