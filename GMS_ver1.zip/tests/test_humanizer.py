"""shared/humanizer.py 단위 테스트."""

from __future__ import annotations

import statistics
import time
from unittest.mock import patch

from shared.humanizer import (
    _calc_lognormal_delay,
    _maybe_micro_afk,
    add_coordinate_noise,
    randomize_click_interval,
    randomize_typing_interval,
    sync_human_delay,
    sync_random_delay,
)


class TestAddCoordinateNoise:
    """add_coordinate_noise() 테스트."""

    def test_returns_integers(self) -> None:
        x, y = add_coordinate_noise(100, 200)
        assert isinstance(x, int)
        assert isinstance(y, int)

    def test_non_negative(self) -> None:
        """결과 좌표가 0 이상인지 (음수 좌표 방지)."""
        for _ in range(100):
            x, y = add_coordinate_noise(0, 0, sigma=1.0)
            assert x >= 0
            assert y >= 0

    def test_statistical_distribution(self) -> None:
        """100회 실행 시 평균이 원점 근처인지."""
        xs: list[int] = []
        ys: list[int] = []
        for _ in range(200):
            x, y = add_coordinate_noise(500, 500, sigma=2.0)
            xs.append(x)
            ys.append(y)

        mean_x = statistics.mean(xs)
        mean_y = statistics.mean(ys)
        assert 495 < mean_x < 505  # 평균 ≈ 500
        assert 495 < mean_y < 505

    def test_default_sigma_has_wider_spread_than_sigma_two(self) -> None:
        """기본 sigma(4.0)가 sigma=2.0보다 더 넓게 퍼지는지."""
        default_sigma = [add_coordinate_noise(500, 500)[0] for _ in range(200)]
        sigma_two = [add_coordinate_noise(500, 500, sigma=2.0)[0] for _ in range(200)]

        stdev_default = statistics.stdev(default_sigma)
        stdev_sigma_two = statistics.stdev(sigma_two)
        assert stdev_default > stdev_sigma_two

    def test_sigma_affects_spread(self) -> None:
        """sigma가 클수록 분산이 큰지."""
        small_sigma = [add_coordinate_noise(500, 500, sigma=1.0)[0] for _ in range(200)]
        large_sigma = [add_coordinate_noise(500, 500, sigma=10.0)[0] for _ in range(200)]

        stdev_small = statistics.stdev(small_sigma)
        stdev_large = statistics.stdev(large_sigma)
        assert stdev_large > stdev_small

    def test_zero_sigma(self) -> None:
        """sigma=0이면 노이즈 없음."""
        for _ in range(10):
            x, y = add_coordinate_noise(100, 200, sigma=0.0)
            assert x == 100
            assert y == 200


class TestRandomizeClickInterval:
    """randomize_click_interval() 테스트."""

    def test_within_range(self) -> None:
        """±20% 범위 내인지."""
        base = 500
        for _ in range(100):
            result = randomize_click_interval(base)
            assert 400 <= result <= 600  # 500 ± 20%

    def test_minimum_one(self) -> None:
        """결과가 최소 1ms."""
        result = randomize_click_interval(1)
        assert result >= 1

    def test_zero_base(self) -> None:
        assert randomize_click_interval(0) == 0

    def test_statistical_mean(self) -> None:
        """100회 평균이 base 근처인지."""
        results = [randomize_click_interval(500) for _ in range(200)]
        mean = statistics.mean(results)
        assert 470 < mean < 530


class TestRandomizeTypingInterval:
    """randomize_typing_interval() 테스트."""

    def test_within_range(self) -> None:
        """±30% 범위 내인지."""
        base = 100
        for _ in range(100):
            result = randomize_typing_interval(base)
            assert 70 <= result <= 130  # 100 ± 30%

    def test_wider_than_click(self) -> None:
        """타이핑 변동이 클릭 변동보다 큰지."""
        click_results = [randomize_click_interval(500) for _ in range(200)]
        typing_results = [randomize_typing_interval(500) for _ in range(200)]

        click_stdev = statistics.stdev(click_results)
        typing_stdev = statistics.stdev(typing_results)
        assert typing_stdev > click_stdev * 0.8  # 타이핑이 더 넓은 분포

    def test_zero_base(self) -> None:
        assert randomize_typing_interval(0) == 0


class TestSyncHumanDelay:
    """sync_human_delay() 테스트."""

    def test_actually_delays(self) -> None:
        """실제로 대기하는지 확인."""
        start = time.monotonic()
        sync_human_delay(100, randomize=False)
        elapsed_ms = (time.monotonic() - start) * 1000
        assert elapsed_ms >= 80  # 약간의 오차 허용

    def test_zero_delay(self) -> None:
        """0ms 딜레이는 즉시 반환."""
        start = time.monotonic()
        sync_human_delay(0)
        elapsed_ms = (time.monotonic() - start) * 1000
        assert elapsed_ms < 50

    def test_randomized_varies(self) -> None:
        """randomize=True 시 매번 다른 딜레이."""
        durations: list[float] = []
        for _ in range(5):
            start = time.monotonic()
            sync_human_delay(200, randomize=True)
            durations.append((time.monotonic() - start) * 1000)

        unique_durations = set(round(d) for d in durations)
        assert len(unique_durations) >= 2  # 최소 2가지 다른 값


class TestHumanDelayDistributions:
    """내부 분포 계산 로직 테스트."""

    def test_lognormal_delay_within_clamped_range(self) -> None:
        base = 1000
        for _ in range(500):
            delay = _calc_lognormal_delay(base)
            assert 300 <= delay <= 3000

    def test_lognormal_delay_median_near_base(self) -> None:
        base = 500
        delays = [_calc_lognormal_delay(base) for _ in range(500)]
        median = statistics.median(delays)
        assert 420 <= median <= 580

    def test_micro_afk_returns_zero_when_probability_missed(self) -> None:
        with patch("shared.humanizer.random.random", return_value=0.5):
            assert _maybe_micro_afk(enabled=True) == 0.0

    def test_micro_afk_returns_within_range_when_triggered(self) -> None:
        with (
            patch("shared.humanizer.random.random", return_value=0.0),
            patch("shared.humanizer.random.uniform", return_value=1234.0),
        ):
            assert _maybe_micro_afk(enabled=True) == 1234.0

    def test_micro_afk_returns_zero_when_disabled(self) -> None:
        with patch("shared.humanizer.random.random", return_value=0.0):
            assert _maybe_micro_afk(enabled=False) == 0.0

    def test_micro_afk_uses_custom_chance_and_range(self) -> None:
        with patch("shared.humanizer.random.random", return_value=0.5):
            assert _maybe_micro_afk(enabled=True, chance=0.4) == 0.0
        with (
            patch("shared.humanizer.random.random", return_value=0.0),
            patch("shared.humanizer.random.uniform", return_value=999.0),
        ):
            assert (
                _maybe_micro_afk(
                    enabled=True,
                    chance=1.0,
                    min_ms=900.0,
                    max_ms=1100.0,
                )
                == 999.0
            )


class TestSyncRandomDelay:
    """sync_random_delay() 테스트."""

    def test_within_range(self) -> None:
        start = time.monotonic()
        sync_random_delay(50, 100)
        elapsed_ms = (time.monotonic() - start) * 1000
        assert 30 <= elapsed_ms <= 150  # 오차 허용

    def test_zero_range(self) -> None:
        start = time.monotonic()
        sync_random_delay(0, 0)
        elapsed_ms = (time.monotonic() - start) * 1000
        assert elapsed_ms < 50
