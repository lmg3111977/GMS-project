"""editor/ai_gen_dialog — 프롬프트 로드·JSON 검증."""

from __future__ import annotations

import json
import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PyQt6")

from editor.ai_gen_dialog import (  # noqa: E402
    AIGenDialog,
    _load_system_prompt,
    normalize_pasted_json_text,
    parse_ai_macro_json,
)
from shared.models import DelayAction, KeyPressAction, Macro


class TestLoadSystemPrompt:
    def test_loads_from_skills_file_when_present(self) -> None:
        p = _load_system_prompt()
        assert len(p) > 200
        assert "매크로" in p or "JSON" in p

    def test_skills_prompt_is_actions_only_contract(self) -> None:
        """액션 전용 프롬프트(메타는 에디터)가 로드되는지 확인."""
        p = _load_system_prompt()
        assert "에디터에서 관리하므로 출력하지 마세요" in p
        assert "MOUSE_MOVE: x" in p


class TestParseAiMacroJson:
    def test_empty_returns_error(self) -> None:
        actions, err = parse_ai_macro_json("   ")
        assert actions == []
        assert err == "empty"

    def test_invalid_json(self) -> None:
        actions, err = parse_ai_macro_json("{not json")
        assert actions == []
        assert err is not None
        assert "JSON 파싱 실패" in err

    def test_dict_without_actions(self) -> None:
        actions, err = parse_ai_macro_json('{"name": "x"}')
        assert actions == []
        assert "actions" in err

    def test_full_macro_object(self) -> None:
        raw = {
            "name": "테스트",
            "version": "1.0",
            "actions": [
                {"type": "DELAY", "ms": 100},
                {"type": "KEY_PRESS", "key": "a"},
            ],
        }
        actions, err = parse_ai_macro_json(json.dumps(raw))
        assert err is None
        assert len(actions) == 2
        assert isinstance(actions[0], DelayAction)
        assert isinstance(actions[1], KeyPressAction)

    def test_actions_array_only(self) -> None:
        raw = [{"type": "DELAY", "ms": 50}]
        actions, err = parse_ai_macro_json(json.dumps(raw))
        assert err is None
        assert len(actions) == 1
        m = Macro.model_validate({"name": "AI 생성 매크로", "version": "1.0", "actions": raw})
        assert m.name == "AI 생성 매크로"

    def test_invalid_action_type(self) -> None:
        raw = {"name": "x", "actions": [{"type": "NOT_A_TYPE"}]}
        actions, err = parse_ai_macro_json(json.dumps(raw))
        assert actions == []
        assert err is not None
        assert "검증 실패" in err
        assert "첫 오류" in err

    def test_actions_must_be_list(self) -> None:
        actions, err = parse_ai_macro_json('{"actions": "not_a_list"}')
        assert actions == []
        assert err is not None
        assert "배열" in err

    def test_markdown_fence_stripped(self) -> None:
        inner = [{"type": "DELAY", "ms": 10}]
        wrapped = "```json\n" + json.dumps(inner) + "\n```"
        actions, err = parse_ai_macro_json(wrapped)
        assert err is None
        assert len(actions) == 1

    def test_normalize_pasted_json_text(self) -> None:
        assert normalize_pasted_json_text('  [{"a":1}]  ') == '[{"a":1}]'
        assert normalize_pasted_json_text("```\n{}\n```") == "{}"

    def test_empty_actions_array_validates_but_is_empty_list(self) -> None:
        actions, err = parse_ai_macro_json("[]")
        assert err is None
        assert actions == []


class TestAIGenDialogConstruct:
    def test_get_user_request_text_empty_until_accept(self) -> None:
        from PyQt6.QtWidgets import QApplication

        _app = QApplication.instance() or QApplication([])
        assert _app is not None
        dlg = AIGenDialog()
        assert dlg.get_user_request_text() == ""
        dlg.close()

    def test_dialog_instantiates_offscreen(self) -> None:
        from PyQt6.QtWidgets import QApplication

        _app = QApplication.instance() or QApplication([])
        assert _app is not None
        dlg = AIGenDialog()
        assert dlg.windowTitle() == "AI 매크로 생성 도우미"
        dlg.close()
