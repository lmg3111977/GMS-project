"""QTest로 실제 키 입력·포커스를 통한 액션 리스트 단축키 통합 검증.

`_setup_shortcuts()`에 등록된 동작을 액션 리스트 포커스 유무에 따라 순차 확인한다.
"""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PyQt6")

from PyQt6.QtCore import Qt
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import (
    QApplication,
    QDockWidget,
    QLineEdit,
    QMainWindow,
    QVBoxLayout,
    QWidget,
)

from editor.action_list import ActionListWidget
from editor.main_window.hotkeys import HotkeysMixin
from editor.main_window.undo_redo import UndoRedoMixin
from shared.models import DelayAction


class _StubParamPanel:
    last_action: object | None = None

    def set_action(self, action: object) -> None:
        self.last_action = action

    def clear_panel(self) -> None:
        self.last_action = None


class HotkeysUndoIntegrationWindow(HotkeysMixin, UndoRedoMixin, QMainWindow):
    """에디터의 Hotkeys + Undo와 동일한 연결(액션 리스트 + about_to_modify → undo 스냅샷)."""

    def __init__(self) -> None:
        super().__init__()
        self._undo_stack: list[list[object]] = []
        self._redo_stack: list[list[object]] = []
        self._is_modified = False
        self._log_calls: list[tuple[str, str]] = []
        self._recording_calls = 0
        self._capture_calls = 0
        self._step_calls = 0

        central = QWidget()
        layout = QVBoxLayout(central)
        self._outside_focus = QLineEdit()
        self._outside_focus.setPlaceholderText("non-action-list-focus")
        layout.addWidget(self._outside_focus)

        self._action_list = ActionListWidget()
        self._action_list.action_list_about_to_modify.connect(self._save_undo_state)
        layout.addWidget(self._action_list, stretch=1)
        self.setCentralWidget(central)

        self._param_panel = _StubParamPanel()
        self._setup_shortcuts()

    def log_message(self, level: str, msg: str) -> None:
        self._log_calls.append((level, msg))

    def _update_param_header(self, action: object | None, index: int | None = None) -> None:
        return

    def _update_title(self) -> None:
        return

    def _refresh_variable_suggestions(self) -> None:
        return

    def _toggle_recording(self) -> None:
        self._recording_calls += 1

    def _capture_mouse_clipboard(self) -> None:
        self._capture_calls += 1

    def _step_macro(self) -> None:
        self._step_calls += 1


@pytest.fixture()
def app() -> QApplication:
    qapp = QApplication.instance()
    if qapp is None:
        qapp = QApplication([])
    return qapp


def _process(app: QApplication) -> None:
    app.processEvents()


def _focus_action_list(w: HotkeysUndoIntegrationWindow) -> None:
    w._action_list.setFocus()
    w._action_list.activateWindow()
    w.raise_()


def _focus_outside(w: HotkeysUndoIntegrationWindow) -> None:
    w._outside_focus.setFocus()


def _key_click(
    app: QApplication,
    w: HotkeysUndoIntegrationWindow,
    key: Qt.Key,
    modifiers: Qt.KeyboardModifier = Qt.KeyboardModifier.NoModifier,
) -> None:
    QTest.keyClick(w.focusWidget() or w, key, modifiers)
    _process(app)


def test_qtest_step1_focus_outside_blocks_ctrl_z_when_stack_nonempty(app: QApplication) -> None:
    """리스트 밖 포커스: Ctrl+Z가 undo를 실행하지 않는다(스택은 그대로)."""
    w = HotkeysUndoIntegrationWindow()
    w.show()
    _process(app)
    w._action_list.set_actions([DelayAction(ms=10)])
    w._undo_stack.clear()
    w._undo_stack.append([])  # 수동: '이전 상태가 비어 있음'을 가정한 스택
    _focus_outside(w)
    _process(app)
    assert not w._is_action_list_focus_context()
    _key_click(app, w, Qt.Key.Key_Z, Qt.KeyboardModifier.ControlModifier)
    assert len(w._action_list.get_all_actions()) == 1
    assert not any("실행 취소 완료" in m for _, m in w._log_calls)


def test_qtest_step2_add_then_ctrl_z_restores(app: QApplication) -> None:
    """리스트 포커스: 액션 추가 후 Ctrl+Z로 이전 목록으로 복구."""
    w = HotkeysUndoIntegrationWindow()
    w.show()
    _process(app)
    _focus_action_list(w)
    _process(app)
    assert w._is_action_list_focus_context()
    w._action_list.add_action(DelayAction(ms=5))
    assert len(w._action_list.get_all_actions()) == 1
    _key_click(app, w, Qt.Key.Key_Z, Qt.KeyboardModifier.ControlModifier)
    assert len(w._action_list.get_all_actions()) == 0
    assert any("실행 취소 완료" in m for _, m in w._log_calls)


def test_qtest_step3_undo_then_ctrl_y_redo(app: QApplication) -> None:
    """Ctrl+Z 후 Ctrl+Y로 다시 적용."""
    w = HotkeysUndoIntegrationWindow()
    w.show()
    _process(app)
    _focus_action_list(w)
    _process(app)
    w._action_list.add_action(DelayAction(ms=7))
    assert len(w._action_list.get_all_actions()) == 1
    _key_click(app, w, Qt.Key.Key_Z, Qt.KeyboardModifier.ControlModifier)
    assert len(w._action_list.get_all_actions()) == 0
    _key_click(app, w, Qt.Key.Key_Y, Qt.KeyboardModifier.ControlModifier)
    assert len(w._action_list.get_all_actions()) == 1
    assert any("다시 실행 완료" in m for _, m in w._log_calls)


def test_qtest_step4_delete_and_backspace_require_focus(app: QApplication) -> None:
    """리스트 포커스일 때만 Delete/Backspace로 삭제."""
    w = HotkeysUndoIntegrationWindow()
    w.show()
    _process(app)
    w._action_list.set_actions([DelayAction(ms=1), DelayAction(ms=2)])
    w._action_list.setCurrentRow(0)
    _focus_outside(w)
    _process(app)
    _key_click(app, w, Qt.Key.Key_Delete)
    assert len(w._action_list.get_all_actions()) == 2
    _focus_action_list(w)
    _process(app)
    _key_click(app, w, Qt.Key.Key_Delete)
    assert len(w._action_list.get_all_actions()) == 1
    w._action_list.set_actions([DelayAction(ms=1), DelayAction(ms=2)])
    w._action_list.setCurrentRow(1)
    _key_click(app, w, Qt.Key.Key_Backspace)
    assert len(w._action_list.get_all_actions()) == 1


def test_qtest_step5_ctrl_d_duplicate_requires_focus(app: QApplication) -> None:
    """리스트 포커스일 때만 Ctrl+D 복제."""
    w = HotkeysUndoIntegrationWindow()
    w.show()
    _process(app)
    w._action_list.set_actions([DelayAction(ms=3)])
    w._action_list.setCurrentRow(0)
    _focus_outside(w)
    _process(app)
    _key_click(app, w, Qt.Key.Key_D, Qt.KeyboardModifier.ControlModifier)
    assert len(w._action_list.get_all_actions()) == 1
    _focus_action_list(w)
    _process(app)
    _key_click(app, w, Qt.Key.Key_D, Qt.KeyboardModifier.ControlModifier)
    assert len(w._action_list.get_all_actions()) == 2


def test_qtest_step6_f9_r_f8_f10_without_action_list_focus(app: QApplication) -> None:
    """F9 / Ctrl+R / F8 / F10은 액션 리스트 포커스와 무관하게 동작."""
    w = HotkeysUndoIntegrationWindow()
    w.show()
    _process(app)
    w._action_list.set_actions([DelayAction(ms=1)])
    w._action_list.setCurrentRow(0)
    _focus_outside(w)
    _process(app)
    assert not w._is_action_list_focus_context()
    _key_click(app, w, Qt.Key.Key_F9)
    assert w._action_list.get_breakpoint_indices() == {0}
    _key_click(app, w, Qt.Key.Key_R, Qt.KeyboardModifier.ControlModifier)
    assert w._recording_calls == 1
    _key_click(app, w, Qt.Key.Key_F8)
    assert w._capture_calls == 1
    _key_click(app, w, Qt.Key.Key_F10)
    assert w._step_calls == 1


def test_qtest_step7_log_dock_ctrl_l_toggle_matches_editor_pattern(app: QApplication) -> None:
    """`log_dock.py`와 동일: 독 `toggleViewAction()` + Ctrl+L로 표시/숨김 토글."""
    dock = QDockWidget("실행 로그 · 이미지/픽셀")
    dock.setMinimumSize(120, 80)
    dock.setWidget(QWidget())
    main = QMainWindow()
    main.setCentralWidget(QWidget())
    main.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)
    toggle = dock.toggleViewAction()
    toggle.setShortcut("Ctrl+L")
    main.addAction(toggle)
    main.show()
    _process(app)
    assert dock.isVisible()
    QTest.keyClick(main.focusWidget() or main, Qt.Key.Key_L, Qt.KeyboardModifier.ControlModifier)
    _process(app)
    assert not dock.isVisible()
    QTest.keyClick(main.focusWidget() or main, Qt.Key.Key_L, Qt.KeyboardModifier.ControlModifier)
    _process(app)
    assert dock.isVisible()


def test_editor_file_menu_shortcuts_registered_on_window(app: QApplication) -> None:
    """메뉴/도구에 등록된 QAction 단축키가 문서(`shortcut-guide.md`)와 맞도록 고정한다."""
    from editor.main_window.window import MacroEditorWindow

    w = MacroEditorWindow()
    w.show()
    _process(app)
    collected: dict[str, str] = {}

    def walk(menu: object) -> None:
        for a in menu.actions():  # type: ignore[union-attr]
            if a.menu() is not None:
                walk(a.menu())
                continue
            sc = a.shortcut().toString()
            if sc:
                collected[sc] = a.text()

    for top in w.menuBar().actions():
        m = top.menu()
        if m is not None:
            walk(m)

    expected = {
        "Ctrl+N",
        "Ctrl+O",
        "Ctrl+S",
        "Ctrl+Shift+S",
        "Ctrl+Shift+V",
        "Alt+F4",
        "Ctrl+L",
    }
    assert expected.issubset(set(collected.keys())), collected
    w.close()
