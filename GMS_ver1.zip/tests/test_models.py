"""shared/models.py 단위 테스트."""

from __future__ import annotations

import json
import uuid

import pytest
from pydantic import ValidationError

from shared.models import (
    ActionType,
    CommentAction,
    DelayAction,
    GotoAction,
    IfPixelAction,
    KeyComboAction,
    KeyPressAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    Macro,
    MacroSettings,
    MouseButton,
    MouseClickAction,
    MouseDragAction,
    MouseMoveAction,
    MouseScrollAction,
    PixelWaitAction,
    TypeTextAction,
    VariableSetAction,
)

# ---------------------------------------------------------------------------
# ActionType enum
# ---------------------------------------------------------------------------


class TestActionType:
    """ActionType enum 테스트."""

    def test_has_all_types(self) -> None:
        """ActionType 개수 스냅샷."""
        assert len(ActionType) == 34

    def test_string_values(self) -> None:
        """StrEnum이므로 값이 문자열인지 확인."""
        assert ActionType.MOUSE_MOVE == "MOUSE_MOVE"
        assert ActionType.KEY_PRESS == "KEY_PRESS"
        assert ActionType.DELAY == "DELAY"


# ---------------------------------------------------------------------------
# 개별 Action 기본값 생성
# ---------------------------------------------------------------------------


class TestActionDefaults:
    """모든 Action 모델이 기본값으로 인스턴스화 가능한지 테스트."""

    def test_mouse_move_defaults(self) -> None:
        action = MouseMoveAction()
        assert action.type == ActionType.MOUSE_MOVE
        assert action.x == 0
        assert action.y == 0
        assert action.is_relative is False
        assert action.duration_ms == 0
        assert action.enabled is True
        assert action.comment == ""
        assert action.action_id  # UUID가 생성됨

    def test_mouse_click_defaults(self) -> None:
        action = MouseClickAction()
        assert action.button == MouseButton.LEFT
        assert action.count == 1

    def test_mouse_drag_defaults(self) -> None:
        action = MouseDragAction()
        assert action.start_x == 0
        assert action.duration_ms == 200

    def test_mouse_scroll_defaults(self) -> None:
        action = MouseScrollAction()
        assert action.amount == 3
        assert action.direction == "down"

    def test_key_press_defaults(self) -> None:
        action = KeyPressAction()
        assert action.key == ""
        assert action.count == 1

    def test_key_combo_defaults(self) -> None:
        action = KeyComboAction()
        assert action.modifiers == []
        assert action.key == ""

    def test_type_text_defaults(self) -> None:
        action = TypeTextAction()
        assert action.text == ""
        assert action.interval_ms == 50
        assert action.count == 1

    def test_delay_defaults(self) -> None:
        action = DelayAction()
        assert action.ms == 1000
        assert action.random_min is None
        assert action.random_max is None

    def test_comment_defaults(self) -> None:
        action = CommentAction()
        assert action.type == ActionType.COMMENT
        assert action.comment == ""

    def test_loop_start_defaults(self) -> None:
        action = LoopStartAction()
        assert action.count == -1  # 무한

    def test_loop_end_defaults(self) -> None:
        action = LoopEndAction()
        assert action.type == ActionType.LOOP_END

    def test_label_defaults(self) -> None:
        action = LabelAction()
        assert action.name == ""

    def test_goto_defaults(self) -> None:
        action = GotoAction()
        assert action.target == ""

    def test_if_pixel_defaults(self) -> None:
        action = IfPixelAction()
        assert action.color == "#000000"
        assert action.tolerance == 10
        assert action.detect_change is False

    def test_pixel_wait_defaults(self) -> None:
        action = PixelWaitAction()
        assert action.timeout_ms == 5000
        assert action.detect_change is False
        assert action.change_reference == "target"

    def test_variable_set_defaults(self) -> None:
        action = VariableSetAction()
        assert action.var_name == ""
        assert action.expression is None


# ---------------------------------------------------------------------------
# 커스텀 값 생성
# ---------------------------------------------------------------------------


class TestActionCustomValues:
    """커스텀 값으로 Action 생성 테스트."""

    def test_mouse_move_custom(self) -> None:
        action = MouseMoveAction(x=960, y=540, duration_ms=200, comment="중앙으로")
        assert action.x == 960
        assert action.y == 540
        assert action.duration_ms == 200
        assert action.comment == "중앙으로"

    def test_key_combo_with_modifiers(self) -> None:
        action = KeyComboAction(modifiers=["Ctrl", "Shift"], key="c")
        assert action.modifiers == ["Ctrl", "Shift"]
        assert action.key == "c"

    def test_delay_with_random_range(self) -> None:
        action = DelayAction(ms=500, random_min=400, random_max=600)
        assert action.random_min == 400
        assert action.random_max == 600

    def test_if_pixel_custom(self) -> None:
        action = IfPixelAction(
            x=100,
            y=200,
            color="#FF0000",
            tolerance=15,
            detect_change=True,
        )
        assert action.tolerance == 15
        assert action.detect_change is True

    def test_loop_start_finite(self) -> None:
        action = LoopStartAction(label="main_loop", count=10)
        assert action.count == 10

    def test_disabled_action(self) -> None:
        action = KeyPressAction(key="a", enabled=False)
        assert action.enabled is False


# ---------------------------------------------------------------------------
# pydantic 검증
# ---------------------------------------------------------------------------


class TestActionValidation:
    """pydantic 검증 규칙 테스트."""

    def test_mouse_move_x_large_relative_allowed(self) -> None:
        action = MouseMoveAction(x=99999, is_relative=True)
        assert action.x == 99999

    def test_mouse_click_count_zero(self) -> None:
        with pytest.raises(ValidationError):
            MouseClickAction(count=0)

    def test_mouse_click_count_too_large(self) -> None:
        with pytest.raises(ValidationError):
            MouseClickAction(count=10)

    def test_key_press_count_zero(self) -> None:
        with pytest.raises(ValidationError):
            KeyPressAction(count=0)

    def test_type_text_count_zero(self) -> None:
        with pytest.raises(ValidationError):
            TypeTextAction(count=0)

    def test_delay_ms_negative(self) -> None:
        with pytest.raises(ValidationError):
            DelayAction(ms=-1)

    def test_delay_ms_too_large(self) -> None:
        with pytest.raises(ValidationError):
            DelayAction(ms=4_000_000)

    def test_label_name_invalid_chars(self) -> None:
        with pytest.raises(ValidationError):
            LabelAction(name="hello world!")  # 공백+특수문자

    def test_label_name_too_long(self) -> None:
        with pytest.raises(ValidationError):
            LabelAction(name="a" * 51)

    def test_if_pixel_invalid_color(self) -> None:
        with pytest.raises(ValidationError):
            IfPixelAction(color="red")  # #RRGGBB 형식 아님

    def test_if_pixel_valid_color(self) -> None:
        action = IfPixelAction(color="#AbCdEf")
        assert action.color == "#AbCdEf"

    def test_variable_name_invalid(self) -> None:
        with pytest.raises(ValidationError):
            VariableSetAction(var_name="has space")


# ---------------------------------------------------------------------------
# action_id 고유성
# ---------------------------------------------------------------------------


class TestActionId:
    """action_id UUID 자동 생성 테스트."""

    def test_auto_generated_uuid(self) -> None:
        action = MouseMoveAction()
        uuid.UUID(action.action_id)  # 유효한 UUID인지 확인

    def test_two_actions_have_different_ids(self) -> None:
        a1 = MouseMoveAction()
        a2 = MouseMoveAction()
        assert a1.action_id != a2.action_id

    def test_custom_id_preserved(self) -> None:
        custom_id = "custom-id-123"
        action = MouseMoveAction(action_id=custom_id)
        assert action.action_id == custom_id


# ---------------------------------------------------------------------------
# Discriminated Union + JSON 라운드트립
# ---------------------------------------------------------------------------


class TestDiscriminatedUnion:
    """Action Union과 JSON 직렬화/역직렬화 테스트."""

    def test_macro_with_mixed_actions(self) -> None:
        macro = Macro(
            name="테스트 매크로",
            actions=[
                MouseMoveAction(x=100, y=200),
                DelayAction(ms=500),
                KeyPressAction(key="a"),
                MouseClickAction(button=MouseButton.RIGHT, count=2),
                LabelAction(name="start"),
                GotoAction(target="start"),
                LoopStartAction(count=5),
                LoopEndAction(),
            ],
        )
        assert len(macro.actions) == 8

    def test_macro_json_roundtrip(self) -> None:
        """Macro를 JSON으로 직렬화 후 역직렬화하면 내용이 동일한지 확인."""
        original = Macro(
            name="라운드트립 테스트",
            hotkey="F8",
            settings=MacroSettings(humanize=False, base_delay_ms=100),
            actions=[
                MouseMoveAction(x=960, y=540, duration_ms=200, comment="중앙"),
                DelayAction(ms=500, random_min=400, random_max=600),
                KeyComboAction(modifiers=["Ctrl"], key="c"),
                IfPixelAction(
                    x=100,
                    y=200,
                    color="#FF0000",
                ),
                LabelAction(name="a"),
                LabelAction(name="b"),
            ],
        )

        json_str = original.model_dump_json()
        restored = Macro.model_validate_json(json_str)

        assert restored.name == original.name
        assert restored.hotkey == original.hotkey
        assert restored.settings.humanize is False
        assert len(restored.actions) == len(original.actions)

        assert isinstance(restored.actions[0], MouseMoveAction)
        assert restored.actions[0].x == 960

        assert isinstance(restored.actions[2], KeyComboAction)
        assert restored.actions[2].modifiers == ["Ctrl"]

        assert isinstance(restored.actions[3], IfPixelAction)
        assert restored.actions[3].color == "#FF0000"

    def test_discriminated_union_resolves_type(self) -> None:
        """JSON에서 type 필드로 올바른 모델이 선택되는지 확인."""
        raw = {
            "name": "test",
            "version": "1.0",
            "hotkey": "F6",
            "settings": {"humanize": True, "base_delay_ms": 50},
            "actions": [
                {"type": "MOUSE_MOVE", "x": 100, "y": 200},
                {"type": "KEY_PRESS", "key": "a"},
                {"type": "DELAY", "ms": 500},
            ],
        }
        macro = Macro.model_validate(raw)
        assert isinstance(macro.actions[0], MouseMoveAction)
        assert isinstance(macro.actions[1], KeyPressAction)
        assert isinstance(macro.actions[2], DelayAction)

    def test_invalid_action_type_raises(self) -> None:
        """존재하지 않는 type 값이면 ValidationError."""
        raw = {
            "name": "test",
            "version": "1.0",
            "hotkey": "F6",
            "settings": {"humanize": True, "base_delay_ms": 50},
            "actions": [{"type": "NONEXISTENT", "x": 0}],
        }
        with pytest.raises(ValidationError):
            Macro.model_validate(raw)


# ---------------------------------------------------------------------------
# MacroSettings / Macro
# ---------------------------------------------------------------------------


class TestMacroModel:
    """Macro 최상위 모델 테스트."""

    def test_default_macro(self) -> None:
        macro = Macro()
        assert macro.name == "새 매크로"
        assert macro.version == "1.0"
        assert macro.hotkey == "F6"
        assert macro.settings.humanize is True
        assert macro.actions == []

    def test_settings_custom(self) -> None:
        settings = MacroSettings(
            humanize=False,
            base_delay_ms=100,
            micro_afk_enabled=True,
            micro_afk_chance_percent=5,
            micro_afk_min_ms=300,
            micro_afk_max_ms=900,
        )
        assert settings.base_delay_ms == 100
        assert settings.micro_afk_enabled is True
        assert settings.micro_afk_chance_percent == 5
        assert settings.micro_afk_min_ms == 300
        assert settings.micro_afk_max_ms == 900

    def test_empty_macro_json(self) -> None:
        macro = Macro()
        data = json.loads(macro.model_dump_json())
        assert data["name"] == "새 매크로"
        assert data["actions"] == []
