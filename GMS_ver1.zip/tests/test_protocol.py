"""shared/protocol.py 단위 테스트."""

from __future__ import annotations

import struct

import pytest

from shared.models import (
    KeyComboAction,
    KeyPressAction,
    MouseClickAction,
    MouseMoveAction,
    MouseScrollAction,
    TypeTextAction,
)
from shared.protocol import (
    PACKET_ETX,
    PACKET_STX,
    InvalidPacketError,
    SerialCommand,
    action_to_commands,
    build_emergency_stop,
    build_handshake,
    decode_packet,
    encode_command,
    encode_key_press,
    encode_mouse_click,
    encode_mouse_move,
    encode_mouse_scroll,
    encode_type_char,
)

# ---------------------------------------------------------------------------
# 패킷 인코딩 / 디코딩
# ---------------------------------------------------------------------------


class TestEncodeCommand:
    """encode_command() 테스트."""

    def test_empty_payload(self) -> None:
        packet = encode_command(SerialCommand.KEY_RELEASE_ALL)
        assert packet[0] == PACKET_STX
        assert packet[1] == SerialCommand.KEY_RELEASE_ALL
        assert packet[2] == 0  # length
        assert packet[-1] == PACKET_ETX
        assert len(packet) == 5

    def test_with_payload(self) -> None:
        payload = b"\x0a\x14"
        packet = encode_command(SerialCommand.MOUSE_CLICK, payload)
        assert packet[0] == PACKET_STX
        assert packet[1] == SerialCommand.MOUSE_CLICK
        assert packet[2] == 2  # length
        assert packet[3:5] == payload
        assert packet[-1] == PACKET_ETX

    def test_payload_too_large(self) -> None:
        with pytest.raises(ValueError, match="페이로드 크기 초과"):
            encode_command(SerialCommand.KEY_PRESS, b"\x00" * 61)

    def test_checksum_calculation(self) -> None:
        cmd = SerialCommand.KEY_PRESS
        payload = b"\x61"
        packet = encode_command(cmd, payload)
        expected_checksum = cmd ^ len(payload) ^ 0x61
        assert packet[-2] == expected_checksum


class TestDecodePacket:
    """decode_packet() 테스트."""

    def test_roundtrip_all_commands(self) -> None:
        """모든 CMD에 대해 encode→decode 라운드트립."""
        test_cases = [
            (SerialCommand.MOUSE_MOVE_REL, struct.pack("<hh", 50, -30)),
            (SerialCommand.MOUSE_CLICK, struct.pack("BB", 1, 2)),
            (SerialCommand.MOUSE_DOWN, struct.pack("B", 1)),
            (SerialCommand.MOUSE_UP, struct.pack("B", 2)),
            (SerialCommand.MOUSE_SCROLL, struct.pack("b", -3)),
            (SerialCommand.KEY_PRESS, struct.pack("B", 0x61)),
            (SerialCommand.KEY_DOWN, struct.pack("B", 0x80)),
            (SerialCommand.KEY_UP, struct.pack("B", 0x80)),
            (SerialCommand.KEY_RELEASE_ALL, b""),
            (SerialCommand.TYPE_CHAR, struct.pack("B", 0x41)),
            (SerialCommand.HANDSHAKE, struct.pack("B", 1)),
            (SerialCommand.ACK, struct.pack("B", 0)),
            (SerialCommand.EMERGENCY_STOP, b""),
        ]
        for cmd, payload in test_cases:
            packet = encode_command(cmd, payload)
            decoded_cmd, decoded_payload = decode_packet(packet)
            assert decoded_cmd == cmd, f"CMD 불일치: {cmd}"
            assert decoded_payload == payload, f"Payload 불일치: {cmd}"

    def test_invalid_stx(self) -> None:
        packet = bytes([0x00, 0x10, 0x01, 0x61, 0x00, PACKET_ETX])
        with pytest.raises(InvalidPacketError, match="잘못된 STX"):
            decode_packet(packet)

    def test_invalid_etx(self) -> None:
        packet = encode_command(SerialCommand.KEY_PRESS, b"\x61")
        corrupted = packet[:-1] + bytes([0x00])
        with pytest.raises(InvalidPacketError, match="잘못된 ETX"):
            decode_packet(corrupted)

    def test_checksum_mismatch(self) -> None:
        packet = bytearray(encode_command(SerialCommand.KEY_PRESS, b"\x61"))
        packet[-2] ^= 0xFF  # 체크섬 변조
        with pytest.raises(InvalidPacketError, match="체크섬 불일치"):
            decode_packet(bytes(packet))

    def test_packet_too_short(self) -> None:
        with pytest.raises(InvalidPacketError, match="패킷 너무 짧음"):
            decode_packet(b"\x02\x10")

    def test_length_mismatch(self) -> None:
        packet = bytearray(encode_command(SerialCommand.KEY_PRESS, b"\x61"))
        packet[2] = 5  # length를 5로 변조 (실제 payload는 1바이트)
        with pytest.raises(InvalidPacketError, match="패킷 길이 불일치"):
            decode_packet(bytes(packet))


# ---------------------------------------------------------------------------
# 개별 인코더
# ---------------------------------------------------------------------------


class TestIndividualEncoders:
    """개별 명령 인코더 테스트."""

    def test_encode_mouse_move(self) -> None:
        packet = encode_mouse_move(100, -50)
        cmd, payload = decode_packet(packet)
        assert cmd == SerialCommand.MOUSE_MOVE_REL
        dx, dy = struct.unpack("<hh", payload)
        assert dx == 100
        assert dy == -50

    def test_encode_mouse_move_clamp(self) -> None:
        """int16 범위 초과 시 클램핑."""
        packet = encode_mouse_move(40000, -40000)
        cmd, payload = decode_packet(packet)
        dx, dy = struct.unpack("<hh", payload)
        assert dx == 32767
        assert dy == -32768

    def test_encode_mouse_click(self) -> None:
        packet = encode_mouse_click(1, 2)
        cmd, payload = decode_packet(packet)
        assert cmd == SerialCommand.MOUSE_CLICK
        assert payload == bytes([1, 2])

    def test_encode_mouse_scroll_positive(self) -> None:
        packet = encode_mouse_scroll(3)
        cmd, payload = decode_packet(packet)
        amount = struct.unpack("b", payload)[0]
        assert amount == 3

    def test_encode_mouse_scroll_negative(self) -> None:
        packet = encode_mouse_scroll(-5)
        cmd, payload = decode_packet(packet)
        amount = struct.unpack("b", payload)[0]
        assert amount == -5

    def test_encode_key_press(self) -> None:
        packet = encode_key_press(0x61)
        cmd, payload = decode_packet(packet)
        assert cmd == SerialCommand.KEY_PRESS
        assert payload[0] == 0x61

    def test_encode_type_char(self) -> None:
        packet = encode_type_char("A")
        cmd, payload = decode_packet(packet)
        assert cmd == SerialCommand.TYPE_CHAR
        assert payload[0] == ord("A")


# ---------------------------------------------------------------------------
# 핸드셰이크 / 비상정지
# ---------------------------------------------------------------------------


class TestSpecialPackets:
    """핸드셰이크, 비상정지 패킷 테스트."""

    def test_handshake(self) -> None:
        packet = build_handshake(version=1)
        cmd, payload = decode_packet(packet)
        assert cmd == SerialCommand.HANDSHAKE
        assert payload[0] == 1

    def test_emergency_stop(self) -> None:
        packet = build_emergency_stop()
        cmd, payload = decode_packet(packet)
        assert cmd == SerialCommand.EMERGENCY_STOP
        assert payload == b""


# ---------------------------------------------------------------------------
# action_to_commands
# ---------------------------------------------------------------------------


class TestActionToCommands:
    """action_to_commands() 변환 테스트."""

    def test_mouse_move_absolute_splits(self) -> None:
        """절대 좌표 MouseMove는 여러 패킷으로 분할."""
        action = MouseMoveAction(x=960, y=540)
        packets = action_to_commands(action, current_mouse_pos=(0, 0))
        assert len(packets) >= 4  # 960/127 ≈ 8 스텝

        total_dx = 0
        total_dy = 0
        for pkt in packets:
            cmd, payload = decode_packet(pkt)
            assert cmd == SerialCommand.MOUSE_MOVE_REL
            dx, dy = struct.unpack("<hh", payload)
            assert -128 <= dx <= 127
            assert -128 <= dy <= 127
            total_dx += dx
            total_dy += dy

        assert total_dx == 960
        assert total_dy == 540

    def test_mouse_move_small_no_split(self) -> None:
        """작은 이동은 분할 없이 1개 패킷."""
        action = MouseMoveAction(x=50, y=30, is_relative=True)
        packets = action_to_commands(action, (0, 0))
        assert len(packets) == 1

    def test_mouse_click_single_packet(self) -> None:
        action = MouseClickAction(button="LEFT", count=1)
        packets = action_to_commands(action, (0, 0))
        assert len(packets) == 1
        cmd, _ = decode_packet(packets[0])
        assert cmd == SerialCommand.MOUSE_CLICK

    def test_key_press_single_packet(self) -> None:
        action = KeyPressAction(key="a")
        packets = action_to_commands(action, (0, 0))
        assert len(packets) == 1
        cmd, _ = decode_packet(packets[0])
        assert cmd == SerialCommand.KEY_PRESS

    def test_key_press_repeat_packets(self) -> None:
        action = KeyPressAction(key="a", count=3)
        packets = action_to_commands(action, (0, 0))
        assert len(packets) == 3
        for pkt in packets:
            cmd, _ = decode_packet(pkt)
            assert cmd == SerialCommand.KEY_PRESS

    def test_key_combo_sequence(self) -> None:
        """KeyCombo는 modifier down → key press → modifier up 순서."""
        action = KeyComboAction(modifiers=["Ctrl", "Shift"], key="c")
        packets = action_to_commands(action, (0, 0))

        assert len(packets) == 5  # Ctrl down, Shift down, c press, Shift up, Ctrl up

        cmds = [decode_packet(p)[0] for p in packets]
        assert cmds[0] == SerialCommand.KEY_DOWN  # Ctrl down
        assert cmds[1] == SerialCommand.KEY_DOWN  # Shift down
        assert cmds[2] == SerialCommand.KEY_PRESS  # c press
        assert cmds[3] == SerialCommand.KEY_UP  # Shift up (역순)
        assert cmds[4] == SerialCommand.KEY_UP  # Ctrl up (역순)

    def test_type_text_multi_char(self) -> None:
        """TypeText는 각 글자마다 패킷 생성."""
        action = TypeTextAction(text="abc")
        packets = action_to_commands(action, (0, 0))
        assert len(packets) == 3
        for pkt in packets:
            cmd, _ = decode_packet(pkt)
            assert cmd == SerialCommand.TYPE_CHAR

    def test_type_text_repeat_packets(self) -> None:
        action = TypeTextAction(text="ab", count=3)
        packets = action_to_commands(action, (0, 0))
        assert len(packets) == 6
        for pkt in packets:
            cmd, _ = decode_packet(pkt)
            assert cmd == SerialCommand.TYPE_CHAR

    def test_scroll_direction(self) -> None:
        action_down = MouseScrollAction(amount=3, direction="down")
        packets = action_to_commands(action_down, (0, 0))
        cmd, payload = decode_packet(packets[0])
        assert struct.unpack("b", payload)[0] == -3

        action_up = MouseScrollAction(amount=3, direction="up")
        packets = action_to_commands(action_up, (0, 0))
        cmd, payload = decode_packet(packets[0])
        assert struct.unpack("b", payload)[0] == 3

    def test_non_io_action_returns_empty(self) -> None:
        """흐름 제어 액션은 빈 리스트 반환."""
        from shared.models import DelayAction, GotoAction, LabelAction

        for action in [DelayAction(), LabelAction(name="x"), GotoAction(target="x")]:
            packets = action_to_commands(action, (0, 0))
            assert packets == []
