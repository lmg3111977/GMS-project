"""VarSet·IfVar가 전용 헤더 없이 패널 상단 설명(ACTION_DESCRIPTIONS)을 쓰는지 검증."""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PyQt6")

from PyQt6.QtWidgets import QApplication, QLabel

from editor.param_panel import ParamPanel
from shared.models import ActionType

# base.ACTION_DESCRIPTIONS 고유 머리글 — 좌측/우측 별도 가이드 제거 후에도 패널에 남아 있어야 함
_EXPECTED_SNIPPETS: dict[ActionType, str] = {
    ActionType.VARIABLE_SET: "【VarSet / 변수 설정】",
    ActionType.IF_VARIABLE: "【IfVar / 변수 조건】",
}


@pytest.fixture()
def app() -> QApplication:
    qapp = QApplication.instance()
    if qapp is None:
        qapp = QApplication([])
    return qapp


def test_variable_actions_use_same_top_description_pattern_as_other_actions(app: QApplication) -> None:
    _ = app
    panel = ParamPanel()
    containers = panel._containers  # noqa: SLF001 — 스택 페이지별 컨테이너 규약
    for at, snippet in _EXPECTED_SNIPPETS.items():
        container = containers[at]
        texts = [lb.text() for lb in container.findChildren(QLabel)]
        assert any(snippet in t for t in texts), f"상단 설명 라벨 없음: {at}"
