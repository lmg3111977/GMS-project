"""action_flatten 기본 동작 테스트."""

from shared.action_flatten import flatten_actions_for_execution
from shared.models import (
    DelayAction,
    IfPixelAction,
    Macro,
)


def test_flatten_keeps_actions_order() -> None:
    src = IfPixelAction(
        x=1,
        y=2,
        color="#112233",
        tolerance=5,
    )
    flat = flatten_actions_for_execution([src, DelayAction(ms=10)])
    assert len(flat) == 2
    assert isinstance(flat[0], IfPixelAction)
    assert isinstance(flat[1], DelayAction)


def test_macro_roundtrip_without_block() -> None:
    m = Macro(
        name="t",
        actions=[
            DelayAction(ms=1),
        ],
    )
    data = m.model_dump(mode="json")
    m2 = Macro.model_validate(data)
    assert len(m2.actions) == 1
    assert m2.actions[0].type == m.actions[0].type
    flat = flatten_actions_for_execution(list(m2.actions))
    assert len(flat) == 1
