"""engine/serial_cmd.py 단위 테스트 (mock serial)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from engine.serial_cmd import (
    SerialCommander,
    SerialConnectionError,
    detect_arduino_port,
    list_available_ports,
)
from shared.protocol import (
    PACKET_ETX,
    PACKET_STX,
    SerialCommand,
    build_handshake,
    encode_command,
)

# ---------------------------------------------------------------------------
# 포트 탐지
# ---------------------------------------------------------------------------


class TestDetectPort:
    """detect_arduino_port() 테스트."""

    @patch("engine.serial_cmd.serial.tools.list_ports.comports")
    def test_finds_leonardo(self, mock_comports: MagicMock) -> None:
        """VID:PID 일치하는 포트 감지."""
        mock_port = MagicMock()
        mock_port.vid = 0x2341
        mock_port.pid = 0x8036
        mock_port.device = "COM5"
        mock_port.description = "Arduino Leonardo"
        mock_comports.return_value = [mock_port]

        result = detect_arduino_port()
        assert result == "COM5"

    @patch("engine.serial_cmd.serial.tools.list_ports.comports")
    def test_no_arduino_returns_none(self, mock_comports: MagicMock) -> None:
        """Arduino 없으면 None."""
        mock_port = MagicMock()
        mock_port.vid = 0x1234
        mock_port.pid = 0x5678
        mock_comports.return_value = [mock_port]

        result = detect_arduino_port()
        assert result is None

    @patch("engine.serial_cmd.serial.tools.list_ports.comports")
    def test_empty_ports(self, mock_comports: MagicMock) -> None:
        mock_comports.return_value = []
        assert detect_arduino_port() is None


class TestListPorts:
    """list_available_ports() 테스트."""

    @patch("engine.serial_cmd.serial.tools.list_ports.comports")
    def test_returns_port_info(self, mock_comports: MagicMock) -> None:
        mock_port = MagicMock()
        mock_port.device = "COM3"
        mock_port.description = "USB Serial"
        mock_port.vid = 0x2341
        mock_port.pid = 0x8036
        mock_comports.return_value = [mock_port]

        ports = list_available_ports()
        assert len(ports) == 1
        assert ports[0]["device"] == "COM3"
        assert ports[0]["vid"] == 0x2341


# ---------------------------------------------------------------------------
# SerialCommander
# ---------------------------------------------------------------------------


def _make_ack_packet(status: int = 0x00) -> bytes:
    """ACK 패킷을 생성한다."""
    return encode_command(SerialCommand.ACK, bytes([status]))


class TestSerialCommanderConnect:
    """SerialCommander.connect() 테스트."""

    @patch("engine.serial_cmd.serial.Serial")
    @patch("engine.serial_cmd.detect_arduino_port")
    def test_connect_auto_detect(
        self,
        mock_detect: MagicMock,
        mock_serial_class: MagicMock,
    ) -> None:
        """자동 탐지 → 연결 → 핸드셰이크 성공."""
        mock_detect.return_value = "COM5"

        mock_ser = MagicMock()
        mock_ser.is_open = True
        mock_ser.in_waiting = 6
        mock_ser.read.return_value = _make_ack_packet(0x00)
        mock_serial_class.return_value = mock_ser

        commander = SerialCommander()
        commander.connect()

        assert commander.is_connected()
        assert commander.port_name == "COM5"

    @patch("engine.serial_cmd.detect_arduino_port")
    def test_connect_no_port_raises(self, mock_detect: MagicMock) -> None:
        """포트를 찾을 수 없을 때."""
        mock_detect.return_value = None

        commander = SerialCommander()
        with pytest.raises(SerialConnectionError, match="찾을 수 없습니다"):
            commander.connect()

    def test_not_connected_initially(self) -> None:
        commander = SerialCommander()
        assert not commander.is_connected()


class TestSerialCommanderSend:
    """SerialCommander.send_command() 테스트."""

    def test_send_without_connection_raises(self) -> None:
        commander = SerialCommander()
        with pytest.raises(SerialConnectionError, match="연결되어 있지 않습니다"):
            commander.send_command(build_handshake())

    @patch("engine.serial_cmd.serial.Serial")
    def test_send_command_with_ack(self, mock_serial_class: MagicMock) -> None:
        """패킷 전송 후 ACK 수신 성공."""
        mock_ser = MagicMock()
        mock_ser.is_open = True
        mock_ser.in_waiting = 6
        mock_ser.read.return_value = _make_ack_packet(0x00)
        mock_serial_class.return_value = mock_ser

        commander = SerialCommander(port="COM3")
        commander._serial = mock_ser

        result = commander.send_command(build_handshake())
        assert result is True
        mock_ser.write.assert_called()

    @patch("engine.serial_cmd.serial.Serial")
    def test_mouse_click_uses_dynamic_ack_timeout(
        self,
        mock_serial_class: MagicMock,
    ) -> None:
        """MOUSE_CLICK(count=3)은 ACK timeout을 늘려 대기한다."""
        mock_ser = MagicMock()
        mock_ser.is_open = True
        mock_serial_class.return_value = mock_ser

        commander = SerialCommander(port="COM3")
        commander._serial = mock_ser
        commander._wait_for_ack = MagicMock(return_value=0x00)  # type: ignore[method-assign]

        packet = encode_command(SerialCommand.MOUSE_CLICK, bytes([1, 3]))
        result = commander.send_command(packet)

        assert result is True
        commander._wait_for_ack.assert_called_once_with(timeout=0.25)

    @patch("engine.serial_cmd.serial.Serial")
    def test_non_click_command_uses_default_ack_timeout(
        self,
        mock_serial_class: MagicMock,
    ) -> None:
        """MOUSE_CLICK 이외 명령은 기본 ACK timeout을 사용한다."""
        mock_ser = MagicMock()
        mock_ser.is_open = True
        mock_serial_class.return_value = mock_ser

        commander = SerialCommander(port="COM3")
        commander._serial = mock_ser
        commander._wait_for_ack = MagicMock(return_value=0x00)  # type: ignore[method-assign]

        packet = build_handshake()
        result = commander.send_command(packet)

        assert result is True
        commander._wait_for_ack.assert_called_once_with(timeout=0.1)


class TestSerialCommanderEmergencyStop:
    """emergency_stop() 테스트."""

    @patch("engine.serial_cmd.serial.Serial")
    def test_emergency_stop_sends_packet(self, mock_serial_class: MagicMock) -> None:
        mock_ser = MagicMock()
        mock_ser.is_open = True
        mock_serial_class.return_value = mock_ser

        commander = SerialCommander()
        commander._serial = mock_ser

        commander.emergency_stop()
        mock_ser.write.assert_called_once()

        sent_data = mock_ser.write.call_args[0][0]
        assert sent_data[0] == PACKET_STX
        assert sent_data[1] == SerialCommand.EMERGENCY_STOP
        assert sent_data[-1] == PACKET_ETX

    def test_emergency_stop_when_disconnected(self) -> None:
        """연결 안 되어 있으면 조용히 무시."""
        commander = SerialCommander()
        commander.emergency_stop()  # 에러 없음


class TestSerialCommanderDisconnect:
    """disconnect() 테스트."""

    @patch("engine.serial_cmd.serial.Serial")
    def test_disconnect_sends_emergency_and_closes(
        self,
        mock_serial_class: MagicMock,
    ) -> None:
        mock_ser = MagicMock()
        mock_ser.is_open = True
        mock_serial_class.return_value = mock_ser

        commander = SerialCommander()
        commander._serial = mock_ser

        commander.disconnect()

        mock_ser.write.assert_called()  # EMERGENCY_STOP
        mock_ser.close.assert_called_once()
        assert not commander.is_connected()


class TestMousePositionTracking:
    """마우스 위치 추적 테스트."""

    def test_initial_position(self) -> None:
        commander = SerialCommander()
        assert commander.current_mouse_pos == (0, 0)

    def test_set_position(self) -> None:
        commander = SerialCommander()
        commander.current_mouse_pos = (500, 300)
        assert commander.current_mouse_pos == (500, 300)
