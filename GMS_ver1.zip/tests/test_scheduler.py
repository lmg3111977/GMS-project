"""engine/scheduler.py 단위 테스트."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from engine.scheduler import ActionScheduler, SchedulerError
from engine.variables import VariableStore
from shared.models import (
    DelayAction,
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    KeyPressAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    MouseClickAction,
    MouseMoveAction,
    PixelWaitAction,
    VariableSetAction,
)


def make_scheduler(
    actions: list,
    mock_serial: bool = True,
    mock_screen: bool = True,
) -> ActionScheduler:
    """테스트용 스케줄러를 생성한다."""
    serial_mock = MagicMock() if mock_serial else None
    if serial_mock:
        serial_mock.send_action.return_value = True

    screen_mock = MagicMock() if mock_screen else None

    scheduler = ActionScheduler(
        serial_commander=serial_mock,
        screen_analyzer=screen_mock,
        variable_store=VariableStore(),
    )
    scheduler.load_actions(actions)
    return scheduler


class TestSequentialExecution:
    """순차 실행 테스트."""

    def test_empty_actions_returns_false(self) -> None:
        scheduler = make_scheduler([])
        assert scheduler.execute_next() is False

    def test_three_actions_execute_in_order(self) -> None:
        scheduler = make_scheduler(
            [
                MouseMoveAction(x=100, y=100),
                MouseClickAction(),
                KeyPressAction(key="a"),
            ]
        )

        assert scheduler.execute_next() is True  # MouseMove
        assert scheduler.program_counter == 1
        assert scheduler.execute_next() is True  # MouseClick
        assert scheduler.program_counter == 2
        assert scheduler.execute_next() is False  # KeyPress → 끝 도달
        assert scheduler.is_finished

    def test_disabled_action_skipped(self) -> None:
        scheduler = make_scheduler(
            [
                MouseMoveAction(x=100, y=100, enabled=True),
                MouseClickAction(enabled=False),  # 건너뜀
                KeyPressAction(key="a", enabled=True),
            ]
        )

        assert scheduler.execute_next() is True  # MouseMove
        assert scheduler.execute_next() is False  # KeyPress (Click 건너뜀) → 끝
        assert scheduler.is_finished


class TestLabelAndGoto:
    """Label + Goto 테스트."""

    def test_goto_jumps_to_label(self) -> None:
        scheduler = make_scheduler(
            [
                LabelAction(name="start"),  # 0
                MouseClickAction(),  # 1
                GotoAction(target="start"),  # 2 → 0으로 점프
            ]
        )

        scheduler.execute_next()  # Label (통과)
        assert scheduler.program_counter == 1
        scheduler.execute_next()  # MouseClick
        assert scheduler.program_counter == 2
        scheduler.execute_next()  # Goto → 0으로
        assert scheduler.program_counter == 0

    def test_goto_undefined_label_raises(self) -> None:
        scheduler = make_scheduler(
            [
                GotoAction(target="nonexistent"),
            ]
        )

        with pytest.raises(SchedulerError, match="Label이 없음"):
            scheduler.execute_next()

    def test_label_is_passthrough(self) -> None:
        """Label 액션은 실행 없이 다음으로 진행."""
        scheduler = make_scheduler(
            [
                LabelAction(name="x"),
                MouseClickAction(),
            ]
        )

        scheduler.execute_next()  # Label → 통과
        assert scheduler.program_counter == 1


class TestLoop:
    """루프 테스트."""

    def test_loop_count_3(self) -> None:
        """Loop(count=3)이 내부 액션을 정확히 3번 실행."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(
            [
                LoopStartAction(count=3),  # 0
                MouseClickAction(),  # 1
                LoopEndAction(),  # 2
            ]
        )

        steps = 0
        while scheduler.execute_next():
            steps += 1
            if steps > 20:
                pytest.fail("무한 루프 감지")

        click_count = serial_mock.send_action.call_count
        assert click_count == 3

    def test_loop_end_without_start_raises(self) -> None:
        with pytest.raises(SchedulerError, match="LoopStart가 없음"):
            make_scheduler([LoopEndAction()])

    def test_nested_loops(self) -> None:
        """중첩 루프: 외부 2회 × 내부 3회 = 6회."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(
            [
                LoopStartAction(count=2),  # 0: 외부
                LoopStartAction(count=3),  # 1: 내부
                MouseClickAction(),  # 2
                LoopEndAction(),  # 3: 내부 끝
                LoopEndAction(),  # 4: 외부 끝
            ]
        )

        steps = 0
        while scheduler.execute_next():
            steps += 1
            if steps > 100:
                pytest.fail("무한 루프 감지")

        assert serial_mock.send_action.call_count == 6

    def test_loop_nesting_limit(self) -> None:
        """11단계 중첩 → SchedulerError."""
        actions = []
        for _ in range(11):
            actions.append(LoopStartAction(count=1))
        actions.append(MouseClickAction())
        for _ in range(11):
            actions.append(LoopEndAction())

        scheduler = make_scheduler(actions)

        with pytest.raises(SchedulerError, match="루프 중첩 제한"):
            while scheduler.execute_next():
                pass

    def test_loop_count_expression_overrides_count(self) -> None:
        """count_expression이 있으면 count 대신 변수 식으로 반복 횟수 결정."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(
            serial_commander=serial_mock,
            variable_store=VariableStore(),
        )
        # load_actions 마지막에 reset()이 변수를 비우므로, n은 액션으로 먼저 설정
        scheduler.load_actions(
            [
                VariableSetAction(var_name="n", value="4"),
                LoopStartAction(count=999, count_expression="{n}"),
                MouseClickAction(),
                LoopEndAction(),
            ]
        )
        steps = 0
        while scheduler.execute_next():
            steps += 1
            if steps > 40:
                pytest.fail("무한 루프 감지")
        assert serial_mock.send_action.call_count == 4

    def test_loop_count_expression_invalid_raises(self) -> None:
        """count_expression 평가 결과가 숫자가 아니면 SchedulerError."""
        scheduler = make_scheduler(
            [
                LoopStartAction(count=1, count_expression="not_a_number"),
                MouseClickAction(),
                LoopEndAction(),
            ]
        )
        with pytest.raises(SchedulerError, match="정수가 아닙니다"):
            while scheduler.execute_next():
                pass

    def test_loop_range_expression_works_like_for(self) -> None:
        """range_start/end 식으로 for(i=start; i<end; i++) 반복 횟수를 계산한다."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(
            serial_commander=serial_mock,
            variable_store=VariableStore(),
        )
        scheduler.load_actions(
            [
                VariableSetAction(var_name="s", value="1"),
                VariableSetAction(var_name="e", value="4"),
                LoopStartAction(
                    count=-1,
                    range_start_expression="{s}",
                    range_end_expression="{e}",
                    range_end_inclusive=False,
                ),
                MouseClickAction(),
                LoopEndAction(),
            ]
        )
        while scheduler.execute_next():
            pass
        assert serial_mock.send_action.call_count == 3

    def test_loop_range_expression_inclusive(self) -> None:
        """range_end_inclusive=True면 for(i=start; i<=end; i++)처럼 동작한다."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(
            serial_commander=serial_mock,
            variable_store=VariableStore(),
        )
        scheduler.load_actions(
            [
                VariableSetAction(var_name="s", value="1"),
                VariableSetAction(var_name="e", value="3"),
                LoopStartAction(
                    count=-1,
                    range_start_expression="{s}",
                    range_end_expression="{e}",
                    range_end_inclusive=True,
                ),
                MouseClickAction(),
                LoopEndAction(),
            ]
        )
        while scheduler.execute_next():
            pass
        assert serial_mock.send_action.call_count == 3


class TestIfPixel:
    """IfPixel 조건 분기 테스트."""

    def test_if_pixel_true_goes_next(self) -> None:
        """픽셀 색상 일치 → then 블록(다음 액션)."""
        screen_mock = MagicMock()
        screen_mock.check_pixel_color.return_value = True
        screen_mock.get_pixel_match_metrics.return_value = (True, 0.0, 1.0)

        scheduler = ActionScheduler(screen_analyzer=screen_mock)
        scheduler.load_actions(
            [
                IfPixelAction(x=100, y=200, color="#FF0000"),
                LabelAction(name="found_path"),
                ElseAction(),
                LabelAction(name="else_path"),
                EndIfAction(),
                MouseClickAction(),
            ]
        )

        scheduler.execute_next()  # IfPixel true → 다음 액션
        assert scheduler.program_counter == 1

    def test_if_pixel_false_goes_else_block(self) -> None:
        """픽셀 색상 불일치 → else 블록."""
        screen_mock = MagicMock()
        screen_mock.check_pixel_color.return_value = False
        screen_mock.get_pixel_match_metrics.return_value = (False, 50.0, 0.0)

        scheduler = ActionScheduler(screen_analyzer=screen_mock)
        scheduler.load_actions(
            [
                IfPixelAction(x=100, y=200, color="#FF0000"),
                LabelAction(name="found_path"),
                ElseAction(),
                LabelAction(name="else_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()  # IfPixel false → else 블록
        assert scheduler.program_counter == 3

    def test_if_pixel_no_screen_goes_else(self) -> None:
        """ScreenAnalyzer 없으면 else 분기."""
        scheduler = ActionScheduler(screen_analyzer=None)
        scheduler.load_actions(
            [
                IfPixelAction(x=100, y=200, color="#FF0000"),
                LabelAction(name="then_path"),
                ElseAction(),
                LabelAction(name="else_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()
        assert scheduler.program_counter == 3  # else 블록 첫 액션

    def test_if_pixel_detect_change_true_goes_next_when_mismatch(self) -> None:
        """변화 감지 모드에서 불일치면 then 블록으로 진행."""
        screen_mock = MagicMock()
        screen_mock.check_pixel_color.return_value = False
        screen_mock.get_pixel_match_metrics.return_value = (False, 50.0, 0.0)

        scheduler = ActionScheduler(screen_analyzer=screen_mock)
        scheduler.load_actions(
            [
                IfPixelAction(x=100, y=200, color="#FF0000", detect_change=True),
                LabelAction(name="changed_path"),
                ElseAction(),
                LabelAction(name="else_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()
        assert scheduler.program_counter == 1

    def test_if_pixel_detect_change_true_goes_else_when_still_match(self) -> None:
        """변화 감지 모드에서 일치 상태면 else 블록으로 진행."""
        screen_mock = MagicMock()
        screen_mock.check_pixel_color.return_value = True
        screen_mock.get_pixel_match_metrics.return_value = (True, 0.0, 1.0)

        scheduler = ActionScheduler(screen_analyzer=screen_mock)
        scheduler.load_actions(
            [
                IfPixelAction(x=100, y=200, color="#FF0000", detect_change=True),
                LabelAction(name="changed_path"),
                ElseAction(),
                LabelAction(name="else_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()
        assert scheduler.program_counter == 3


class TestPixelWait:
    """PixelWait 조건 분기 테스트."""

    def test_pixel_wait_detect_change_succeeds_on_mismatch(self) -> None:
        screen_mock = MagicMock()
        screen_mock.check_pixel_color.side_effect = [True, False]
        screen_mock.get_pixel_match_metrics.return_value = (False, 80.0, 0.0)

        scheduler = ActionScheduler(screen_analyzer=screen_mock)
        scheduler.load_actions(
            [
                PixelWaitAction(
                    x=100,
                    y=200,
                    color="#FF0000",
                    detect_change=True,
                    timeout_ms=500,
                ),
                LabelAction(name="changed_path"),
                ElseAction(),
                LabelAction(name="timeout_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()
        assert scheduler.program_counter == 1

    def test_pixel_wait_detect_change_runtime_reference(self) -> None:
        screen_mock = MagicMock()
        screen_mock.get_pixel_color.return_value = "#111111"
        screen_mock.check_pixel_color.side_effect = [True, False]
        screen_mock.get_pixel_match_metrics.return_value = (False, 80.0, 0.0)

        scheduler = ActionScheduler(screen_analyzer=screen_mock)
        scheduler.load_actions(
            [
                PixelWaitAction(
                    x=100,
                    y=200,
                    color="#FF0000",
                    detect_change=True,
                    change_reference="runtime",
                    timeout_ms=500,
                ),
                LabelAction(name="changed_path"),
                ElseAction(),
                LabelAction(name="timeout_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()
        assert scheduler.program_counter == 1
        screen_mock.check_pixel_color.assert_any_call(100, 200, "#111111", 10)

    def test_pixel_wait_detect_change_timeout_goes_else(self) -> None:
        screen_mock = MagicMock()
        screen_mock.check_pixel_color.return_value = True
        screen_mock.get_pixel_match_metrics.return_value = (True, 0.0, 1.0)

        scheduler = ActionScheduler(screen_analyzer=screen_mock)
        scheduler.load_actions(
            [
                PixelWaitAction(
                    x=100,
                    y=200,
                    color="#FF0000",
                    detect_change=True,
                    timeout_ms=0,
                ),
                LabelAction(name="changed_path"),
                ElseAction(),
                LabelAction(name="timeout_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()
        assert scheduler.program_counter == 3


class TestDelay:
    """Delay 테스트."""

    def test_fixed_delay(self) -> None:
        """Delay 후 다음 액션으로 진행."""
        scheduler = make_scheduler(
            [
                DelayAction(ms=10),
                MouseClickAction(),
            ]
        )

        scheduler.execute_next()  # Delay
        assert scheduler.program_counter == 1

    def test_random_delay(self) -> None:
        scheduler = make_scheduler(
            [
                DelayAction(ms=50, random_min=10, random_max=20),
            ]
        )
        scheduler.execute_next()
        assert scheduler.is_finished


class TestVariableSet:
    """VariableSet 테스트."""

    def test_set_direct_value(self) -> None:
        scheduler = make_scheduler(
            [
                VariableSetAction(var_name="count", value="42"),
            ]
        )

        scheduler.execute_next()
        assert scheduler.variables.get("count") == "42"

    def test_set_expression(self) -> None:
        scheduler = make_scheduler(
            [
                VariableSetAction(var_name="x", value="10"),
                VariableSetAction(var_name="y", expression="{x} + 5"),
            ]
        )

        scheduler.execute_next()
        scheduler.execute_next()
        assert scheduler.variables.get("y") == "15"

    def test_set_expression_supports_mod_floor_div_pow(self) -> None:
        scheduler = make_scheduler(
            [
                VariableSetAction(var_name="base", value="10"),
                VariableSetAction(var_name="a", expression="{base} % 3"),
                VariableSetAction(var_name="b", expression="{base} // 4"),
                VariableSetAction(var_name="c", expression="2 ** 3"),
            ]
        )

        while scheduler.execute_next():
            pass

        assert scheduler.variables.get("a") == "1"
        assert scheduler.variables.get("b") == "2"
        assert scheduler.variables.get("c") == "8"


class TestIfVariable:
    """IfVariable 분기 테스트."""

    def test_compare_value_supports_variable_reference(self) -> None:
        scheduler = make_scheduler(
            [
                VariableSetAction(var_name="hp", value="30"),
                VariableSetAction(var_name="threshold", value="20"),
                IfVariableAction(var_name="hp", operator=">", compare_value="{threshold}"),
                LabelAction(name="then_path"),
                ElseAction(),
                LabelAction(name="else_path"),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()  # hp 설정
        scheduler.execute_next()  # threshold 설정
        scheduler.execute_next()  # IfVariable
        assert scheduler.program_counter == 3  # then 블록 진입


class TestDryRun:
    """serial=None (dry-run) 모드 테스트."""

    def test_dry_run_no_error(self) -> None:
        """serial 없이도 에러 없이 실행."""
        scheduler = ActionScheduler(serial_commander=None, screen_analyzer=None)
        scheduler.load_actions(
            [
                MouseMoveAction(x=100, y=100),
                MouseClickAction(),
                KeyPressAction(key="a"),
            ]
        )

        while scheduler.execute_next():
            pass

        assert scheduler.is_finished


class TestReset:
    """reset() 테스트."""

    def test_reset_restarts_from_beginning(self) -> None:
        scheduler = make_scheduler(
            [
                MouseMoveAction(x=100, y=100),
                MouseClickAction(),
            ]
        )

        scheduler.execute_next()  # 1개 실행
        assert scheduler.program_counter == 1

        scheduler.reset()
        assert scheduler.program_counter == 0
        assert not scheduler.is_finished
