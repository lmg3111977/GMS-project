"""shared/schema.py 단위 테스트."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from shared.models import (
    BreakAction,
    DelayAction,
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    ImageSearchAction,
    KeyPressAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    Macro,
    MacroSettings,
    MouseMoveAction,
    VariableSetAction,
)
from shared.schema import (
    MacroValidationError,
    load_macro,
    save_macro,
    validate_macro_logic,
)

# ---------------------------------------------------------------------------
# save / load 라운드트립
# ---------------------------------------------------------------------------


class TestSaveLoad:
    """save_macro() / load_macro() 라운드트립 테스트."""

    def test_roundtrip_basic(self, tmp_path: Path) -> None:
        """기본 매크로 save → load → 내용 일치."""
        original = Macro(
            name="라운드트립 테스트",
            hotkey="F8",
            actions=[
                MouseMoveAction(x=100, y=200, comment="이동"),
                DelayAction(ms=500),
                KeyPressAction(key="a"),
            ],
        )

        file_path = tmp_path / "test.json"
        save_macro(original, file_path)
        loaded = load_macro(file_path)

        assert loaded.name == original.name
        assert loaded.hotkey == original.hotkey
        assert len(loaded.actions) == 3
        assert loaded.actions[0].x == 100  # type: ignore[attr-defined]
        assert loaded.actions[1].ms == 500  # type: ignore[attr-defined]

    def test_roundtrip_complex(self, tmp_path: Path) -> None:
        """조건 분기 + 루프 포함 매크로 라운드트립."""
        original = Macro(
            name="복잡한 매크로",
            settings=MacroSettings(humanize=False),
            actions=[
                LabelAction(name="start"),
                LoopStartAction(label="main", count=5),
                IfPixelAction(x=100, y=200, color="#FF0000"),
                ElseAction(),
                EndIfAction(),
                LoopEndAction(),
            ],
        )

        file_path = tmp_path / "complex.json"
        save_macro(original, file_path)
        loaded = load_macro(file_path)

        assert loaded.settings.humanize is False
        assert len(loaded.actions) == 6

    def test_saved_file_is_valid_json(self, tmp_path: Path) -> None:
        """저장된 파일이 유효한 JSON이고 들여쓰기가 있는지 확인."""
        macro = Macro(actions=[MouseMoveAction(x=50, y=50)])
        file_path = tmp_path / "formatted.json"
        save_macro(macro, file_path)

        content = file_path.read_text(encoding="utf-8")
        data = json.loads(content)
        assert isinstance(data, dict)
        assert "name" in data
        assert "actions" in data

    def test_load_nonexistent_file(self) -> None:
        with pytest.raises(FileNotFoundError):
            load_macro("/nonexistent/path/macro.json")

    def test_load_invalid_json(self, tmp_path: Path) -> None:
        file_path = tmp_path / "broken.json"
        file_path.write_text("{broken json!!!", encoding="utf-8")
        with pytest.raises(MacroValidationError, match="JSON 파싱 실패"):
            load_macro(file_path)

    def test_load_non_object_json(self, tmp_path: Path) -> None:
        file_path = tmp_path / "array.json"
        file_path.write_text("[1, 2, 3]", encoding="utf-8")
        with pytest.raises(MacroValidationError, match="객체여야 함"):
            load_macro(file_path)

    def test_load_invalid_model(self, tmp_path: Path) -> None:
        """유효한 JSON이지만 모델 검증 실패."""
        file_path = tmp_path / "bad_model.json"
        data = {
            "name": "test",
            "version": "1.0",
            "hotkey": "F6",
            "settings": {"humanize": True, "base_delay_ms": 50},
            "actions": [{"type": "FAKE_TYPE"}],
        }
        file_path.write_text(json.dumps(data), encoding="utf-8")
        with pytest.raises(MacroValidationError, match="모델 검증 실패"):
            load_macro(file_path)

    def test_creates_parent_directory(self, tmp_path: Path) -> None:
        """저장 경로의 상위 디렉토리가 없으면 자동 생성."""
        macro = Macro()
        file_path = tmp_path / "sub" / "dir" / "macro.json"
        save_macro(macro, file_path)
        assert file_path.exists()


# ---------------------------------------------------------------------------
# validate_macro_logic
# ---------------------------------------------------------------------------


class TestValidateMacroLogic:
    """validate_macro_logic() 논리 검증 테스트."""

    def test_valid_macro_no_issues(self) -> None:
        """정상 매크로 → 이슈 없음."""
        macro = Macro(
            actions=[
                LabelAction(name="start"),
                MouseMoveAction(x=100, y=100),
                GotoAction(target="start"),
            ]
        )
        issues = validate_macro_logic(macro)
        assert len(issues) == 0

    def test_empty_macro_warning(self) -> None:
        """빈 매크로 → 경고."""
        macro = Macro()
        issues = validate_macro_logic(macro)
        assert any("[WARNING]" in i for i in issues)

    def test_goto_undefined_label(self) -> None:
        """존재하지 않는 Label을 참조하는 Goto."""
        macro = Macro(
            actions=[
                GotoAction(target="nonexistent"),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[ERROR]" in i and "nonexistent" in i for i in issues)

    def test_duplicate_label(self) -> None:
        """중복 Label 이름."""
        macro = Macro(
            actions=[
                LabelAction(name="dup"),
                LabelAction(name="dup"),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[ERROR]" in i and "중복" in i for i in issues)

    def test_loop_start_without_end(self) -> None:
        """LoopStart만 있고 LoopEnd 없음."""
        macro = Macro(
            actions=[
                LoopStartAction(count=5),
                MouseMoveAction(x=100, y=100),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[ERROR]" in i and "LoopEnd" in i for i in issues)

    def test_loop_end_without_start(self) -> None:
        """LoopEnd만 있고 LoopStart 없음."""
        macro = Macro(
            actions=[
                MouseMoveAction(x=100, y=100),
                LoopEndAction(),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[ERROR]" in i and "LoopStart" in i for i in issues)

    def test_matched_loops_no_issues(self) -> None:
        """올바르게 짝이 맞는 루프."""
        macro = Macro(
            actions=[
                LoopStartAction(count=3),
                DelayAction(ms=100),
                LoopEndAction(),
            ]
        )
        issues = validate_macro_logic(macro)
        errors = [i for i in issues if "[ERROR]" in i]
        assert len(errors) == 0

    def test_retry_fallback_editor_template_no_struct_errors(self) -> None:
        """에디터 추천 '재시도+실패분기': ImageSearch 단일 구조 + success fallback."""
        macro = Macro(
            actions=[
                VariableSetAction(
                    var_name="success",
                    value="",
                    expression="0",
                ),
                LoopStartAction(count=5),
                ImageSearchAction(
                    store_found_var="found",
                    max_retry=1,
                    retry_interval_ms=300,
                ),
                VariableSetAction(
                    var_name="success",
                    value="",
                    expression="1",
                ),
                BreakAction(),
                ElseAction(),
                DelayAction(ms=200),
                EndIfAction(),
                LoopEndAction(),
                IfVariableAction(
                    var_name="success",
                    operator="==",
                    compare_value="0",
                ),
                KeyPressAction(key="esc"),
                ElseAction(),
                EndIfAction(),
            ]
        )
        issues = validate_macro_logic(macro)
        errors = [i for i in issues if "[ERROR]" in i]
        assert errors == []

    def test_nested_loops_valid(self) -> None:
        """중첩 루프 (올바르게 짝 맞음)."""
        macro = Macro(
            actions=[
                LoopStartAction(count=3),
                LoopStartAction(count=2),
                DelayAction(ms=100),
                LoopEndAction(),
                LoopEndAction(),
            ]
        )
        issues = validate_macro_logic(macro)
        errors = [i for i in issues if "[ERROR]" in i]
        assert len(errors) == 0

    def test_disabled_label_not_indexed(self) -> None:
        """비활성화된 Label은 인덱싱되지 않음 → Goto가 참조하면 에러."""
        macro = Macro(
            actions=[
                LabelAction(name="disabled_label", enabled=False),
                GotoAction(target="disabled_label"),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[ERROR]" in i for i in issues)

    def test_save_with_error_raises(self, tmp_path: Path) -> None:
        """검증 에러가 있는 매크로 저장 시 MacroValidationError."""
        macro = Macro(
            actions=[
                GotoAction(target="nowhere"),
            ]
        )
        with pytest.raises(MacroValidationError):
            save_macro(macro, tmp_path / "invalid.json")

    def test_warning_if_variable_uses_undefined_var(self) -> None:
        macro = Macro(
            actions=[
                IfVariableAction(var_name="state", operator="==", compare_value="1"),
                ElseAction(),
                EndIfAction(),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[WARNING]" in i and "이전에 설정되지 않았습니다" in i for i in issues)

    def test_warning_if_variable_undefined_compare_ref(self) -> None:
        macro = Macro(
            actions=[
                VariableSetAction(var_name="hp", value="10"),
                IfVariableAction(var_name="hp", operator=">", compare_value="{threshold}"),
                ElseAction(),
                EndIfAction(),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[WARNING]" in i and "미정의 변수 참조" in i for i in issues)

    def test_warning_if_variable_non_numeric_compare_with_order_operator(self) -> None:
        macro = Macro(
            actions=[
                VariableSetAction(var_name="hp", value="10"),
                IfVariableAction(var_name="hp", operator=">", compare_value="hello"),
                ElseAction(),
                EndIfAction(),
            ]
        )
        issues = validate_macro_logic(macro)
        assert any("[WARNING]" in i and "숫자 비교 권장" in i for i in issues)
