"""shared.auth.client 인증 HTTP 재시도 테스트."""

from __future__ import annotations

from urllib import error

from shared.auth.client import AuthClientConfig, AuthHttpClient


class _DummyResponse:
    def __init__(self, body: str) -> None:
        self._body = body.encode("utf-8")

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> _DummyResponse:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


def test_verify_login_retries_with_increased_timeout(monkeypatch) -> None:
    calls: list[float] = []
    outcomes = [TimeoutError("The read operation timed out"), _DummyResponse('{"ok": true}')]

    def fake_urlopen(req, timeout):
        calls.append(float(timeout))
        current = outcomes.pop(0)
        if isinstance(current, Exception):
            raise current
        return current

    monkeypatch.setattr("shared.auth.client.request.urlopen", fake_urlopen)
    monkeypatch.setattr("shared.auth.client.time.sleep", lambda _: None)

    client = AuthHttpClient(
        AuthClientConfig(endpoint="https://example.test/exec", timeout_sec=8.0, retries=1)
    )
    result = client.verify_login(user_id="u1", password="p1")

    assert bool(result.get("ok")) is True
    assert calls == [8.0, 12.0]


def test_verify_login_raises_after_all_retries(monkeypatch) -> None:
    def fake_urlopen(req, timeout):
        raise error.URLError("network down")

    monkeypatch.setattr("shared.auth.client.request.urlopen", fake_urlopen)
    monkeypatch.setattr("shared.auth.client.time.sleep", lambda _: None)

    client = AuthHttpClient(
        AuthClientConfig(endpoint="https://example.test/exec", timeout_sec=8.0, retries=1)
    )

    try:
        client.verify_login(user_id="u1", password="p1")
        raise AssertionError("예외가 발생해야 합니다.")
    except RuntimeError as exc:
        assert "인증 서버 통신 실패" in str(exc)
