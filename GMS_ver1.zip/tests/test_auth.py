"""shared.auth 로그인 가드 테스트."""

from __future__ import annotations

import pytest

from shared.auth.guard import authenticate_or_exit


class _DummyClient:
    def __init__(self, response: dict[str, object]) -> None:
        self._response = response

    def verify_login(self, *, user_id: str, password: str) -> dict[str, object]:
        return self._response


def test_authenticate_success(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GMS_AUTH_URL", "https://example.test/exec")
    monkeypatch.setattr(
        "shared.auth.guard.AuthHttpClient",
        lambda config: _DummyClient({"ok": True, "code": "OK", "message": "로그인 성공"}),
    )
    authenticate_or_exit(user_id="u1", password="p1")


def test_authenticate_missing_url_exits(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GMS_AUTH_URL", raising=False)
    with pytest.raises(SystemExit):
        authenticate_or_exit(user_id="u1", password="p1")


def test_authenticate_failed_login_exits(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GMS_AUTH_URL", "https://example.test/exec")
    monkeypatch.setattr(
        "shared.auth.guard.AuthHttpClient",
        lambda config: _DummyClient({"ok": False, "code": "ACCOUNT_EXPIRED", "message": "만료"}),
    )
    with pytest.raises(SystemExit):
        authenticate_or_exit(user_id="u1", password="p1")
