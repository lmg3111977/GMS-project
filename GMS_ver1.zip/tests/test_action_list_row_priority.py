"""ActionListWidget 행 배경 우선순위 테스트."""

from __future__ import annotations

from editor.action_list.constants import (
    _ROW_BG_BREAKPOINT,
    _ROW_BG_DEFAULT,
    _ROW_BG_EXECUTING,
    _ROW_BG_SELECTED_PRIMARY,
)
from editor.action_list.core import _resolve_row_background_color


def test_executing_wins_even_with_recent_flag() -> None:
    """recent는 배경 계산에 개입하지 않고 executing 배경이 유지된다."""
    color = _resolve_row_background_color(
        0,
        in_hover_group=False,
        has_breakpoint=False,
        is_selected_primary=False,
        is_selected_linked=False,
        is_executing=True,
    )
    assert color == _ROW_BG_EXECUTING


def test_selected_primary_beats_breakpoint() -> None:
    color = _resolve_row_background_color(
        1,
        in_hover_group=False,
        has_breakpoint=True,
        is_selected_primary=True,
        is_selected_linked=False,
        is_executing=False,
    )
    assert color == _ROW_BG_SELECTED_PRIMARY


def test_breakpoint_beats_hover() -> None:
    color = _resolve_row_background_color(
        0,
        in_hover_group=True,
        has_breakpoint=True,
        is_selected_primary=False,
        is_selected_linked=False,
        is_executing=False,
    )
    assert color == _ROW_BG_BREAKPOINT


def test_recent_only_does_not_override_background() -> None:
    """recent 단독 상태는 배경색을 바꾸지 않고 보조 강조만 적용된다."""
    base = _resolve_row_background_color(
        0,
        in_hover_group=False,
        has_breakpoint=False,
        is_selected_primary=False,
        is_selected_linked=False,
        is_executing=False,
    )
    # recent는 배경 계산 함수가 아니라 보조 강조 경로에서 처리되므로,
    # recent 단독 상황에서도 배경은 기본색을 유지해야 한다.
    assert base == _ROW_BG_DEFAULT
