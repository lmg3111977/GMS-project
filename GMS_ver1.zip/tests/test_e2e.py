"""E2E 통합 테스트 — 매크로 생성 → 저장 → 로드 → 실행 전체 흐름."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from engine.runner import MacroRunner, RunnerState
from engine.scheduler import ActionScheduler
from engine.variables import VariableStore
from shared.models import (
    ActionType,
    DelayAction,
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    KeyPressAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    Macro,
    MacroSettings,
    MouseClickAction,
    MouseMoveAction,
)
from shared.schema import load_macro, save_macro, validate_macro_logic

# ---------------------------------------------------------------------------
# 시나리오 1: 매크로 생성 → 저장 → 로드 → 내용 일치
# ---------------------------------------------------------------------------


class TestSaveLoadRoundtrip:
    """매크로 전체 라운드트립 테스트."""

    def test_full_roundtrip(self, tmp_path: Path) -> None:
        """매크로 생성 → JSON 저장 → 로드 → 모든 필드 일치."""
        original = Macro(
            name="E2E 테스트 매크로",
            hotkey="F8",
            settings=MacroSettings(humanize=False, base_delay_ms=0),
            actions=[
                LabelAction(name="start"),
                MouseMoveAction(x=960, y=540, duration_ms=200, comment="중앙"),
                DelayAction(ms=100),
                MouseClickAction(button="LEFT", count=1),
                KeyPressAction(key="1"),
                GotoAction(target="start"),
            ],
        )

        file_path = tmp_path / "e2e_test.json"
        save_macro(original, file_path)

        loaded = load_macro(file_path)

        assert loaded.name == original.name
        assert loaded.hotkey == original.hotkey
        assert loaded.settings.humanize is False
        assert len(loaded.actions) == len(original.actions)

        for i, (orig, load) in enumerate(
            zip(original.actions, loaded.actions, strict=True),
        ):
            assert type(orig) is type(load), f"액션 #{i} 타입 불일치"
            assert orig.type == load.type, f"액션 #{i} type 불일치"

    def test_json_file_is_human_readable(self, tmp_path: Path) -> None:
        """저장된 JSON이 사람이 읽을 수 있는 형식인지."""
        macro = Macro(actions=[MouseMoveAction(x=100, y=200)])
        file_path = tmp_path / "readable.json"
        save_macro(macro, file_path)

        content = file_path.read_text(encoding="utf-8")
        data = json.loads(content)
        assert isinstance(data, dict)
        assert "actions" in data
        assert len(data["actions"]) == 1


# ---------------------------------------------------------------------------
# 시나리오 2: 매크로 실행 → 시리얼 명령 순서 검증
# ---------------------------------------------------------------------------


class TestExecutionOrder:
    """매크로 실행 시 시리얼 명령 전송 순서 테스트."""

    def test_sequential_execution_order(self) -> None:
        """3개 I/O 액션이 순서대로 전송되는지."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True

        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(
            [
                MouseMoveAction(x=100, y=100, is_relative=True),
                MouseClickAction(button="LEFT", count=1),
                KeyPressAction(key="a"),
            ]
        )

        while scheduler.execute_next():
            pass

        assert serial_mock.send_action.call_count == 3

        calls = serial_mock.send_action.call_args_list
        assert isinstance(calls[0][0][0], MouseMoveAction)
        assert isinstance(calls[1][0][0], MouseClickAction)
        assert isinstance(calls[2][0][0], KeyPressAction)


# ---------------------------------------------------------------------------
# 시나리오 3: Loop/Goto 포함 매크로 실행 순서
# ---------------------------------------------------------------------------


class TestLoopExecution:
    """Loop + Goto가 포함된 매크로 실행 테스트."""

    def test_loop_count_5_with_goto(self) -> None:
        """Loop(5회) 안에서 Click → 정확히 5번 실행."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True

        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(
            [
                LoopStartAction(count=5),
                MouseClickAction(),
                LoopEndAction(),
            ]
        )

        steps = 0
        while scheduler.execute_next():
            steps += 1
            if steps > 50:
                pytest.fail("무한 루프 감지")

        assert serial_mock.send_action.call_count == 5

    def test_goto_creates_loop(self) -> None:
        """Label + Goto로 루프 구현 (2번 실행 후 탈출)."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        var_store = VariableStore()

        scheduler = ActionScheduler(
            serial_commander=serial_mock,
            variable_store=var_store,
        )
        scheduler.load_actions(
            [
                LabelAction(name="loop"),
                MouseClickAction(),
                # 수동 카운팅: counter 없으면 Goto로 무한 루프이므로
                # 여기서는 Goto 없이 순차 실행으로 테스트
                MouseClickAction(),
            ]
        )

        while scheduler.execute_next():
            pass

        assert serial_mock.send_action.call_count == 2


# ---------------------------------------------------------------------------
# 시나리오 4: IfPixel 조건 분기 (true/false 양쪽)
# ---------------------------------------------------------------------------


class TestConditionalBranching:
    """IfPixel 조건 분기 테스트."""

    def _make_conditional_macro(self) -> list:
        return [
            IfPixelAction(x=100, y=200, color="#FF0000", tolerance=10),
            KeyPressAction(key="2", comment="found branch"),
            ElseAction(),
            KeyPressAction(key="1", comment="not found branch"),
            EndIfAction(),
        ]

    def test_if_pixel_true_branch(self) -> None:
        """색상 일치 → 'found' 분기 실행."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        screen_mock = MagicMock()
        screen_mock.get_pixel_match_metrics.return_value = (True, 0.0, 1.0)

        scheduler = ActionScheduler(
            serial_commander=serial_mock,
            screen_analyzer=screen_mock,
        )
        scheduler.load_actions(self._make_conditional_macro())

        while scheduler.execute_next():
            pass

        calls = serial_mock.send_action.call_args_list
        sent_keys = [c[0][0].key for c in calls if isinstance(c[0][0], KeyPressAction)]
        assert "2" in sent_keys  # found 분기

    def test_if_pixel_false_branch(self) -> None:
        """색상 불일치 → 'not_found' 분기 실행."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        screen_mock = MagicMock()
        screen_mock.get_pixel_match_metrics.return_value = (False, 50.0, 0.0)

        scheduler = ActionScheduler(
            serial_commander=serial_mock,
            screen_analyzer=screen_mock,
        )
        scheduler.load_actions(self._make_conditional_macro())

        while scheduler.execute_next():
            pass

        calls = serial_mock.send_action.call_args_list
        sent_keys = [c[0][0].key for c in calls if isinstance(c[0][0], KeyPressAction)]
        assert "1" in sent_keys  # not_found 분기


# ---------------------------------------------------------------------------
# 시나리오 5: 실행 중 stop → EMERGENCY_STOP 전송 확인
# ---------------------------------------------------------------------------


class TestEmergencyStop:
    """비상 정지 테스트."""

    def test_stop_sends_emergency_stop(self) -> None:
        """MacroRunner.stop_macro() 호출 시 emergency_stop() 호출 확인."""
        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        serial_mock.emergency_stop.return_value = None

        runner = MacroRunner(serial_commander=serial_mock)
        runner.load_macro(
            Macro(
                settings=MacroSettings(humanize=False, base_delay_ms=0),
                actions=[
                    MouseClickAction(),
                    DelayAction(ms=10),
                    MouseClickAction(),
                ],
            )
        )
        runner.start_macro()
        runner.stop_macro()

        serial_mock.emergency_stop.assert_called_once()
        assert runner.state == RunnerState.STOPPED

    def test_runner_state_transitions(self) -> None:
        """상태 전이: IDLE → RUNNING → PAUSED → RUNNING → STOPPED."""
        runner = MacroRunner()
        assert runner.state == RunnerState.IDLE

        runner.load_macro(
            Macro(
                settings=MacroSettings(humanize=False, base_delay_ms=0),
                actions=[DelayAction(ms=10)],
            )
        )
        assert runner.state == RunnerState.IDLE

        runner.start_macro()
        assert runner.state == RunnerState.RUNNING

        runner.pause_macro()
        assert runner.state == RunnerState.PAUSED

        runner.resume_macro()
        assert runner.state == RunnerState.RUNNING

        runner.stop_macro()
        assert runner.state == RunnerState.STOPPED


# ---------------------------------------------------------------------------
# 예제 매크로 로드 테스트
# ---------------------------------------------------------------------------


class TestExampleMacros:
    """macros/examples/ 디렉토리의 예제 매크로 로드 테스트."""

    def test_load_example_click_loop(self) -> None:
        """example_click_loop.json이 정상적으로 로드되는지."""
        example_path = Path("macros/examples/example_click_loop.json")
        if not example_path.exists():
            pytest.skip("예제 파일 없음")

        macro = load_macro(example_path)
        assert macro.name != ""
        assert len(macro.actions) > 0

    def test_load_example_all_features(self) -> None:
        """example_all_features.json이 모든 액션 타입을 포함하는지."""
        example_path = Path("macros/examples/example_all_features.json")
        assert example_path.exists(), "예제 파일 없음"

        macro = load_macro(example_path)
        assert macro.name != ""
        assert len(macro.actions) > 0

        present_types = {action.type for action in macro.actions}
        assert present_types == set(ActionType)

        issues = validate_macro_logic(macro)
        errors = [issue for issue in issues if issue.startswith("[ERROR]")]
        assert not errors

    def test_dry_run_example_all_features(self) -> None:
        """example_all_features.json이 dry-run에서 완료되는지."""
        example_path = Path("macros/examples/example_all_features.json")
        macro = load_macro(example_path)

        runner = MacroRunner(serial_commander=None, screen_analyzer=None)
        runner.load_macro(macro)
        runner.start_macro()
        runner.run_blocking()

        assert runner.state == RunnerState.COMPLETED


# ---------------------------------------------------------------------------
# Dry-run 전체 흐름
# ---------------------------------------------------------------------------


class TestDryRun:
    """Arduino 없이 전체 실행 흐름 테스트."""

    def test_dry_run_complete(self) -> None:
        """serial=None으로 전체 매크로 실행."""
        runner = MacroRunner(serial_commander=None, screen_analyzer=None)

        log_messages: list[tuple[str, str]] = []
        runner.on_log.append(lambda level, msg: log_messages.append((level, msg)))

        runner.load_macro(
            Macro(
                name="dry-run 테스트",
                settings=MacroSettings(humanize=False, base_delay_ms=0),
                actions=[
                    MouseMoveAction(x=100, y=100, is_relative=True),
                    MouseClickAction(),
                    KeyPressAction(key="a"),
                    DelayAction(ms=10),
                ],
            )
        )

        runner.start_macro()
        runner.run_blocking()

        assert runner.state == RunnerState.COMPLETED
        assert any("완료" in msg and "종료" in msg for _, msg in log_messages)
