"""shared/keymap.py 단위 테스트."""

from __future__ import annotations

import pytest

from shared.keymap import (
    get_all_key_names,
    get_key_name,
    get_keycode,
    get_mouse_button_code,
    get_mouse_button_name,
    is_modifier_key,
)


class TestGetKeycode:
    """get_keycode() 테스트."""

    def test_alphabet_lowercase(self) -> None:
        assert get_keycode("a") == 0x61
        assert get_keycode("z") == 0x7A

    def test_digits(self) -> None:
        assert get_keycode("0") == 0x30
        assert get_keycode("9") == 0x39

    def test_function_keys(self) -> None:
        assert get_keycode("F1") == 0xC2
        assert get_keycode("F12") == 0xCD

    def test_modifiers(self) -> None:
        assert get_keycode("Ctrl") == 0x80
        assert get_keycode("Shift") == 0x81
        assert get_keycode("Alt") == 0x82
        assert get_keycode("Win") == 0x83

    def test_left_right_modifiers(self) -> None:
        assert get_keycode("LeftCtrl") == 0x80
        assert get_keycode("RightCtrl") == 0x84

    def test_special_keys(self) -> None:
        assert get_keycode("Enter") == 0xB0
        assert get_keycode("Esc") == 0xB1
        assert get_keycode("Space") == 0x20
        assert get_keycode("Tab") == 0xB3
        assert get_keycode("Backspace") == 0xB2

    def test_arrow_keys(self) -> None:
        assert get_keycode("Up") == 0xDA
        assert get_keycode("Down") == 0xD9
        assert get_keycode("Left") == 0xD8
        assert get_keycode("Right") == 0xD7

    def test_navigation_keys(self) -> None:
        assert get_keycode("Insert") == 0xD1
        assert get_keycode("Delete") == 0xD4
        assert get_keycode("Home") == 0xD2
        assert get_keycode("End") == 0xD5
        assert get_keycode("PageUp") == 0xD3
        assert get_keycode("PageDown") == 0xD6

    def test_unknown_key_raises(self) -> None:
        with pytest.raises(KeyError, match="알 수 없는 키 이름"):
            get_keycode("NonExistentKey")

    def test_aliases(self) -> None:
        assert get_keycode("Return") == get_keycode("Enter")
        assert get_keycode("Escape") == get_keycode("Esc")


class TestGetKeyName:
    """get_key_name() 역방향 조회 테스트."""

    def test_reverse_lookup(self) -> None:
        assert get_key_name(0xB0) == "Enter"
        assert get_key_name(0x61) == "a"

    def test_unknown_code_raises(self) -> None:
        with pytest.raises(KeyError, match="알 수 없는 키코드"):
            get_key_name(0x00)


class TestGetAllKeyNames:
    """get_all_key_names() 테스트."""

    def test_returns_sorted_list(self) -> None:
        names = get_all_key_names()
        assert names == sorted(names)

    def test_has_minimum_keys(self) -> None:
        names = get_all_key_names()
        assert len(names) >= 80

    def test_contains_common_keys(self) -> None:
        names = get_all_key_names()
        for key in ["a", "Enter", "F1", "Ctrl", "Space", "Up"]:
            assert key in names


class TestMouseButton:
    """마우스 버튼 매핑 테스트."""

    def test_left_button(self) -> None:
        assert get_mouse_button_code("LEFT") == 1

    def test_right_button(self) -> None:
        assert get_mouse_button_code("RIGHT") == 2

    def test_middle_button(self) -> None:
        assert get_mouse_button_code("MIDDLE") == 4

    def test_case_insensitive(self) -> None:
        assert get_mouse_button_code("left") == 1

    def test_unknown_button_raises(self) -> None:
        with pytest.raises(KeyError):
            get_mouse_button_code("EXTRA")

    def test_reverse_mouse(self) -> None:
        assert get_mouse_button_name(1) == "LEFT"
        assert get_mouse_button_name(2) == "RIGHT"


class TestIsModifierKey:
    """is_modifier_key() 테스트."""

    def test_modifiers_return_true(self) -> None:
        for key in ["Ctrl", "Shift", "Alt", "Win", "LeftCtrl", "RightAlt"]:
            assert is_modifier_key(key) is True

    def test_non_modifiers_return_false(self) -> None:
        for key in ["a", "F1", "Enter", "Space"]:
            assert is_modifier_key(key) is False
