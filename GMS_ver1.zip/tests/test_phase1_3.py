"""Phase 1~3 변경사항 테스트.

- Phase 1-1: _apply_debug_visuals → diff 기반 O(1) (UI 테스트 — skip if no PyQt6)
- Phase 1-3: stop_event를 통한 wait_for_* 즉시 중단
- Phase 3: 서브매크로 순환 참조 탐지
"""

from __future__ import annotations

import threading
import time
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from engine.scheduler import ActionScheduler, SchedulerError
from engine.variables import VariableStore
from shared.models import (
    ElseAction,
    EndIfAction,
    KeyPressAction,
    PixelWaitAction,
)

# ===================================================================
# 헬퍼
# ===================================================================


def make_scheduler(
    actions: list,
    mock_serial: bool = True,
    mock_screen: bool = True,
    stop_event: threading.Event | None = None,
) -> ActionScheduler:
    """테스트용 스케줄러를 생성한다."""
    serial_mock = MagicMock() if mock_serial else None
    if serial_mock:
        serial_mock.send_action.return_value = True

    screen_mock = MagicMock() if mock_screen else None

    scheduler = ActionScheduler(
        serial_commander=serial_mock,
        screen_analyzer=screen_mock,
        variable_store=VariableStore(),
        stop_event=stop_event,
    )
    scheduler.load_actions(actions)
    return scheduler


# ===================================================================
# Phase 1-3: stop_event → wait_for_* 즉시 중단
# ===================================================================


class TestStopEvent:
    """stop_event를 통한 wait_for_* 즉시 중단 테스트."""

    def test_pixel_wait_respects_stop_event(self) -> None:
        """PixelWait 중 stop_event가 set되면 즉시 탈출."""
        from engine.screen import ScreenAnalyzer

        stop_event = threading.Event()

        # 실제 ScreenAnalyzer 대신 mock 사용
        screen_mock = MagicMock(spec=ScreenAnalyzer)
        screen_mock.check_pixel_color.return_value = False  # 항상 불일치

        # 0.2초 후 stop_event set
        def delayed_stop() -> None:
            time.sleep(0.2)
            stop_event.set()

        threading.Thread(target=delayed_stop, daemon=True).start()

        _start = time.monotonic()
        _result = screen_mock.wait_for_pixel(
            100,
            200,
            "#FF0000",
            10,
            5000,
        )
        # mock이라 실제 루프를 타지 않으므로, screen.py의 실제 함수를 직접 테스트
        # 대신 ScreenAnalyzer 인스턴스 없이 함수 시그니처 검증

        # 실제 동작 테스트: stop_event 전달 시그니처 확인
        scheduler = ActionScheduler(
            serial_commander=None,
            screen_analyzer=screen_mock,
            variable_store=VariableStore(),
            stop_event=stop_event,
        )
        # stop_event가 scheduler에 저장되는지
        assert scheduler._stop_event is stop_event

    def test_scheduler_passes_stop_event_to_wait(self) -> None:
        """scheduler가 wait_for_pixel 호출 시 stop_event를 전달하는지."""
        stop_event = threading.Event()
        screen_mock = MagicMock()
        screen_mock.wait_for_pixel.return_value = True
        screen_mock.get_pixel_match_metrics.return_value = (True, 0.0, 1.0)

        scheduler = ActionScheduler(
            serial_commander=None,
            screen_analyzer=screen_mock,
            variable_store=VariableStore(),
            stop_event=stop_event,
        )
        scheduler.load_actions(
            [
                PixelWaitAction(
                    x=100,
                    y=200,
                    color="#FF0000",
                    tolerance=10,
                    timeout_ms=5000,
                ),
                ElseAction(),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()

        # wait_for_pixel 호출 시 stop_event= 키워드가 전달되었는지
        screen_mock.wait_for_pixel.assert_called_once()
        call_kwargs = screen_mock.wait_for_pixel.call_args
        assert call_kwargs.kwargs.get("stop_event") is stop_event

    def test_stop_event_none_is_backward_compatible(self) -> None:
        """stop_event=None (기본값)으로 생성해도 정상 동작."""
        screen_mock = MagicMock()
        screen_mock.wait_for_pixel.return_value = True
        screen_mock.get_pixel_match_metrics.return_value = (True, 0.0, 1.0)

        scheduler = ActionScheduler(
            serial_commander=None,
            screen_analyzer=screen_mock,
            variable_store=VariableStore(),
            # stop_event 미전달 → None
        )
        scheduler.load_actions(
            [
                PixelWaitAction(
                    x=100,
                    y=200,
                    color="#FF0000",
                    tolerance=10,
                    timeout_ms=1000,
                ),
                ElseAction(),
                EndIfAction(),
            ]
        )

        scheduler.execute_next()
        screen_mock.wait_for_pixel.assert_called_once()
        call_kwargs = screen_mock.wait_for_pixel.call_args
        assert call_kwargs.kwargs.get("stop_event") is None


# ===================================================================
# Phase 3: 서브매크로 순환 참조 탐지
# ===================================================================


class TestSubMacroCycleDetection:
    """서브매크로 순환 참조 탐지 테스트."""

    def test_direct_self_recursion_detected(self, tmp_path: Path) -> None:
        """A.json이 자기 자신을 호출하면 순환 참조 에러."""
        macro_a = tmp_path / "a.json"
        macro_a.write_text(
            '{"name":"A","version":"1.0","actions":['
            '{"type":"KEY_PRESS","key":"1"},'
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_a).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        from shared.schema import load_macro

        macro = load_macro(str(macro_a))

        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(macro.actions, source_path=str(macro_a))

        # KEY_PRESS 실행
        scheduler.execute_next()

        # SUB_MACRO_CALL → 자기 자신 → 순환 참조
        with pytest.raises(SchedulerError, match="순환 참조"):
            scheduler.execute_next()

    def test_indirect_cycle_a_b_a_detected(self, tmp_path: Path) -> None:
        """A→B→A 간접 순환 참조 감지."""
        macro_a = tmp_path / "a.json"
        macro_b = tmp_path / "b.json"

        # B가 A를 호출
        macro_b.write_text(
            '{"name":"B","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_a).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        # A가 B를 호출
        macro_a.write_text(
            '{"name":"A","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_b).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        from shared.schema import load_macro

        macro = load_macro(str(macro_a))

        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(macro.actions, source_path=str(macro_a))

        # A의 SUB_MACRO_CALL → B 진입
        scheduler.execute_next()

        # B의 SUB_MACRO_CALL → A 시도 → 순환 참조
        with pytest.raises(SchedulerError, match="순환 참조"):
            scheduler.execute_next()

    def test_non_cyclic_deep_call_allowed(self, tmp_path: Path) -> None:
        """순환이 아닌 깊은 호출 (A→B→C)은 허용."""
        macro_c = tmp_path / "c.json"
        macro_c.write_text(
            '{"name":"C","version":"1.0","actions":[' '{"type":"KEY_PRESS","key":"3"}' "]}",
            encoding="utf-8",
        )

        macro_b = tmp_path / "b.json"
        macro_b.write_text(
            '{"name":"B","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_c).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        macro_a = tmp_path / "a.json"
        macro_a.write_text(
            '{"name":"A","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_b).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        from shared.schema import load_macro

        macro = load_macro(str(macro_a))

        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(macro.actions, source_path=str(macro_a))

        # A → B → C 순차 진입/복귀 — 에러 없이 완료
        steps = 0
        while scheduler.execute_next():
            steps += 1
            if steps > 20:
                pytest.fail("무한 루프 감지")

        assert scheduler.is_finished


# ===================================================================
# Phase 1-3: runner의 stop_event 라이프사이클
# ===================================================================


class TestRunnerStopEvent:
    """runner의 stop_event 관리 테스트."""

    def test_stop_event_lifecycle(self) -> None:
        """start에서 clear, stop에서 set."""
        from engine.runner import MacroRunner
        from shared.models import Macro, MacroSettings

        runner = MacroRunner(serial_commander=None, screen_analyzer=None)

        macro = Macro(
            name="test",
            actions=[KeyPressAction(key="a")],
            settings=MacroSettings(),
        )

        runner.load_macro(macro)

        # start 전에는 clear 상태
        assert not runner._stop_event.is_set()

        runner.start_macro()
        # start 후에도 clear
        assert not runner._stop_event.is_set()

        runner.stop_macro()
        # stop 후 set
        assert runner._stop_event.is_set()

        # 재시작하면 clear
        runner.load_macro(macro)
        runner.start_macro()
        assert not runner._stop_event.is_set()


# ===================================================================
# Phase 3-2: 서브매크로 사전 로딩
# ===================================================================


class TestSubMacroPreload:
    """서브매크로 사전 로딩 테스트."""

    def test_preload_caches_sub_macros(self, tmp_path: Path) -> None:
        """load_actions 시 서브매크로가 캐시에 저장되는지."""
        macro_sub = tmp_path / "sub.json"
        macro_sub.write_text(
            '{"name":"Sub","version":"1.0","actions":[' '{"type":"KEY_PRESS","key":"x"}' "]}",
            encoding="utf-8",
        )

        from shared.schema import load_macro

        main_macro = tmp_path / "main.json"
        main_macro.write_text(
            '{"name":"Main","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_sub).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        macro = load_macro(str(main_macro))

        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(macro.actions)

        # 캐시에 sub.json이 사전 로딩되었는지
        resolved_sub = str(macro_sub.resolve())
        assert resolved_sub in scheduler._sub_macro_cache
        assert scheduler._sub_macro_cache[resolved_sub].name == "Sub"

    def test_preload_recursive_caches_nested(self, tmp_path: Path) -> None:
        """A→B→C 구조에서 B와 C 모두 사전 로딩되는지."""
        macro_c = tmp_path / "c.json"
        macro_c.write_text(
            '{"name":"C","version":"1.0","actions":[' '{"type":"KEY_PRESS","key":"3"}' "]}",
            encoding="utf-8",
        )

        macro_b = tmp_path / "b.json"
        macro_b.write_text(
            '{"name":"B","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_c).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        macro_a = tmp_path / "a.json"
        macro_a.write_text(
            '{"name":"A","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_b).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        from shared.schema import load_macro

        macro = load_macro(str(macro_a))

        serial_mock = MagicMock()
        serial_mock.send_action.return_value = True
        scheduler = ActionScheduler(serial_commander=serial_mock)
        scheduler.load_actions(macro.actions)

        # B와 C 모두 캐시에 있어야 함
        assert str(macro_b.resolve()) in scheduler._sub_macro_cache
        assert str(macro_c.resolve()) in scheduler._sub_macro_cache

    def test_cache_survives_reset(self, tmp_path: Path) -> None:
        """reset() 후에도 캐시가 유지되는지."""
        macro_sub = tmp_path / "sub.json"
        macro_sub.write_text(
            '{"name":"Sub","version":"1.0","actions":[' '{"type":"KEY_PRESS","key":"x"}' "]}",
            encoding="utf-8",
        )

        from shared.schema import load_macro

        main_macro = tmp_path / "main.json"
        main_macro.write_text(
            '{"name":"Main","version":"1.0","actions":['
            '{"type":"SUB_MACRO_CALL","macro_path":"' + str(macro_sub).replace("\\", "\\\\") + '"}'
            "]}",
            encoding="utf-8",
        )

        macro = load_macro(str(main_macro))

        scheduler = ActionScheduler(serial_commander=MagicMock())
        scheduler._serial.send_action.return_value = True
        scheduler.load_actions(macro.actions)

        cache_before = dict(scheduler._sub_macro_cache)
        scheduler.reset()

        assert scheduler._sub_macro_cache == cache_before
