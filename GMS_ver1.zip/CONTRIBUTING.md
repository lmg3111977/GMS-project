# Contributing

## 원칙

- [`docs/governance/constitution.md`](docs/governance/constitution.md), [`docs/governance/quality-gates.md`](docs/governance/quality-gates.md) 준수
- 신규 코드는 **`shared/`, `engine/`, `editor/`, `player/`, `tests/`** 범위에서 작업
- 매크로 샘플이 필요하면 `macros/examples/` 에 추가하고 문서에 링크

## 브랜치

- `main`: CI 통과 유지
- `feature/<topic>`, `fix/<topic>`

## 로컬 검증 (필수)

[Quality Gates](docs/governance/quality-gates.md)의 명령을 모두 통과해야 합니다.

## PR 체크리스트

- [ ] 목적·범위 설명
- [ ] `tests/` 추가/갱신
- [ ] `README.md` / `QUICKSTART.md` / 온보딩·트러블슈팅 중 해당 문서 갱신
- [ ] `macros/examples/` 또는 스키마 변경 시 계약 문서 동기화
- [ ] 안전·장치 연결 관련 변경 시 [`docs/governance/constitution.md`](docs/governance/constitution.md) §9 또는 [`docs/user/troubleshooting.md`](docs/user/troubleshooting.md) 반영

## 리뷰 기준

- 현재 아키텍처 경계 준수 (`shared/`, `engine/`, `editor/`, `player/`, `tests/`)
- 회귀 테스트로 의미 보존
- 초보자 문서와 명령어 일치
