# CLAUDE.md

## 시작
"작업 현황" 1줄 요약 후 시작. "이어서 해줘"면 즉시 재개.

## 응답 형식
**구현:** 상황 1줄 → 수정대상(파일·함수·변경점) → Cursor 프롬프트
**탐색/분석:** 현황요약 → 분석/설계안 → 다음단계 제안

## 검증 (프로젝트 특화)
- 빠른: `ruff check [변경파일]`
- 전체: `ruff check shared engine editor player tests && black --check shared engine editor player tests && pytest -q tests`
- 성능: 악화율 >1.0%면 실패

## Cursor 프롬프트 원칙
파일·함수·목적 첫줄 / old코드 스니펫 필수 / 출력예시 / 품질+주의사항 상단 / 검증명령 끝에 / 불확실 시 TODO
구조: `목적 / 주의사항 / 수정N(파일-함수: old→new) / 검증명령`

## 작업 현황
- [ ] ScreenPort 연동 및 조건 액션 설계
- [ ] 에디터: 액션 추가/편집 UI 확장
- [x] 편의성 기능 점검
