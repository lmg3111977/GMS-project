# Skill: 새 액션 추가

## 목표

현재 매크로 구조(v1.0)에 액션 타입을 추가하고 스키마·실행기·테스트를 맞춘다.

## 단계

1. `shared/models/` — 액션 모델 추가/확장
2. `shared/schema.py` — 로딩/검증 경로 반영
3. `engine/scheduler/` — 해당 액션 핸들러 실행 분기 반영
4. `tests/` — 정상/실패 케이스 추가
5. `macros/examples/` — 최소 예제 JSON 추가
6. 관련 문서 — 지원 액션 목록 갱신

## 검증

[Quality Gates](../docs/governance/quality-gates.md) 통과 확인.
