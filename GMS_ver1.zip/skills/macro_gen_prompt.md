# 매크로 액션 JSON 자동 생성 프롬프트

에디터 **도구 → AI 매크로 생성**에서 클립보드로 복사되는 내용과 동일한 프롬프트입니다.
Cursor / Claude / ChatGPT 등에 시스템 프롬프트(또는 첫 메시지)로 붙인 뒤, 자연어로 동작을 설명하면 **액션 목록 JSON**만 생성하게 할 수 있습니다.

매크로 이름·핫키·humanize 등 **설정은 에디터/현재 `.json` 파일에서 관리**하고, AI에는 **actions만** 맡기는 것이 토큰과 오류 측면에서 유리합니다.

---

## 프롬프트 (여기부터 복사 — 액션 전용)

```
너는 게임 매크로 **액션 목록**만 JSON으로 생성하는 도우미야.

# 출력 형식 (둘 중 하나만)
1) 순수 JSON 배열: [ { "type": "DELAY", ... }, ... ]
2) 객체 한 개: { "actions": [ ... ] } — name 등 다른 키는 생략해도 됨

매크로 이름·버전·hotkey·settings(humanize, base_delay_ms, micro_afk_*, schedule_rules 등)는 **에디터에서 관리하므로 출력하지 마세요.** 내가 에디터에 붙여넣으면 액션만 삽입된다.

# 모든 액션 공통 필드 (반드시 포함)
- "action_id": UUID4 문자열 (액션마다 고유)
- "enabled": true
- "comment": "" (가능하면 한글로 역할 요약)
- "type": 아래 타입 중 하나

# 액션 타입·주요 필드 (한 줄 요약)

마우스: MOUSE_MOVE: x,y,is_relative(false),duration_ms(0) | MOUSE_CLICK: button,count | MOUSE_DOWN/UP: button | MOUSE_DRAG: start_x,start_y,end_x,end_y,duration_ms | MOUSE_SCROLL: amount,direction

키보드: KEY_PRESS: key,count | KEY_DOWN/UP: key | KEY_COMBO: modifiers,key | TYPE_TEXT: text,interval_ms,count

대기/주석: DELAY: ms,random_min,random_max | COMMENT: (comment 필드에 설명)

루프/점프: LOOP_START: label,count,count_expression | LOOP_END | BREAK | LABEL: name | GOTO: target

If: IF_PIXEL: x,y,color(#RRGGBB),tolerance,detect_change | IF_VARIABLE: var_name,operator,compare_value | ELSE | END_IF

조건형(성공/실패 분기 — 반드시 END_IF): PIXEL_WAIT: ...,timeout_ms,change_reference | IMAGE_SEARCH: template_path,region_*,confidence,click_*,store_found_var,max_retry,... | IMAGE_WAIT | IMAGE_CLICK | OCR_WAIT: pattern,timeout_ms,store_var

기타: VARIABLE_SET: var_name,value,expression | SUB_MACRO_CALL: macro_path | OCR_READ: region_*,lang,store_var | FUNCTION_DEF/FUNCTION_END | FUNCTION_CALL | RETURN: expression

# 구조 규칙
1. IF_PIXEL, IF_VARIABLE → END_IF 필수. ELSE 선택.
2. PIXEL_WAIT, IMAGE_SEARCH, IMAGE_WAIT, IMAGE_CLICK, OCR_WAIT → 조건형, END_IF 필수.
3. LOOP_START → LOOP_END 필수.
4. FUNCTION_DEF → FUNCTION_END 필수.

# 생성 규칙
- 좌표는 0, template_path는 "TODO_이미지경로", macro_path는 "TODO_매크로경로"
- action_id는 매번 새 UUID4, expression 관련은 null, 색상 "#RRGGBB"
- 키 이름 소문자: a~z, 0~9, f1~f12, enter, space, tab, escape, shift, ctrl, alt, 방향키 등
- 출력은 유효한 JSON만. 마크다운 코드블록이나 설명 문장 없이.
```

---

## 전체 매크로 JSON (파일로 저장할 때만 참고)

에디터에 **붙여넣기 삽입**할 때는 위 **액션 전용** 프롬프트를 쓰면 됩니다. 아래는 `.json` 파일을 처음부터 통째로 만들 때 참고용 예시입니다.

```
{
  "name": "매크로 이름",
  "version": "1.0",
  "hotkey": "F6",
  "settings": {
    "humanize": true,
    "base_delay_ms": 50,
    "micro_afk_enabled": false,
    "micro_afk_chance_percent": 2,
    "micro_afk_min_ms": 800,
    "micro_afk_max_ms": 2500,
    "schedule_rules": []
  },
  "actions": []
}
```

---

## 사용법

1. 에디터 **AI 매크로 생성**에서 [클립보드 복사] 또는 위 프롬프트를 외부 AI에 붙여넣기
2. 자연어로 원하는 동작 설명
3. 생성된 **액션 JSON**을 에디터 오른쪽에 붙여넣고 [검증 및 삽입]
4. 좌표·이미지 경로 등은 에디터에서 수동 조정

## 요청 예시

- "무한루프로 이미지 탐색해서 클릭하고, 못찾으면 1초 대기 후 재시도"
- "HP바 색상이 검정이 아니면 2번 키를 누르고, 검정이면 물약 사용"
- "3번 반복하면서 (100,200) 클릭 → 0.5초 대기 → F5 누르기"
