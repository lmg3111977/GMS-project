# Skill: 스키마 / Macro 변경

## 목표

매크로 계약(v1.0)을 바꿀 때 스키마·모델·테스트를 동시에 맞춘다.

## 단계

1. `shared/schema.py` — 검증/로딩 규칙 갱신
2. `shared/models/` — 모델 구조 및 필드 매핑 갱신
3. 기존 샘플 JSON 전수 검색·갱신
4. `tests/` 회귀 테스트 갱신
5. `docs/governance/constitution.md` 또는 온보딩에 변경 요약(필요 시)

## 검증

`docs/governance/constitution.md` 품질 게이트와 동일.
