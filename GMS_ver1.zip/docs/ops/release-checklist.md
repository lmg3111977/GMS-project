# Release Checklist

## 품질 게이트

- [ ] [Quality Gates](../governance/quality-gates.md)의 전체 명령 통과 확인

## 동작

- [ ] `python main.py --run macros/examples/example_click_loop.json --dry-run`
- [ ] `python main.py` GUI 실행

## 문서

- [ ] `README.md`, `QUICKSTART.md` 링크 유효
- [ ] `docs/governance/constitution.md`와 명령 일치
- [ ] `docs/user/troubleshooting.md` 반영

## 배포 메모

- [ ] 변경 요약
- [ ] 알려진 제한(Stub 기본 등)
