# 단축키 가이드

GameMacroStudio에서 현재 동작하는 단축키를 한 곳에 정리한 문서입니다.

## 에디터 공통

- `Ctrl+N`: 새 매크로 만들기
- `Ctrl+O`: 매크로 열기
- `Ctrl+S`: 저장
- `Ctrl+Shift+S`: 다른 이름으로 저장
- `Ctrl+Shift+V`: 매크로 검증
- `Alt+F4`: 프로그램 종료

## 실행/디버그

- `Ctrl+F5`: 매크로 실행
- `Ctrl+F6`: 일시정지/재개 토글
- `Ctrl+F7`: 정지
- `Ctrl+R`: 녹화 시작/정지
- `F8`: 현재 마우스 좌표 + 픽셀 색상 캡처
  - 누를 때마다 히스토리에 누적 저장(최근 10개)
  - 동일 좌표/색상 연속 캡처 시 중복 추가 안 됨
  - 파라미터 패널의 "F8 자동 입력" 버튼은 가장 최근 캡처 항목을 우선 적용
  - 상태바의 히스토리 콤보에서 이전 캡처를 선택해 활성 항목으로 전환 가능(항목 왼쪽에 색상 스와치 표시)
  - 상태바의 색 미리보기 칩에 실제 픽셀 색이 표시됨, 마우스를 올리면 HEX·클립보드 문자열 확인
  - 시스템 클립보드도 최신값으로 동시 갱신(기존 방식과 호환)
- `F9`: 현재 액션 브레이크포인트 토글
- `F10`: 1스텝 실행

## 편집/화면

- `Ctrl+Z`: 실행 취소 (액션 리스트 포커스일 때, **접기 상태·브레이크포인트** 포함)
- `Ctrl+Y`: 다시 실행 (액션 리스트 포커스일 때)
- `Delete` / `Backspace`: 선택된 액션 삭제 (액션 리스트 포커스일 때; Windows/Qt에서는 단축키 표시가 `Del`로 보일 수 있음)
- `Ctrl+D`: 선택된 행 복제 (액션 리스트 포커스일 때, 다중 선택 시 각 행마다 복제)
- `Ctrl+L`: 하단 패널(실행 로그 · 이미지/픽셀 캡처) 표시/숨김

## 플레이어 모드

- `Ctrl+F5`: 실행
- `Ctrl+F6`: 일시정지/재개
- `Ctrl+F7`: 정지

위 3개는 전역 핫키로 등록되어, 다른 창이 활성화된 상태에서도 동작하도록 설계되어 있습니다.

## 문서·코드·테스트 동기화

- 앱 내 단축키 등록(실행/디버그·편집 중 일부): `editor/main_window/hotkeys.py` (`_setup_shortcuts`, 전역 핫키는 `_setup_global_hotkeys`)
- 파일/도구 메뉴 단축키: `editor/main_window/window.py` (`_setup_menu_bar`)
- 하단 패널 `Ctrl+L`: `editor/main_window/log_dock.py`
- 액션 리스트 단축키(바인딩·Undo 스냅샷): `tests/test_action_list_shortcuts.py` (`pytest -q tests/test_action_list_shortcuts.py`)
- QTest 실제 키 입력·포커스·하단 패널 `Ctrl+L` 패턴·메뉴 단축키: `tests/test_action_list_shortcuts_qtest.py` (`pytest -q tests/test_action_list_shortcuts_qtest.py`)
