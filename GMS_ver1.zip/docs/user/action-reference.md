# 액션 타입 참고 (Macro v1.0)

`shared/models/enums.py` 의 `ActionType` 과 동일합니다. JSON 의 `type` 필드에 아래 문자열이 들어갑니다.

| type | 설명 |
|------|------|
| `MOUSE_MOVE` | 마우스 이동 |
| `MOUSE_CLICK` | 클릭 |
| `MOUSE_DOWN` / `MOUSE_UP` | 버튼 누름/뗌 |
| `MOUSE_DRAG` | 드래그 |
| `MOUSE_SCROLL` | 스크롤 |
| `KEY_PRESS` / `KEY_DOWN` / `KEY_UP` | 키 입력 |
| `KEY_COMBO` | 조합키 |
| `TYPE_TEXT` | 문자열 입력 |
| `DELAY` | 대기 |
| `LOOP_START` / `LOOP_END` | 반복 블록 |
| `LABEL` / `GOTO` | 점프 |
| `BREAK` | 루프 탈출 |
| `IF_PIXEL` | 픽셀 색 조건 |
| `ELSE` / `END_IF` | 분기 구조 (구조형 if와 짝) |
| `PIXEL_WAIT` | 픽셀 대기 |
| `IMAGE_SEARCH` / `IMAGE_WAIT` / `IMAGE_CLICK` | 이미지 검색·대기·클릭 |
| `OCR_READ` | 화면 영역에서 글자를 한 번 읽어 변수에 저장 (구조형 If 블록 아님) |
| `OCR_WAIT` | OCR로 패턴이 보일 때까지 대기 후 then/else 분기 (If·Else·EndIf와 함께 사용) |
| `VARIABLE_SET` | 변수 대입 |
| `IF_VARIABLE` | 변수 비교 분기 |
| `SUB_MACRO_CALL` | 다른 JSON 매크로 호출 |
| `COMMENT` | 구간 메모 (실행 무시) |
| `FUNCTION_DEF` | 함수 정의 시작 (이름·매개변수) |
| `FUNCTION_END` | 함수 정의 끝 (FUNCTION_DEF와 짝) |
| `FUNCTION_CALL` | 함수 호출 (인자 전달·반환값 변수 저장) |
| `RETURN` | 함수 반환 (수식 평가 후 호출자 변수에 저장) |

## 에디터 좌측 버튼 이름 ↔ JSON `type`

에디터 그리드에 보이는 라벨(영문 약어·한글)과 JSON의 `type` 문자열 대응입니다. 같은 타입은 한 그룹에 한 번만 배치됩니다.

| 에디터 버튼 (표시명) | `type` |
|---------------------|--------|
| Click | `MOUSE_CLICK` |
| Move | `MOUSE_MOVE` |
| Down / Up | `MOUSE_DOWN` / `MOUSE_UP` |
| Drag | `MOUSE_DRAG` |
| Scroll | `MOUSE_SCROLL` |
| Press | `KEY_PRESS` |
| Down / Up (키보드) | `KEY_DOWN` / `KEY_UP` |
| Combo | `KEY_COMBO` |
| Text | `TYPE_TEXT` |
| Delay | `DELAY` |
| Comment | `COMMENT` |
| VarSet | `VARIABLE_SET` |
| IfPixel | `IF_PIXEL` |
| IfVar | `IF_VARIABLE` |
| PixWait | `PIXEL_WAIT` |
| ImgSearch / ImgWait / ImgClick | `IMAGE_SEARCH` / `IMAGE_WAIT` / `IMAGE_CLICK` |
| OCR읽기 / OCR대기 | `OCR_READ` / `OCR_WAIT` |
| For(Loop+) / EndFor(Loop-) | `LOOP_START` / `LOOP_END` |
| Else / EndIf | `ELSE` / `END_IF` |
| Break | `BREAK` |
| Label / Goto | `LABEL` / `GOTO` |
| SubCall | `SUB_MACRO_CALL` |
| 함수 정의 / 함수 끝 / 함수 호출 / 반환 | `FUNCTION_DEF` / `FUNCTION_END` / `FUNCTION_CALL` / `RETURN` |

## 함수 기능 사용 예

에디터 우측 패널의 이름과 JSON 파일에 저장되는 필드 이름은 아래처럼 대응합니다.

| 화면에서 보이는 이름 | JSON 필드 (FUNCTION_CALL 등) |
|----------------------|------------------------------|
| 함수 이름 | `target` |
| 인자 | `args` (목록) |
| 반환 변수 | `return_var` |
| (함수 정의) 매개변수 | `params` (목록) |
| (반환 액션) 반환 수식 | `expression` |

```
# 1) 함수 정의 (JSON: FUNCTION_DEF … FUNCTION_END)
FUNCTION_DEF  name=hp_check  params=[]
  VARIABLE_SET  var_name=result  value=100   # 실제로는 OCR/이미지로 읽어올 수 있음
  RETURN  expression={result}
FUNCTION_END

# 2) 함수 호출 — 화면에서는 「함수 이름」「인자」「반환 변수」에 각각 대응
FUNCTION_CALL  target=hp_check  args=[]  return_var=hp

# 3) IfVariable로 분기
IF_VARIABLE  var_name=hp  operator=<  compare_value=30
  ...위험 상태 처리...
ELSE
  ...정상 처리...
END_IF
```

**스코프 규칙**:
- 함수 내부에서 선언된 변수는 로컬 — 함수 종료 후 사라짐
- 함수 내부에서 글로벌 변수를 읽을 수 있음 (로컬 우선, 없으면 글로벌 fallback)
- **반환 변수**(`return_var`)로 지정한 이름은 매크로 전역 변수에 저장됨

**제한**:
- 재귀 깊이 최대 10단계
- 함수 이름: 영문·숫자·밑줄, 영문/밑줄로 시작
- `RETURN` 없이 `FUNCTION_END`(함수 끝)에 도달하면 빈 문자열(`""`) 반환

필드 정의는 각 `shared/models/*.py` 의 Pydantic 모델을 참고하세요. 저장 시 검증은 [`shared/schema.py`](../../shared/schema.py) 를 따릅니다.
