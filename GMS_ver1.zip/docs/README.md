# 문서 안내

## 📐 spec/ — 기술 스펙

구현 기준이 되는 설계 문서.

- [auth-login.md](spec/auth-login.md) — GAS 로그인 스펙
- [tech-overview.md](spec/tech-overview.md) — 기술 개요

## 📏 governance/ — 규칙·정책

반드시 준수해야 하는 규범.

- [constitution.md](governance/constitution.md) — 최상위 규범 (헌법)
- [quality-gates.md](governance/quality-gates.md) — 품질 게이트

## 🤖 ai-collaboration/ — AI 협업

Claude Code + Cursor 워크플로우.

- [ai-workflow.md](ai-collaboration/ai-workflow.md) — 작업 흐름
- [role-division.md](ai-collaboration/role-division.md) — 역할 분담
- [unified-template.md](ai-collaboration/prompt-templates/unified-template.md) — Cursor 프롬프트 템플릿

## 📖 user/ — 사용자 가이드

프로그램 사용법.

- [action-reference.md](user/action-reference.md) — 액션 레퍼런스
- [shortcut-guide.md](user/shortcut-guide.md) — 단축키 가이드
- [troubleshooting.md](user/troubleshooting.md) — 문제 해결

## 🚀 onboarding/ — 시작 가이드

처음 참여하는 개발자·사용자용.

- [first-macro.md](onboarding/first-macro.md) — 첫 매크로 만들기
- [editor-walkthrough.md](onboarding/editor-walkthrough.md) — 에디터 둘러보기

## 📋 ops/ — 운영

릴리스·배포 절차.

- [release-checklist.md](ops/release-checklist.md) — 릴리스 체크리스트
