# GameMacroStudio — Constitution

> 이 문서는 **현재 코드베이스의 단일 최상위 규범**입니다.
> AI 코딩 도구에 **항상 컨텍스트로 제공**하세요.
> 이 규칙을 위반하는 코드는 머지하지 않습니다.

---

## 1. 프로젝트 개요

- **이름**: GameMacroStudio
- **목적**: Arduino Leonardo(ATmega32U4)와 시리얼 통신하여 HID(마우스/키보드)를 제어하는 PC 기반 게임 매크로 제작 프로그램
- **핵심 원칙**: PC가 두뇌, Arduino는 손. 모든 연산/로직/조건판단은 PC에서 처리하고, Arduino는 시리얼 명령을 HID 출력으로 변환하는 브릿지 역할만 수행

---

## 2. 소스 오브 트루스 (경로)

| 영역 | 경로 |
|------|------|
| 진입점 | `main.py` (AppContext → EditorSession 또는 headless_run) |
| 데이터 모델 | `shared/models/` (enums, base, mouse, keyboard, flow, image, variable, ocr, macro) |
| 프로토콜 | `shared/protocol.py`, `shared/keymap.py` |
| 스키마 로드/저장 | `shared/schema.py` |
| 유틸리티 | `shared/humanizer.py`, `shared/mouse_utils.py`, `shared/config.py` |
| 엔진 | `engine/runner.py`, `engine/scheduler/`, `engine/serial_cmd.py`, `engine/screen.py` |
| 에디터 UI | `editor/main_window/` (window + 8 mixin), `editor/param_panel/` (panel + 7 widget 그룹) |
| 에디터 세션 | `editor/session.py`, `editor/action_list.py`, `editor/recorder.py` |
| 플레이어 | `player/session.py`, `player/tray_app.py` |
| 테스트 | `tests/` |
| Arduino | `arduino/hid_bridge/hid_bridge.ino` |

---

## 3. 언어 및 런타임

| 항목 | 규칙 |
|------|------|
| Python 버전 | 3.11 이상 필수 |
| Type hint | 모든 함수, 메서드의 매개변수와 반환값에 필수 |
| Docstring | Google style, 모든 public 클래스/함수에 필수 |
| 인코딩 | UTF-8 (BOM 없음) |
| 최대 줄 길이 | 100자 (black 포매터 설정) |

---

## 4. 네이밍 규칙

| 대상 | 규칙 | 예시 |
|------|------|------|
| 파일명 | snake_case.py | `serial_cmd.py`, `flow_handlers.py` |
| 클래스 | PascalCase | `ActionScheduler`, `MacroEditorWindow` |
| 함수 / 메서드 | snake_case | `load_macro()`, `_handle_loop_start()` |
| 상수 | UPPER_SNAKE_CASE | `SUPPORTED_TYPES`, `DEFAULT_BAUD_RATE` |
| Private | `_` 접두사 | `_device`, `_dispatch_action()` |
| 테스트 | `test_` 접두사 | `test_load_macro_success()` |
| Mixin | `...Mixin` 접미사 | `FileIOMixin`, `FlowHandlersMixin` |

### 금지되는 이름

- 한 글자 변수 (루프 카운터 `i`, `j`, `k` 제외)
- 축약어 (`mgr` → `manager`, `btn` → `button`). 단, 업계 표준은 허용: `msg`, `config`, `args`, `id`, `ui`

---

## 5. 아키텍처 규칙

### 5.1 패키지 구조 (의존성 방향)

```
main.py (진입점, AppContext)
  ├── editor/      → shared/, engine/
  ├── player/      → shared/, engine/
  ├── engine/      → shared/ (PyQt 의존 금지)
  └── shared/      → 표준 라이브러리 + pydantic만
```

### 5.2 파일 분리 원칙 (바이브코딩 최적화)

- **300줄 초과 금지**: 파일이 300줄을 넘으면 패키지/mixin으로 분리
- **이유**: AI의 컨텍스트 윈도우 효율 극대화
- **분리 방법**: 패키지 변환(`__init__.py` re-export) 또는 mixin 패턴

### 5.3 현재 패키지 구조

| 원래 파일 | 분리 결과 |
|-----------|----------|
| `shared/models.py` (1202줄) | `shared/models/` 패키지 (9개 파일: enums, base, mouse, keyboard, flow, image, variable, ocr, macro) |
| `editor/param_panel.py` (2860줄) | `editor/param_panel/` 패키지 (8개 파일: base, mouse/keyboard/flow/image/ocr_widgets, panel) |
| `editor/main_window.py` (2784줄) | `editor/main_window/` 패키지 (10개 파일: window + 8 mixin) |
| `engine/scheduler.py` (1648줄) | `engine/scheduler/` 패키지 (9개 파일: core + 7 mixin + models) |

### 5.4 Import 규칙

- `shared/` 안에서는 외부 라이브러리 의존 **pydantic만** 허용
- `engine/`은 PyQt6 의존 **금지** (GUI 없이 테스트 가능해야 함)
- `editor/`, `player/`에서만 PyQt6 사용
- 순환 의존 발생 시 **구조 결함** — 코드가 아니라 의존 방향을 고친다

---

## 6. Macro Format

- 스키마 버전: `"1.0"` (Pydantic BaseModel 기반)
- 로더/검증: `shared/schema.py`
- 지원 액션: `shared/models/enums.py`의 `ActionType` (29종)
- 파일 포맷: JSON (UTF-8, 들여쓰기 2칸)

---

## 7. 시리얼 통신 규칙

### 7.1 연결 설정

| 항목 | 값 |
|------|-----|
| 보드레이트 | 115200 (고정) |
| 읽기 타임아웃 | 100ms |
| 연결 타임아웃 | 3000ms |

### 7.2 패킷 포맷

```
[STX 0x02] [CMD 1B] [LENGTH 1B] [PAYLOAD 0~60B] [CHECKSUM 1B] [ETX 0x03]
```

### 7.3 안전 장치

- EMERGENCY_STOP(0xFF): 수신 즉시 모든 키/마우스 해제
- COM 포트 하드코딩 **금지** — VID/PID(`2341:8036`) 자동탐지
- Arduino 부팅 후 5초 대기

---

## 8. 에러 처리 규칙

- `print()` 사용 **금지** — 모든 출력은 `logging` 모듈
- 로거: `logging.getLogger(__name__)`
- bare `except:` 사용 **금지** — 구체적 예외 타입 명시
- 예외 발생 시 `logger.exception()` 호출

---

## 9. 금지 패턴

```python
# ❌ 와일드카드 import
from shared.models import *
# ✅ 명시적 import
from shared.models import MouseClickAction

# ❌ time.sleep() 직접 호출
time.sleep(0.5)
# ✅ humanizer 또는 interruptible 경유
from shared.humanizer import sync_human_delay

# ❌ 하드코딩 COM 포트
serial.Serial("COM3", 115200)
# ✅ 자동 탐지
from engine.serial_cmd import detect_arduino_port

# ❌ 전역 mutable 변수
device = None
# ✅ 의존성 주입
class MacroRunner:
    def __init__(self, serial_commander: SerialCommander | None) -> None: ...
```

---

## 10. 테스트 규칙

- 위치: `tests/`
- 파일명: `test_{모듈명}.py`
- 프레임워크: pytest
- 하드웨어 없이도 통과해야 함 (mock/stub 필수)

---

## 11. 품질 게이트 (필수)

[Quality Gates](quality-gates.md) 참조.

- AI 에이전트(Cursor 등)는 검증 단계에서 해당 문서에 정의된 명령을 **터미널에서 스스로 실행**한다. 사용자에게 배치 실행을 요구하지 않는다.

---

## 12. Git 규칙

- 커밋 메시지: `<영역>: <변경 요약>` (예: `shared: models 패키지 분리`)
- 브랜치: `main`, `feature/<topic>`, `fix/<topic>`

---

## 13. 문서 동기화

- 동작 변경 시 관련 문서를 **같은 변경에** 갱신
- 규칙 변경 시 `docs/governance/constitution.md`, `docs/governance/*` 정합성 유지

---

## 14. 외부 라이브러리

승인된 목록: pydantic, pyserial, PyQt6, mss, pynput, opencv-python-headless, numpy, pytesseract, Pillow.
추가 시 이 문서와 `docs/spec/tech-overview.md`를 함께 갱신한다.
