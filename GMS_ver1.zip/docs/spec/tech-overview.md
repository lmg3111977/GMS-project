# 기술 개요

> 구현 세부는 소스가 우선입니다. 이 문서는 동작 구조·스택·디렉터리 요약입니다. 언어 규칙·경로 권위·승인 라이브러리 목록은 [Constitution](../governance/constitution.md)과 맞춥니다.

## 아키텍처

### 진입점

- `main.py` (`AppContext` → `EditorSession` / `headless_run`)
- CLI: `python main.py --run <macro.json>`
- GUI: 인자 없이 실행

패키지 의존성 방향·계층 경계는 [Constitution §5](../governance/constitution.md) 참조.

### 데이터 흐름

```text
macro JSON 파일
  → shared/schema.py (검증/로딩)
  → Macro 모델 (shared/models/)
  → engine/runner.py
  → engine/scheduler/
  → engine/serial_cmd.py
  → Arduino
```

### 매크로 포맷

- 버전: `v1.0`
- 모델·스키마·프로토콜 경로는 [Constitution §2](../governance/constitution.md) 표를 따른다.

### 에디터·테스트

- 메인 윈도우: `editor/main_window/`, 파라미터 패널: `editor/param_panel/`
- `tests/`: 로더, 스케줄러, 러너, 에디터 관련 회귀 테스트

## 기술 스택

- **런타임**: Python 3.11 이상 — 언어·타입 힌트·포매터 규칙은 [Constitution §3](../governance/constitution.md) 참조.
- **승인된 외부 라이브러리**: [Constitution §14](../governance/constitution.md) 참조.
- **품질 도구**: pytest, ruff, black, mypy

### 의존성

`requirements.txt`, `pyproject.toml`의 `[project]` 및 `[tool.*]`를 따른다.

## 디렉토리 구조

세부 경로의 단일 권위는 [Constitution §2](../governance/constitution.md)입니다. 요약:

| 경로 | 역할 |
|------|------|
| `shared/models/`, `shared/schema.py` | 데이터 모델·검증/로딩 |
| `engine/runner.py`, `engine/scheduler/` | 실행 엔진·스케줄러 |
| `editor/main_window/`, `editor/param_panel/` | 에디터 UI |
| `player/` | 트레이 플레이어 |
| `tests/` | 테스트 |
