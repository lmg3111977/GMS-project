# GAS 기반 로그인 스펙 (아이디·비밀번호)

## 1) Google Sheet 스키마

시트 이름: `licenses`

1행 헤더 예시 (순서 자유, 이름만 일치):

| 컬럼 | 타입 | 설명 |
|---|---|---|
| `user_id` | string | 로그인 아이디 (고유 권장) |
| `password` | string | 비밀번호 (평문 저장 — 운영 시 시트 권한으로 보호) |
| `status` | string | `active` / `suspended` / `revoked` |
| `expires_at` | string | UTC ISO8601 (`2026-12-31T23:59:59Z`) |
| `last_seen_at` | string | UTC ISO8601 마지막 성공 로그인 시각 |
| `memo` | string | 관리자 메모 (선택) |

권장:
- `user_id` 중복 금지
- 시트 편집 권한은 관리자만

## 2) GAS API 요청/응답

엔드포인트: 웹앱 `POST` (본문 JSON)

요청 JSON:

```json
{
  "userId": "myuser",
  "password": "secret"
}
```

응답 JSON:

```json
{
  "ok": true,
  "code": "OK",
  "message": "로그인 성공",
  "expiresAt": "2026-12-31T23:59:59Z"
}
```

오류 시에도 동일 필드 형식, `ok: false`.

## 3) 클라이언트 설정

- **API URL**: `config.json`의 `auth_url`, 또는 `--auth-url`, 또는 환경변수 `GMS_AUTH_URL`  
  (배포본에는 고정 URL만 넣는 것을 권장)
- **아이디·비밀번호**: GUI 입력, 또는 `login_username`(아이디만), 또는 `GMS_USER_ID` / `GMS_PASSWORD`, 또는 `--user-id` / `--password`

## 4) Fail-Closed

네트워크 오류, JSON 오류, `ok !== true` 이면 앱은 즉시 종료한다.
