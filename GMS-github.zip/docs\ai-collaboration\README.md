# AI 협업 (공식 허브)

바이브코딩 시 **이 폴더만** 공식 템플릿으로 사용합니다.

## 순서

1. [`role-division.md`](role-division.md) — Cursor + Claude Code 역할 분담 (필독)
2. [`ai-workflow.md`](ai-workflow.md) — 컨텍스트에 넣을 파일 순서
3. 작업 유형별 [`prompt-templates/`](prompt-templates/) 템플릿 채우기
4. [`../governance/quality-gates.md`](../governance/quality-gates.md) 검증
5. 스킬: [`../../skills/README.md`](../../skills/README.md)

## 템플릿

| 파일 | 용도 |
|------|------|
| [prompt-templates/bugfix.md](prompt-templates/bugfix.md) | 버그 수정 |
| [prompt-templates/feature.md](prompt-templates/feature.md) | 기능 추가 |
| [prompt-templates/refactor.md](prompt-templates/refactor.md) | 리팩터 |
| [prompt-templates/test.md](prompt-templates/test.md) | 테스트 추가 |
| [prompt-templates/docs.md](prompt-templates/docs.md) | 문서만 갱신 |
