# Docs Template

## 입력 슬롯
- 변경된 사실(코드/CLI/포맷):
- 대상 문서:
- 초보자 안내 문장:

## 요청 문안
- Claude: 코드 직접 수정 금지, 문서 수정 대상/변경점 명세 + Cursor용 프롬프트 생성
- Cursor: 문서만 수정(코드 파일 수정 금지)
- 문서의 검증/명령어는 현재 프로젝트 규칙과 일치해야 함

## 빠른 검증 (기본)
- 문서 변경과 직접 관련된 항목만 우선 점검

## 전체 검증 (조건부: 머지 전/릴리즈 전/핵심 로직 변경)
```bash
ruff check shared engine editor player tests
black --check shared engine editor player tests
pytest -q tests
```

## 완료
- 문서 간 규칙 충돌 없음
- 온보딩 경로(`QUICKSTART.md`)와 모순 없음
- 출력 형식: 1) 상황 한 줄 2) 수정 대상 3) Cursor용 프롬프트
