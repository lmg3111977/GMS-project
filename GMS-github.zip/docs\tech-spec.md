# Tech Spec

> 구현 세부는 소스가 우선입니다. 이 문서는 현재 동작 구조의 개요와 경계를 고정합니다.

## 1. 진입점

- `main.py` (`AppContext` → `EditorSession` / `headless_run`)
- CLI: `python main.py --run <macro.json>`
- GUI: 인자 없이 실행

## 2. 데이터 흐름

```text
macro JSON 파일
  → shared/schema.py (검증/로딩)
  → Macro 모델 (shared/models/)
  → engine/runner.py
  → engine/scheduler/
  → engine/serial_cmd.py
  → Arduino
```

## 3. 매크로 포맷

- 버전: `v1.0`
- 모델: `shared/models/`
- 스키마/로딩: `shared/schema.py`

## 4. 에디터 구조

- 메인 윈도우: `editor/main_window/`
- 파라미터 패널: `editor/param_panel/`

## 5. 테스트

- `tests/`: 로더, 스케줄러, 러너, 에디터 관련 회귀 테스트
