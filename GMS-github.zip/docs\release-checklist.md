# Release Checklist (v2)

## 품질 게이트

- [ ] `ruff check shared engine editor player tests`
- [ ] `black --check shared engine editor player tests`
- [ ] `mypy shared engine editor player`
- [ ] `pytest -q tests`

## 동작

- [ ] `python main.py --run macros/examples/example_click_loop.json --dry-run`
- [ ] `python main.py` GUI 실행

## 문서

- [ ] `README.md`, `QUICKSTART.md` 링크 유효
- [ ] `docs/constitution.md`와 명령 일치
- [ ] `docs/troubleshooting.md` 반영

## 배포 메모

- [ ] 변경 요약
- [ ] 알려진 제한(Stub 기본 등)
