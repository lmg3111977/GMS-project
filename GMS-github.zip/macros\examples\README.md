# 예제 매크로

이 폴더의 JSON은 **`version`: `"1.0"`** ([`shared/schema.py`](../../shared/schema.py)) 기준입니다.

- 예: [`example_click_loop.json`](example_click_loop.json) — 루프 + 클릭 + 딜레이
- 서브매크로 예: [`sub/`](sub/)
- 빠른 시작: [`QUICKSTART.md`](../../QUICKSTART.md)
