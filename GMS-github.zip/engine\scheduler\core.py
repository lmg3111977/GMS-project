"""액션 스케줄러 — 메인 클래스.

매크로의 Action 리스트를 순서대로 실행하되,
Loop, Goto, Label, If-Pixel 등 흐름 제어 액션을 해석하여
실행 포인터(program counter)를 관리한다.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from pathlib import Path

from engine.scheduler.coord_utils import CoordUtilsMixin
from engine.scheduler.flow_handlers import FlowHandlersMixin
from engine.scheduler.function_handlers import FunctionHandlersMixin
from engine.scheduler.image_handlers import ImageHandlersMixin
from engine.scheduler.io_actions import IOActionsMixin
from engine.scheduler.models import FunctionFrame, LoopFrame, SchedulerError, SubMacroFrame
from engine.scheduler.ocr_handlers import OCRHandlersMixin
from engine.scheduler.sub_macro import SubMacroMixin
from engine.screen import ScreenAnalyzer
from engine.serial_cmd import SerialCommander
from engine.variables import VariableStore
from shared.action_flatten import (
    BranchFlattenError,
    flatten_actions_for_execution,
    iter_sub_macro_calls_deep,
)
from shared.models import (
    Action,
    ActionType,
    ElseAction,
    EndIfAction,
    FunctionDefAction,
    FunctionEndAction,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    OCRWaitAction,
    PixelWaitAction,
)

logger = logging.getLogger(__name__)


class ActionScheduler(
    FlowHandlersMixin,
    FunctionHandlersMixin,
    ImageHandlersMixin,
    OCRHandlersMixin,
    SubMacroMixin,
    IOActionsMixin,
    CoordUtilsMixin,
):
    """액션 스케줄러.

    매크로의 Action 리스트를 로드하고,
    execute_next()를 반복 호출하여 한 액션씩 실행한다.
    """

    def __init__(
        self,
        serial_commander: SerialCommander | None = None,
        screen_analyzer: ScreenAnalyzer | None = None,
        variable_store: VariableStore | None = None,
        stop_event: threading.Event | None = None,
        link_lost_event: threading.Event | None = None,
        visual_debug_callback: (
            Callable[[str, bytes | None, bytes | None, bool], None] | None
        ) = None,
    ) -> None:
        """초기화.

        Args:
            serial_commander: 시리얼 통신 관리자 (None이면 dry-run 모드)
            screen_analyzer: 화면 분석기 (None이면 픽셀 감지 비활성)
            variable_store: 변수 저장소 (None이면 자동 생성)
            stop_event: 정지 요청 이벤트 (set 시 wait_for_* 즉시 탈출)
            link_lost_event: Arduino 비정상 끊김 시 대기/딜레이 즉시 탈출
            visual_debug_callback: (종류, 기준 PNG, 화면 PNG, 찾은쪽 표시 여부)
                마지막 인자가 False면 찾은 이미지용 화면 캡처를 생략(이미지 실패 시 템플릿은 전달).
        """
        self._serial = serial_commander
        self._screen = screen_analyzer
        self._visual_debug_cb = visual_debug_callback
        self._variables = variable_store or VariableStore()
        self._stop_event = stop_event
        self._link_lost_event = link_lost_event

        self._actions: list[Action] = []
        self._label_map: dict[str, int] = {}
        self._loop_end_map: dict[int, int] = {}
        self._if_else_map: dict[int, int] = {}
        self._if_end_map: dict[int, int] = {}
        self._else_end_map: dict[int, int] = {}
        self._else_to_if_map: dict[int, int] = {}
        self._sub_macro_cache: dict[str, object] = {}
        self._function_map: dict[str, int] = {}
        self._function_end_map: dict[int, int] = {}
        self._program_counter: int = 0
        self._loop_stack: list[LoopFrame] = []
        self._call_stack: list[SubMacroFrame] = []
        self._function_call_stack: list[FunctionFrame] = []
        self._is_loaded: bool = False
        self._nested_macro_paths: set[str] = set()
        self._root_macro_path: str | None = None

        self._dispatch_table: dict[ActionType, Callable[[Action], None]] = {
            ActionType.LABEL: lambda _a: self._inc_pc(),
            ActionType.GOTO: self._handle_goto,
            ActionType.LOOP_START: self._handle_loop_start,
            ActionType.LOOP_END: lambda _a: self._handle_loop_end(),
            ActionType.IF_PIXEL: self._handle_if_pixel,
            ActionType.PIXEL_WAIT: self._handle_pixel_wait,
            ActionType.DELAY: self._handle_delay,
            ActionType.COMMENT: lambda _a: self._inc_pc(),
            ActionType.VARIABLE_SET: self._handle_variable_set,
            ActionType.BREAK: lambda _a: self._handle_break(),
            ActionType.IMAGE_SEARCH: self._handle_image_search,
            ActionType.IF_VARIABLE: self._handle_if_variable,
            ActionType.ELSE: self._handle_else,
            ActionType.END_IF: lambda _a: self._inc_pc(),
            ActionType.IMAGE_WAIT: self._handle_image_wait,
            ActionType.IMAGE_CLICK: self._handle_image_click,
            ActionType.OCR_READ: self._handle_ocr_read,
            ActionType.OCR_WAIT: self._handle_ocr_wait,
            ActionType.SUB_MACRO_CALL: self._handle_sub_macro_call,
            ActionType.FUNCTION_DEF: lambda _a: self._handle_function_def(),
            ActionType.FUNCTION_END: lambda _a: self._handle_function_end(),
            ActionType.FUNCTION_CALL: self._handle_function_call,
            ActionType.RETURN: self._handle_return,
        }

    def set_serial_commander(self, serial_commander: SerialCommander | None) -> None:
        """실행 중 시리얼 참조를 교체한다 (리허설·복구용). dry-run은 None."""
        self._serial = serial_commander

    @property
    def program_counter(self) -> int:
        """현재 실행 위치."""
        return self._program_counter

    @property
    def variables(self) -> VariableStore:
        """변수 저장소."""
        return self._variables

    def _raise_if_link_lost(self) -> None:
        """Arduino 끊김 이벤트가 켜져 있으면 SchedulerError로 중단한다."""
        if self._link_lost_event is not None and self._link_lost_event.is_set():
            raise SchedulerError("Arduino 연결 끊김 (시리얼 연결 손실)")

    def _emit_visual_debug_image(
        self,
        kind: str,
        template_path: str,
        region_x: int,
        region_y: int,
        region_width: int,
        region_height: int,
        hit_xy: tuple[int, int] | None,
    ) -> None:
        """이미지 매칭 계열 액션의 디버그 썸네일을 콜백으로 전달한다.

        실패(hit_xy None) 시에는 화면 캡처만 생략하고, 템플릿(찾을 이미지)은 표시용으로 로드한다.
        """
        if self._visual_debug_cb is None or self._screen is None:
            return
        from engine import visual_debug as vd

        if hit_xy is None:
            ref = vd.template_png_thumb(template_path)
            try:
                self._visual_debug_cb(kind, ref, None, False)
            except Exception as exc:
                logger.debug("visual_debug 콜백 에러: %s", exc)
            return

        ref = vd.template_png_thumb(template_path)
        scr = vd.screen_center_png_thumb(self._screen, hit_xy[0], hit_xy[1])
        try:
            self._visual_debug_cb(kind, ref, scr, True)
        except Exception as exc:
            logger.debug("visual_debug 콜백 에러: %s", exc)

    def _emit_visual_debug_pixel(
        self,
        kind: str,
        color_hex: str,
        px: int,
        py: int,
        *,
        capture_screen: bool,
    ) -> None:
        """픽셀 색상 계열 액션의 디버그 썸네일을 콜백으로 전달한다.

        capture_screen False(조건 불만족·타임아웃)이면 화면 캡처를 생략한다.
        """
        if self._visual_debug_cb is None or self._screen is None:
            return
        from engine import visual_debug as vd

        ref = vd.expected_color_png_thumb(color_hex)
        scr = vd.screen_center_png_thumb(self._screen, px, py) if capture_screen else None
        try:
            self._visual_debug_cb(kind, ref, scr, capture_screen)
        except Exception as exc:
            logger.debug("visual_debug 콜백 에러: %s", exc)

    @property
    def is_finished(self) -> bool:
        """매크로 끝에 도달했는지."""
        if self._program_counter < len(self._actions):
            return False
        return len(self._call_stack) == 0

    def _build_label_loop_maps(self, actions: list[Action]) -> None:
        """평면 액션 리스트로부터 Label 인덱스와 LoopStart↔LoopEnd 매핑을 만든다."""
        self._label_map = {}
        self._loop_end_map = {}
        self._if_else_map = {}
        self._if_end_map = {}
        self._else_end_map = {}
        self._else_to_if_map = {}
        self._function_map = {}
        self._function_end_map = {}
        loop_stack: list[int] = []
        if_stack: list[int] = []
        else_stack: list[int] = []
        function_stack: list[int] = []

        for idx, action in enumerate(actions):
            if isinstance(action, LabelAction) and action.enabled and action.name:
                self._label_map[action.name] = idx

            if isinstance(action, LoopStartAction):
                loop_stack.append(idx)
            elif isinstance(action, LoopEndAction):
                if not loop_stack:
                    raise SchedulerError(f"액션 #{idx}: LoopEnd에 대응하는 LoopStart가 없음")
                start_idx = loop_stack.pop()
                self._loop_end_map[start_idx] = idx
            elif isinstance(
                action,
                (
                    IfPixelAction,
                    IfVariableAction,
                    PixelWaitAction,
                    ImageSearchAction,
                    ImageWaitAction,
                    ImageClickAction,
                    OCRWaitAction,
                ),
            ):
                if_stack.append(idx)
            elif isinstance(action, ElseAction):
                if not if_stack:
                    raise SchedulerError(f"액션 #{idx}: Else에 대응하는 If가 없음")
                if_idx = if_stack.pop()
                self._if_else_map[if_idx] = idx
                self._else_to_if_map[idx] = if_idx
                else_stack.append(idx)
            elif isinstance(action, EndIfAction):
                if else_stack:
                    else_idx = else_stack.pop()
                    self._else_end_map[else_idx] = idx
                    origin_if = self._else_to_if_map.get(else_idx)
                    if origin_if is not None and origin_if not in self._if_end_map:
                        self._if_end_map[origin_if] = idx
                elif if_stack:
                    if_idx = if_stack.pop()
                    self._if_end_map[if_idx] = idx
                else:
                    raise SchedulerError(f"액션 #{idx}: EndIf에 대응하는 If/Else가 없음")
            elif isinstance(action, FunctionDefAction) and action.enabled and action.name:
                if action.name in self._function_map:
                    raise SchedulerError(f"함수 '{action.name}' 중복 정의")
                self._function_map[action.name] = idx
                function_stack.append(idx)
            elif isinstance(action, FunctionEndAction):
                if not function_stack:
                    raise SchedulerError(f"액션 #{idx}: FunctionEnd에 대응하는 FunctionDef가 없음")
                def_idx = function_stack.pop()
                self._function_end_map[def_idx] = idx

        if loop_stack:
            first_unmatched = loop_stack[-1]
            raise SchedulerError(f"액션 #{first_unmatched}: LoopStart에 대응하는 LoopEnd가 없음")
        if if_stack:
            first_unmatched_if = if_stack[-1]
            raise SchedulerError(f"액션 #{first_unmatched_if}: If에 대응하는 EndIf가 없음")
        if else_stack:
            first_unmatched_else = else_stack[-1]
            raise SchedulerError(f"액션 #{first_unmatched_else}: Else에 대응하는 EndIf가 없음")
        if function_stack:
            raise SchedulerError(
                f"액션 #{function_stack[-1]}: FunctionDef에 대응하는 FunctionEnd가 없음"
            )

    def load_actions(
        self,
        actions: list[Action],
        *,
        source_path: str | None = None,
    ) -> None:
        """액션 리스트를 로드하고 라벨 인덱스를 빌드한다.

        액션 리스트를 그대로 로드한다.

        서브매크로가 있으면 로드 시점에 미리 파일을 읽어 캐시한다.
        실행 중 디스크 I/O를 제거하기 위함.

        Args:
            actions: 실행할 액션 리스트 (분기 블록 포함 가능)
            source_path: 루트 매크로 파일 경로 (서브매크로 순환 참조 탐지용, 선택)

        Raises:
            SchedulerError: 액션 수 제한 초과 시
        """
        try:
            flat_actions = flatten_actions_for_execution(list(actions))
        except BranchFlattenError as exc:
            raise SchedulerError(str(exc)) from exc

        if len(flat_actions) > 10000:
            raise SchedulerError(
                f"액션 수 제한 초과(분기 펼침 후): {len(flat_actions)}개 (최대 10,000개)"
            )

        self._actions = flat_actions
        self._sub_macro_cache: dict[str, object] = {}

        self._build_label_loop_maps(flat_actions)

        self._preload_sub_macros(actions)

        self._root_macro_path = str(Path(source_path).resolve()) if source_path else None
        self.reset()
        self._is_loaded = True
        logger.info(
            "스케줄러 로드 완료: %d개 액션(펼침), %d개 라벨, %d개 서브매크로 캐시",
            len(flat_actions),
            len(self._label_map),
            len(self._sub_macro_cache),
        )

    def _preload_sub_macros(
        self,
        actions: list[Action],
        visited: set[str] | None = None,
    ) -> None:
        """서브매크로를 재귀적으로 사전 로딩한다.

        순환 참조는 건너뛰고 경고만 남긴다 (실행 시점에서 SchedulerError로 잡힘).
        """
        from shared.schema import load_macro

        if visited is None:
            visited = set()

        for action in iter_sub_macro_calls_deep(actions):
            if not action.macro_path:
                continue

            resolved = str(Path(action.macro_path).resolve())
            if resolved in self._sub_macro_cache:
                continue
            if resolved in visited:
                logger.warning("서브매크로 사전 로딩 중 순환 참조 감지: %s (스킵)", resolved)
                continue

            visited.add(resolved)
            try:
                sub_macro = load_macro(action.macro_path)
                self._sub_macro_cache[resolved] = sub_macro
                logger.debug(
                    "서브매크로 사전 로딩: %s (%d개 액션)", resolved, len(sub_macro.actions)
                )
                self._preload_sub_macros(sub_macro.actions, visited)
            except Exception as exc:
                logger.warning("서브매크로 사전 로딩 실패: %s — %s", resolved, exc)

    def reset(self) -> None:
        """실행 상태를 초기화한다."""
        self._program_counter = 0
        self._loop_stack.clear()
        self._call_stack.clear()
        self._function_call_stack.clear()
        self._nested_macro_paths.clear()
        if self._root_macro_path:
            self._nested_macro_paths.add(self._root_macro_path)
        self._variables.reset()

    def execute_next(self) -> bool:
        """다음 액션 1개를 실행한다.

        Returns:
            True: 실행 성공 (다음 액션 있음)
            False: 매크로 끝에 도달

        Raises:
            SchedulerError: 실행 중 에러 (미정의 Label, 루프 초과 등)
        """
        if not self._is_loaded:
            raise SchedulerError("액션이 로드되지 않았습니다")

        self._raise_if_link_lost()

        while self._program_counter < len(self._actions):
            action = self._actions[self._program_counter]
            if action.enabled:
                break
            logger.debug(
                "액션 #%d 건너뜀 (비활성): %s",
                self._program_counter,
                action.type,
            )
            self._program_counter += 1

        if self._program_counter >= len(self._actions):
            if self._call_stack:
                self._return_from_sub_macro()
                return True
            return False

        action = self._actions[self._program_counter]
        logger.debug(
            "액션 #%d 실행: %s",
            self._program_counter,
            action.type,
        )

        self._dispatch_action(action)

        if self._program_counter >= len(self._actions) and self._call_stack:
            self._return_from_sub_macro()
            return True

        return self._program_counter < len(self._actions) or bool(self._call_stack)

    # -------------------------------------------------------------------
    # 액션 디스패치
    # -------------------------------------------------------------------

    def _inc_pc(self) -> None:
        self._program_counter += 1

    def _dispatch_action(self, action: Action) -> None:
        """액션 타입별로 적절한 핸들러를 호출한다."""
        handler = self._dispatch_table.get(action.type)
        if handler is not None:
            handler(action)
        else:
            self._execute_io_action(action)
            self._program_counter += 1
