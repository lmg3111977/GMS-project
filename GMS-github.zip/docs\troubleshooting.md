# Troubleshooting

## 매크로 로드 / 저장 오류

- **`version`은 현재 `"1.0"`** — [`shared/schema.py`](../../shared/schema.py) 의 `CURRENT_SCHEMA_VERSION` 과 맞춥니다.
- **`actions`가 비어 있으면** 저장 검증에서 실패할 수 있습니다.
- **분기 구조(If/Else/EndIf, Loop)** 가 깨지면 [`shared/action_flatten.py`](../../shared/action_flatten.py) 단계에서 오류가 납니다. 에디터에서 조건 블록을 다시 추가해 보세요.
- 지원하지 않는 `type` 은 [`docs/user/action-reference.md`](user/action-reference.md) 를 확인하세요.

## 실행이 안 됨

- 가상환경 활성화 후 `pip install -r requirements.txt` 재실행
- 최소 재현: `python main.py --run macros/examples/example_click_loop.json`
- **실행 전 대화상자**에서 **리허설**을 켜면 Arduino로 HID를 보내지 않고 Stub 로그만 남깁니다 (앱 전체를 `--dry-run` 으로 켠 경우와 유사).
- 앱 전체 Stub: `python main.py --dry-run`

## PyQt6 / GUI

- `python main.py` 실행 시 import 오류면 PyQt6 설치 확인
- Python 3.11+ 권장

## 액션 리스트에서 If/Else/End 구조가 갑자기 바뀜

에디터는 **삭제·드래그 이동 뒤** 구조형 if/else/end 균형이 깨지면 [`editor/action_list/core.py`](../../editor/action_list/core.py) 의 `_repair_if_structure_after_delete()` 로 **자동 복구**합니다.

- **Else가 두 번 연속**이면 중복 Else를 제거할 수 있습니다.
- **EndIf 직전에 Else가 없으면** Else를 끼워 넣을 수 있습니다.
- 스캔 후에도 **닫히지 않은 if 프레임**이 있으면 목록 **맨 끝에** Else/EndIf를 붙일 수 있습니다.

의도는 “실행 불가능한 깨진 목록”을 막는 것입니다. 순서가 예상과 다르면 **실행 취소(Ctrl+Z)** 로 되돌리거나, 백업 JSON에서 복구해 보세요.

## (선택) Arduino / COM

실제 Leonardo + 시리얼 연결 시:

- 케이블이 **데이터** 지원인지 확인
- 포트 충돌(다른 시리얼 모니터 종료)
- **리허설** 또는 **`--dry-run`** 으로 먼저 흐름만 검증한 뒤 실기 연결

## 안전

- 개발 중 예상치 못한 입력 반복 시 즉시 `Ctrl+F7` 정지 (에디터/플레이어 공통)
- 실행 상태 확인이 필요하면 `Ctrl+L`로 하단 로그·캡처 패널을 열어 원인 확인
- 실제 게임·서비스 약관 준수

## 문서 정합성

- 온보딩 인덱스: [`onboarding/README.md`](onboarding/README.md)
- 단축키 가이드: [`user/shortcut-guide.md`](user/shortcut-guide.md)
