"""매크로 JSON 직렬화/역직렬화.

macro.json 파일의 저장과 로드를 담당한다.
pydantic 모델의 model_dump() / model_validate()를 래핑하여
파일 I/O, 버전 검증, 논리 검증, 마이그레이션을 처리한다.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path

from pydantic import ValidationError

from shared.action_flatten import BranchFlattenError, flatten_actions_for_execution
from shared.models import (
    ElseAction,
    EndIfAction,
    GotoAction,
    IfPixelAction,
    IfVariableAction,
    ImageClickAction,
    ImageSearchAction,
    ImageWaitAction,
    LabelAction,
    LoopEndAction,
    LoopStartAction,
    Macro,
    OCRReadAction,
    OCRWaitAction,
    PixelWaitAction,
    VariableSetAction,
)

logger = logging.getLogger(__name__)

CURRENT_SCHEMA_VERSION: str = "1.0"
_VAR_REF_PATTERN = re.compile(r"\{(\w+)\}")
_NUMERIC_LITERAL_PATTERN = re.compile(r"^[+-]?\d+(?:\.\d+)?$")


# ---------------------------------------------------------------------------
# 커스텀 예외
# ---------------------------------------------------------------------------


class MacroValidationError(Exception):
    """매크로 파일 검증 실패 에러.

    JSON 파싱 실패, pydantic 검증 실패, 논리 검증 실패 등에 사용한다.
    """


# ---------------------------------------------------------------------------
# 저장 / 로드
# ---------------------------------------------------------------------------


def save_macro(macro: Macro, file_path: str | Path) -> None:
    """매크로를 JSON 파일로 저장한다.

    Args:
        macro: 저장할 Macro 인스턴스
        file_path: 저장 경로

    Raises:
        MacroValidationError: 저장 전 검증 실패 시
        OSError: 파일 쓰기 실패 시
    """
    issues = validate_macro_logic(macro)
    errors = [i for i in issues if i.startswith("[ERROR]")]
    if errors:
        raise MacroValidationError(f"매크로 검증 실패 ({len(errors)}개 에러): {errors[0]}")

    path = Path(file_path)
    json_str = macro.model_dump_json(indent=2)

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json_str, encoding="utf-8")

    logger.info("매크로 저장 완료: %s (%d개 액션)", path, len(macro.actions))


def load_macro(file_path: str | Path) -> Macro:
    """JSON 파일에서 매크로를 로드한다.

    Args:
        file_path: 매크로 JSON 파일 경로

    Returns:
        검증된 Macro 인스턴스

    Raises:
        MacroValidationError: 파싱/검증 실패 시
        FileNotFoundError: 파일이 없을 때
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"매크로 파일을 찾을 수 없음: {path}")

    try:
        raw_text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise MacroValidationError(f"파일 읽기 실패: {exc}") from exc

    try:
        raw_data = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise MacroValidationError(f"JSON 파싱 실패: {exc}") from exc

    if not isinstance(raw_data, dict):
        raise MacroValidationError("매크로 JSON 최상위는 객체여야 함")

    _normalize_legacy_schedule_settings(raw_data)

    file_version = raw_data.get("version", "1.0")
    if file_version != CURRENT_SCHEMA_VERSION:
        logger.info("버전 마이그레이션: %s → %s", file_version, CURRENT_SCHEMA_VERSION)
        raw_data = migrate_macro(raw_data, file_version)

    try:
        macro = Macro.model_validate(raw_data)
    except ValidationError as exc:
        raise MacroValidationError(
            f"매크로 모델 검증 실패: {exc}\n"
            "참고: docs/troubleshooting.md, docs/user/action-reference.md"
        ) from exc

    logger.info("매크로 로드 완료: %s (%d개 액션)", path, len(macro.actions))
    return macro


def _normalize_legacy_schedule_settings(raw_data: dict) -> None:
    """구 스케줄 필드를 schedule_rules로 정규화한다."""
    settings = raw_data.get("settings")
    if not isinstance(settings, dict):
        return

    if isinstance(settings.get("schedule_rules"), list):
        return

    enabled = bool(settings.get("schedule_enabled", False))
    time_hhmm = settings.get("schedule_time_hhmm", "20:00")
    if not isinstance(time_hhmm, str):
        time_hhmm = "20:00"

    macro_path = settings.get("schedule_macro_path", "")
    if not isinstance(macro_path, str):
        macro_path = ""

    if enabled and macro_path.strip():
        settings["schedule_rules"] = [
            {
                "enabled": True,
                "time_hhmm": time_hhmm,
                "macro_path": macro_path,
            }
        ]
    else:
        settings["schedule_rules"] = []


# ---------------------------------------------------------------------------
# 논리 검증
# ---------------------------------------------------------------------------


def validate_macro_logic(macro: Macro) -> list[str]:
    """매크로의 논리적 유효성을 검증한다.

    pydantic 스키마 검증과 별도로, 실행 시 발생할 수 있는
    논리적 오류를 사전에 찾아낸다.

    Args:
        macro: 검증할 Macro 인스턴스

    Returns:
        문제 메시지 목록. "[ERROR] ..." 또는 "[WARNING] ..." 형식.
        빈 리스트이면 유효함.
    """
    issues: list[str] = []

    if len(macro.actions) == 0:
        issues.append("[WARNING] 매크로에 액션이 없습니다.")
        return issues

    try:
        flat_actions = flatten_actions_for_execution(macro.actions)
    except BranchFlattenError as exc:
        return [f"[ERROR] {exc}"]

    if len(flat_actions) > 10000:
        issues.append(
            f"[ERROR] 액션 수 제한 초과(분기 펼침 후): {len(flat_actions)}개 (최대 10,000개)"
        )

    label_names: dict[str, int] = {}
    for idx, action in enumerate(flat_actions):
        if isinstance(action, LabelAction) and action.enabled:
            if action.name in label_names:
                issues.append(
                    f"[ERROR] #{idx}: 중복 Label 이름 '{action.name}' "
                    f"(이전 정의: #{label_names[action.name]})"
                )
            else:
                label_names[action.name] = idx

    seen_vars: set[str] = set()

    def _extract_var_refs(text: str | None) -> set[str]:
        if not text:
            return set()
        return {m.group(1) for m in _VAR_REF_PATTERN.finditer(text)}

    def _warn_undefined_refs(idx: int, field_name: str, text: str | None) -> None:
        for ref in sorted(_extract_var_refs(text)):
            if ref not in seen_vars:
                issues.append(
                    f"[WARNING] #{idx}: {field_name}에서 미정의 변수 참조 '{{{ref}}}' "
                    "(실행 시 0/빈값으로 해석될 수 있음)"
                )

    def _register_defined_var(name: str | None) -> None:
        t = (name or "").strip()
        if t:
            seen_vars.add(t)

    for idx, action in enumerate(flat_actions):
        if not action.enabled:
            continue

        if isinstance(action, GotoAction):
            if action.target and action.target not in label_names:
                issues.append(
                    f"[ERROR] #{idx}: Goto target '{action.target}' — "
                    f"해당 Label이 존재하지 않음"
                )

        elif isinstance(action, IfVariableAction):
            if action.var_name.strip() and action.var_name not in seen_vars:
                issues.append(
                    f"[WARNING] #{idx}: IfVariable 변수 '{action.var_name}'가 "
                    "이전에 설정되지 않았습니다"
                )
            _warn_undefined_refs(idx, "IfVariable.compare_value", action.compare_value)
            if action.operator in (">", "<", ">=", "<="):
                compare_text = action.compare_value.strip()
                if (
                    compare_text
                    and not _extract_var_refs(compare_text)
                    and not _NUMERIC_LITERAL_PATTERN.fullmatch(compare_text)
                ):
                    issues.append(
                        f"[WARNING] #{idx}: IfVariable 연산자 '{action.operator}'는 "
                        f"숫자 비교 권장 (현재 비교값: {action.compare_value!r})"
                    )
        elif isinstance(action, VariableSetAction):
            _warn_undefined_refs(idx, "VariableSet.expression", action.expression)
        elif isinstance(action, LoopStartAction):
            _warn_undefined_refs(idx, "LoopStart.count_expression", action.count_expression)
            _warn_undefined_refs(
                idx, "LoopStart.range_start_expression", action.range_start_expression
            )
            _warn_undefined_refs(idx, "LoopStart.range_end_expression", action.range_end_expression)

        if isinstance(action, VariableSetAction):
            _register_defined_var(action.var_name)
        elif isinstance(action, ImageSearchAction):
            _register_defined_var(action.store_x_var)
            _register_defined_var(action.store_y_var)
            _register_defined_var(action.store_xy_combined_var)
            _register_defined_var(action.store_found_var)
            _register_defined_var(action.store_confidence_var)
        elif isinstance(action, ImageWaitAction):
            _register_defined_var(action.store_x_var)
            _register_defined_var(action.store_y_var)
        elif isinstance(action, (OCRReadAction, OCRWaitAction)):
            _register_defined_var(action.store_var)

    # if/else/end 구조 검증
    if_stack: list[int] = []
    else_stack: list[int] = []
    for idx, action in enumerate(flat_actions):
        is_struct_if = isinstance(
            action,
            (
                IfPixelAction,
                IfVariableAction,
                PixelWaitAction,
                ImageSearchAction,
                ImageWaitAction,
                ImageClickAction,
                OCRWaitAction,
            ),
        )
        if is_struct_if:
            if_stack.append(idx)
        elif isinstance(action, ElseAction):
            if not if_stack:
                issues.append(f"[ERROR] #{idx}: Else에 대응하는 If가 존재하지 않음")
            else:
                if_stack.pop()
                else_stack.append(idx)
        elif isinstance(action, EndIfAction):
            if else_stack:
                else_stack.pop()
            elif if_stack:
                if_stack.pop()
            else:
                issues.append(f"[ERROR] #{idx}: EndIf에 대응하는 If/Else가 존재하지 않음")

    if if_stack:
        issues.append(f"[ERROR] #{if_stack[-1]}: If에 대응하는 EndIf가 존재하지 않음")
    if else_stack:
        issues.append(f"[ERROR] #{else_stack[-1]}: Else에 대응하는 EndIf가 존재하지 않음")

    loop_stack: list[int] = []
    max_nesting_depth: int = 0
    for idx, action in enumerate(flat_actions):
        if not action.enabled:
            continue

        if isinstance(action, LoopStartAction):
            loop_stack.append(idx)
            max_nesting_depth = max(max_nesting_depth, len(loop_stack))
        elif isinstance(action, LoopEndAction):
            if not loop_stack:
                issues.append(f"[ERROR] #{idx}: LoopEnd에 대응하는 LoopStart가 없음")
            else:
                loop_stack.pop()

    for unclosed_idx in loop_stack:
        issues.append(f"[ERROR] #{unclosed_idx}: LoopStart에 대응하는 LoopEnd가 없음")

    if max_nesting_depth > 10:
        issues.append(f"[ERROR] 루프 중첩이 10단계를 초과함 ({max_nesting_depth}단계)")

    return issues


# ---------------------------------------------------------------------------
# 버전 마이그레이션
# ---------------------------------------------------------------------------


def migrate_macro(data: dict, from_version: str) -> dict:
    """구버전 매크로 데이터를 현재 스키마 버전으로 변환한다.

    Args:
        data: 원본 JSON 딕셔너리
        from_version: 원본 스키마 버전

    Returns:
        마이그레이션된 딕셔너리
    """
    if from_version == CURRENT_SCHEMA_VERSION:
        return data

    logger.warning(
        "알 수 없는 스키마 버전: %s (현재: %s). 마이그레이션 없이 시도합니다.",
        from_version,
        CURRENT_SCHEMA_VERSION,
    )

    data["version"] = CURRENT_SCHEMA_VERSION
    return data
