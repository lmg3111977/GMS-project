# Contribution Policy (v2)

- 신규 코드: `shared/`, `engine/`, `editor/`, `player/` · 테스트: `tests/`
- 최상위 규범: [`../constitution.md`](../constitution.md)
- 상세 절차: [`../../CONTRIBUTING.md`](../../CONTRIBUTING.md)
