# Skill: 시리얼 / 장치 (v2)

## 목표

실제 Arduino·시리얼을 연결할 때 어댑터와 정책을 맞춘다.

## 참고

- 현재 기본 실행 경로는 `StubDevice` (`src/runtime/adapters/device_stub.py`)
- 실제 연결은 `src/runtime/adapters/device_serial.py` 등에서 구현·테스트

## 단계

1. `python main.py --list-ports` (CLI는 `src/app.py`에 정의)
2. 포트·보드·케이블 확인 — [`docs/troubleshooting.md`](../docs/troubleshooting.md)
3. 어댑터 구현 후 `tests_v2`에서 mock serial로 검증
