# Quality Gates (v2)

권위: [`docs/constitution.md`](../constitution.md) 섹션 7과 동일합니다.

```bash
ruff check shared engine editor player tests
black --check shared engine editor player tests
mypy shared engine editor player
pytest -q tests
```
