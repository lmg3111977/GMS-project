# AI Workflow

## 1) 역할 분리 (고정)

- Claude Code(두뇌): 탐색, 수정 대상 명세(파일/함수/클래스/변경점), Cursor용 프롬프트 생성, 검증 실행
- Cursor Agent(손): Claude 명세에 따라 코드 수정만 수행
- Claude Code는 코드 직접 수정 금지

## 2) 실행 순서

1. Claude Code가 관련 파일을 탐색하고 변경 범위를 고정한다.
2. Claude Code가 Cursor용 수정 프롬프트를 생성한다.
3. Cursor Agent가 명세 범위 내에서만 코드를 수정한다.
4. Claude Code가 빠른 검증(변경 범위 중심)을 수행한다.
5. 필요 조건(머지 전, 릴리즈 전, 핵심 로직 변경)일 때만 전체 검증/성능 검증을 수행한다.

## 3) 빠른 검증 (기본)

- 변경 파일 중심 린트와 관련 테스트를 우선 실행한다.
- 출력은 실패 핵심만 짧게 요약한다.

## 4) 전체 검증 게이트 (조건부)

```bash
ruff check shared engine editor player tests
black --check shared engine editor player tests
pytest -q tests
```

## 5) 성능 회귀 검증 (조건부)

- 성능 저하 가능 변경(캐시 제거, 반복 증가, 비동기→동기 회귀, 불필요 I/O 추가) 금지
- 핵심 경로 기준선(before) 3회 평균과 변경 후(after) 3회 평균을 비교
- 악화율(%) = `(after - before) / before * 100`
- 악화율이 1.0% 초과하면 실패 처리

## 6) 실패 루프

1. Claude Code가 실패 원인을 1줄로 요약한다.
2. Claude Code가 수정 프롬프트를 재생성한다.
3. Cursor Agent가 재수정한다.
4. Claude Code가 재검증한다.
- 최대 2회 반복 후에도 실패하면 사용자 승인 요청

## 7) 출력 형식 (고정)

1) 상황 한 줄  
2) 수정 대상(파일 + 함수/클래스 + 변경점)  
3) Cursor에 바로 붙여넣을 프롬프트
