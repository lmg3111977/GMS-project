# Spec Overview (v1.0)

- 아키텍처: [`../tech-spec.md`](../tech-spec.md)
- 기술 스택: [`../tech-stack.md`](../tech-stack.md)
- 태스크: [`../tasks.md`](../tasks.md)
- 헌법: [`../constitution.md`](../constitution.md)

소스 상세:

- `shared/models/` — 데이터 모델
- `engine/runner.py`, `engine/scheduler/` — 실행 엔진
- `editor/main_window/`, `editor/param_panel/` — 에디터 UI
- `player/` — 트레이 플레이어
- `tests/` — 테스트
