"""GameMacroStudio 통합 런처.

에디터 모드(기본) 또는 헤드리스 실행을 시작하고,
에디터 ↔ 플레이어 모드 전환을 지원한다.

사용법:
    python main.py                     에디터 모드로 시작
    python main.py --run macro.json    헤드리스 1회 실행
    python main.py --dry-run           Arduino 없이 에디터 모드
    python main.py --list-ports        사용 가능한 COM 포트 목록
"""

from __future__ import annotations

import argparse
import contextlib
import logging
import sys
import threading
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 앱 컨텍스트 — 세션 간 공유 자원
# ---------------------------------------------------------------------------


@dataclass
class AppContext:
    """에디터/플레이어 세션에 주입되는 앱 수준 자원."""

    app_config: dict[str, Any]
    serial_commander: Any  # engine.serial_cmd.SerialCommander
    screen_analyzer: Any  # engine.screen.ScreenAnalyzer | None
    dry_run: bool = False
    gui_runner_holder: dict[str, Any] = field(default_factory=lambda: {"runner": None})
    on_monitor_disconnected: list[Any] = field(default_factory=list)
    on_monitor_reconnected: list[Any] = field(default_factory=list)
    _quit_func: Any = None

    def set_quit_on_last_window_closed(self, enabled: bool) -> None:
        """QApplication.setQuitOnLastWindowClosed 래퍼."""
        if self._quit_func is not None:
            self._quit_func(enabled)


# ---------------------------------------------------------------------------
# 연결 모니터 — 백그라운드에서 USB 분리 감지
# ---------------------------------------------------------------------------


def _start_connection_monitor(ctx: AppContext) -> threading.Event:
    """시리얼 연결 상태를 폴링하여 분리/재연결을 감지한다."""
    stop_event = threading.Event()

    def _monitor() -> None:
        was_connected = ctx.serial_commander.is_connected()
        while not stop_event.is_set():
            stop_event.wait(2.0)
            if stop_event.is_set():
                break
            now_connected = ctx.serial_commander.is_connected()
            if was_connected and not now_connected:
                for cb in ctx.on_monitor_disconnected:
                    with contextlib.suppress(Exception):
                        cb()
            elif not was_connected and now_connected:
                for cb in ctx.on_monitor_reconnected:
                    with contextlib.suppress(Exception):
                        cb()
            was_connected = now_connected

    thread = threading.Thread(target=_monitor, daemon=True, name="ConnMonitor")
    thread.start()
    return stop_event


# ---------------------------------------------------------------------------
# 모드 전환 오케스트레이터
# ---------------------------------------------------------------------------


def _run_gui(ctx: AppContext) -> int:
    """에디터/플레이어 GUI를 시작하고 모드 전환을 관리한다."""
    from PyQt6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    app.setApplicationName("GameMacroStudio")
    ctx._quit_func = app.setQuitOnLastWindowClosed

    shared_state: dict[str, object] = {
        "macro": None,
        "macro_path": None,
        "is_modified": False,
    }

    from editor.session import EditorSession
    from player.session import PlayerSession

    current_session: list[Any] = [None]

    def switch_to_player() -> None:
        session = PlayerSession(ctx)
        current_session[0] = session
        session.launch(shared_state, switch_to_editor)

    def switch_to_editor() -> None:
        session = EditorSession(ctx)
        current_session[0] = session
        session.launch(shared_state, switch_to_player)

    switch_to_editor()

    monitor_stop = _start_connection_monitor(ctx)
    exit_code = app.exec()
    monitor_stop.set()
    return exit_code


# ---------------------------------------------------------------------------
# CLI 파서
# ---------------------------------------------------------------------------


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="GameMacroStudio - Arduino HID 매크로 제작/실행",
    )
    parser.add_argument(
        "--run",
        metavar="MACRO_JSON",
        help="GUI 없이 매크로를 1회 실행한다",
    )
    parser.add_argument(
        "--port",
        metavar="COM_PORT",
        help="시리얼 포트를 지정한다 (미지정 시 자동 탐지)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Arduino 없이 실행 (StubDevice 모드)",
    )
    parser.add_argument(
        "--list-ports",
        action="store_true",
        help="사용 가능한 시리얼 포트를 나열한다",
    )
    return parser.parse_args()


# ---------------------------------------------------------------------------
# 메인
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    args = _parse_args()

    # --list-ports: 포트 목록 출력
    if args.list_ports:
        from engine.serial_cmd import list_available_ports

        ports = list_available_ports()
        if not ports:
            print("사용 가능한 시리얼 포트가 없습니다.")
        for p in ports:
            vid = f"{p['vid']:04X}" if p["vid"] else "----"
            pid = f"{p['pid']:04X}" if p["pid"] else "----"
            print(f"  {p['device']:10s}  {vid}:{pid}  {p['description']}")
        return

    # --run: 헤드리스 실행
    if args.run:
        from engine.headless_run import run_macro_blocking_headless

        exit_code = run_macro_blocking_headless(
            args.run,
            port=args.port,
            dry_run=args.dry_run,
            log=logger,
        )
        sys.exit(exit_code)

    # GUI 모드
    from engine.screen import ScreenAnalyzer
    from engine.serial_cmd import SerialCommander
    from shared.config import load_config

    app_config = load_config()
    raw_last = app_config.get("last_port")
    last_port = raw_last if isinstance(raw_last, str) and raw_last.strip() else None
    port = args.port or last_port

    serial_commander = SerialCommander(port=port)
    screen_analyzer: ScreenAnalyzer | None = None
    try:
        screen_analyzer = ScreenAnalyzer()
    except Exception as exc:
        logger.warning("화면 분석기 초기화 실패 (매크로 실행은 가능): %s", exc)

    # 시작 시 연결 시도는 GUI 로드 후 EditorSession.launch()에서 백그라운드로 수행

    ctx = AppContext(
        app_config=app_config,
        serial_commander=serial_commander,
        screen_analyzer=screen_analyzer,
        dry_run=args.dry_run,
    )

    exit_code = _run_gui(ctx)

    # 정리
    if serial_commander.is_connected():
        serial_commander.disconnect()
    if screen_analyzer is not None:
        screen_analyzer.close()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
