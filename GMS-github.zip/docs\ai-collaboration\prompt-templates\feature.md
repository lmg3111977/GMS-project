# Feature Template

## 입력 슬롯
- 기능 목표:
- 사용자 시나리오:
- 변경 파일 후보(`shared/`, `engine/`, `editor/`, `player/`, `tests/`):
- 제외 범위:

## 요청 문안
- Claude: 코드 직접 수정 금지, 수정 대상(파일/함수/클래스/변경점) 명세 + Cursor용 프롬프트 생성
- Cursor: 명세 범위 내 코드만 수정(범위 외 변경 금지)
- 성능 저하 변경(캐시 제거, 반복 증가, 비동기→동기 회귀, 불필요 I/O) 금지

## 빠른 검증 (기본)
- 변경 파일 중심 린트 + 관련 테스트 우선 실행

## 전체 검증 (조건부: 머지 전/릴리즈 전/핵심 로직 변경)
```bash
ruff check shared engine editor player tests
black --check shared engine editor player tests
pytest -q tests
```

## 성능 검증 / 완료
- 전체 검증 조건일 때만 핵심 경로 전/후 3회 평균 비교, 악화율 `(after - before) / before * 100` 1.0% 초과 시 실패
- 실패 시 원인 1줄 요약 후 수정 프롬프트 재생성, 최대 2회 재시도
- 출력 형식: 1) 상황 한 줄 2) 수정 대상 3) Cursor용 프롬프트
