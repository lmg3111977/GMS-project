# Onboarding

1. [`../../QUICKSTART.md`](../../QUICKSTART.md) — 단일 진입점
2. [`first-macro.md`](first-macro.md) — 첫 매크로 (JSON·버전)
3. [`editor-walkthrough.md`](editor-walkthrough.md) — 에디터 단계별
4. [`../user/action-reference.md`](../user/action-reference.md) — 액션 타입 표
5. [`../user/shortcut-guide.md`](../user/shortcut-guide.md) — 단축키 전체
6. [`../troubleshooting.md`](../troubleshooting.md) — 문제 해결
