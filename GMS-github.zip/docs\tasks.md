# Tasks (v2)

## 완료 (기준)

- [x] `src/` 런타임 + Macro v2 로더 + Stub 실행 경로
- [x] `src/editor` MVP (열기·실행)
- [x] `tests_v2` + CI 게이트

## 진행 권장

- [ ] 시리얼 `DevicePort` 실제 구현 + mock 테스트
- [ ] `ScreenPort` 연동 및 조건 액션(픽셀/이미지) 설계
- [ ] 에디터: 액션 추가/편집 UI 확장
- [ ] 문서·샘플 동기화 자동화(선택)

## 완료 정의

`docs/constitution.md` 품질 게이트 통과 + 관련 `tests_v2` 갱신
