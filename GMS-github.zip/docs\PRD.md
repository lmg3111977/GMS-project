# PRD (Macro v1.0 제품 방향)

## 비전

PC에서 매크로를 정의하고(에디터), 실행 엔진이 순차/조건 로직을 수행한다.  
**현재 구현**은 Macro v1.0 기준의 `shared/`, `engine/`, `editor/`, `player/`, `tests/` 아키텍처이다.

## 대상 사용자

- 반복 입력을 줄이고 싶은 사용자
- JSON·GUI로 매크로를 다루고 싶은 초보자

## 원칙

| 원칙 | v1.0에서의 의미 |
|------|----------------|
| 안전 | Stub 기본, 실제 장치는 어댑터·정책 명확화 후 |
| 명확한 계약 | `shared/models` + 스키마 |
| 테스트 가능 | 모듈 분리와 `tests/` 기반 검증 |

## 요구사항 (상태)

| 영역 | 목표 | 비고 |
|------|------|------|
| 매크로 정의 | JSON 기반 매크로 | `shared/models/` |
| 실행 | 러너/스케줄러 기반 실행 | `engine/runner.py`, `engine/scheduler/` |
| 편집 | GUI 편집기 | `editor/main_window/`, `editor/param_panel/` |
| 플레이어 | 트레이 실행 | `player/` |
| 검증 | 자동화 테스트 | `tests/` |

## 상세 설계

[`tech-spec.md`](tech-spec.md)
