# Project Skills (v2)

반복 작업용 체크리스트입니다. **프롬프트 템플릿**은 [`docs/ai-collaboration/`](../docs/ai-collaboration/README.md)가 공식입니다.

## 스킬

- [`add-action-skill.md`](add-action-skill.md)
- [`schema-migration-skill.md`](schema-migration-skill.md)
- [`serial-debug-skill.md`](serial-debug-skill.md)

## 공통

- `AGENTS.md`, `docs/constitution.md`, `.cursor/rules/*`
- 코드: `src/`, 테스트: `tests_v2/`
- 온보딩: [`QUICKSTART.md`](../QUICKSTART.md)
