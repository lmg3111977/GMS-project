# Test Template

## 입력 슬롯
- 대상 기능:
- 실패 시나리오:
- Mock 필요 여부:
- 대상 경로(`tests/`):

## 요청 문안
- Claude: 코드 직접 수정 금지, 테스트 추가 위치/케이스 명세 + Cursor용 프롬프트 생성
- Cursor: 명세대로 테스트 코드만 수정
- 하드웨어 의존 없이 재현/검증 가능한 테스트 우선

## 빠른 검증 (기본)
- 변경된 테스트 파일과 관련 테스트만 우선 실행

## 전체 검증 (조건부: 머지 전/릴리즈 전/핵심 로직 변경)
```bash
ruff check shared engine editor player tests
black --check shared engine editor player tests
pytest -q tests
```

## 성능 검증 / 완료
- 전체 검증 조건일 때만 테스트 실행시간 급증 여부를 전/후 3회 평균으로 확인(악화율 1.0% 초과 시 실패)
- 실패 시 원인 1줄 요약 후 수정 프롬프트 재생성, 최대 2회 재시도
- 출력 형식: 1) 상황 한 줄 2) 수정 대상 3) Cursor용 프롬프트
