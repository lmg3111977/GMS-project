# AGENTS.md

AI 에이전트 규칙 포인터. 최상위 규범: [`docs/constitution.md`](docs/constitution.md)

## 우선순위

1. **안전성** — dry_run 기본, 긴급 정지·재연결
2. **정확성** — 스키마·로더·스케줄러 일치
3. **유지보수성** — 300줄 이하, 패키지 분리, mixin
4. **사용자 경험** — 온보딩·오류 메시지

## 상세 규칙 위치

| 영역 | 파일 |
|------|------|
| 아키텍처·분리·액션 체크리스트 | `.cursor/rules/architecture.mdc` |
| 실행·시리얼·금지 패턴 | `.cursor/rules/safety.mdc` |
| 검증·테스트·코드 품질·커밋 | `.cursor/rules/quality-gates.mdc` |
| 문서 동기화 | `.cursor/rules/docs-sync.mdc` |
| 역할 분리·작업 흐름·소통 | `CLAUDE.md` (전역 + 프로젝트) |
