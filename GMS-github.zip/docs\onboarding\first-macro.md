# 첫 매크로 만들기

## 전제

- [`QUICKSTART.md`](../../QUICKSTART.md) 의 설치·실행까지 완료
- 포맷: **`version`: `"1.0"`** — [`shared/schema.py`](../../shared/schema.py) 의 `CURRENT_SCHEMA_VERSION` 과 일치

## 샘플 복사

[`macros/examples/example_click_loop.json`](../../macros/examples/example_click_loop.json) 을 복사해 이름만 바꿉니다.

필수 필드:

- `version`: `"1.0"`
- `name`: 문자열
- `actions`: 배열 (비어 있지 않음)

지원 액션 타입은 [`docs/user/action-reference.md`](../user/action-reference.md) 와 `shared/models/enums.py` 의 `ActionType` 을 참고하세요.

## 실행

```bash
python main.py --run path/to/your.json
```

## GUI에서 편집

1. `python main.py`
2. 파일 → 열기로 JSON 선택 (`macros/` 권장)
3. 좌측에서 액션 추가 (카테고리 버튼)
4. Ctrl+F5 로 실행 (실행 전 요약·리허설 옵션 확인)
5. 필요 시 Ctrl+F6(일시정지/재개), Ctrl+F7(정지), F8(좌표/색상 캡처) 사용

## 다음

- 에디터 단계별 안내: [`editor-walkthrough.md`](editor-walkthrough.md)
- 단축키 전체: [`../user/shortcut-guide.md`](../user/shortcut-guide.md)
- 문제 해결: [`../troubleshooting.md`](../troubleshooting.md)
