from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from typing import Any

from engine.scheduler import ActionScheduler, SchedulerError
from engine.screen import ScreenAnalyzer
from engine.serial_cmd import SerialCommander
from engine.variables import VariableStore
from shared.humanizer import sync_human_delay
from shared.models import Macro

from .events import EventEmitterMixin
from .reconnect import ReconnectMixin
from .state import RunnerState

logger = logging.getLogger(__name__)


class MacroRunner(EventEmitterMixin, ReconnectMixin):
    def __init__(
        self,
        serial_commander: SerialCommander | None = None,
        screen_analyzer: ScreenAnalyzer | None = None,
        *,
        enable_visual_debug: bool = True,
    ) -> None:
        self._serial = serial_commander
        self._screen = screen_analyzer
        self._variables = VariableStore()
        self._stop_event = threading.Event()
        self._link_lost_event = threading.Event()
        self._arduino_reconnect_busy = threading.Event()
        if self._serial is not None:
            self._serial.set_link_lost_event(self._link_lost_event)
        self._scheduler = ActionScheduler(
            serial_commander=self._serial,
            screen_analyzer=self._screen,
            variable_store=self._variables,
            stop_event=self._stop_event,
            link_lost_event=self._link_lost_event if self._serial else None,
            visual_debug_callback=(self._dispatch_visual_debug if enable_visual_debug else None),
        )
        self._state: RunnerState = RunnerState.IDLE
        self._macro: Macro | None = None
        self._debug_breakpoints: set[int] = set()
        self._step_requested: bool = False
        self._lock = threading.Lock()
        self._pause_event = threading.Event()
        self.on_state_changed: list[Callable[..., Any]] = []
        self.on_action_executed: list[Callable[..., Any]] = []
        self.on_variables_changed: list[Callable[..., Any]] = []
        self.on_error: list[Callable[..., Any]] = []
        self.on_log: list[Callable[..., Any]] = []
        self.on_finished: list[Callable[..., Any]] = []
        self.on_connection_lost: list[Callable[..., Any]] = []
        self.on_reconnected: list[Callable[..., Any]] = []
        self.on_visual_debug: list[Callable[[str, bytes | None, bytes | None, bool], Any]] = []
        self.reconnect_interval_sec: float = 5.0
        self._stats_start_time: float = 0.0
        self._stats_action_count: int = 0
        self._stats_error_count: int = 0

    @property
    def arduino_reconnect_in_progress(self) -> bool:
        return self._arduino_reconnect_busy.is_set()

    @property
    def state(self) -> RunnerState:
        with self._lock:
            return self._state

    @property
    def macro(self) -> Macro | None:
        return self._macro

    @property
    def program_counter(self) -> int:
        return self._scheduler.program_counter

    @property
    def variables(self) -> VariableStore:
        return self._variables

    def set_serial_commander(self, serial_commander: SerialCommander | None) -> None:
        if self._serial is not None:
            self._serial.set_link_lost_event(None)
        self._serial = serial_commander
        if self._serial is not None:
            self._serial.set_link_lost_event(self._link_lost_event)
        self._scheduler.set_serial_commander(serial_commander)

    def set_breakpoints(self, breakpoints: set[int]) -> None:
        with self._lock:
            self._debug_breakpoints = set(breakpoints)

    def request_step(self) -> None:
        with self._lock:
            self._step_requested = True

    def load_macro(self, macro: Macro, *, source_path: str | None = None) -> None:
        if self._get_state() == RunnerState.RUNNING:
            raise RuntimeError("실행 중에는 매크로를 로드할 수 없습니다")
        self._macro = macro
        self._scheduler.load_actions(macro.actions, source_path=source_path)
        self._set_state(RunnerState.IDLE)
        self._emit_log("INFO", f"매크로 로드 완료: {macro.name} ({len(macro.actions)}개 액션)")

    def start_macro(self) -> None:
        if self._macro is None:
            raise RuntimeError("매크로가 로드되지 않았습니다")
        if self._get_state() == RunnerState.RUNNING:
            logger.warning("이미 실행 중입니다")
            return
        self._scheduler.reset()
        self._stop_event.clear()
        self._link_lost_event.clear()
        self._stats_start_time = time.monotonic()
        self._stats_action_count = 0
        self._stats_error_count = 0
        if self._serial is not None:
            try:
                self._serial.sync_mouse_position_from_os()
            except Exception as exc:  # pragma: no cover
                logger.warning("마우스 위치 동기화 실패: %s", exc)
        self._set_state(RunnerState.RUNNING)
        self._emit_log("INFO", "매크로 실행 시작")

    def pause_macro(self) -> None:
        if self._get_state() != RunnerState.RUNNING:
            return
        self._set_state(RunnerState.PAUSED)
        self._emit_log("INFO", "매크로 일시정지")

    def resume_macro(self) -> None:
        if self._get_state() != RunnerState.PAUSED:
            return
        self._set_state(RunnerState.RUNNING)
        self._emit_log("INFO", "매크로 재개")

    def stop_macro(self) -> None:
        if self._get_state() in (RunnerState.IDLE, RunnerState.STOPPED, RunnerState.COMPLETED):
            return
        self._stop_event.set()
        self._link_lost_event.clear()
        self._set_state(RunnerState.STOPPED)
        if self._serial is not None:
            try:
                self._serial.emergency_stop()
            except Exception as exc:
                logger.error("비상정지 전송 실패: %s", exc)
        self._emit_log("WARNING", "매크로 정지 + EMERGENCY_STOP")
        self._emit_stats_summary()

    def run_blocking(self) -> None:
        if self._get_state() not in (RunnerState.RUNNING, RunnerState.PAUSED):
            return
        while True:
            with self._lock:
                loop_state = self._state
            if loop_state not in (RunnerState.RUNNING, RunnerState.PAUSED):
                break
            if loop_state == RunnerState.PAUSED:
                if self._serial is not None and self._link_lost_event.is_set():
                    if not self._recover_arduino_link(
                        "Arduino 연결 끊김 (일시정지 중)", resume_running=False
                    ):
                        break
                    continue
                should_step = False
                with self._lock:
                    if self._step_requested:
                        self._step_requested = False
                        should_step = True
                if should_step:
                    with self._lock:
                        if self._state != RunnerState.PAUSED:
                            continue
                    self._run_single_step(force_pause_after=True, skip_breakpoint_check=True)
                    continue
                self._pause_event.wait(timeout=0.05)
                self._pause_event.clear()
                continue
            try:
                with self._lock:
                    if self._state != RunnerState.RUNNING:
                        continue
                    current_index = self._scheduler.program_counter
                    hit_breakpoint = current_index in self._debug_breakpoints
                if hit_breakpoint:
                    self._set_state(RunnerState.PAUSED)
                    self._emit_log("INFO", f"브레이크포인트 도달: 액션 #{current_index}")
                    continue
                if self._serial is not None and self._link_lost_event.is_set():
                    if not self._recover_arduino_link(
                        "Arduino 연결 끊김 (시리얼 연결 손실)", resume_running=True
                    ):
                        break
                    continue
                self._run_single_step(force_pause_after=False, skip_breakpoint_check=False)
            except SchedulerError as exc:
                error_msg = str(exc)
                self._stats_error_count += 1
                is_disconnect = "연결 끊김" in error_msg or "연결 실패" in error_msg
                if is_disconnect:
                    if not self._recover_arduino_link(error_msg, resume_running=True):
                        break
                    continue
                self._emit_log("ERROR", f"스케줄러 에러: {exc}")
                self._emit_error(error_msg)
                self.stop_macro()
                break
            except Exception as exc:
                self._emit_log("ERROR", f"예상치 못한 에러: {exc}")
                self._emit_error(str(exc))
                self.stop_macro()
                break
        for callback in list(self.on_finished):
            try:
                callback()
            except Exception as exc:
                logger.debug("on_finished 콜백 에러: %s", exc)

    def _run_single_step(self, force_pause_after: bool, skip_breakpoint_check: bool) -> None:
        _ = skip_breakpoint_check
        current_index = self._scheduler.program_counter
        has_more = self._scheduler.execute_next()
        self._stats_action_count += 1
        self._emit_action_executed(current_index)
        if self.on_variables_changed:
            snap = self._variables.get_all_if_changed()
            if snap is not None:
                self._emit_variables_changed(snap)
        if (
            not force_pause_after
            and self._macro is not None
            and self._macro.settings.humanize
            and self._macro.settings.base_delay_ms > 0
        ):
            sync_human_delay(
                self._macro.settings.base_delay_ms,
                randomize=True,
                allow_micro_afk=self._macro.settings.micro_afk_enabled,
                micro_afk_chance_percent=self._macro.settings.micro_afk_chance_percent,
                micro_afk_min_ms=self._macro.settings.micro_afk_min_ms,
                micro_afk_max_ms=self._macro.settings.micro_afk_max_ms,
                stop_event=self._stop_event,
                link_lost_event=self._link_lost_event if self._serial else None,
            )
        if not has_more:
            self._emit_stats_summary()
            self._emit_log("INFO", "매크로 실행이 정상적으로 완료되어 종료되었습니다.")
            self._set_state(RunnerState.COMPLETED)
            return
        if force_pause_after and self._get_state() == RunnerState.PAUSED:
            return

    def _set_state(self, new_state: RunnerState) -> None:
        with self._lock:
            old_state = self._state
            self._state = new_state
        logger.info("상태 변경: %s → %s", old_state, new_state)
        for callback in self.on_state_changed:
            try:
                callback(new_state)
            except Exception as exc:
                logger.debug("on_state_changed 콜백 에러: %s", exc)

    def _get_state(self) -> RunnerState:
        with self._lock:
            return self._state
