# Tech Stack (v1.0)

## 런타임

- Python 3.11+
- pydantic
- PyQt6
- pyserial
- opencv-python-headless
- pytesseract
- mss
- pynput

## 품질

- pytest, ruff, black, mypy

## 디렉터리 (권위)

| 경로 | 역할 |
|------|------|
| `shared/models/` | 데이터 모델 |
| `engine/runner.py`, `engine/scheduler/` | 실행 엔진 및 스케줄러 |
| `editor/main_window/`, `editor/param_panel/` | 에디터 UI |
| `player/` | 트레이 플레이어 |
| `tests/` | 테스트 |

## 의존성

`requirements.txt`, `[project]` / `[tool.*]` in `pyproject.toml`를 따른다.
