# Safety Policy (v2)

- 개발 기본: Stub 어댑터로 실제 입력 최소화
- 프로덕션 시리얼/HID: 긴급 정지·재연결 정책 유지
- 무한 루프성 매크로는 스키마·인터프리터에서 명시적으로만 허용

상세: [`../constitution.md`](../constitution.md) 섹션 9
